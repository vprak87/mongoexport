const Utils = require('../../common/utils');

class Hoteldata {

  constructor(options) {

    const defaults = {
      CountryList: [],
      PMSList: [],
      AccountingToolList: [],
      TimeZoneList: {
        cst: [],
        est: [],
        pst: [],
        hst: [],
        ast: [],
        nst: []
      },
      CurrencyList:{
        na: [],
        cad: [],
        usd: []
      }
    }
  
    let opts = Object.assign({}, defaults, options);

    // assign options to instance data (using only property names contained
    //  in defaults object to avoid copying properties we don't want)
    Object.keys(defaults).forEach(prop => {
        this[prop] = opts[prop];
    });
  }

  setFormat(data) {
    TimeZoneList.cst.push({
      value: "Central Standard Time",
      text: "Central Time (US & Canada)"
    });
    TimeZoneList.est.push({
      value: "Mountain Standard Time",
      text:"Mountain Time (US & Canada)"
    });
    TimeZoneList.pst.push({
      value: "Pacific Standard Time",
      text: "Pacific Time (US & Canada)"
    });
    TimeZoneList.hst.push({
      value: "Hawaiian Standard Time",
      text: "Hawaii-Aleutian Time (US & Canada)"
    });
    TimeZoneList.ast.push({
      value: "Atlantic Standard Time",
      text: "Atlantic Time (US & Canada)"
    });
    TimeZoneList.nst.push({
      value: "Newfoundland Standard Time",
      text: "Newfoundland Time (US & Canada)"
    });

    CurrencyList.na.push({
      value: "NA",
      text: "No Selection"
    });

    CurrencyList.na.push({
      value: "CAD",
      text: "CAD $"
    });

    CurrencyList.na.push({
      value: "USD",
      text: "USD $"
    });

    return this;
  }
}

module.exports = Hoteldata;