const _ = require('lodash');
const crypto = require('crypto');
const numeral = require('numeral');
const moment = require('moment');
const momenttz = require('moment-timezone');
const algorithm = 'sha1';
const _MS_PER_DAY = 1000 * 60 * 60 * 24;

module.exports = {
    convertLocalTimeCST: (date) => {
        let m = moment.utc(date);
        return m.tz('America/Chicago').toISOString();
    },
    isInValidValue: (value) => {
        return !value || (_.isEmpty(value) && value.length == 0)
    },
    getKeysValues: (array, key) => {
        return _.map(array, key)
    },
    encode: (text) => {
        var hash = crypto.createHash(algorithm).update(text).digest('hex');
        return hash;
    },
    compare: (value1, value2) => {
        return value1 == value2 ? true : false;
    },
    average: (totalvalue, totalcount) => {
        if (totalcount == 0) return 0;
        if (totalvalue == 0) return 0;
        return totalvalue / totalcount;
    },
    formatValue: (value, formatstring) => {
        return numeral(value).format(formatstring);
    },
    dateDiffInDays: (startdate, enddate) => {
        const utc1 = Date.UTC(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        const utc2 = Date.UTC(enddate.getFullYear(), enddate.getMonth(), enddate.getDate());
        return Math.floor((utc2 - utc1) / _MS_PER_DAY) + 1;
    },
    firstDayOfMonth: (currentdate) => {
        let today = moment(currentdate).startOf('month');
        return today.toDate();
    },
    lastDayOfMonth: (currentdate) => {
        let today = moment(currentdate).endOf('month');
        return today.toDate();
    },
    firstDayOfYear: (currentdate) => {
        let today = moment(currentdate).startOf('year');
        return today.toDate();
    },
    lastDayOfYear: (currentdate) => {
        let today = moment(currentdate).endOf('year');
        return today.toDate();
    },
    firstSundayOfMonth: (currentdate) => {
        let today = moment(currentdate).startOf('month').endOf('isoweek').startOf("day");
        return today.toDate();
    },
    getMonthByName: (monthname) => {
        let today = moment().month(monthname).format("M");
        return today;
    },
    getMonthNumber: (currentdate) => {
        return moment(currentdate).format("M");
    },
    getWeekNumber: (currentdate) => {
        var weeknumber = moment(currentdate, "MMDDYYYY").isoWeek();
        return weeknumber;
    },
    getFormattedDate: (currentdate, format) => {
        return moment(currentdate).format(format);
    },
    lastYearDate: (currentdate) => {
        let lastYear = moment(currentdate).subtract(1, 'year');
        return lastYear.toDate();
    },
    lastMonthDate: () => {
        let lastMonth = moment(currentdate).subtract(1, 'month');
        return lastMonth.toDate();
    },
    sameDayLastYear: (currentdate) => {
        let today = moment(currentdate);
        let lastYear = moment(currentdate).subtract(1, 'year')
            .isoWeek(today.isoWeek())
            .isoWeekday(today.isoWeekday());
        return lastYear.toDate();
    },

    isFriOrSat: (currentdate) => {
        if (!currentdate == "Friday" && !currentdate == "Saturday") {
            return false;
        } else {
            return true;
        }
    },

    isNullOrEmpty: (value) => {
        if (!value || value == null || value == '') {
            return true;
        } else {
            return false;
        }
    },

    addDays: (currentdate, noOfdays) => {
        let addedDate = moment(currentdate).add((noOfdays), 'days').format("YYYY-MM-DD");
        return addedDate;
    },

    daysInMonth: (date) => {
        date = new Date(date);
        let daysformat = moment(date).format("YYYY-MM");
        let days = moment(daysformat, "YYYY-MM").daysInMonth();
        return days;
    },


    getFirstDayOfWeek: (currentdate, year, week) => {
        return moment(currentdate).day("Sunday").year(year).week(week).startOf("day").toDate();
    },
    addMonths: (currentdata, addingNo) => {
        return moment(currentdata).add(addingNo, 'months').toDate();
    },
    addYears: (currentdata, addingNo) => {
        return moment(currentdata).add(addingNo, 'years').toDate();
    },
    addDate: (currentdata, addingNo) => {
        return moment(currentdata).add(addingNo, 'days').toDate();
    },
    GetTTMDates: (currentDate) => {

        let enddate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1, 23, 59, 59);


        enddate = new Date(moment(enddate).subtract(1, 'month'));

        enddate = new Date(enddate.getFullYear(), enddate.getMonth(), (32 - new Date(enddate.getFullYear(), enddate.getMonth(), 32).getDate()), 23, 59, 59);



        let startdate = new Date(moment(enddate).subtract(11, 'month'));
        startdate = new Date(startdate.getFullYear(), startdate.getMonth(), 1, 0, 0, 0)
        return [startdate, enddate];

    },
    sort: (values, field) => {
        return _.sortBy(values, [field]);
    },
    split: (string, delimiter) => {
        string = string.split(delimiter);
        var stringArray = new Array();
        for (var i = 0; i < string.length; i++) {
            stringArray.push(string[i]);
            // if (i != string.length - 1) {
            //     stringArray.push(delimiter);
            // }
        }
        return stringArray;
    },
    getDateNumofWeek: (currentdate) => {
        return moment(currentdate).isoWeekday()
    },
    getDaysinMonth: (year, month) => {
        return moment([year, month]).daysInMonth()
    },
    evenRound: (num, decimalPlaces) => {
        num = num==null?0:num;
        var d = decimalPlaces || 0;
        var m = Math.pow(10, d);
        var n = +(d ? num * m : num).toFixed(8); // Avoid rounding errors
        var i = Math.floor(n), f = n - i;
        var e = 1e-8; // Allow for rounding errors in f
        var r = (f > 0.5 - e && f < 0.5 + e) ?
            ((i % 2 == 0) ? i : i + 1) : Math.round(n);
        return d ? r / m : r;
    },
    startofDay: (date) => {
        let startofDay = moment(date).startOf('day');
        return startofDay.toDate();
    },
    endofDay: (date) => {
        let endofDay = moment(date).endOf('day');
        return endofDay.toDate();
    },
    startofMonth: (date) => {
        return new Date(moment(date).format('YYYY-MM-01'));
    },
    startofYear: (date) => {
        return new Date(moment(date).format('YYYY-01-01'));
    },
    getNoficationType: (value) => {

        if (value > 0 && value <= 30) {
            return "error";
        }
        else if (value > 30 && value <= 60) {
            return "";
        }
        else {
            return "success";
        }
    },
    getNoficationTypeOOO: (value) => {

        if (value > 0 && value <= 10) {
            return "";
        }
        else if (value > 10 && value <= 60) {
            return "";
        }
        else {
            return "error";
        }
    },
    sum: (listarray, field) => {
        var value_sum = 0;
        if (listarray == null || listarray.length <= 0) return value_sum;
        listarray.forEach(function (obj) {
            value_sum += obj[field];
        });
        return value_sum;
    },
    avg: (listarray, field) => {
        var value_sum = 0;
        if (listarray == null || listarray.length <= 0) return value_sum;
        listarray.forEach(function (obj) {
            value_sum += obj[field];
        });
        return value_sum / listarray.length;
    },
}