let HttpMessages = {
    InvalidToken: "Invalid Token",
    TokenFailed: "Failed To Authenticate Token.",
    UserTokenFailed: "Failed To Authenticate User.",
    HotelNotFound: "Hotel NOT found.",
    UserNOTLoggedIn: "User is not Logged In",
    internalErrorMsg: "Somthing goes wrong, Try after somtime",
    paramsMissingMsg: 'Request paramas missing',
    authUserNotFound: 'Authentication failed. User not found',
    invalidAccountDetail: 'Invalid account detail',
    authFailed: 'Authentication failed. Wrong Password',
    invalidEmail: 'Invalid email address',
    passwordCodeMessage: "Verificatin code send on mobile",
    passwordCodeVerificationSuccess: "Code verification success",
    forgotPasswordCodeNotVerified: "Verificatin code not verified",
    passwordChangeSuccessFully: "Password change successfully",
    passwordChangeError: "Password not matched",
    emailSent: "Code Sent on your register email",
    actionSuccessfully: 'Recored updated successfully',
    listingFounded: 'Listing founded',
    biilAddressNotFounded: 'BillingAddressId not founded',
    requestNotFound: 'Request value not founded',
    recordedNotfound: "Record Not found",
    recordedAdded: "Record Added Successfully",
    recoredFound: "Record Founded",
    recoredDeleted: "Record Deleted",
    recoredUpdateed: "Record Updated Successfully",
    usernameAlreadyExist: "This username already exists",
    mobileAlreadyExist: "This mobile already exists",
    kpiAlreadyExist: "This kpi already exists",
    usernameAvailable: "This username available",
    loginAvailable: "Mobile login available",
    mobileVerified: "Mobile login verified",
    DefaultValues:
    {
        ScorecardSTRCurrentMonthPer: 3,
        ScorecardTotalRevenuePer: 95,
        ScorecardGOPBudgetPer: 95,
        ScorecardLabourPORVariance: 0.3,
        ScorecardServiceWeightedPer: 4,
        ScorecardServiceScore: 4,
        CloseLoss: 0,
        AlertOccMin: 0,
        AlertOccMax: 0,
        AlertOccMTDMin: 0,
        AlertOccMTDMax: 0,
        AlertADRMin: 0,
        AlertADRMTDMin: 0,
        AlertADRMTDMax: 0,
        AlertRevParMin: 0,
        AlertRevParMax: 0,
        AlertRevParMTDMin: 0,
        AlertOOOMin: 0,
        AlertOOOMax: 0,
        AlertOOOMTDMin: 0,
        AlertOOOMTDMax: 0,
    },
    NumeralFormats:
    {
        Comma2DecimalNegativeBrackets: '(0,0.00)',
        Comma0DecimalNegativeBrackets: '(0,0)',
        NoComma2DecimalNegativeBrackets: '(0.00)',
        NoComma2Decimal: '0.00',
        NoDecimal: '0',
        NoComma0Decimal: '0,0',
        Comma2Decimal: '0,0.00',
        Comma1Decimal: '0,0.0',

    },
    Colors:
    {
        Green: "green",
        Orange: "orange",
        Red: "red",

    },
    Currency:
    {
        Dollar: "$",
    },
    Suffix:
    {
        Percentage: "%",
    },
    RevenueCategory:
    {
        Profit: "Profit"
    },
    RevenueDescription:
    {
        GOP: "GOP",
        GOPPlan: "GOP_Plan",
        NOI: "NOI",
        NOIPlan: "NOI_Plan"
    },
    PickupReport:
    {
        NA: -9999
    },
    StarComparison:
    {
        LastYear: "lastyear",
        Last28Days: "last28days",
        Budget: "budget",
    },
    NoDataValue: { NODATA: "NO DATA" ,ZERODATA:"0"},
    StarType:
    {
        Week: "week",
        Month: "month"
    },
    RevenueType: {
        RoomRevenue: "RoomRevenue",
        FANDBRevenue: "FANDBRevenue",
        OtherRevenue: "OtherRevenue",
        MiscellaneousRevenue: "MiscellaneousRevenue",
        ForcastRoomRevenue: "ForcastRoomRevenue",
        Debit: "Debit",
        Credit: "Credit",
        TaxExemptRevenue: "TaxExemptRevenue",
        Cash: "Cash",
        Tax: "Tax",
        OutOfOrder: "OutOfOrder",
        RoomsWithComp: "RoomsWithComp",
        OOORooms: "OOORooms",
        NonRevenue: "NonRevenue",
        Expense: "Expense",
        LaborExpense: "LaborExpense",
        ExtendedStay: "ExtendedStay",
        Profit: "Profit",
        ARAging: "ARAging",
        TrailBalance: "TrailBalance",
        RoomWithGuest: "RoomWithGuest"
    },
    DashboardTableName:
    {
        Portfolio: 'Consolidated Report',
        Property: 'Daily Manager Report',
        PropertyColumnName: 'Property Table Column Name',
        PropertyColumnPeriod: 'Property Table Column Period',
        PropertyRowName: 'Property Table Row Name',
        PNLTableRowName:'PNL Table Row Name',
        PNLTableColumnPeriod:'PNL Table Column Period',
        PNLTableColumnName:'PNL Table Column Name',
    },
    PNLType:
    {
        PNLMonthly:'PNLMonthly',
        PNLYearly:'PNLYearly',
    },
    Units:
    {
        Percentage: '%',
        Currency: '$',
        Number: '#',
        DecimalNumber: '#.#',
        Text: ''
    },
    VarianceLevel:
    {
        Down: 'down',
        Up: 'up',
        Nochange: 'nochange',

    },
    LaborStatus:
    {
        Win: 'Win',
        Loss: 'Loss',
        CloseLoss: 'CloseLoss'

    },
    Urls:
    {
        InsertCustomKPI: '/CustomKPI/Add',
        UpdateCustomKPI: '/CustomKPI/Update',
        DeleteCustomKPI: '/CustomKPI/Delete',
        AddKPIColumns: '/KPI/Add',
        GetKPIColumn: '/KPI/FetchKPIData',
        UpdateKPIColumn: 'KPI/Update',
        ReorderKPIColumns: 'KPI/Reorder',
        UpdateScorecardConfig: '/Config/UpdateScorecard',
        UpdateLaborConfig: '/Config/UpdateLabor',
        UpdatePropertyConfig: '/Config/UpdateProperty',
        UpdateSinglePropertyConfig: '/Config/UpdateSingleProperty',
        GetToken: '/MYP2/GetToken',
        OtaHotelRate: 'https://api.otainsight.com',
        OtaHotelDemands: 'https://api.otainsight.com',
        FacebookPage: 'https://www.facebook.com',
        CurrencyExchange: 'http://rate-exchange-1.appspot.com'
    },
    MembershipLevel:
    {
        Member: 'Member',
        Gold: 'Gold',
        Club: 'Club',
        Platinum: 'Platinum',
        Spire: 'Spire',
        Blue: 'Blue',
        Silver: 'Silver',
        Diamond: 'Diamond',
        Discoverist: 'Discoverist',
        Explorist: 'Explorist',
        Globalist: 'Globalist',
        Ambassador: 'Ambassador',
        Titanium: 'Titanium'
    },
    MissingDates:
    {
        RoomRevenue: "Room Revenue",
        OtherRevenue: "Other/F&B Revenue"
    },
    PageNames:
    {
        _306090Report: '306090Report',
        MedalliaReport: 'MedalliaReport',
        GSSMonthlyReport: 'GSSMonthlyReport',
        GSSRollUpReport: 'GSSRollUpReport',
        RevinatePopularity: 'RevinatePopularity',
        RevinateRatingComparisons: 'RevinateRatingComparisons',
        RevinateSentimentAnalysis: 'RevinateSentimentAnalysis',
        ReviewPro: 'ReviewPro',
        TrustYouSurveyComparison: 'TrustYouSurveyComparison',
        TrustYouSurveyReviews: 'TrustYouSurveyReviews',
        TrustYouSurveyStatistics: 'TrustYouSurveyStatistics',
        ContactSupport: 'ContactSupport',
        VRUReport: 'VRUReport',
        Configuration: 'Configuration',
        TrialBalanceBreakDown: 'TrialBalanceBreakDown',
        RevenueBreakdown: 'RevenueBreakdown',
        PortfolioDashboard: 'PortfolioDashboard',
        ReplyToComment: 'ReplyToComment',
        Labor: 'Labor',
        STRRollUp: 'STRRollUp',
        PLStatementMonthly: 'PLStatementMonthly',
        PLStatementYearly: 'PLStatementYearly',
        STRWeekly: 'STRWeekly',
        PickupSummaryReport:'PickupSummaryReport',
        MonthlyPickup:'MonthlyPickup',
        StarReportsDefault:'StarReportsDefault',
        PickupReport:'PickupReport',
        CashDetail:'CashDetail',
        ARAging:'ARAging'
    },
    ScorecardServiceItems:
    {
        BrandAverage: "Brand Average",
        HotelGSSRate: "Hotel GSS Rate",
        Variance: "Variance",
        PercentageToBrand: "Percentage To Brand",
        CHIHotelRanking: "CHI Hotel Ranking",
    },
    PropertyPageCharts:
    {
        RollingRevenueComparision: "rollingrevenuecomparision",
        RevenueBreakdowan: "revenuebreakdowan",
        ActVsBudVsLastYr: "actvsbudvslastyr",
        ADRVsRevPAR: "adrvsrevpar",
        DashboardOcc: "dashboardocc",
        DashboardADR: "dashboardadr",
        DashboardRevPAR: "dashboardrevpar",
        MembershipStays: "membershipstays",
        DashboardMarketCurrentVsLastYear: "dashboardmarketcurrentvslastyear",
        CashWidget: "cashwidget",
        GuestLedgerWidget: "guestledgerwidget",
        PayrollActualvsPlanWidget: "payrollactualvsplanwidget",
        STRWidget: "strwidget",
        TripadvisorRatingWidget: "tripadvisorratingwidget",
        GooglePlaceRatingWidget: "googleplaceratingwidget",
        FacebookPageWidget: "facebookpagewidget",
        YelpReviewWidget: "yelpreviewwidget",
        WeatherWidget: "weatherwidget",
        ARAgingWidget: "aragingwidget",
        GSSPriority: "gsspriority",
        OOOCompWidget: "ooocompwidget",
        TotalProfit: "totalprofit",
        TotalExpenseBreakdown: "totalexpensebreakdown",
        ExpenseBudgetDepartment: "expensebudgetdepartment",
        ExpenseBudgetCategory: "expensebudgetcategory",
        InvoicevsCreditcard: "invoicevscreditcard",
        ExpenseFormByGLCode: "expenseformbyglcode",

    }
}

module.exports = HttpMessages