const { Hotels: HotelsSchema, SchemaField: HotelsSchemaFields } = require('../models/hotels');
const { Hotelgroup: HotelgroupSchema, SchemaField: HotelgroupSchemaFields } = require('../models/hotelgroup');
const { Sorthotelbygroup: SorthotelbygroupSchema, SchemaField: SorthotelbygroupSchemaFields } = require('../models/sorthotelbygroup');

const { User: UserSchema, SchemaField: UserSchemaFields } = require('../models/user');
const HotelGroupXrefHelper = require('./hotelgroupxref_helper');
const { Userhotelxref: UserhotelxrefSchema, SchemaField: UserhotelxrefSchemaFields } = require('../models/userhotelxref');
const { Userhotelgroupxref: UserhotelgroupxrefSchema, SchemaField: UserhotelgroupxrefSchemaFields } = require('../models/userhotelgroupxref');
const { Hotelgroupxref: HotelgroupxrefSchema, SchemaField: HotelgroupxrefSchemaFields } = require('../models/hotelgroupxref');

const dbtable = require('../schema/db_table');

const UserHelper = require('../helpers/user_helper');

const UserHotelXrefHelper = require('../helpers/userhotelxref_helper');

const HotelData = require('../customeview/models/hoteldata');

var log = require('log4js').getLogger("hotels_helper");

const _ = require('lodash');
class HotelsHelper {

    static FilterForMYP(hotelId, UserId, cd) {
        let resultArray = [];
        let FilterForMYArray = [];
        HotelsSchema.find({ [HotelsSchemaFields.IsActive]: true }, [HotelsSchemaFields.ID]).exec((err, result) => {

            _.filter(result, function (data) {
                let finalResult = new Promise((resolve, reject) => {
                    UserhotelxrefSchema.find(
                        {
                            $and: [
                                { [UserhotelxrefSchemaFields.UserID]: UserId },
                                { [UserhotelxrefSchemaFields.HotelID]: data.ID },
                                { [UserhotelxrefSchemaFields.DisplayFor]: { $ne: 2 } }
                            ]
                        }
                    ).exec((err, result) => {
                        if (err) {
                            reject(err)
                        }
                        resultArray.push(result)
                        resolve()
                    })
                })
                FilterForMYArray.push(finalResult)


            })
            Promise.all(FilterForMYArray).then(resp => {
                let hotels = [];
                _.filter(resultArray, function (data) {
                    if (data[0] != undefined) {
                        hotels.push(data[0].HotelID)
                    }
                })
                cd(null, hotels);
            })

        })

    }

    static getHotelDataByCMPID(id, cb) {

        return HotelsSchema.findOne({ [HotelsSchemaFields.Cmp_Id]: id }, (err, hoteldata) => {
            if (err) {
                log.error(err);
            }
            if (!hoteldata) {

                //if Cmp_Id not found the check hotelid for data for failover testing 
                //Remove it once we have CMP API entry added to all hotels in MYP
                HotelsSchema.findOne({ [HotelsSchemaFields.ID]: id }, (err, hoteldata2) => {
                    if (err) {
                        log.error(err);
                    }
                    if (!hoteldata2) {
                        return cb('hoteldata not found', null);
                    }
                    cb(null, hoteldata2);
                });

            }
            else {
                cb(null, hoteldata);
            }
        });
    }

    static GetData(hotelid, cb) {

        log.debug('Call GetData, hotelid:' + hotelid);
        let hotelAggregate = HotelsSchema.aggregate();
        hotelAggregate.match({
            [HotelsSchemaFields.ID]: hotelid
        })

        //user org detail
        hotelAggregate.lookup({
            from: dbtable.USER,
            let: { orgId: `$${HotelsSchemaFields.OrganizationID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$orgId", `$${UserSchemaFields.ID}`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [UserSchemaFields.CompanyName]: 1
                    }
                }
            ],
            as: "CompanyName"
        })

        return hotelAggregate.exec((err, result) => {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetData result not found");
            }
            return cb(null, result);
        });
    }

    static GetHotelsData(lsthotelids, cb) {

        log.debug('Call GetHotelsData, hotelid:' + lsthotelids);

        return HotelsSchema.find({
            [HotelsSchemaFields.ID]: {
                $in: lsthotelids
            }
        }).exec(function (err, result) {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetHotelsData result not found");
            }
            return cb(null, result);
        });
    }

    static GetHotelRevenueData(hotelid, cb) {
        log.debug('Call GetData, hotelid:' + hotelid);

        HotelsSchema.findOne({ [HotelsSchemaFields.ID]: hotelid }, (err, result) => {

            cb(null, result);
        })
    }

    static GetLaborHouseKeeping(hotelid, cb) {
        log.debug('Call GetData, hotelid:' + hotelid);

        HotelsSchema.find({ $and: [{ [HotelsSchemaFields.ID]: hotelid }, { [HotelsSchemaFields.IsActive]: true }] }, (err, result) => {

            cb(null, result);
        })
    }


    static GetHotelsByOrganizationId(orgid, secondaryorgid, cb) {

        log.debug('Call GetHotelsByOrganizationId, orgid:' + orgid + ' secondaryorgid:' + secondaryorgid);

        HotelsSchema.find({
            $and: [
                { $or: [{ [HotelsSchemaFields.OrganizationID]: orgid }, { [HotelsSchemaFields.OrganizationID]: secondaryorgid }] }
                , { [HotelsSchemaFields.IsActive]: true }
            ]
        }, (err, result) => {
            cb(null, result);
        })
    }

    static GetHotelsByIds(hotelids, cb) {

        log.debug('Call GetHotelsByIds');

        let ids = [];
        hotelids.forEach(element => {
            ids.push(element.id);
        });
        HotelsSchema.find({
            [HotelsSchemaFields.ID]: { $in: ids },
            [HotelsSchemaFields.IsActive]: true
        }, (err, result) => {
            cb(null, result);
        })
    }
    static GetHotelByOrganizationId(orgid, cb) {
        log.debug('Call GetHotelByOrganizationId, orgid:' + orgid);

        let hotelAggregate = HotelsSchema.aggregate();
        hotelAggregate.match({
            [HotelsSchemaFields.OrganizationID]: orgid
        })

        //user org detail
        hotelAggregate.lookup({
            from: dbtable.USER,
            let: { orgId: `$${HotelsSchemaFields.OrganizationID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$orgId", `$${UserhotelxrefSchema.ID}`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [UserSchemaFields.CompanyName]: 1
                    }
                }
            ],
            as: "CompanyName"
        })

        return hotelAggregate.exec((err, result) => {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetData result not found");
            }
            return cb(null, result);
        });
    }

    static GetHotelListByHotelGroup(userid, hotelId, hotelGroupId, roleId, cb) {
        return new Promise((resolve, reject) => {
            let hotelIds = [];
            if (roleId == 1) {
                if (hotelGroupId > 0) {
                    HotelGroupXrefHelper.getHotelByGroupId(hotelGroupId, (err, result) => {
                        const map = new Map();
                        for (const item of result) {
                            if (!map.has(item.Hotel_Id)) {
                                map.set(item.Hotel_Id, true);    // set any value to Map
                                let id = item.Hotel_Id;
                                hotelIds.push({ id });
                            }
                        }
                        resolve(hotelIds);
                    })
                }
                else {
                    hotelIds.push({ hotelId });
                    resolve(hotelIds);
                }
            }
            else {
                if (hotelGroupId > 0) {

                    HotelGroupXrefHelper.getHotelByGroupId(hotelGroupId, (err, result) => {
                        const map = new Map();
                        for (const item of result) {
                            if (!map.has(item.Hotel_Id)) {
                                map.set(item.Hotel_Id, true);    // set any value to Map
                                let id = item.Hotel_Id;
                                hotelIds.push({ id });
                            }
                        }

                        resolve(hotelIds);
                    })
                }
                else {
                    hotelIds.push({ hotelId });
                    resolve(hotelIds);
                }
            }

        });
    }

    static GetAllActiveHotelsForSuperAdmin(cb) {

        let hotelAggregate = HotelsSchema.aggregate();

        hotelAggregate.match({
            [HotelsSchemaFields.IsActive]: true
        })

        //user org detail
        hotelAggregate.lookup({
            from: dbtable.USER,
            let: { orgId: `$${HotelsSchemaFields.OrganizationID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$orgId", `$${UserSchemaFields.ID}`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [UserSchemaFields.CompanyName]: 1
                    }
                }
            ],
            as: "CompanyName"
        })


        return hotelAggregate.exec((err, result) => {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetAllActiveHotelsForSuperAdmin result not found");
            }
            return cb(null, result);
        });

    }

    static GetHotelGroupsByOrganizationId(userid, orgid, cb) {

        let hotelAggregate = HotelgroupSchema.aggregate();

        hotelAggregate.match({
            $and: [
                { [HotelgroupSchemaFields.Org_Id]: orgid },
                { [HotelgroupSchemaFields.IsDelete]: { $ne: true } }
            ]
        })
        hotelAggregate.sort({
            [HotelgroupSchemaFields.Group_Name]: 1
        });

        //[USERHOTELGROUPXREF] 
        hotelAggregate.lookup({
            from: dbtable.USERHOTELGROUPXREF,
            let: { hotelgrpId: `$${HotelgroupSchemaFields.ID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$hotelgrpId", `$Hotel_Group_Id`] },
                                { $eq: [userid, `$User_Id`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [UserhotelgroupxrefSchema.ID]: 1
                    }
                }
            ],
            as: "Userhotelgroupxref"
        })

        hotelAggregate.group({
            _id: null,
            kpicolumns: {
                $push: {
                    _id: "$_id",
                    ID: "$Id",
                    Group_Name: "$Group_Name",
                    Userhotelgroupxref: "$Userhotelgroupxref",
                }
            }

        })


        hotelAggregate.project({
            kpicolumn: {
                $filter: {
                    input: "$kpicolumns",
                    as: "kpicolumn",
                    cond: {
                        $and: [
                            { $gt: [{ $size: "$$kpicolumn.Userhotelgroupxref" }, 0] }
                        ]
                    }
                }
            }
        })



        return hotelAggregate.exec((err, result) => {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetHotelGroupsByOrganizationId result not found");
            }
            if (result.length == 0) {
                return cb(null, null);
            }
            else {

                // return cb(null, result[0].kpicolumn);
                var objresult = result[0].kpicolumn;
                var counter = result[0].kpicolumn.length;

                if (objresult.length == 0) {
                    return cb(null, null);
                }
                else {

                    objresult.forEach(function (item) {

                        // GetSortedHotelListByGroupId
                        let sorthotelbygroupsAggregate = SorthotelbygroupSchema.aggregate();
                        sorthotelbygroupsAggregate.match({
                            $and: [
                                { [SorthotelbygroupSchemaFields.GroupID]: item.ID }
                            ]
                        })
                        sorthotelbygroupsAggregate.sort({
                            [SorthotelbygroupSchemaFields.DisplayOrder]: 1
                        });

                        sorthotelbygroupsAggregate.exec((err, sorthotelbygroups_result) => {
                            if (err) {
                                log.error(err);
                            }
                            if (!sorthotelbygroups_result) {
                                log.debug("sorthotelbygroupsAggregate result not found");
                            }
                            if (sorthotelbygroups_result) {
                                let matchedobjgrp = objresult.filter(d => {
                                    return (d.ID != item.ID);
                                });
                                if (matchedobjgrp.length > 0) {
                                    matchedobjgrp = matchedobjgrp[0];
                                    matchedobjgrp.hotels = sorthotelbygroups_result;
                                    counter = counter - 1;
                                    if (counter == 0) {
                                        return cb(null, objresult);
                                    }
                                }
                            }
                            //TBD HotelGroupXrefs

                        });

                    });

                }

            }
        });


    }

    static GetHotelsByGroupId(userid, grpid, cb) {

        //grpid 
        HotelgroupxrefSchema.find({
            [HotelgroupxrefSchemaFields.Group_Id]: grpid
        }).exec(function (err, grp_result) {
            if (err) {
                log.error(err);
            }
            if (!grp_result || grp_result.length == 0) {
                return cb(null, null);
            }
            else {

                var lsthotelids = []
                grp_result.forEach(function (item) {
                    lsthotelids.push(item.Hotel_Id);
                });

                let hotelAggregate = HotelsSchema.aggregate();

                hotelAggregate.match({
                    [HotelsSchemaFields.ID]: {
                        $in: lsthotelids
                    }
                })

                //user org detail
                hotelAggregate.lookup({
                    from: dbtable.USER,
                    let: { orgId: `$${HotelsSchemaFields.OrganizationID}` },
                    pipeline: [
                        {
                            $match:
                            {
                                $expr: {
                                    $and: [
                                        { $eq: ["$$orgId", `$${UserSchemaFields.ID}`] },
                                    ]
                                }
                            }
                        },
                        {
                            $project: {
                                "_id": 1,
                                [UserSchemaFields.CompanyName]: 1
                            }
                        }
                    ],
                    as: "CompanyName"
                })


                //[UserHotelXRef] 
                hotelAggregate.lookup({
                    from: dbtable.USERHOTELXREF,
                    let: { hotelId: `$${HotelsSchemaFields.ID}` },
                    pipeline: [
                        {
                            $match:
                            {
                                $expr: {
                                    $and: [
                                        { $eq: ["$$hotelId", `$HotelID`] },
                                        { $eq: [userid, `$UserID`] },
                                        { $ne: [2, `$DisplayFor`] },
                                    ]
                                }
                            }
                        },
                        {
                            $project: {
                                "_id": 1,
                                [UserhotelxrefSchema.HotelID]: 1
                            }
                        }
                    ],
                    as: "Userhotelxref"
                })



                hotelAggregate.group({
                    _id: null,
                    kpicolumns: {
                        $push: {
                            _id: "$_id",
                            ID: "$ID",
                            HotelName: "$HotelName",
                            HotelID: "$HotelID",
                            CompanyName: "$CompanyName",
                            Userhotelxref: "$Userhotelxref",
                        }
                    }

                })


                // hotelAggregate.project({
                //     kpicolumn: {
                //         $filter: {
                //             input: "$kpicolumns",
                //             as: "kpicolumn",
                //             cond: {
                //                 $and: [
                //                     { $gt: [{ $size: "$$kpicolumn.Userhotelxref" }, 0] }
                //                 ]
                //             }
                //         }
                //     }
                // })




                return hotelAggregate.exec((err, result) => {

                    if (err) {
                        log.error(err);
                    }
                    if (!result) {
                        log.debug("GetHotelsByGroupId result not found");
                    }
                    if (result == undefined) {
                        return cb(null, null);
                    }

                    if (result.length == 0) {
                        return cb(null, null);
                    }
                    else {

                        var obj_result = result[0].kpicolumns;
                        // return cb(null, result[0].kpicolumns);

                        // GetSortedHotelListByGroupId
                        let sorthotelbygroupsAggregate = SorthotelbygroupSchema.aggregate();
                        sorthotelbygroupsAggregate.match({
                            $and: [
                                { [SorthotelbygroupSchemaFields.GroupID]: grpid }
                            ]
                        })
                        sorthotelbygroupsAggregate.sort({
                            [SorthotelbygroupSchemaFields.DisplayOrder]: 1
                        });
                        sorthotelbygroupsAggregate.exec((err, sorthotelbygroups_result) => {
                            if (err) {
                                log.error(err);
                            }
                            if (!sorthotelbygroups_result) {
                                return cb(null, obj_result);
                            }
                            if (sorthotelbygroups_result) {
                                var obj_result_sorted = [];
                                sorthotelbygroups_result.forEach(function (sorthotelbygroup) {
                                    let matchedobjgrp = obj_result.filter(d => {
                                        return (sorthotelbygroup.HotelID == d.ID);
                                    });
                                    if (matchedobjgrp.length > 0) {
                                        matchedobjgrp = matchedobjgrp[0];
                                        obj_result_sorted.push(matchedobjgrp);
                                    }
                                });
                                return cb(null, obj_result_sorted);
                            }
                        });


                    }
                });
            }



        });

    }

    static GetHotelsGroupData(userid, orgid, cb) {

        let hotelAggregate = HotelgroupSchema.aggregate();

        hotelAggregate.match({
            $and: [
                { [HotelgroupSchemaFields.Org_Id]: orgid },
                { [HotelgroupSchemaFields.IsDelete]: { $ne: true } }
            ]
        })
        hotelAggregate.sort({
            [HotelgroupSchemaFields.Group_Name]: 1
        });

        //[USERHOTELGROUPXREF] 
        hotelAggregate.lookup({
            from: dbtable.USERHOTELGROUPXREF,
            let: { hotelgrpId: `$${HotelgroupSchemaFields.ID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$hotelgrpId", `$Hotel_Group_Id`] },
                                { $eq: [userid, `$User_Id`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [UserhotelgroupxrefSchema.ID]: 1
                    }
                }
            ],
            as: "Userhotelgroupxref"
        })

        hotelAggregate.group({
            _id: null,
            kpicolumns: {
                $push: {
                    _id: "$_id",
                    ID: "$Id",
                    Group_Name: "$Group_Name",
                    Userhotelgroupxref: "$Userhotelgroupxref",
                }
            }

        })

        hotelAggregate.project({
            kpicolumn: {
                $filter: {
                    input: "$kpicolumns",
                    as: "kpicolumn",
                    cond: {
                        $and: [
                            { $gt: [{ $size: "$$kpicolumn.Userhotelgroupxref" }, 0] }
                        ]
                    }
                }
            }
        })

        return hotelAggregate.exec((err, result) => {

            if (err) {
                log.error(err);
            } 
            if (result.length == 0 || result[0].kpicolumn.length ==0) {
                log.debug("GetHotelGroupsByOrganizationId result not found");
                return cb(null, null);
            }
           else {
                var lsthotelgroups = []
                var objresult = result[0].kpicolumn;
                var counter = result[0].kpicolumn.length;
                objresult.forEach(function (item) {
                    lsthotelgroups.push(item.ID);
                });

                 //grpid 
                HotelgroupxrefSchema.find({ [HotelgroupxrefSchemaFields.Group_Id]: {
                    $in: lsthotelgroups
                }}).exec(function (err, grp_result) {
                    if (err) {
                        log.error(err);
                    }
                    if (!grp_result || grp_result.length == 0) {
                        return cb(null, null);
                    }
                    else {
                        
                        var lsthotelids = []
                        grp_result.forEach(function (item) {
                            lsthotelids.push(item.Hotel_Id);
                        });

                        let hotelAggregate = HotelsSchema.aggregate();

                        hotelAggregate.match({
                            [HotelsSchemaFields.ID]: {
                                $in: lsthotelids
                            }
                        })

                        //user org detail
                        hotelAggregate.lookup({
                            from: dbtable.USER,
                            let: { orgId: `$${HotelsSchemaFields.OrganizationID}` },
                            pipeline: [
                                {
                                    $match:
                                    {
                                        $expr: {
                                            $and: [
                                                { $eq: ["$$orgId", `$${UserSchemaFields.ID}`] },
                                            ]
                                        }
                                    }
                                },
                                {
                                    $project: {
                                        "_id": 1,
                                        [UserSchemaFields.CompanyName]: 1
                                    }
                                }
                            ],
                            as: "CompanyName"
                        })


                        //[UserHotelXRef] 
                        hotelAggregate.lookup({
                            from: dbtable.USERHOTELXREF,
                            let: { hotelId: `$${HotelsSchemaFields.ID}` },
                            pipeline: [
                                {
                                    $match:
                                    {
                                        $expr: {
                                            $and: [
                                                { $eq: ["$$hotelId", `$HotelID`] },
                                                { $eq: [userid, `$UserID`] },
                                                { $ne: [2, `$DisplayFor`] },
                                            ]
                                        }
                                    }
                                },
                                {
                                    $project: {
                                        "_id": 1,
                                        [UserhotelxrefSchema.HotelID]: 1
                                    }
                                }
                            ],
                            as: "Userhotelxref"
                        })
                        hotelAggregate.group({
                            _id: null,
                            kpicolumns: {
                                $push: {
                                    _id: "$_id",
                                    ID: "$ID",
                                    HotelName: "$HotelName",
                                    HotelID: "$HotelID",
                                    CompanyName: "$CompanyName",
                                    Userhotelxref: "$Userhotelxref",
                                }
                            }

                        })
                        return hotelAggregate.exec((err, result) => {

                            if (err) {
                                log.error(err);
                            }
                            if (!result) {
                                log.debug("GetHotelsByGroupId result not found");
                            }
                            if (result.length == 0) {
                                return cb(null, null);
                            }
                            else {

                                var obj_result = result[0].kpicolumns;
                                
                                // return cb(null, result[0].kpicolumns);
                                objresult.forEach(function (item) {

                                    // GetSortedHotelListByGroupId
                                    let sorthotelbygroupsAggregate = SorthotelbygroupSchema.aggregate();
                                    sorthotelbygroupsAggregate.match({
                                        $and: [
                                            { [SorthotelbygroupSchemaFields.GroupID]: item.ID }
                                        ]
                                    })
                                    sorthotelbygroupsAggregate.sort({
                                        [SorthotelbygroupSchemaFields.DisplayOrder]: 1
                                    });
            
                                    sorthotelbygroupsAggregate.exec((err, sorthotelbygroups_result) => {
                                        if (err) {
                                            log.error(err);
                                        }
                                        if (!sorthotelbygroups_result) {
                                            log.debug("sorthotelbygroupsAggregate result not found");
                                        }
                                        if (sorthotelbygroups_result) {
                                            let matchedobjgrp = objresult.filter(d => {
                                                return (d.ID == item.ID);
                                            });
                                            if (matchedobjgrp.length > 0) {
                                                matchedobjgrp = matchedobjgrp[0];
                                                matchedobjgrp.hotels = sorthotelbygroups_result;
                                                counter = counter - 1;
                                                if (counter == 0) {
                                                    return cb(null, objresult);
                                                }
                                            }
                                        }
                                        //TBD HotelGroupXrefs
            
                                    });
            
                                });
            
                            }
                        });
                    }
                });
            }
        });
       

    }

    static GetHotelsByOrganizationId(userid, orgid, secondaryorgid, cb) {

        let hotelAggregate = HotelsSchema.aggregate();

        hotelAggregate.match({
            $and: [
                { $or: [{ [HotelsSchemaFields.OrganizationID]: orgid }, { [HotelsSchemaFields.OrganizationID]: secondaryorgid }] }
                , { [HotelsSchemaFields.IsActive]: true }
            ]
        })

        //user org detail
        hotelAggregate.lookup({
            from: dbtable.USER,
            let: { orgId: `$${HotelsSchemaFields.OrganizationID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$orgId", `$${UserSchemaFields.ID}`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [UserSchemaFields.CompanyName]: 1
                    }
                }
            ],
            as: "CompanyName"
        })


        //[UserHotelXRef] 
        hotelAggregate.lookup({
            from: dbtable.USERHOTELXREF,
            let: { hotelId: `$${HotelsSchemaFields.ID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$hotelId", `$HotelID`] },
                                { $eq: [userid, `$UserID`] },
                                { $ne: [2, `$DisplayFor`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [UserhotelxrefSchema.HotelID]: 1
                    }
                }
            ],
            as: "Userhotelxref"
        })



        hotelAggregate.group({
            _id: null,
            kpicolumns: {
                $push: {
                    _id: "$_id",
                    ID: "$ID",
                    HotelName: "$HotelName",
                    CompanyName: "$CompanyName",
                    Userhotelxref: "$Userhotelxref",
                }
            }

        })


        hotelAggregate.project({
            kpicolumn: {
                $filter: {
                    input: "$kpicolumns",
                    as: "kpicolumn",
                    cond: {
                        $and: [
                            { $gt: [{ $size: "$$kpicolumn.Userhotelxref" }, 0] }
                        ]
                    }
                }
            }
        })




        return hotelAggregate.exec((err, result) => {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetHotelsByOrganizationId result not found");
            }
            if (result.length == 0) {
                return cb(null, null);
            }
            else {
                return cb(null, result[0].kpicolumn);
            }
        });

    }

    static GetHotelsByOrganizationIdandRoleID(userid, orgid, secondaryorgid, roleid, cb) {

        let hotelAggregate = HotelsSchema.aggregate();

        hotelAggregate.match({
            $and: [
                { $or: [{ [HotelsSchemaFields.OrganizationID]: orgid }, { [HotelsSchemaFields.OrganizationID]: secondaryorgid }] }
                , { [HotelsSchemaFields.IsActive]: true }
            ]
        })

        //user org detail
        hotelAggregate.lookup({
            from: dbtable.USER,
            let: { orgId: `$${HotelsSchemaFields.OrganizationID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$orgId", `$${UserSchemaFields.ID}`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [UserSchemaFields.CompanyName]: 1
                    }
                }
            ],
            as: "CompanyName"
        })




        //[UserHotelXRef] 
        hotelAggregate.lookup({
            from: dbtable.USERHOTELXREF,
            let: { hotelId: `$${HotelsSchemaFields.ID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$hotelId", `$HotelID`] },
                                { $eq: [userid, `$UserID`] },
                                { $ne: [2, `$DisplayFor`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [UserhotelxrefSchema.HotelID]: 1
                    }
                }
            ],
            as: "Userhotelxref"
        })



        hotelAggregate.group({
            _id: null,
            kpicolumns: {
                $push: {
                    _id: "$_id",
                    ID: "$ID",
                    HotelName: "$HotelName",
                    CompanyName: "$CompanyName",
                    Userhotelxref: "$Userhotelxref",
                }
            }

        })

        if (roleid != 1) {

            hotelAggregate.project({
                kpicolumn: {
                    $filter: {
                        input: "$kpicolumns",
                        as: "kpicolumn",
                        cond: {
                            $and: [
                                { $gt: [{ $size: "$$kpicolumn.Userhotelxref" }, 0] }
                            ]
                        }
                    }
                }
            })
        }


        return hotelAggregate.exec((err, result) => {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetHotelsByOrganizationId result not found");
            }
            if (result.length == 0) {
                return cb(null, null);
            }
            else {
                if (roleid != 1) {
                    return cb(null, result[0].kpicolumn);
                }
                else {
                    return cb(null, result[0].kpicolumns);
                }
            }
        });

    }


    static getActiveHotelsforGivenGroup(GroupID, cd) {
        let hotels;
        return new Promise((resolve, reject) => {
            HotelsSchema.find({
                $and: [
                    { [HotelsSchemaFields.OrganizationID]: GroupID },
                    { [HotelsSchemaFields.IsActive]: true }
                ]
            }).exec((err, result) => {
                if (err) {
                    reject(err);
                }
                hotels = result;
                resolve()
            })
        }).then(resp => {
            cd(null, hotels)
        })
    }

    static getActiveHotels(cd) {
        HotelsSchema.find({
            $and: [
                { [HotelsSchemaFields.IsActive]: true }
            ]
        }).exec((err, result) => {
            cd(null, result)
        })
    }

    static GetHotels(hotelid, orgid, cd) {
        let Hotels = new HotelData()
        if (hotelid > 0) {
            HotelsHelper.GetLaborHouseKeeping(hotelid, (err, result) => {
                cd(null, result)
            })
        } else if (orgid > 0) {
            HotelsHelper.getActiveHotelsforGivenGroup(orgid, (err, result) => {
                cd(null, result)
            })
        } else {
            HotelsHelper.getActiveHotels((err, result) => {
                cd(null, result)
            })
        }
    }
    static GetHotelsForSuperAdminNew(userId, cd) {
        let Hotels = [];
        let um = [];
        let mch = [];
        return new Promise((resolve, reject) => {
            HotelsHelper.getActiveHotels((err, result) => {
                if (err) {
                    reject(err);
                }
                Hotels = result
                resolve()
            })
        }).then(resp => {
            let y = Hotels.filter(function (data) {
                let model = new HotelData();
                model.AddressLine1 = data.AddressLine1;
                model.ID = data.ID;
                model.City = data.City;
                model.Country = data.CountryISO2;
                model.AccountingTool = data.AccountingTool;
                model.AddressLine2 = data.AddressLine2;
                model.Attention = data.Attention;
                model.HotelCode = data.HotelCode;
                model.HotelName = data.HotelName;
                model.NumberofAvailableRooms = data.NumberofAvailableRooms == null ? 0 : data.NumberofAvailableRooms.Value;
                model.State = data.StateISO2;
                model.OrganizationId = data.OrganizationID;
                model.PMS = data.PMS;
                model.PMSPropertyID = data.PMSPropertyID;
                model.PMSPropertyName = data.PMSPropertyName;
                model.TimeZone = data.TimeZone;
                model.Zip = data.Zip;
                model.IsActive = data.IsActive;
                model.IsValidMYP = true;
                return mch.push(model)
            })
            let hotelArray = [];
            let z = y.filter(function (data) {
                hotelArray.push(
                    new Promise((resolve, reject) => {
                        UserHotelXrefHelper.getUserHoteData(userId, data.ID, (err, result) => {

                            um.push(result)
                            resolve()

                        })
                    })
                )


            })
            Promise.all(hotelArray).then(resp => {
                let x = [];
                um.filter(function (data) {
                    if (data.length > 0) {

                        x.push(data[0]);
                    }
                })
                x.filter(function (data) {
                    if (data.DisplayFor == 2) {
                        y.filter(function (data) {
                            data.IsValidMYP = false;
                        })
                    }
                })
                let result = y.filter(function (data) {
                    return _.map(_.sortBy(data, data.HotelName), _.values);
                })
                cd(null, result)
            })


        })

    }
    static getHotelDatabyOrganizationID(Orgid, secondaryOrganizationId, cd) {
        HotelsSchema.find({
            $and: [
                { [HotelsSchemaFields.OrganizationID]: { $in: [Orgid, secondaryOrganizationId] } }

            ]
        }).exec((err, result) => {
            cd(null, result)
        })
    }
    static getHotelsByOrganizationIdNew(Orgid, userId, cd) {
        let all = false; let allowinactive = false;
        let Hotels = [];
        let um = [];
        let mch = [];
        let user = [];
        return new Promise((resolve, reject) => {
            UserHelper.getUserData(userId, (err, result) => {
                if (err) {
                    reject(err);
                }
                user.push(result)
                resolve()
            })
        }).then(resp => {

            let secondaryOrganizationId;
            let roleId;
            _.filter(user, function (data) {
                if (data.SecondaryOrganizationId > 0) {
                    secondaryOrganizationId = data.SecondaryOrganizationId
                } else {
                    secondaryOrganizationId = Orgid
                }
                roleId = data.RoleID
            })
            let result;
            if(roleId == 1){
                result = new Promise((resolve, reject) => {
                    HotelsHelper.GetHotelsForSuperAdminNew(userId, (err, result) => {
                        if (err) {
                            reject(err);
                        }
                        Hotels = result
                        
                        resolve()
                        cd(null, Hotels)
                    })
                })
            }
            else 
            {
                if (allowinactive == true) {
                result = new Promise((resolve, reject) => {
                    HotelsHelper.getHotelDatabyOrganizationID(Orgid, secondaryOrganizationId, (err, result) => {
                        if (err) {
                            reject(err);
                        }
                        Hotels = result
                        resolve()
                    })
                })

            } else {
                result = new Promise((resolve, reject) => {
                    HotelsSchema.find({
                        $and: [
                            { [HotelsSchemaFields.OrganizationID]: { $in: [Orgid, secondaryOrganizationId] } },
                            { [HotelsSchemaFields.IsActive]: true }

                        ]
                    }).exec((err, result) => {
                        if (err) {
                            reject(err);
                        }
                        Hotels = result
                        resolve()
                    })
                })

            }

            result.then(resp => {
                let dataResult;
                let uhr;
                let mchArray = [];
                _.filter(Hotels, function (data) {
                    
                    let x = new Promise((resolve, reject) => {

                        UserHotelXrefHelper.getDatabyUserID(userId, (err, result) => {

                            uhr = result

                            if (uhr.length > 0) {
                                let model = new HotelData();
                                model.AddressLine1 = data.AddressLine1;
                                model.ID = data.ID;
                                model.City = data.City;
                                model.Country = data.CountryISO2;
                                model.AccountingTool = data.AccountingTool;
                                model.AddressLine2 = data.AddressLine2;
                                model.Attention = data.Attention;
                                model.HotelCode = data.HotelCode;
                                model.HotelName = data.HotelName;
                                model.NumberofAvailableRooms = data.NumberofAvailableRooms == null ? 0 : data.NumberofAvailableRooms.Value;
                                model.State = data.StateISO2;
                                model.OrganizationId = data.OrganizationID;
                                model.PMS = data.PMS;
                                model.PMSPropertyID = data.PMSPropertyID;
                                model.PMSPropertyName = data.PMSPropertyName;
                                model.TimeZone = data.TimeZone;
                                model.Zip = data.Zip;
                                model.IsActive = data.IsActive;

                                if (all == true) {
                                    model.IsValidMYP = true;

                                }
                                _.filter(uhr, function (key) {
                                    if (key.DisplayFor != 2) {
                                        model.IsValidMYP = true;
                                    }
                                })
                                mch.push(model)
                                resolve()

                            }

                        })
                    })
                    mchArray.push(x)
                })

                Promise.all(mchArray).then(resp => {
                    if (mch.length > 0) {
                        _.sortBy(mch, x => x.HotelName)
                    }

                    cd(null, mch)
                })
            })
            }
        })
    
    }
    static getHotelsByOrganizationIdNew_GraphQL(orgid,userid, cb) {
        return HotelsHelper.getHotelsByOrganizationIdNew(orgid,userid, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }

    static GetAllActiveHotelIdsForSuperAdmin(cb) { // get only ids array
        log.debug('Call GetAllActiveHotelIdsForSuperAdmin');
        let hotelIds = [];
        HotelsSchema.find({ [HotelsSchemaFields.IsActive]: true }, (err, result) => {
            const map = new Map();
            for (const item of result) { //Get unique id 
                if (!map.has(item.ID)) {
                    map.set(item.ID, true);    // set any value to Map
                    let id = item.ID;
                    hotelIds.push({ id });
                }
            }

            cb(null, hotelIds);
        })
    }

    static GetHotelIdsByOrganizationId(orgid, secondaryorgid, cb) { //get only ids array

        log.debug('Call GetHotelIdsByOrganizationId, orgid:' + orgid + ' secondaryorgid:' + secondaryorgid);
        let hotelIds = [];
        HotelsSchema.find({
            $and: [
                { $or: [{ [HotelsSchemaFields.OrganizationID]: orgid }, { [HotelsSchemaFields.OrganizationID]: secondaryorgid }] }
                , { [HotelsSchemaFields.IsActive]: true }
            ]
        }, (err, result) => {
            const map = new Map();
            for (const item of result) { //Get unique id 
                if (!map.has(item.ID)) {
                    map.set(item.ID, true);    // set any value to Map
                    let id = item.ID;
                    hotelIds.push({ id });
                }
            }

            cb(null, hotelIds);
        })
    }
}
module.exports = HotelsHelper;

