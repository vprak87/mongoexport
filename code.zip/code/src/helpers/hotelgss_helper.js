
const { Hotelgss: HotelgssSchema, SchemaField: HotelgssSchemaFields } = require('../models/hotelgss');
const Utils = require('../common/utils');
var log = require('log4js').getLogger("hotelgss_helper");
const Hotelgssdata = require('../portfolio/models/hotelgssdata');

class HotelgssHelper {

    static GetPriorityData(lsthotelids, startdate, enddate, priority, cb) {

        log.debug("Call GetPriorityData");

        // let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        // let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);
        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let year_start = new Date(startdate.getFullYear(), 0, 1); //Jan
        let end = new Date(enddate.getFullYear(), 11, 31); //Dec
        var currMonthName = Utils.getFormattedDate(start, 'MMM');
        currMonthName = currMonthName.toLowerCase();

        return HotelgssSchema.find({
            [HotelgssSchemaFields.SetPriority]: priority
            ,
            [HotelgssSchemaFields.HotelID]: {
                $in: lsthotelids
            },
            [HotelgssSchemaFields.Date]: {
                $gte: year_start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetPriorityData result not found");
                return cb("data not found", null);
            }
            else {

                let lstHotelgssdata = [];
                result.forEach(function (item) {
                    let objHotelgssdata = new Hotelgssdata();
                    objHotelgssdata.description = item.Description;
                    objHotelgssdata.benchmark = item.Benchmark;
                    objHotelgssdata.total = item.Total;
                    objHotelgssdata.HotelID = item.HotelID;
                    objHotelgssdata.monthname = currMonthName;
                    //#region  //get value based on column name and month name 
                    if (currMonthName == "jan") {
                        objHotelgssdata.actual = item.Current_Jan;
                    }
                    else if (currMonthName == "feb") {
                        objHotelgssdata.actual = item.Current_Feb;
                    }
                    else if (currMonthName == "mar") {
                        objHotelgssdata.actual = item.Current_Mar;
                    }
                    else if (currMonthName == "apr") {
                        objHotelgssdata.actual = item.Current_Apr;
                    }
                    else if (currMonthName == "may") {
                        objHotelgssdata.actual = item.Current_May;
                    }
                    else if (currMonthName == "jun") {
                        objHotelgssdata.actual = item.Current_Jun;
                    }
                    else if (currMonthName == "jul") {
                        objHotelgssdata.actual = item.Current_Jul;
                    }
                    else if (currMonthName == "aug") {
                        objHotelgssdata.actual = item.Current_Aug;
                    }
                    else if (currMonthName == "sep") {
                        objHotelgssdata.actual = item.Current_Sep;
                    }
                    else if (currMonthName == "oct") {
                        objHotelgssdata.actual = item.Current_Oct;
                    }
                    else if (currMonthName == "nov") {
                        objHotelgssdata.actual = item.Current_Nov;
                    }
                    else if (currMonthName == "dec") {
                        objHotelgssdata.actual = item.Current_Dec;
                    }
                    //#endregion

                    //#region  YTD  //get value based on column name and month name 
                    if (currMonthName == "jan") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Jan;
                    }
                    else if (currMonthName == "feb") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Feb;
                    }
                    else if (currMonthName == "mar") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Mar;
                    }
                    else if (currMonthName == "apr") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Apr;
                    }
                    else if (currMonthName == "may") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_May;
                    }
                    else if (currMonthName == "jun") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Jun;
                    }
                    else if (currMonthName == "jul") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Jul;
                    }
                    else if (currMonthName == "aug") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Aug;
                    }
                    else if (currMonthName == "sep") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Sep;
                    }
                    else if (currMonthName == "oct") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Oct;
                    }
                    else if (currMonthName == "nov") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Nov;
                    }
                    else if (currMonthName == "dec") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Dec;
                    }
                    //#endregion

                    lstHotelgssdata.push(objHotelgssdata);
                });

                return cb(null, lstHotelgssdata);
            }
        });
    }
    static GetGSSPriorityData(lsthotelids,currentdate, startdate, enddate, priority, cb) {

        log.debug("Call GetPriorityData");

        // let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        // let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);
        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let year_start = Utils.startofYear(start);  //Jan
        let end = new Date(enddate.getFullYear(), 11, 31); //Dec
        var currMonthName = Utils.getFormattedDate(currentdate, 'MMM');
        currMonthName = currMonthName.toLowerCase();

        return HotelgssSchema.find({
            [HotelgssSchemaFields.SetPriority]: priority
            ,
            [HotelgssSchemaFields.HotelID]: {
                $in: lsthotelids
            },
            [HotelgssSchemaFields.Date]: {
                $gte: year_start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetPriorityData result not found");
                return cb("data not found", null);
            }
            else {

                let lstHotelgssdata = [];
                result.forEach(function (item) {
                    let objHotelgssdata = new Hotelgssdata();
                    objHotelgssdata.description = item.Description;
                    objHotelgssdata.benchmark = item.Benchmark;
                    objHotelgssdata.total = item.Total;
                    objHotelgssdata.HotelID = item.HotelID;
                    objHotelgssdata.monthname = currMonthName;
                    //#region  //get value based on column name and month name 
                    if (currMonthName == "jan") {
                        objHotelgssdata.actual = item.Current_Jan;
                    }
                    else if (currMonthName == "feb") {
                        objHotelgssdata.actual = item.Current_Feb;
                    }
                    else if (currMonthName == "mar") {
                        objHotelgssdata.actual = item.Current_Mar;
                    }
                    else if (currMonthName == "apr") {
                        objHotelgssdata.actual = item.Current_Apr;
                    }
                    else if (currMonthName == "may") {
                        objHotelgssdata.actual = item.Current_May;
                    }
                    else if (currMonthName == "jun") {
                        objHotelgssdata.actual = item.Current_Jun;
                    }
                    else if (currMonthName == "jul") {
                        objHotelgssdata.actual = item.Current_Jul;
                    }
                    else if (currMonthName == "aug") {
                        objHotelgssdata.actual = item.Current_Aug;
                    }
                    else if (currMonthName == "sep") {
                        objHotelgssdata.actual = item.Current_Sep;
                    }
                    else if (currMonthName == "oct") {
                        objHotelgssdata.actual = item.Current_Oct;
                    }
                    else if (currMonthName == "nov") {
                        objHotelgssdata.actual = item.Current_Nov;
                    }
                    else if (currMonthName == "dec") {
                        objHotelgssdata.actual = item.Current_Dec;
                    }
                    //#endregion

                    //#region  YTD  //get value based on column name and month name 
                    if (currMonthName == "jan") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Jan;
                    }
                    else if (currMonthName == "feb") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Feb;
                    }
                    else if (currMonthName == "mar") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Mar;
                    }
                    else if (currMonthName == "apr") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Apr;
                    }
                    else if (currMonthName == "may") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_May;
                    }
                    else if (currMonthName == "jun") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Jun;
                    }
                    else if (currMonthName == "jul") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Jul;
                    }
                    else if (currMonthName == "aug") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Aug;
                    }
                    else if (currMonthName == "sep") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Sep;
                    }
                    else if (currMonthName == "oct") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Oct;
                    }
                    else if (currMonthName == "nov") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Nov;
                    }
                    else if (currMonthName == "dec") {
                        objHotelgssdata.actual_YTD = item.Current_YTD_Dec;
                    }
                    //#endregion

                    lstHotelgssdata.push(objHotelgssdata);
                });

                return cb(null, lstHotelgssdata);
            }
        });
    }


}
module.exports = HotelgssHelper;



