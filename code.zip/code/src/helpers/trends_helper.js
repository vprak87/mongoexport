const HoteldashboardcalculationsHelper = require('./hoteldashboardcalculations_helper');
const HotelroomstatusdashboardcalculationsHelper = require('./hotelroomstatusdashboardcalculations_helper');
const HotelbudgetdashboardcalculationsHelper = require('./hotelbudgetdashboardcalculations_helper');
const Trendschartdata = require('../trends/models/trendschartdata');
const HotelsHelper = require('./hotels_helper');
const Constants = require('../common/constants');
const Utils = require('../common/utils');
const moment = require('moment');

const UserHelper = require('./user_helper');
var log = require('log4js').getLogger("trends_helper");

class TrendsHelper {
    static getChartData(hotelid, reportdate, period, userconfigdata, cb) {
        var numDays = parseInt(period) - 1;
        var dtreportdate = new Date(reportdate);

        let startdate = new Date(dtreportdate.getFullYear(), dtreportdate.getMonth(), dtreportdate.getDate() - numDays);
        let enddate = new Date(dtreportdate.getFullYear(), dtreportdate.getMonth(), dtreportdate.getDate() + 1);

        //LastYear date
        let stlastYear = Utils.sameDayLastYear(startdate);
        var startdate_LastYear = new Date(stlastYear);

        let enlastYear = Utils.sameDayLastYear(enddate);
        let enddate_LastYear = new Date(enlastYear);

        let hoteldashboardcalculationsData = [];
        let hoteldashboardcalculationsData_LastYear = [];
        let hotelbudgetdashboardcalculationsData = [];

        let hotelroomstatusdashboardcalculationsData = [];
        let hotelroomstatusdashboardcalculationsData_LastYear = [];

        return Promise.all([
            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations data
                HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, hoteldashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_result) {
                        hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations_LastYear data
                HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate_LastYear, enddate_LastYear, (err, hoteldashboardcalculations_LastYear_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_LastYear_result) {
                        hoteldashboardcalculationsData_LastYear = hoteldashboardcalculations_LastYear_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get hotelroomstatusdashboardcalculations  data
                HotelroomstatusdashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, hotelroomstatusdashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelroomstatusdashboardcalculations_result) {
                        hotelroomstatusdashboardcalculationsData = hotelroomstatusdashboardcalculations_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get hotelroomstatusdashboardcalculations  data
                HotelroomstatusdashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate_LastYear, enddate_LastYear, (err, hotelroomstatusdashboardcalculations_LastYear_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelroomstatusdashboardcalculations_LastYear_result) {
                        hotelroomstatusdashboardcalculationsData_LastYear = hotelroomstatusdashboardcalculations_LastYear_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get hotelbudgetdashboardcalculations  data
                HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, hotelbudgetdashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelbudgetdashboardcalculations_result) {
                        hotelbudgetdashboardcalculationsData = hotelbudgetdashboardcalculations_result;
                    }
                    resolve();
                });

            })

        ]).then(resp => {
            let lstTranslineItem = [];

            while (startdate < enddate) {
                let dt = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate())

                let occupancy = 0;
                let forecastoccupancy = 0;
                let occupancyly = 0;
                let adr = 0;
                let forecastadr = 0;
                let adrly = 0;
                let revpar = 0;
                let forecastrevpar = 0;
                let revparly = 0;
                let roomrevenue = 0;
                let forecastroomrevenue = 0;
                let roomrevenuely = 0;
                let fbrevenue = 0;
                let fbrevenuely = 0;
                let forecastfbrevenue = 0;
                let otherrevenue = 0;
                let otherrevenuely = 0;
                let forecastotherrevenue = 0;
                let forecasttotalrevenue = 0;
                let noofroomsold = 0;
                let noofroomsoldly = 0;
                let forecastroomsold = 0;
                let comprooms = 0;
                let forecastcomprooms = 0;
                let comproomsly = 0;
                let ooorooms = 0;
                let forecastooorooms = 0;
                let oooroomsly = 0;
                let totalrevenue = 0;
                let totalrevenuely = 0;
                let budgetoccupancy = 0;
                let budgetadr = 0;
                let budgetrevpar = 0;
                let budgetroomrevenue = 0;
                let budgetfbrevenue = 0;
                let budgetotherrevenue = 0;
                let budgettotalrevenue = 0;
                let budgetnoofroomsold = 0;
                let budgetcomprrooms = 0;
                let budgetooorooms = 0;

                if (hoteldashboardcalculationsData.length > 0) {
                    // let obj = hoteldashboardcalculationsData.filter(d => {
                    //     var time = new Date(d.Date);
                    //     return (time >= dt && time <= dt);
                    // });

                    hoteldashboardcalculationsData.forEach(element=>{
                        if(new Date(element.Date).setHours(0, 0, 0, 0)>=dt && new Date(element.Date).setHours(0, 0, 0, 0) <= dt ){
                           
                            // obj.forEach(element => {
                                let todate = new Date(element.Date);
                                let fromdate = new Date(element.Date);
                                let TDays = Math.floor(todate - fromdate) + 1;
        
                                let _Occupancy = element.Occupancy == null ? 0 : element.Occupancy;
                                if (_Occupancy != 0)
                                    occupancy = occupancy + (_Occupancy / TDays);
        
                                let _ForecastOccupancy = element.ForecastOccupancy == null ? 0 : element.ForecastOccupancy;
                                if (_ForecastOccupancy != 0)
                                    forecastoccupancy = forecastoccupancy + (_ForecastOccupancy / TDays);
        
                                let _ADR = element.ADR == null ? 0 : element.ADR;
                                if (_ADR != 0)
                                    adr = adr + (_ADR / TDays);
        
                                let _ForecastADR = element.ForecastADR == null ? 0 : element.ForecastADR;
                                if (_ForecastADR != 0)
                                    forecastadr = forecastadr + (_ForecastADR / TDays);
        
                                let _RevPAR = element.RevPAR == null ? 0 : element.RevPAR;
                                if (_RevPAR != 0)
                                    revpar = revpar + (_RevPAR / TDays);
        
                                let _ForecastRevPAR = element.ForecastRevPAR == null ? 0 : element.ForecastRevPAR;
                                if (_ForecastRevPAR != 0)
                                    forecastrevpar = forecastrevpar + (_ForecastRevPAR / TDays);
        
                                let _RoomRevenue = element.TotalRevenue == null ? 0 : element.TotalRevenue;
                                if (_RoomRevenue != 0)
                                    roomrevenue = roomrevenue + (_RoomRevenue / TDays);
        
                                let _ForecastRoomRevenue = element.ForecastRoomRevenue == null ? 0 : element.ForecastRoomRevenue;
                                if (_ForecastRoomRevenue != 0)
                                    forecastroomrevenue = forecastroomrevenue + (_ForecastRoomRevenue / TDays);
        
                                let _FBRevenue = element.FANDBRevenue == null ? 0 : element.FANDBRevenue;
                                if (_FBRevenue != 0)
                                    fbrevenue = fbrevenue + (_FBRevenue / TDays);
        
                                let _ForecastFBRevenue = element.ForecastFBRevenue == null ? 0 : element.ForecastFBRevenue;
                                if (_ForecastFBRevenue != 0)
                                    forecastfbrevenue = forecastfbrevenue + (_ForecastFBRevenue / TDays);
        
                                let _OtherRevenue = element.OtherRevenue == null ? 0 : element.OtherRevenue;
                                if (_OtherRevenue != 0)
                                    otherrevenue = otherrevenue + (_OtherRevenue / TDays);
        
                                let _ForecastOtherRevenue = element.ForecastOtherRevenue == null ? 0 : element.ForecastOtherRevenue;
                                if (_ForecastOtherRevenue != 0)
                                    forecastotherrevenue = forecastotherrevenue + (_ForecastOtherRevenue / TDays);
        
                                let _ForecastTotalRevenue =element.ForecastRoomRevenue + element.ForecastFANDBRevenue + element.ForecastOtherRevenue                    
                                if (_ForecastTotalRevenue != 0)
                                    forecasttotalrevenue = forecasttotalrevenue + (_ForecastTotalRevenue / TDays);
        
                                let _NoOfRoomSold = element.NoOfRoomSold == null ? 0 : element.NoOfRoomSold;
                                if (_NoOfRoomSold != 0)
                                    noofroomsold = noofroomsold + (_NoOfRoomSold / TDays);
        
                                let _ForecastCompRooms = element.ForecastCompRooms == null ? 0 : element.ForecastCompRooms;
                                if (_ForecastCompRooms != 0)
                                    forecastcomprooms = forecastcomprooms + (_ForecastCompRooms / TDays);
        
                                let _ForecastoooRooms = element.ForecastoooRooms == null ? 0 : element.ForecastoooRooms;
                                if (_ForecastoooRooms != 0)
                                    forecastooorooms = forecastooorooms + (_ForecastoooRooms / TDays);

                                let _TotalRevenue =  element.TotalRevenue + element.FANDBRevenue + element.OtherRevenue + element.Outet1OtherRevenue + element.Outet2OtherRevenue + element.Outet3OtherRevenue + element.Outet4OtherRevenue+ element.Outet1FANDBRevenue + element.Outet2FANDBRevenue+ element.Outet3FANDBRevenue + element.Outet4FANDBRevenue + element.RestaurantRevenue + element.BarRevenue + element.BanquetRevenue + element.ParkingRevenue + element.GiftShopRevenue + element.BeverageRevenue + element.FoodRevenue;
                                if (_TotalRevenue != 0)
                                    totalrevenue = totalrevenue + (_TotalRevenue / TDays);
        
                            // })
                        }
                    })
                }

                // Last Year
                if (hoteldashboardcalculationsData_LastYear.length > 0) {
                    let lastDt = new Date(Utils.sameDayLastYear(dt));
                    // let objLastYear = hoteldashboardcalculationsData_LastYear.filter(d => {
                    //     var time = new Date(d.Date).getTime();
                    //     return (lastDt >= time && time <= lastDt);
                    // });
                    hoteldashboardcalculationsData_LastYear.forEach(element=>{
                        if(new Date(element.Date).setHours(0, 0, 0, 0)>=lastDt && new Date(element.Date).setHours(0, 0, 0, 0) <= lastDt ){
                           
                    // objLastYear.forEach(element => {
                        let todate = new Date(element.Date);
                        let fromdate = new Date(element.Date);
                        let TDays = Math.floor(todate - fromdate) + 1;

                        let _OccupancyLY = element.Occupancy == null ? 0 : element.Occupancy;
                        if (_OccupancyLY != 0)
                            occupancyly = occupancyly + (_OccupancyLY / TDays);

                        let _ADRLY = element.ADR == null ? 0 : element.ADR;
                        if (_ADRLY != 0)
                            adrly = adrly + (_ADRLY / TDays);

                        let _RevPARLY = element.RevPAR == null ? 0 : element.RevPAR;
                        if (_RevPARLY != 0)
                            revparly = revparly + (_RevPARLY / TDays);

                        let _RoomRevenueLY = element.TotalRevenue == null ? 0 : element.TotalRevenue;
                        if (_RoomRevenueLY != 0)
                            roomrevenuely = roomrevenuely + (_RoomRevenueLY / TDays);

                        let _FANDBRevenueLY = element.FANDBRevenue == null ? 0 : element.FANDBRevenue;
                        if (_FANDBRevenueLY != 0)
                            fbrevenuely = fbrevenuely + (_FANDBRevenueLY / TDays);

                        let _OtherRevenueLY = element.OtherRevenue == null ? 0 : element.OtherRevenue;
                        if (_OtherRevenueLY != 0)
                            otherrevenuely = otherrevenuely + (_OtherRevenueLY / TDays);

                        let _TotalRevenueLY = element.TotalRevenue + element.FANDBRevenue + element.OtherRevenue + element.Outet1OtherRevenue + element.Outet2OtherRevenue + element.Outet3OtherRevenue + element.Outet4OtherRevenue+ element.Outet1FANDBRevenue + element.Outet2FANDBRevenue+ element.Outet3FANDBRevenue + element.Outet4FANDBRevenue + element.RestaurantRevenue + element.BarRevenue + element.BanquetRevenue + element.ParkingRevenue + element.GiftShopRevenue + element.BeverageRevenue + element.FoodRevenue;
                        if (_TotalRevenueLY != 0)
                            totalrevenuely = totalrevenuely + (_TotalRevenueLY / TDays);

                        let _NoOfRoomSoldLY = element.NoOfRoomSold == null ? 0 : element.NoOfRoomSold;
                        if (_NoOfRoomSoldLY != 0)
                            noofroomsoldly = noofroomsoldly + (_NoOfRoomSoldLY / TDays);
                    
                       } 
                   })

                }

                // Current Year OOORooms
                if (hotelroomstatusdashboardcalculationsData.length > 0) {                   
                    hotelroomstatusdashboardcalculationsData.forEach(element=>{
                        if(new Date(element.Date).setHours(0, 0, 0, 0)>=dt && new Date(element.Date).setHours(0, 0, 0, 0) <= dt ){
                        
                    // objRoomsLastYear.forEach(element => {
                        let todate = new Date(element.Date);
                        let fromdate = new Date(element.Date);
                        let TDays = Math.floor(todate - fromdate) + 1;

                        let _CompRooms = element.CompRooms == null ? 0 : element.CompRooms;
                        if (_CompRooms != 0)
                            comprooms = comprooms + (_CompRooms / TDays);
                        
                        let _oooRooms = element.OutOfOrderRooms_NoCalc == null ? 0 : element.OutOfOrderRooms_NoCalc;
                        if (_oooRooms != 0)
                            ooorooms = ooorooms + (_oooRooms / TDays);
                        }
                    })
                }
                // Last Year OOORooms
                if (hotelroomstatusdashboardcalculationsData_LastYear.length > 0) {
                    let lastDt = new Date(Utils.sameDayLastYear(dt));
                   
                    hotelroomstatusdashboardcalculationsData_LastYear.forEach(element=>{
                        if(new Date(element.Date).setHours(0, 0, 0, 0)>=lastDt && new Date(element.Date).setHours(0, 0, 0, 0) <= lastDt ){
                        
                    // objRoomsLastYear.forEach(element => {
                        let todate = new Date(element.Date);
                        let fromdate = new Date(element.Date);
                        let TDays = Math.floor(todate - fromdate) + 1;

                        let _CompRoomsLY = element.CompRooms == null ? 0 : element.CompRooms;
                        if (_CompRoomsLY != 0)
                            comproomsly = comproomsly + (_CompRoomsLY / TDays);

                        let _OutOfOrderRoomsLY = element.OutOfOrderRooms_NoCalc == null ? 0 : element.OutOfOrderRooms_NoCalc;
                        if (_OutOfOrderRoomsLY != 0)
                            oooroomsly = oooroomsly + (_OutOfOrderRoomsLY / TDays);
                        }})
                }
                // Budget data
                if (hotelbudgetdashboardcalculationsData.length > 0) {
                    // let objBudget = hotelbudgetdashboardcalculationsData.filter(d => {
                    //     var time = new Date(d.Date).getTime();
                    //     return (dt >= time && time <= dt);
                    // });

                    hotelbudgetdashboardcalculationsData.forEach(element=>{
                        if(new Date(element.Date).setHours(0, 0, 0, 0)>=dt && new Date(element.Date).setHours(0, 0, 0, 0) <= dt ){
                           
                    // objBudget.forEach(element => {
                        let todate = new Date(element.Date);
                        let fromdate = new Date(element.Date);
                        let TDays = Math.floor(todate - fromdate) + 1;

                        let _BudgetOccupancy = element.BudgetOccupancy == null ? 0 : element.BudgetOccupancy;
                        if (_BudgetOccupancy != 0)
                            budgetoccupancy = budgetoccupancy + (_BudgetOccupancy / TDays);

                        let _BudgetADR = element.BudgetADR == null ? 0 : element.BudgetADR;
                        if (_BudgetADR != 0)
                            budgetadr = budgetadr + (_BudgetADR / TDays);

                        //let _BudgetRevPAR = element.BudgetRevPAR == null ? 0 : element.BudgetRevPAR;
                        budgetrevpar = budgetrevpar + ((_BudgetADR*_BudgetOccupancy)/100);

                        let _BudgetRoomRevenue = element.BudgetRoomRevenue == null ? 0 : element.BudgetRoomRevenue;
                        if (_BudgetRoomRevenue != 0)
                            budgetroomrevenue = budgetroomrevenue + (_BudgetRoomRevenue / TDays);

                        let _BudgetFBRevenue = element.BudgetFBRevenue == null ? 0 : element.BudgetFBRevenue;
                        if (_BudgetFBRevenue != 0)
                            budgetfbrevenue = budgetfbrevenue + (_BudgetFBRevenue / TDays);

                        let _BudgetOtherRevenue = element.BudgetOtherRevenue == null ? 0 : element.BudgetOtherRevenue;
                        if (_BudgetOtherRevenue != 0)
                            budgetotherrevenue = budgetotherrevenue + (_BudgetOtherRevenue / TDays);

                        let _BudgetTotalRevenue = element.BudgetRoomRevenue + element.BudgetFANDBRevenue + element.BudgetOtherRevenue
                        if (_BudgetTotalRevenue != 0)
                            budgettotalrevenue = budgettotalrevenue + (_BudgetTotalRevenue / TDays);

                        let _BudgetNoOfRoomSold = element.BudgetRoomSold == null ? 0 : element.BudgetRoomSold;
                        if (_BudgetNoOfRoomSold != 0)
                            budgetnoofroomsold = budgetnoofroomsold + (_BudgetNoOfRoomSold / TDays);

                        let _BudgetCompRooms = element.BudgetCompRooms == null ? 0 : element.BudgetCompRooms;
                        if (_BudgetCompRooms != 0)
                            budgetcomprrooms = budgetcomprrooms + (_BudgetCompRooms / TDays);

                        let _BudgetoooRooms = element.BudgetoooRooms == null ? 0 : element.BudgetoooRooms;
                        if (_BudgetoooRooms != 0)
                            budgetooorooms = budgetooorooms + (_BudgetoooRooms / TDays);
                       

                        let _ForecastRoomSold = element.ForecastRoomSold == null ? 0 : element.ForecastRoomSold;
                        if (_ForecastRoomSold != 0)
                            forecastroomsold = forecastroomsold + (_ForecastRoomSold / TDays);
                    }
                    })
                }

                let objTransChartdata = new Trendschartdata();
                objTransChartdata.currentdt = moment(dt).format('ll');
                objTransChartdata.occupancy = occupancy;
                objTransChartdata.forecastoccupancy = forecastoccupancy;
                objTransChartdata.adr = adr;
                objTransChartdata.forecastadr = forecastadr;
                objTransChartdata.revpar = revpar;
                objTransChartdata.forecastrevpar = forecastrevpar;
                objTransChartdata.roomrevenue = roomrevenue;
                objTransChartdata.forecastroomrevenue = forecastroomrevenue;
                objTransChartdata.fbrevenue = fbrevenue;
                objTransChartdata.forecastfbrevenue = forecastfbrevenue;
                objTransChartdata.otherrevenue = otherrevenue;
                objTransChartdata.forecastotherrevenue = forecastotherrevenue;
                objTransChartdata.forecasttotalrevenue = forecasttotalrevenue;
                objTransChartdata.noofroomsold = noofroomsold;
                objTransChartdata.comprooms = comprooms;
                objTransChartdata.forecastcomprooms = forecastcomprooms;
                objTransChartdata.ooorooms = ooorooms;
                objTransChartdata.forecastooorooms = forecastooorooms;

                objTransChartdata.occupancyly = occupancyly;
                objTransChartdata.adrly = adrly;
                objTransChartdata.revparly = revparly;
                objTransChartdata.roomrevenuely = roomrevenuely;
                objTransChartdata.fbrevenuely = fbrevenuely;
                objTransChartdata.otherrevenuely = otherrevenuely;
                objTransChartdata.totalrevenuely = totalrevenuely;
                objTransChartdata.totalrevenue = totalrevenue;
                objTransChartdata.noofroomsoldly = noofroomsoldly;
                objTransChartdata.comproomsly = comproomsly;
                objTransChartdata.oooroomsly = oooroomsly;
                objTransChartdata.forecastnoofroomsold =forecastroomsold;
                objTransChartdata.budgetoccupancy = budgetoccupancy;
                objTransChartdata.budgetadr = budgetadr;
                objTransChartdata.budgetrevpar = budgetrevpar;
                objTransChartdata.budgetroomrevenue = budgetroomrevenue;
                objTransChartdata.budgetfbrevenue = budgetfbrevenue;
                objTransChartdata.budgetotherrevenue = budgetotherrevenue;
                objTransChartdata.budgettotalrevenue = budgettotalrevenue;
                objTransChartdata.budgetnoofroomsold = budgetnoofroomsold;
                objTransChartdata.budgetcomprrooms = budgetcomprrooms;
                objTransChartdata.budgetooorooms = budgetooorooms;
                objTransChartdata = objTransChartdata.setFormat(objTransChartdata);

                lstTranslineItem.push(objTransChartdata);
                startdate = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate() + 1);// Will increase month if over range
            }

            cb(null, lstTranslineItem);

        }, err => {
            return cb(err);
        })
    }


    static getChartData_GraphQL(userid, hotelid, reportdate, period, cb) {

        return UserHelper.getUserData(userid, (err, userdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    TrendsHelper.getChartData(hoteldata.ID, reportdate, period, userdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }
}

module.exports = TrendsHelper;