
const { CreatePropertyDashboardTableMapping: CreatePropertyDashboardTableMappingSchema, SchemaField: CreatePropertyDashboardTableMappingSchemaFields } = require('../models/createpropertydashboardtablemappings');
const { PropertyChartConfig: PropertyChartConfigSchema, SchemaField: PropertyChartConfigSchemaFields } = require('../models/propertychartconfig');

const dbtable = require('../schema/db_table');
const SequenceHelper = require('./sequence_helper');
const RESTHelper = require('./rest_helper');
const Constants = require('../common/constants');
const PropertyDashboardTableData = require('../property/models/propertydashboardtabledata');
const PropertyChartConfigData = require('../property/models/propertychartconfigdata');
var log = require('log4js').getLogger("CreatePropertyDashboardTableMappingHelper");


class CreatePropertyDashboardTableMappingHelper {

    static GetPropertyDashboardTableMapping(userId,cb){
          
        return CreatePropertyDashboardTableMappingSchema.find({
            [CreatePropertyDashboardTableMappingSchemaFields.UserID]: userId
        }).sort({ [CreatePropertyDashboardTableMappingSchemaFields.DiplayOrder]: -1 }).exec(function (err, result2) {
            if (err) {
                log.error(err);
            }
            
            var lstPropertyTable=[];
            if(result2.length > 0){
                result2.forEach((element, index) => {
                    var PropertyTable = new PropertyDashboardTableData();
                    PropertyTable.id = element.ID,
                    PropertyTable.columname = element.ColumName,
                    PropertyTable.columperiod = element.ColumPeriod,
                    PropertyTable.displayorder = element.DisplayOrder,
                    PropertyTable.userid = element.UserID
                    lstPropertyTable.push(PropertyTable);
                });
                return cb(null, lstPropertyTable);
            }
            else{
                var columns = [];
                var lstColumns = [];
                columns.push({ columname: "Actual",columperiod:"MTD" });
                columns.push({ columname: "LastYear",columperiod:"MTD" });
                columns.push({ columname: "LastYear",columperiod:"YTD" });
                columns.push({ columname: "Budget",columperiod:"MTD" });
                columns.push({ columname: "Actual",columperiod:"Current" });
                columns.push({ columname: "Forecast",columperiod:"MTD" });
                columns.push({ columname: "Forecast",columperiod:"YTD" });
                columns.push({ columname: "VarianceToBudget",columperiod:"MTD" });
                columns.push({ columname: "VarianceToForecast",columperiod:"MTD" });
                var today = new Date();
                var disInd = 1;
                var resultInd = 1;
                columns.forEach(function (item) {

                    log.debug('Call addColumns, userid:' + userId + 'columname:' + item.columname + 'columperiod:' + item.columperiod);
                
                    //InsertCreateOwnTableMapping
                    SequenceHelper.getValueForNextSequence(dbtable.CREATEPROPERTYDASHBOARDTABLEMAPPINGS, (err, seq_result) => {
                        if (seq_result) {
                            let id = parseInt(seq_result);

                            var createpropertytablemappings = {
                                [CreatePropertyDashboardTableMappingSchemaFields.ID]: id,
                                [CreatePropertyDashboardTableMappingSchemaFields.DisplayOrder]: disInd,
                                [CreatePropertyDashboardTableMappingSchemaFields.ColumName]: item.columname,
                                [CreatePropertyDashboardTableMappingSchemaFields.ColumPeriod]: item.columperiod,
                                [CreatePropertyDashboardTableMappingSchemaFields.UserID]: userId
                            };

                            let createpropertytablemappingsSchema = new CreatePropertyDashboardTableMappingSchema(createpropertytablemappings);
                            createpropertytablemappingsSchema.save((err, createpropertytablemapping_result) => {
                                if (err)
                                    return cb(err, null);
                                else {

                                    var PropertyTable = new PropertyDashboardTableData();
                                    PropertyTable.id = createpropertytablemapping_result.ID,
                                    PropertyTable.columname = createpropertytablemapping_result.ColumName,
                                    PropertyTable.columperiod = createpropertytablemapping_result.ColumPeriod,
                                    PropertyTable.displayorder = createpropertytablemapping_result.DisplayOrder,
                                    PropertyTable.userid = createpropertytablemapping_result.UserID
                                    lstColumns.push(PropertyTable)
                                }
                                resultInd++;
                                if(disInd == 10){
                                    return cb(null, lstColumns);
                                }
                            })
                            disInd++;
                        }
                    });

                    
                })

                
            }            
            
        });       
    }

    static addAndGetPropertyTableDefaultColumns(userid,cb) {

        var columns = [];
        var lstColumns = [];
        columns.push({ columname: "Actual",columperiod:"MTD" });
        columns.push({ columname: "LastYear",columperiod:"MTD" });
        columns.push({ columname: "LastYear",columperiod:"YTD" });
        columns.push({ columname: "Budget",columperiod:"MTD" });
        columns.push({ columname: "Actual",columperiod:"Current" });
        columns.push({ columname: "Forecast",columperiod:"MTD" });
        columns.push({ columname: "Forecast",columperiod:"YTD" });
        columns.push({ columname: "VarianceToBudget",columperiod:"MTD" });
        columns.push({ columname: "VarianceToForecast",columperiod:"MTD" });
        var today = new Date();
        var disInd = 1;
        columns.forEach(function (item) {

            log.debug('Call addColumns, userid:' + userid + 'columname:' + item.columname + 'columperiod:' + item.columperiod);
        
            //InsertCreateOwnTableMapping
            SequenceHelper.getValueForNextSequence(dbtable.CREATEPROPERTYDASHBOARDTABLEMAPPINGS, (err, seq_result) => {
                if (seq_result) {
                    let id = parseInt(seq_result);

                    var createpropertytablemappings = {
                        [CreatePropertyDashboardTableMappingSchemaFields.ID]: id,
                        [CreatePropertyDashboardTableMappingSchemaFields.DisplayOrder]: disInd,
                        [CreatePropertyDashboardTableMappingSchemaFields.ColumName]: item.columname,
                        [CreatePropertyDashboardTableMappingSchemaFields.ColumPeriod]: item.columperiod,
                        [CreatePropertyDashboardTableMappingSchemaFields.UserID]: userid
                    };

                    let createpropertytablemappingsSchema = new CreatePropertyDashboardTableMappingSchema(createpropertytablemappings);
                    createpropertytablemappingsSchema.save((err, createpropertytablemapping_result) => {
                        if (err)
                            return cb(err, null);
                        else {

                            var PropertyTable = new PropertyDashboardTableData();
                            PropertyTable.id = createpropertytablemapping_result.ID,
                            PropertyTable.columname = createpropertytablemapping_result.ColumName,
                            PropertyTable.columperiod = createpropertytablemapping_result.ColumPeriod,
                            PropertyTable.displayorder = createpropertytablemapping_result.DisplayOrder,
                            PropertyTable.userid = createpropertytablemapping_result.UserID
                            lstColumns.push(PropertyTable)
                        }
                    })
                    disInd++;
                }
            });
        })
        
        return cb(null, lstColumns);
    }

    static addPropertyTableColumns(userid, columname, columperiod, displayorder, cb) {

        log.debug('Call addColumns, userid:' + userid + 'columname:' + columname + 'columperiod:' + columperiod);
        var today = new Date();

                //InsertCreateOwnTableMapping
                SequenceHelper.getValueForNextSequence(dbtable.CREATEPROPERTYDASHBOARDTABLEMAPPINGS, (err, seq_result) => {
                    if (seq_result) {
                        let id = parseInt(seq_result);

                        var createpropertytablemappings = {
                            [CreatePropertyDashboardTableMappingSchemaFields.ID]: id,
                            [CreatePropertyDashboardTableMappingSchemaFields.DisplayOrder]: displayorder,
                            [CreatePropertyDashboardTableMappingSchemaFields.ColumName]: columname,
                            [CreatePropertyDashboardTableMappingSchemaFields.ColumPeriod]: columperiod,
                            [CreatePropertyDashboardTableMappingSchemaFields.UserID]: userid
                        };

                        let createpropertytablemappingsSchema = new CreatePropertyDashboardTableMappingSchema(createpropertytablemappings);
                        createpropertytablemappingsSchema.save((err, createpropertytablemapping_result) => {
                            if (err)
                                return cb(err, null);
                            else {

                                var PropertyTable = new PropertyDashboardTableData();
                                PropertyTable.id = createpropertytablemapping_result.ID,
                                PropertyTable.columname = createpropertytablemapping_result.ColumName,
                                PropertyTable.columperiod = createpropertytablemapping_result.ColumPeriod,
                                PropertyTable.displayorder = createpropertytablemapping_result.DisplayOrder,
                                PropertyTable.userid = createpropertytablemapping_result.UserID
                                return cb(null, PropertyTable);
                            }
                        })

                    }
                    else {
                        return cb(new Error(HttpMsg.internalErrorMsg), null);
                    }
                });

    }
    
    static removePropertyTableColumn(userid, columname, columperiod, cb) {

        log.debug('Call removeKPIColumn, userid:' + userid + 'columname:' + columname + 'columperiod:' + columperiod);

        //remove it from CreatePropertyDashboardTableMappingSchema
        CreatePropertyDashboardTableMappingSchema.deleteOne({
            $and: [
                { [CreatePropertyDashboardTableMappingSchemaFields.ColumName]: columname },
                { [CreatePropertyDashboardTableMappingSchemaFields.ColumPeriod]: columperiod },
                { [CreatePropertyDashboardTableMappingSchemaFields.UserID]: userid }
            ]}, (err, result) => {
            if (err) {
                log.error(err);
            }

            cb(null, result);
        })
    }

    static reorderTableColumn(userid, columname, columperiod, displayordercounter, cb) {

        log.debug('Call reorderTableColumn, userid:' + userid + 'columname:' + columname + 'columperiod:' + columperiod + 'displayordercounter' + displayordercounter);
        
        CreatePropertyDashboardTableMappingSchema.findOneAndUpdate(
            {
                 [CreatePropertyDashboardTableMappingSchemaFields.ColumName]: columname ,
                 [CreatePropertyDashboardTableMappingSchemaFields.ColumPeriod]: columperiod ,
                 [CreatePropertyDashboardTableMappingSchemaFields.UserID]: userid 
            },
            {
                [CreatePropertyDashboardTableMappingSchemaFields.DisplayOrder]: displayordercounter
            },
            {
                new: true
            }
        ).exec((err, result) => {
            cb(null, result);
        })

    }

    static updateTableColumn(userid, oldcolumname, oldcolumperiod,newcolumname, newcolumperiod, cb) {
        log.debug('Call updateTableColumn, userid:' + userid + 'oldcolumname: ' + oldcolumname + "oldcolumperiod:" + oldcolumperiod + "newcolumname" + newcolumname);
        var today = new Date();

        //CreatePropertyDashboardTableMappingSchema
        CreatePropertyDashboardTableMappingSchema.findOneAndUpdate(
            {
                [CreatePropertyDashboardTableMappingSchemaFields.ColumName]: oldcolumname ,
                [CreatePropertyDashboardTableMappingSchemaFields.ColumPeriod]: oldcolumperiod,
                [CreatePropertyDashboardTableMappingSchemaFields.UserID]: userid 
            },
            {
                [CreatePropertyDashboardTableMappingSchemaFields.ColumName]: newcolumname ,
                [CreatePropertyDashboardTableMappingSchemaFields.ColumPeriod]: newcolumperiod,
            },
            {
                new: true
            }
        ).exec((err, result) => {           
            if (err) {
                log.error(err);
            }
            var lstPropertyTable=[];
            if(result){
                var PropertyTable = new PropertyDashboardTableData();
                PropertyTable.id = result.ID,
                PropertyTable.columname = result.ColumName,
                PropertyTable.columperiod = result.ColumPeriod,
                PropertyTable.displayorder = result.DisplayOrder,
                PropertyTable.userid = result.UserID
                lstPropertyTable.push(PropertyTable);
            }
            return cb(null, PropertyTable);
        })
    }
    //-----------Property Chart config ---------------------

    static createOrUpdatePropertyChartConfig(id,userid, widgetname, charttype, chartperiod,comparechartdata, cb) {

        PropertyChartConfigSchema.findOne({ [PropertyChartConfigSchemaFields.ID]: id }, (err, config) => {
            if (err) {
                log.error(err);
            }
            if (!config) {
               //#region 
                //InsertCreateOwnTableMapping
                log.debug('Call Create PropertyChartConfig, userid:' + userid + 'ChartType:' + charttype + 'WidgetName:' + widgetname);
                SequenceHelper.getValueForNextSequence(dbtable.PROPERTYCHARTCONFIG, (err, seq_result) => {
                    if (seq_result) {
                        let id = parseInt(seq_result);

                        var propertychartconfig = {
                            [PropertyChartConfigSchemaFields.ID]: id,
                            [PropertyChartConfigSchemaFields.WidgetName]: widgetname,
                            [PropertyChartConfigSchemaFields.ChartType]: charttype,
                            [PropertyChartConfigSchemaFields.ChartPeriod]: chartperiod,
                            [PropertyChartConfigSchemaFields.CompareChartData]: comparechartdata,
                            [PropertyChartConfigSchemaFields.UserID]: userid
                        };

                        let propertychartconfigSchema = new PropertyChartConfigSchema(propertychartconfig);
                        propertychartconfigSchema.save((err, config_result) => {
                            if (err)
                                return cb(err, null);
                            else {

                                var PropertyChart = new PropertyChartConfigData();
                                PropertyChart.id = config_result.ID,
                                PropertyChart.widgetname = config_result.WidgetName,
                                PropertyChart.charttype = config_result.ChartType,
                                PropertyChart.chartperiod = config_result.ChartPeriod,                                
                                PropertyChart.comparechartdata = config_result.CompareChartData,
                                PropertyChart.userid = config_result.UserID
                                return cb(null, PropertyChart);
                            }
                        })

                    }
                    else {
                        return cb(new Error(HttpMsg.internalErrorMsg), null);
                    }
                });
               //#endregion
            }
            else {
                log.debug('Call update PropertyChartConfig, userid:' + userid + 'ID:' + id + 'WidgetName:' + widgetname);
       
                PropertyChartConfigSchema.findOneAndUpdate(                    
                    {
                        [PropertyChartConfigSchemaFields.ID]: id,
                        //[PropertyChartConfigSchemaFields.UserID]: userid,
                    },
                    {
                        [PropertyChartConfigSchemaFields.WidgetName]: widgetname,
                        [PropertyChartConfigSchemaFields.ChartType]: charttype,
                        [PropertyChartConfigSchemaFields.ChartPeriod]: chartperiod,
                        [PropertyChartConfigSchemaFields.CompareChartData]: comparechartdata 
                    },
                    {
                        new: true
                    }
                ).exec((err, result) => {           
                    if (err) {
                        log.error(err);
                    }
                    
                    if(result){
                        var PropertyChart = new PropertyChartConfigData();
                        PropertyChart.id = result.ID,
                        PropertyChart.widgetname = result.WidgetName,
                        PropertyChart.charttype = result.ChartType,
                        PropertyChart.chartperiod = result.ChartPeriod,                                
                        PropertyChart.comparechartdata = result.CompareChartData,
                        PropertyChart.userid = result.UserID
                        return cb(null, PropertyChart);
                    }
                })
            }
        });
    }

    static getPropertyChartConfigById(id, cb) {
        var PropertyChart = new PropertyChartConfigData();
        return  PropertyChartConfigSchema.findOne({ [PropertyChartConfigSchemaFields.ID]: id }, (err, config_result) => {
            if (err) {
                log.error(err);
            }
            if (!config_result) {
                kpiData.kpikey = 'kpi not found';
            }
            else {                
                PropertyChart.id = config_result.ID,
                PropertyChart.widgetname = config_result.WidgetName,
                PropertyChart.charttype = config_result.ChartType,
                PropertyChart.chartperiod = config_result.ChartPeriod,                                
                PropertyChart.comparechartdata = config_result.CompareChartData,
                PropertyChart.userid = config_result.UserID
            }
            cb(null, PropertyChart);
        });
    }
    static getPropertyChartConfigByUserId(userId, cb) {
        var lstChartConfigData = [];
        return PropertyChartConfigSchema.find({
            $and: [{ [PropertyChartConfigSchemaFields.UserID]: userId },]
        }, (err, result) => {
            if (err) {
                log.error(err);
            }
            if (result.length <= 0) {
                return cb('kpinotfound', null);
            }
            else {
                result.forEach((element, index) => {
                    var PropertyChart = new PropertyChartConfigData();
                    PropertyChart.id = element.ID,
                    PropertyChart.widgetname = element.WidgetName,
                    PropertyChart.charttype = element.ChartType,
                    PropertyChart.chartperiod = element.ChartPeriod,                                
                    PropertyChart.comparechartdata = element.CompareChartData,
                    PropertyChart.userid = element.UserID
                    lstChartConfigData.push(PropertyChart);
                });
                cb(null, lstChartConfigData);
            }

        });
    }
    static deletePropertyChartConfig(id, cb) {
        PropertyChartConfigSchema.deleteOne({ [PropertyChartConfigSchemaFields.ID]: id }, (err, result) => {
            if (err) {
                log.error(err);
            }

            cb(null, result);
        })
    }
}

module.exports = CreatePropertyDashboardTableMappingHelper;
