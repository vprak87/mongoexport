const { Hotelbudgetdashboardcalculations: HotelbudgetdashboardcalculationsSchema, SchemaField: HotelbudgetdashboardcalculationsSchemaFields } = require('../models/hotelbudgetdashboardcalculations');

var log = require('log4js').getLogger("hotelbudgetdashboardcalculations_helper");

class HotelbudgetdashboardcalculationsHelper {

    static GetData(hotelid, reportdate, cb) {

        log.debug('Call GetData, hotelid:' + hotelid + "reportdate:" + reportdate);

        let start = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate());
        let end = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate() + 1);

        return HotelbudgetdashboardcalculationsSchema.findOne({
            [HotelbudgetdashboardcalculationsSchemaFields.HotelID]: hotelid,
            [HotelbudgetdashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetData result not found");
            }
            return cb(null, result);
        });
    }

    static GetLatestMTDData(hotelid, reportdate, startdate_mtd, cb) {

        log.debug('Call GetData, hotelid:' + hotelid + "reportdate:" + reportdate + "startdate_mtd:" + startdate_mtd);

        let start = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate());
        let end = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate() + 1);

        return HotelbudgetdashboardcalculationsSchema.findOne({
            [HotelbudgetdashboardcalculationsSchemaFields.HotelID]: hotelid,
            [HotelbudgetdashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetLatestMTDData result not found, checking for latest MTD data");
                let start_mtd = new Date(startdate_mtd.getFullYear(), startdate_mtd.getMonth(), startdate_mtd.getDate());

                //check for latest MTD data
                return HotelbudgetdashboardcalculationsSchema.find({
                    [HotelbudgetdashboardcalculationsSchemaFields.HotelID]: hotelid,
                    [HotelbudgetdashboardcalculationsSchemaFields.Date]: {
                        $gte: start_mtd,
                        $lt: end
                    }
                }).sort({ [HotelbudgetdashboardcalculationsSchemaFields.Date]: -1 }).limit(1).exec(function (err, result2) {
                    if (err) {
                        log.error(err);
                    }
                    if (!result2) {
                        //check for latest MTD data
                        log.debug("GetLatestMTDData result not found");
                        return cb("data not found", null);

                    }
                    return cb(null, result2[0]);
                });
            }
            else {
                return cb(null, result);
            }
        });
    }

    static GetDataBetweenDate(hotelid, startdate, enddate, cb) {

        log.debug('Call GetDataBetweenDate, hotelid:' + hotelid + "startdate:" + startdate + "enddate:" + enddate);

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        return HotelbudgetdashboardcalculationsSchema.find({
            [HotelbudgetdashboardcalculationsSchemaFields.HotelID]: hotelid,
            [HotelbudgetdashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetDataBetweenDate result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }



    static GetLatestPortfolioDataByRange(lsthotelids, reportdate, reportenddate, cb) {

        log.debug("Call GetLatestPortfolioDataByRange, reportdate:" + reportdate);

        let start = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate());
        let end = new Date(reportenddate.getFullYear(), reportenddate.getMonth(), reportenddate.getDate() + 1);

        return HotelbudgetdashboardcalculationsSchema.find({

            [HotelbudgetdashboardcalculationsSchemaFields.HotelID]: {
                $in: lsthotelids
            },
            [HotelbudgetdashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetLatestPortfolioDataByRange result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }


    static GetLatestPortfolioData(lsthotelids, reportdate, cb) {

        log.debug("Call GetLatestPortfolioData, reportdate:" + reportdate);

        let start = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate());
        let end = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate() + 1);

        return HotelbudgetdashboardcalculationsSchema.find({

            [HotelbudgetdashboardcalculationsSchemaFields.HotelID]: {
                $in: lsthotelids
            },
            [HotelbudgetdashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetLatestPortfolioData result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }


}
module.exports = HotelbudgetdashboardcalculationsHelper;

