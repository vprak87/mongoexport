const Utils = require('../common/utils');
const Constants = require('../common/constants');

const { User: UserSchema, SchemaField: UserSchemaFields } = require('../models/user');
const { Dashboardsetting: DashboardsettingSchema, SchemaField: DashboardsettingSchemaFields } = require('../models/dashboardsetting');
const { Userhotelxref: UserhotelxrefSchema, SchemaField: UserhotelxrefSchemaField } = require('../models/userhotelxref');


var log = require('log4js').getLogger("user_helper");

class UserHelper {

    static login(email, password, cb) {
        email = email.toLowerCase();

        return UserSchema.findOne({ [UserSchemaFields.UserName]: email }, (err, user) => {
            if (err) {
                log.error(err);
            }
            if (!user) {
                return cb('user not found',null);
            }
            var encodedpassword = Utils.encode(password);
            var ispwdmatches = Utils.compare(encodedpassword, user.Password);
            if (ispwdmatches == true) {
                return cb(null, user);
            }
            else {
                return cb('password not found',null);
            }
        });
    }

    static getUserConfigData(id, cb) {

        return DashboardsettingSchema.findOne({ [DashboardsettingSchemaFields.UserID]: id }, (err, userconfigdata) => {
            if (err) {
                log.error(err);
            }
            if (!userconfigdata) {
                return cb('userconfigdata not found', null);//TBD send default values
            }
            cb(null, userconfigdata);
        });
    }
    static saveUserConfigData_Labor(data, cb) {

        return DashboardsettingSchema.findOneAndUpdate(
            {
                [DashboardsettingSchemaFields.UserID]: data.userid,
            },
            {
                [DashboardsettingSchemaFields.LaborSection1]: data.laborsection1,
                [DashboardsettingSchemaFields.LaborSection2]: data.laborsection2,
                [DashboardsettingSchemaFields.PayrollDepartmentWise]: data.payrolldepartmentwise,
                [DashboardsettingSchemaFields.PayrollVsRevenueVsOcc]: data.payrollvsrevenuevsocc,
                [DashboardsettingSchemaFields.ActualVsPayrollChart]: data.actualvspayrollchart,
                [DashboardsettingSchemaFields.HouseKeepingWidget]: data.housekeepingwidget,
                [DashboardsettingSchemaFields.PayrollActualvsPlanHoursWidget]: data.payrollactualvsplanhourswidget,
                [DashboardsettingSchemaFields.PayrollActualvsPlanWagesWidget]: data.payrollactualvsplanwageswidget,
                [DashboardsettingSchemaFields.DefaultWeekDay]: data.defaultweekday
            },
            {
                new: true
            }
        ).exec((err, result) => {
            cb(null, result);
        })

    }


    static saveUserConfigData_Scorecard(data, cb) {

        return DashboardsettingSchema.findOneAndUpdate(
            {
                [DashboardsettingSchemaFields.UserID]: data.userid,
            },
            {
                [DashboardsettingSchemaFields.ScorecardRevenueWidget]: data.scorecardrevenuewidget,
                [DashboardsettingSchemaFields.ScorecardSTRWidget]: data.scorecardstrwidget,
                [DashboardsettingSchemaFields.ScorecardLabourWidget]: data.scorecardlabourwidget,
                [DashboardsettingSchemaFields.ScorecardProfitWidget]: data.scorecardprofitwidget,
                [DashboardsettingSchemaFields.ScorecardServiceWidget]: data.scorecardservicewidget,
                [DashboardsettingSchemaFields.ScorecardTotalRevenuePer]: data.scorecardtotalrevenueper,
                [DashboardsettingSchemaFields.ScorecardSTRCurrentMonthPer]: data.scorecardstrcurrentmonthper,
                [DashboardsettingSchemaFields.ScorecardLabourPORVariance]: data.scorecardlabourporvariance,
                [DashboardsettingSchemaFields.ScorecardServiceScore]: data.scorecardservicescore,
                [DashboardsettingSchemaFields.ScorecardServiceWeightedPer]: data.scorecardserviceweightedper
            },
            {
                new: true
            }
        ).exec((err, result) => {
            cb(null, result);
        })

    }
    static saveUserConfigData_Property(data, cb) {

        return DashboardsettingSchema.findOneAndUpdate(
            {
                [DashboardsettingSchemaFields.UserID]: data.userid,
            },
            {
                [DashboardsettingSchemaFields.RollingRevenueComparision]: data.rollingrevenuecomparision,
                [DashboardsettingSchemaFields.RevenueBreakdowan]: data.revenuebreakdowan,
                [DashboardsettingSchemaFields.ActVsBudVsLastYr]: data.actvsbudvslastyr,
                [DashboardsettingSchemaFields.ADRVsRevPAR]: data.adrvsrevpar,
                [DashboardsettingSchemaFields.DashboardOcc]: data.dashboardocc,
                [DashboardsettingSchemaFields.DashboardADR]: data.dashboardadr,
                [DashboardsettingSchemaFields.DashboardRevPAR]: data.dashboardrevpar,
                [DashboardsettingSchemaFields.MembershipStays]: data.membershipstays,
                [DashboardsettingSchemaFields.DashboardMarketCurrentVsLastYear]: data.dashboardmarketcurrentvslastyear,
                [DashboardsettingSchemaFields.CashWidget]: data.cashwidget,
                [DashboardsettingSchemaFields.GuestLedgerWidget]: data.guestledgerwidget,
                [DashboardsettingSchemaFields.PayrollActualvsPlanWidget]: data.payrollactualvsplanwidget,
                [DashboardsettingSchemaFields.STRWidget]: data.strwidget,
                [DashboardsettingSchemaFields.TripadvisorRatingWidget]: data.tripadvisorratingwidget,
                [DashboardsettingSchemaFields.GooglePlaceRatingWidget]: data.googleplaceratingwidget,
                [DashboardsettingSchemaFields.FacebookPageWidget]: data.facebookpagewidget,
                [DashboardsettingSchemaFields.YelpReviewWidget]: data.yelpreviewwidget,
                [DashboardsettingSchemaFields.WeatherWidget]: data.weatherwidget,
                [DashboardsettingSchemaFields.ARAgingWidget]: data.aragingwidget,
                [DashboardsettingSchemaFields.GSSPriority]: data.gsspriority,
                [DashboardsettingSchemaFields.OOOCompWidget]: data.ooocompwidget,
                [DashboardsettingSchemaFields.TotalProfit]: data.totalprofit,
                [DashboardsettingSchemaFields.TotalExpenseBreakdown]: data.totalexpensebreakdown,
                [DashboardsettingSchemaFields.ExpenseBudgetDepartment]: data.expensebudgetdepartment,
                [DashboardsettingSchemaFields.ExpenseBudgetCategory]: data.expensebudgetcategory,
                [DashboardsettingSchemaFields.InvoicevsCreditcard]: data.invoicevscreditcard,
                [DashboardsettingSchemaFields.ExpenseFormByGLCode]: data.expenseformbyglcode,
            },
            {
                new: true
            }
        ).exec((err, result) => {
            cb(null, result);
        })

    }

    static saveUserConfigData_SingleProperty(data, configkey, configvalue, cb) {

        configkey = configkey.toLowerCase();

        if (configkey == Constants.PropertyPageCharts.RollingRevenueComparision) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.RollingRevenueComparision]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.RevenueBreakdowan) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.RevenueBreakdowan]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.ActVsBudVsLastYr) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.ActVsBudVsLastYr]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.ADRVsRevPAR) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.ADRVsRevPAR]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.DashboardOcc) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.DashboardOcc]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.DashboardADR) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.DashboardADR]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.DashboardRevPAR) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.DashboardRevPAR]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.MembershipStays) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.MembershipStays]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.DashboardMarketCurrentVsLastYear) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.DashboardMarketCurrentVsLastYear]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.CashWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.CashWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.GuestLedgerWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.GuestLedgerWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.PayrollActualvsPlanWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.PayrollActualvsPlanWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.STRWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.STRWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.TripadvisorRatingWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.TripadvisorRatingWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.GooglePlaceRatingWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.GooglePlaceRatingWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.FacebookPageWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.FacebookPageWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.YelpReviewWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.YelpReviewWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.WeatherWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.WeatherWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.ARAgingWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.ARAgingWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.GSSPriority) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.GSSPriority]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.OOOCompWidget) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.OOOCompWidget]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.TotalProfit) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.TotalProfit]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.TotalExpenseBreakdown) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.TotalExpenseBreakdown]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.ExpenseBudgetDepartment) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.ExpenseBudgetDepartment]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.ExpenseBudgetCategory) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.ExpenseBudgetCategory]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.InvoicevsCreditcard) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.InvoicevsCreditcard]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }
        else if (configkey == Constants.PropertyPageCharts.ExpenseFormByGLCode) {

            return DashboardsettingSchema.findOneAndUpdate(
                {
                    [DashboardsettingSchemaFields.UserID]: data.userid,
                },
                {
                    [DashboardsettingSchemaFields.ExpenseFormByGLCode]: configvalue,
                },
                {
                    new: true
                }
            ).exec((err, result) => {
                cb(null, result);
            })
        }

    }



    //TODO
    // created a public function to retrieve hotelID for user
    static getHotelListByUserIdFromSession(hotelId, cb) {
        return UserhotelxrefSchema.findOne({ [UserhotelxrefSchemaField.HotelID]: hotelId }, [UserhotelxrefSchemaField.HotelID], (err, result) => {
            if (err) {
                log.error(err)
            }
            if (!result) {
                return cb("User Hotel xref data not found ", null);
            }
            return cb(null, result);
        });
    }

    static getUserData(id, cb) {
        return UserSchema.findOne({ [UserSchemaFields.ID]: id }, (err, user) => {
            if (err) {
                log.error(err);
            }
            if (!user) {
                return cb('user not found', null);
            }
            cb(null, user);
        });
    }
}
module.exports = UserHelper;

