const { Templatemarsters: TemplatemarstersSchema, SchemaField: TemplatemarstersSchemaFields } = require('../models/templatemarsters');

const { PersonalViews: PersonalviewsSchema, SchemaField: PersonalviewsSchemaFields } = require('../models/personalviews');

const { KpiMarsters : KpimarstersSchema, SchemaField: KpimarstersSchemaFields } = require('../models/kpimarsters');

const { TemplatemasterMappings : TemplateMasterMappingsSchema, SchemaField: TemplateMasterMappingsSchemaFields } = require('../models/templatemastermappings');

const { Graphmasters : GraphmastersSchema, SchemaField: GraphmastersSchemaFields } = require('../models/graphmarsters');

const HotelGroupXrefHelper = require('./hotelgroupxref_helper');

const Hotelshelper = require('./hotels_helper');

const HotelGroupHelper = require('./hotelgroup_helper');

const HoteldashboardcalculationsHelper = require('./hoteldashboardcalculations_helper');

const HotelbudgetdashboardcalculationsHelper = require('./hotelbudgetdashboardcalculations_helper');

const HotelroomstatusdashboardcalculationsHelper = require('./hotelroomstatusdashboardcalculations_helper');

const HotelrevenueHelper  = require('./hotelrevenue_helper');

const HotelgmloginmappingsHelper  = require('./hotelgmloginmapping_helper');

const StrreportHelper  = require('./strreport_helper');

const log = require('log4js').getLogger("personalview_helper");

const StatsData = require('../customeview/models/statsdata');

const ChartData =  require('../customeview/models/chartdata');

const _ = require('lodash');

const Utils = require('../common/utils');

const Constants = require('../common/constants');

const mongoose = require('mongoose');

class PersonalViewHelper {
    static getTemplatesList(cd) {
       
        TemplatemarstersSchema.find({}).exec(function (err, result) {
            if(err){
                cd(null,null);
            } 
            cd(null,result)
        })
        
    }  
    static createTemplate(userid,name,description,templateId,cd) {
        PersonalviewsSchema.find({[PersonalviewsSchemaFields.name]:name},[PersonalviewsSchemaFields.name]).exec(function (err, result) {
            
            if(err){
                cd(null,null);
            } 
            
            if(result.length==0){
                let personalview = {
                    [PersonalviewsSchemaFields.userid]: userid,
                    [PersonalviewsSchemaFields.name]: name,
                    [PersonalviewsSchemaFields.nameforsort]: name.toLowerCase(),
                    [PersonalviewsSchemaFields.description]: description,
                    [PersonalviewsSchemaFields.templateid]: templateId
                };
        
                let Personalviews = new PersonalviewsSchema(personalview);
        
                Personalviews.save((err, result) => {
                    if(err){
                        cd(null,null);
                    } 
                    cd(null,[result])
        
                })
            }else{
                result = [ {
                    "_id": "",
                    "userid": 0,
                    "name": name + "name is already exist. please try with deffrent name.",
                    "description": "",
                    "templateid": ""
                }]
                cd(null,result)
            }

            
        })


        
    }
    static getKPIList(cd){
        KpimarstersSchema.find({}).sort({[KpimarstersSchemaFields.Name]:1}).exec(function (err, result) {
            if (err) {
                cd(null,err)
            }            
            cd(null,result)
        })
        
    }


    static getChartDataResult(hotels,fromdate,todate,period,kpi,cd){
            let records = [];
            let records_LY = [];
            let budgetrecords = [];
            let budgetrecords_LY = []; 
            let roomrecords = [];
            let roomrecords_LY = [];
            let x = [];
            let RoomRevenueRecords = [];
            let RoomRevenueRecords_LY = [];
            let RoomRevenueAomunt = [];
            let RoomRevenueAomunt_LY = []; 
            let GM_Login = []; 
            let StrData = []; 
            let AllStatsData = [];                    

            let recordsActive=false;
            let records_LYActive=false;
            let budgetrecordsActive=false;
            let budgetrecords_LYActive=false;
            let roomrecordsActive=false;
            let roomrecords_LYActive=false;

            //let FANDBrevenueBudgetRecords = [];
            //let varienceData = [];
            let RoomRevenueRecordsActive=false;
            let RoomRevenueRecords_LYActive=false;
            let GM_LoginActive = false;
            let StrDataActive = false;

            switch (kpi) {
                case 'noofroomsold':
                case 'numberofavailablerooms':
                case 'occ':
                case 'extendetstayocc':
                case 'extendetstayadr':
                case 'extendetstayrevpar':        
                case 'adr':
                case 'revpar':
                case 'totalpropertyrevenue':
                case 'fandbrevenue$':
                case 'otherincome$':
                case 'totalproperty':
                case 'occexcludingooo':
                case 'revparexcludingooo':
                case 'esroomsold':  
                  recordsActive=true;
                  break;
                case 'noofroomsoldLY':
                case 'occLY':
                case 'occLYper':
                case 'adrLY':
                case 'adrLY$':
                case 'revparLY':
                case 'revparLY$':
                case 'extendetstayoccLY':
                case 'totalpropertyrevenueLY':
                case 'fandbrevenueLY$':
                case 'otherincomeLY$':
                case 'totalpropertyLY': 
                case 'extendetstayadrLY':
                case 'occexcludingoooLY':
                case 'revparexcludingoooLY':
                case 'esroomsoldLY':
                case 'lyroomsold':                             
                  records_LYActive=true;
                  break;
                case 'noofroomsoldBudget':
                case 'noofroomsoldForcast':
                case 'totalroomrevenueBudget':
                case 'totalroomrevenueForcast':  
                case 'occBudget':
                case 'occBudgetper':
                case 'occForcast':
                case 'adrBudget':
                case 'adrBudget$':
                case 'adrForcast':
                case 'revparBudget':
                case 'revparForcast': 
                case 'totalpropertyrevenueBudget':
                case 'totalpropertyrevenueForcast':
                case 'fandbrevenueBudget$':
                case 'fandbrevenueForcast$':
                case 'otherincomeBudget$':
                case 'otherincomeForcast$': 
                case 'totalpropertyBudget':
                case 'totalpropertyForcast':  
                case 'roomrevenueBudget': 
                case 'totalrevenuebudget':                 
                  budgetrecordsActive=true;
                  break;
                case 'noofroomsoldBudgetLY':
                  budgetrecords_LYActive=true;
                  break;  
                case 'totalroomrevenue':
                  RoomRevenueRecordsActive=true;
                  break;
                case 'totalroomrevenueLY': 
                  RoomRevenueRecords_LYActive=true;
                  break;
            }
if(kpi=="noofroomsold"||kpi=="occ"||kpi=="adr"||kpi=="revpar"||kpi=="totalpropertyrevenue"||kpi=="fandbrevenue$"||kpi=="otherincome$"||kpi=="totalproperty"){
    recordsActive=true;records_LYActive=true;budgetrecordsActive=true;
}
if(kpi=="occexcludingooo"||kpi=="revparexcludingooo"){
    recordsActive=true;records_LYActive=true;
}
if(kpi=="totalroomrevenue"){
    RoomRevenueRecordsActive=true;
    RoomRevenueRecords_LYActive=true;
    budgetrecordsActive=true;
    recordsActive=true;
}
if(kpi=='comprooms'||kpi=='outoforderrooms')
{
    recordsActive=true;
    roomrecordsActive=true;
    records_LYActive=true;
}
if(kpi=='monthgoal'){
    RoomRevenueRecordsActive=true;
    recordsActive=true;
}


if(kpi=='totalroomrevenueLY'||kpi=='totalroomrevenueLY$'||kpi=='lyroomrevenuevarience'){records_LYActive=true;} 
if(kpi=='occvarience'||
   kpi=='occvarienceper'||
   kpi=='adrvarience'||
   kpi=='revparvarience'||
   kpi=='lyrevparvarience'||
   kpi=='lyadrvarience'||
   kpi=='adrvarience%'||
   kpi=='otherincomevarience'||   
   kpi=='fandbrevenuevarience'||kpi=='totalpropertyvarience'||kpi=='roomsoldvarience'){
    recordsActive=true;
    records_LYActive=true;
}

if(kpi=='gm_login' ||kpi=='gm_login_CST'){
    GM_LoginActive=true;
    recordsActive=true;
} 
if(kpi=='fandbrevenuebudgetvarience'||kpi=='fandbrevenueforcastvarience'||kpi=='occbudgetvariance'||kpi=='adrbudgetvariance'||kpi=='otherincomebudgetvarience'||kpi=='roomsbudget'||kpi=='revparforcastvarience'||kpi=='adrforcastvarience'||kpi=='occforcastvarience'||kpi=='totalpropertyforcastvarience'||kpi=='revparbudgetvarience'||kpi=='monthforecast'){
    recordsActive=true;
    budgetrecordsActive=true;
    
}
if(kpi=='totalpropertybudgetvarience'){
    recordsActive=true;
    budgetrecordsActive=true;
    RoomRevenueRecordsActive=true;
}
if(kpi=='roomrevenuevarience%'||kpi=='roomrevenueforcastvarience'||kpi=='lyroomrevenuevarience'){
    RoomRevenueRecordsActive=true;
    RoomRevenueRecords_LYActive=true;
}
if(kpi=="revenuevariancebObtogoal"){
    budgetrecordsActive=true;
}
if(kpi=='roomrevenuebudgetvarience'||
kpi=='roomrevenueforcastvarience'){
    RoomRevenueRecordsActive=true;
    budgetrecordsActive=true;
}

if(kpi=='comproomsLY'||kpi=='outoforderroomsLY')
{
    records_LYActive=true;
    
}
if(kpi=='outofordervarience'){
    recordsActive=true;
    roomrecordsActive=true;
    roomrecords_LYActive=true;
}
if(kpi=='strmpi' ||
kpi=='strmpirank' ||
kpi=='strari' ||
kpi=='strarirank' ||
kpi=='strrgi' ||kpi=='strrgirank'){
    recordsActive=true;
    StrDataActive=true;
}
            
            if(fromdate==null && todate==null){

                let reportdate = new Date();
                let dtreportdate_LastYear = Utils.lastYearDate(reportdate);

                if (period == "mtd") {
                    reportdate = Utils.firstDayOfMonth(reportdate);
                    dtreportdate_LastYear = Utils.lastYearDate(reportdate);
                }
                else if (period == "ytd") {
                    reportdate = Utils.firstDayOfYear(reportdate);
                    dtreportdate_LastYear = Utils.lastYearDate(reportdate);
                }
                else if (period.toLowerCase()=="ttm"){
                    reportdate = Utils.sameDayLastYear(reportdate);
                    dtreportdate_LastYear = reportdate;
                }
                
                
                _.filter(hotels,function(data){
                    let data1 = new Promise(function(resolve, reject) {
                        (recordsActive?
                        HoteldashboardcalculationsHelper.GetData(data.ID,reportdate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            records.push(result)
                            resolve()
                            
                        }) : resolve());
                    })
                    let data2 = new Promise(function(resolve, reject) {
                    (budgetrecordsActive?    
                    HotelbudgetdashboardcalculationsHelper.GetData(data.ID,reportdate,(err,result)=>{
                        if (err) {
                            reject(err)
                        }
                        budgetrecords.push(result)
                        resolve()
                        
                        }) : resolve());
                    })
                    let data3 = new Promise(function(resolve, reject) {
                        (records_LYActive?
                        HoteldashboardcalculationsHelper.GetData(data.ID,dtreportdate_LastYear,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            records_LY.push(result)
                            resolve()
                            
                            }) : resolve());
                        }) 
                    let data4 = new Promise(function(resolve, reject) {
                        (budgetrecords_LYActive?
                        HotelbudgetdashboardcalculationsHelper.GetData(data.ID,dtreportdate_LastYear,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            budgetrecords_LY.push(result)
                            resolve()
                            
                            }) : resolve());
                        })
                    let data5 = new Promise(function(resolve, reject) {
                        (roomrecordsActive?
                        HotelroomstatusdashboardcalculationsHelper.GetData(data.ID,reportdate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            roomrecords.push(result)
                            resolve()
                            
                            }) : resolve());
                        })                    
                    let data6 = new Promise(function(resolve, reject) {
                        (roomrecords_LYActive?
                        HotelroomstatusdashboardcalculationsHelper.GetData(data.ID,dtreportdate_LastYear,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            roomrecords_LY.push(result)
                            resolve()
                            
                            }): resolve());
                        })
                    let data8 = new Promise(function(resolve, reject) {
                        (RoomRevenueRecordsActive?
                        HotelrevenueHelper.GetData(data.ID,reportdate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            RoomRevenueRecords.push(result)
                            resolve()
                            
                            }): resolve());
                        })
                    let data9 = new Promise(function(resolve, reject) {
                        (RoomRevenueRecords_LYActive?
                        HotelrevenueHelper.GetData(data.ID,dtreportdate_LastYear,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            RoomRevenueRecords_LY.push(result)
                            resolve()
                            
                            }): resolve());
                        })
                    let data10 =new Promise(function(resolve, reject) {
                        (GM_LoginActive?
                        HotelgmloginmappingsHelper.GetData(data.ID,reportdate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            GM_Login.push(result)
                            resolve()
                            
                            }): resolve());
                        })
                    let data11=new Promise(function(resolve, reject) {
                        (StrDataActive?
                        StrreportHelper.GetData(data.ID,reportdate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            StrData.push(result)
                            resolve()
                            
                            }):resolve())
                        })                                                                                                                   
                  

                    x.push(data1,data2,data3,data4,data5,data6,data8,data9,data10,data11);
    
                })

                Promise.all(x).then(resp=>{
                    if(RoomRevenueRecords!=""){
                        
                        _.filter(records[0],function(data,index){                        
                            
                            RoomRevenueAomunt.push({"Aomunt":_.sumBy(RoomRevenueRecords[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.Amount;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                }),"AmountMTD":_.sumBy(RoomRevenueRecords[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.AmountMTD;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                }),"AmountYTD":_.sumBy(RoomRevenueRecords[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.AmountYTD;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                })})                                                               
                                
                        })
                    }
                    
                    if(RoomRevenueRecords_LY!=""){
                        
                        _.filter(records_LY[0],function(data,index){                        
                            
                            RoomRevenueAomunt_LY.push({"Aomunt":_.sumBy(RoomRevenueRecords_LY[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.Amount;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                }),"AmountMTD":_.sumBy(RoomRevenueRecords_LY[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.AmountMTD;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                }),"AmountYTD":_.sumBy(RoomRevenueRecords_LY[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.AmountYTD;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                })})                                                               
                                
                        })
                    } 

                

                    if(roomrecords!=""){
                        records[0] = _.filter(records[0],function(data,index){
                            let x = _.uniqBy([data, roomrecords[0][index]], 'Date');
                            return _.merge(x[0], x[1]);
                        })
                    }
                    if(roomrecords_LY!=""){
                        records_LY[0] = _.filter(records_LY[0],function(data,index){
                            let x = _.uniqBy([data, roomrecords_LY[0][index]], 'Date');
                            return  _.merge(x[0], x[1]);
                        })
                    }
                    if(StrData!=""){
                        records[0] = _.filter(records[0],function(data,index){
                            let x = _.uniqBy([data, StrData[0][index]], 'Date');
                            return _.merge(x[0], x[1]);
                        })
                    }
                    if(records_LYActive){records[0] = (records!=""?records[0]:records_LY[0]);}
                    else if(budgetrecordsActive){records[0] = (records!=""?records[0]:budgetrecords[0]);}
                    else if(roomrecordsActive){records[0] = (records!=""?records[0]:roomrecords[0]);}
                    else if(roomrecords_LYActive){records[0] = (records!=""?records[0]:roomrecords_LY[0]);}
                    _.filter(records[0],function(data,index){
                        if(kpi=="noofroomsold"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'noofroomsold';
                                statObject.displayname= 'No Of Room SoldMTD';
                                statObject.actualvalue= data.NoOfRoomSoldMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldMTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDBudgetRooms);
                                statObject.forcastvalue=0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'noofroomsold';
                                statObject.displayname= 'No Of Room SoldYTD';
                                statObject.actualvalue= data.NoOfRoomSoldYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].YTDBudgetRooms);
                                statObject.forcastvalue=0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date,
                                statObject.kpikey= 'noofroomsold';
                                statObject.displayname= 'No Of Room SoldTTM';
                                statObject.actualvalue= data.NoOfRoomSoldTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].TTMBudgetRooms);
                                statObject.forcastvalue=0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                               
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'noofroomsold';
                                statObject.displayname= 'No Of Room Sold';
                                statObject.actualvalue= data.NoOfRoomSold;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSold);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomSold);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastRoomSold);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                 
                            }
                        }else if(kpi=="noofroomsoldLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'noofroomsoldLY';
                                statObject.displayname= 'No Of Room Sold LY MTD';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].NoOfRoomSoldMTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'noofroomsoldLY';
                                statObject.displayname= 'No Of Room Sold LY YTD';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'noofroomsoldLY';
                                statObject.displayname= 'No Of Room Sold LY TTM';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'noofroomsoldLY';
                                statObject.displayname= 'No Of Room Sold LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].NoOfRoomSold);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="noofroomsoldBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldBudget';
                                statObject.displayname= 'No Of Room Sold Budget MTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].MTDBudgetRooms);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldBudget';
                                statObject.displayname= 'No Of Room Sold Budget YTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].YTDBudgetRooms);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldBudget';
                                statObject.displayname= 'No Of Room Sold Budget TTM';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].TTMBudgetRooms);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldBudget';
                                statObject.displayname= 'No Of Room Sold Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomSold);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }
                        }
                        else if(kpi=="noofroomsoldForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldForcast';
                                statObject.displayname= 'No Of Room Sold Forcast MTD';
                                statObject.actualvalue= 0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldForcast';
                                statObject.displayname= 'No Of Room Sold Forcast YTD';
                                statObject.actualvalue= 0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldForcast';
                                statObject.displayname= 'No Of Room Sold Forcast TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldForcast';
                                statObject.displayname= 'No Of Room Sold Forcast';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].ForecastRoomSold);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }
                        }else if(kpi=="totalroomrevenue"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'totalroomrevenue';
                                statObject.displayname= 'Total Room Revenue MTD';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD);
                                statObject.lyvalue=(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountMTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'totalroomrevenue';
                                statObject.displayname= 'Total Room Revenue YTD';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountYTD);
                                statObject.lyvalue=(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountYTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].YTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'totalroomrevenue';
                                statObject.displayname= 'Total Room Revenue TTM';
                                statObject.actualvalue= 0;
                                statObject.lyvalue=0;
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].TTMForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'totalroomrevenue';
                                statObject.displayname= 'Total Room Revenue';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt);
                                statObject.lyvalue=(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                 
                            }
                        }                          
                        else if(kpi=="totalroomrevenueLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY';
                                statObject.displayname= 'Total Room Revenue LY MTD';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY';
                                statObject.displayname= 'Total Room Revenue LY YTD';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY';
                                statObject.displayname= 'Total Room Revenue LY TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY';
                                statObject.displayname= 'Total Room Revenue LY';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        } 
                        else if(kpi=="totalroomrevenueBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueBudget';
                                statObject.displayname= 'Total Room Revenue Budget MTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueBudget';
                                statObject.displayname= 'Total Room Revenue Budget YTD';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueBudget';
                                statObject.displayname= 'Total Room Revenue Budget TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueBudget';
                                statObject.displayname= 'Total Room Revenue Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalroomrevenueForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueForcast';
                                statObject.displayname= 'Total Room Revenue Forcast MTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].MTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueForcast';
                                statObject.displayname= 'Total Room Revenue Forcast YTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].YTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueForcast';
                                statObject.displayname= 'Total Room Revenue Forcast TTM';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].TTMForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueForcast';
                                statObject.displayname= 'Total Room Revenue Forcast';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        } 
                        else if(kpi=="numberofavailablerooms"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'numberofavailablerooms';
                                statObject.displayname= 'Number of Available Rooms MTD';
                                statObject.actualvalue= data.AvailableRoomsMTD;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'numberofavailablerooms';
                                statObject.displayname= 'Number of Available Rooms YTD';
                                statObject.actualvalue= data.AvailableRoomsYTD;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'numberofavailablerooms';
                                statObject.displayname= 'Number of Available Rooms TTM';
                                statObject.actualvalue= data.AvailableRoomsTTM;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'numberofavailablerooms';
                                statObject.displayname= 'Number of Available Rooms';
                                statObject.actualvalue= data.AvailableRooms;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="occ"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occ';
                                statObject.displayname= 'Occupancy MTD';
                                statObject.actualvalue=data.OccupancyMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occ';
                                statObject.displayname= 'Occupancy YTD';
                                statObject.actualvalue=data.OccupancyYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occ';
                                statObject.displayname= 'Occupancy TTM';
                                statObject.actualvalue=data.OccupancyTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occ';
                                statObject.displayname= 'Occupancy ';
                                statObject.actualvalue= data.Occupancy;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                 
                            }
                        }
                        else if(kpi=="occLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLY';
                                statObject.displayname= 'Occupancy LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLY';
                                statObject.displayname= 'Occupancy LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLY';
                                statObject.displayname= 'Occupancy LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLY';
                                statObject.displayname= 'Occupancy LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="occBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudget';
                                statObject.displayname= 'Occupancy Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject)); 
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudget';
                                statObject.displayname= 'Occupancy Budget YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject)); 
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudget';
                                statObject.displayname= 'Occupancy Budget TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudget';
                                statObject.displayname= 'Occupancy Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="occForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occForcast';
                                statObject.displayname= 'Occupancy Forcast MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occForcast';
                                statObject.displayname= 'Occupancy Forcast YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occForcast ';
                                statObject.displayname= 'Occupancy Forcast TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                               
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occForcast ';
                                statObject.displayname= 'Occupancy Forcast';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="occvarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarience';
                                statObject.displayname= 'Occupancy Varience MTD';
                                statObject.actualvalue=(data.OccupancyMTD - (records_LY==""?0:records_LY[0][index].OccupancyMTD))*100/(records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarience';
                                statObject.displayname= 'Occupancy Varience YTD';
                                statObject.actualvalue=(data.OccupancyYTD - (records_LY==""?0:records_LY[0][index].OccupancyYTD))*100/(records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                //# Need to Test
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarience ';
                                statObject.displayname= 'Occupancy Varience TTM';
                                statObject.actualvalue=(data.OccupancyTTM - (records_LY==""?0:records_LY[0][index].OccupancyTTM))*100/(records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarience ';
                                statObject.displayname= 'Occupancy Varience';
                                statObject.actualvalue=(data.Occupancy - (records_LY==""?0:records_LY[0][index].Occupancy))*100/(records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        } 
                        else if(kpi=="extendetstayocc"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'extendetstayocc';
                                statObject.displayname= 'Extendet Stay OCC MTD';
                                statObject.actualvalue=data.ESOccupancyMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'extendetstayocc';
                                statObject.displayname= 'Extendet Stay OCC YTD';
                                statObject.actualvalue=data.ESOccupancyYTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'extendetstayocc';
                                statObject.displayname= 'Extendet Stay OCC TTM';
                                statObject.actualvalue=data.ESOccupancyTTM;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'extendetstayocc';
                                statObject.displayname= 'Extendet Stay OCC ';
                                statObject.actualvalue= data.ESOccupancy;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                          
                            }
                        }
                        else if(kpi=="adr"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adr';
                                statObject.displayname= 'ADR MTD';
                                statObject.actualvalue=data.ADRMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adr';
                                statObject.displayname= 'ADR YTD';
                                statObject.actualvalue=data.ADRYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adr';
                                statObject.displayname= 'ADR TTM';
                                statObject.actualvalue=data.ADRTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].ADRTTM);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                          
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adr';
                                statObject.displayname= 'ADR';
                                statObject.actualvalue= data.ADR;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].ADR);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADR);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                        
                            }
                        }
                        else if(kpi=="adrLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY';
                                statObject.displayname= 'ADR LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY';
                                statObject.displayname= 'ADR LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY';
                                statObject.displayname= 'ADR LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY';
                                statObject.displayname= 'ADR LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }
                        }
                        else if(kpi=="adrBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget';
                                statObject.displayname= 'ADR Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget';
                                statObject.displayname= 'ADR Budget YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget';
                                statObject.displayname= 'ADR Budget TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget';
                                statObject.displayname= 'ADR Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="adrForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='adrForcast';
                                statObject.displayname= 'ADR Forcast MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='adrForcast';
                                statObject.displayname= 'ADR Forcast YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='adrForcast';
                                statObject.displayname='ADR Forcast TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='adrForcast';
                                statObject.displayname= 'ADR Forcast';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="adrvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrvarience';
                                statObject.displayname= 'ADR Varience MTD';
                                statObject.actualvalue=(data.ADRMTD - (records_LY==""?0:records_LY[0][index].ADRMTD))*100/(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrvarience';
                                statObject.displayname= 'ADR Varience YTD';
                                statObject.actualvalue=(data.ADRYTD - (records_LY==""?0:records_LY[0][index].ADRYTD))*100/(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrvarience';
                                statObject.displayname='ADR Varience TTM';
                                statObject.actualvalue=(data.ADRTTM - (records_LY==""?0:records_LY[0][index].ADRTTM))*100/(records_LY==""?0:records_LY[0][index].ADRTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrvarience';
                                statObject.displayname= 'ADR Varience';
                                statObject.actualvalue=(data.ADR - (records_LY==""?0:records_LY[0][index].ADR))*100/(records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="extendetstayadr"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayadr';
                                statObject.displayname= 'Extendet Stay ADR MTD';
                                statObject.actualvalue=data.ESADRMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayadr';
                                statObject.displayname= 'Extendet Stay ADR YTD';
                                statObject.actualvalue=data.ESADRYTD;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayadr';
                                statObject.displayname='Extendet Stay ADR TTM';
                                statObject.actualvalue=data.ESADRTTM; 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayadr';
                                statObject.displayname= 'Extendet Stay ADR';
                                statObject.actualvalue=data.ESADR;
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revpar"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revpar';
                                statObject.displayname='RevPar MTD';
                                statObject.actualvalue=data.RevPARMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARMTD);
                                statObject.budgetvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD))/100;
                                statObject.forcastvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revpar';
                                statObject.displayname='RevPar YTD';
                                statObject.actualvalue=data.RevPARYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.budgetvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD))/100;
                                statObject.forcastvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revpar';
                                statObject.displayname='RevPar TTM';
                                statObject.actualvalue=data.RevPARTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARTTM);
                                statObject.budgetvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM))/100;
                                statObject.forcastvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revpar';
                                statObject.displayname='RevPar';
                                statObject.actualvalue=data.RevPAR;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.budgetvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADR) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy))/100;
                                statObject.forcastvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADR) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }
                        else if(kpi=="revparLY"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject=new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY';
                                statObject.displayname='RevPar LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY';
                                statObject.displayname='RevPar LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY';
                                statObject.displayname='RevPar LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY';
                                statObject.displayname='RevPar LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparBudget"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject=new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparBudget';
                                statObject.displayname='RevPar Budget MTD';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparBudget';
                                statObject.displayname='RevPar Budget YTD';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparBudget';
                                statObject.displayname='RevPar Budget TTM';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparBudget';
                                statObject.displayname='RevPar Budget';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADR) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparForcast"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject=new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparForcast';
                                statObject.displayname='RevPar Forcast MTD';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparForcast';
                                statObject.displayname='RevPar Forcast YTD';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparForcast';
                                statObject.displayname='RevPar Forcast TTM';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparForcast';
                                statObject.displayname='RevPar Forcast';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADR) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparvarience';
                                statObject.displayname= 'RevPar Varience MTD';
                                statObject.actualvalue= (data.RevPARMTD - (records_LY==""?0:records_LY[0][index].RevPARMTD))*100/(records_LY==""?0:records_LY[0][index].RevPARMTD); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparvarience';
                                statObject.displayname= 'RevPar Varience YTD';
                                statObject.actualvalue= (data.RevPARYTD - (records_LY==""?0:records_LY[0][index].RevPARYTD))*100/(records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparvarience';
                                statObject.displayname='RevPar Varience TTM';
                                statObject.actualvalue=(data.RevPARTTM - (records_LY==""?0:records_LY[0][index].RevPARTTM))*100/(records_LY==""?0:records_LY[0][index].RevPARTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparvarience';
                                statObject.displayname= 'RevPar Varience';
                                statObject.actualvalue=(data.RevPAR - (records_LY==""?0:records_LY[0][index].RevPAR))*100/(records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="extendetstayrevpar"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayrevpar';
                                statObject.displayname='Extendet Stay RevPAR MTD';
                                statObject.actualvalue=data.ESRevPARMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayrevpar';
                                statObject.displayname='Extendet Stay RevPAR YTD';
                                statObject.actualvalue=data.ESRevPARYTD;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayrevpar';
                                statObject.displayname='Extendet Stay RevPAR TTM';
                                statObject.actualvalue=data.ESRevPARTTM;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayrevpar';
                                statObject.displayname='Extendet Stay RevPAR';
                                statObject.actualvalue=data.ESRevPAR;   
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyrevenue"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyrevenue';
                                statObject.displayname='Total Property Revenue MTD';
                                statObject.actualvalue=_.sum([
                                    data.TotalRevenueMTD,
                                    data.FANDBRevenueMTD,
                                    data.OtherRevenueMTD,
                                    data.Outet1OtherRevenueMTD,
                                    data.Outet2OtherRevenueMTD,
                                    data.Outet3OtherRevenueMTD,
                                    data.Outet4OtherRevenueMTD,
                                    data.Outet1FANDBRevenueMTD,
                                    data.Outet2FANDBRevenueMTD,
                                    data.Outet3FANDBRevenueMTD,
                                    data.Outet4FANDBRevenueMTD,
                                    data.RestaurantRevenueMTD,
                                    data.BarRevenueMTD,
                                    data.BanquetRevenueMTD,
                                    data.ParkingRevenueMTD,
                                    data.GiftShopRevenueMTD,
                                    data.BeverageRevenueMTD,
                                    data.FoodRevenueMTD,
                                ]);
                                statObject.lyvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueMTD),
                                ]);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyrevenue';
                                statObject.displayname='Total Property Revenue YTD';
                                statObject.actualvalue=_.sum([
                                    data.TotalRevenueYTD,
                                    data.FANDBRevenueYTD,
                                    data.OtherRevenueYTD,
                                    data.Outet1OtherRevenueYTD,
                                    data.Outet2OtherRevenueYTD,
                                    data.Outet3OtherRevenueYTD,
                                    data.Outet4OtherRevenueYTD,
                                    data.Outet1FANDBRevenueYTD,
                                    data.Outet2FANDBRevenueYTD,
                                    data.Outet3FANDBRevenueYTD,
                                    data.Outet4FANDBRevenueYTD,
                                    data.RestaurantRevenueYTD,
                                    data.BarRevenueYTD,
                                    data.BanquetRevenueYTD,
                                    data.ParkingRevenueYTD,
                                    data.GiftShopRevenueYTD,
                                    data.BeverageRevenueYTD,
                                    data.FoodRevenueYTD,
                                ]);
                                statObject.lyvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueYTD),
                                ]);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyrevenue';
                                statObject.displayname='Total Property Revenue TTM';
                                statObject.actualvalue=_.sum([
                                    data.TotalRevenueTTM,
                                    data.FANDBRevenueTTM,
                                    data.OtherRevenueTTM,
                                    data.Outet1OtherRevenueTTM,
                                    data.Outet2OtherRevenueTTM,
                                    data.Outet3OtherRevenueTTM,
                                    data.Outet4OtherRevenueTTM,
                                    data.Outet1FANDBRevenueTTM,
                                    data.Outet2FANDBRevenueTTM,
                                    data.Outet3FANDBRevenueTTM,
                                    data.Outet4FANDBRevenueTTM,
                                    data.RestaurantRevenueTTM,
                                    data.BarRevenueTTM,
                                    data.BanquetRevenueTTM,
                                    data.ParkingRevenueTTM,
                                    data.GiftShopRevenueTTM,
                                    data.BeverageRevenueTTM,
                                    data.FoodRevenueTTM,
                                ]);
                                statObject.lyvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueTTM),
                                ]);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyrevenue';
                                statObject.displayname='Total Property Revenue';
                                statObject.actualvalue=_.sum([
                                    data.TotalRevenue,
                                    data.FANDBRevenue,
                                    data.OtherRevenue,
                                    data.Outet1OtherRevenue,
                                    data.Outet2OtherRevenue,
                                    data.Outet3OtherRevenue,
                                    data.Outet4OtherRevenue,
                                    data.Outet1FANDBRevenue,
                                    data.Outet2FANDBRevenue,
                                    data.Outet3FANDBRevenue,
                                    data.Outet4FANDBRevenue,
                                    data.RestaurantRevenue,
                                    data.BarRevenue,
                                    data.BanquetRevenue,
                                    data.ParkingRevenue,
                                    data.GiftShopRevenue,
                                    data.BeverageRevenue,
                                    data.FoodRevenue,
                                ]);
                                statObject.lyvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenue),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenue),
                                    (records_LY==""?0:records_LY[0][index].BarRevenue),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenue),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenue),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenue),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenue),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenue),
                                ]);
                                statObject.budgetvalue=_.sum([
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)
                                ]);
                                statObject.forcastvalue=_.sum([
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastOtherRevenue)
                                ]);  
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyrevenueLY"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueLY';
                                statObject.displayname='Total Property Revenue LY MTD';
                                statObject.actualvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueMTD),
                                ]);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueLY';
                                statObject.displayname='Total Property Revenue LY YTD';
                                statObject.actualvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueYTD),
                                ]);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueLY';
                                statObject.displayname='Total Property Revenue LY TTM';
                                statObject.actualvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueTTM),
                                ]);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueLY';
                                statObject.displayname='Total Property Revenue LY';
                                statObject.actualvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenue),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenue),
                                    (records_LY==""?0:records_LY[0][index].BarRevenue),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenue),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenue),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenue),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenue),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenue),
                                ]);   
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyrevenueBudget"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueBudget';
                                statObject.displayname='Total Property Revenue Budget MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueBudget';
                                statObject.displayname='Total Property Revenue Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueBudget';
                                statObject.displayname='Total Property Revenue Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueBudget';
                                statObject.displayname='Total Property Budget';
                                statObject.actualvalue=_.sum([
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)
                                ]);   
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyrevenueForcast"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueForcast';
                                statObject.displayname='Total Property Revenue Forecast MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueForcast';
                                statObject.displayname='Total Property Revenue Forecast YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueForcast';
                                statObject.displayname='Total Property Revenue Forecast TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueForcast';
                                statObject.displayname='Total Property Forecast';
                                statObject.actualvalue=_.sum([
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastOtherRevenue)
                                ]);   
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="comprooms"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comprooms';
                                statObject.displayname='Comp Rooms MTD';
                                statObject.actualvalue=data.CompRoomsMTD;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comprooms';
                                statObject.displayname='Comp Rooms YTD';
                                statObject.actualvalue=data.CompRoomsYTD;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comprooms';
                                statObject.displayname='Comp Rooms TTM';
                                statObject.actualvalue=data.CompRoomsTTM;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsTTM);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comprooms';
                                statObject.displayname='Comp Rooms';
                                statObject.actualvalue=data.CompRooms;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRooms);
                                statObject.actualunit=Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }                                                                      
                        else if(kpi=="comproomsLY"){
                            if(period.toLowerCase()=="mtd"){                               
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comproomsLY';
                                statObject.displayname='Comp Rooms LY MTD';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comproomsLY';
                                statObject.displayname='Comp Rooms LY YTD';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comproomsLY';
                                statObject.displayname='Comp Rooms LY TTM';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsTTM);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comproomsLY';
                                statObject.displayname='Comp Rooms LY';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRooms);
                                statObject.actualunit=Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="outoforderrooms"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outoforderrooms';
                                statObject.displayname='Out of Order Rooms MTD';
                                statObject.actualvalue=data.OutOfOrderRoomsMTD;
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outoforderrooms';
                                statObject.displayname='Out of Order Rooms YTD';
                                statObject.actualvalue=data.OutOfOrderRoomsYTD;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outoforderrooms';
                                statObject.displayname='Out of Order Rooms TTM';
                                statObject.actualvalue=data.OutOfOrderRoomsTTM;
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outoforderrooms';
                                statObject.displayname='Out of Order Rooms';
                                statObject.actualvalue=data.OutOfOrderRooms;
                                statObject.actualunit=Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="outoforderroomsLY"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=(roomrecords_LY==""?0:roomrecords_LY[0][index].Date);
                                statObject.kpikey='outoforderroomsLY';
                                statObject.displayname='Out of Order Rooms MTD';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(roomrecords_LY==""?0:roomrecords_LY[0][index].Date);
                                statObject.kpikey='outoforderroomsLY';
                                statObject.displayname='Out of Order Rooms YTD';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRoomsYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(roomrecords_LY==""?0:roomrecords_LY[0][index].Date);
                                statObject.kpikey='outoforderroomsLY';
                                statObject.displayname='Out of Order Rooms TTM';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRoomsTTM);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(roomrecords_LY==""?0:roomrecords_LY[0][index].Date);
                                statObject.kpikey='outoforderroomsLY';
                                statObject.displayname='Out of Order Rooms';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRooms);
                                statObject.actualunit=Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="occLYper"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLYper';
                                statObject.displayname= 'Occupancy(%) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLYper';
                                statObject.displayname= 'Occupancy(%) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLYper';
                                statObject.displayname= 'Occupancy(%) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLYper';
                                statObject.displayname= 'Occupancy(%) LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="occvarienceper"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarienceper';
                                statObject.displayname= 'Occupancy(%) Varience MTD ';
                                statObject.actualvalue=data.OccupancyMTD - (records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarienceper';
                                statObject.displayname= 'Occupancy(%) Varience YTD';
                                statObject.actualvalue=data.OccupancyYTD - (records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                //# Need to Test
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarienceper ';
                                statObject.displayname= 'Occupancy(%) Varience TTM';
                                statObject.actualvalue=data.OccupancyTTM - (records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarienceper ';
                                statObject.displayname= 'Occupancy(%) Varience';
                                statObject.actualvalue=data.Occupancy - (records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="occBudgetper"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudgetper';
                                statObject.displayname= 'Occupancy(%) Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject)); 
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudgetper';
                                statObject.displayname= 'Occupancy(%) Budget YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject)); 
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudgetper';
                                statObject.displayname= 'Occupancy(%) Budget TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudgetper';
                                statObject.displayname= 'Occupancy(%) Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="adrLY$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY$';
                                statObject.displayname= 'ADR($) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY$';
                                statObject.displayname= 'ADR($) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY$';
                                statObject.displayname= 'ADR($) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY$';
                                statObject.displayname= 'ADR($) LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }
                        }
                        else if(kpi=="extendetstayoccLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayoccLY';
                                statObject.displayname= 'ExtendetStay OCC LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayoccLY';
                                statObject.displayname= 'ExtendetStay OCC LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESOccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'extendetstayoccLY';
                                statObject.displayname= 'ExtendetStay OCC LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESOccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'extendetstayoccLY';
                                statObject.displayname= 'ExtendetStay LY OCC ';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESOccupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                          
                            }
                        }
                        else if(kpi=="adrBudget$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget$';
                                statObject.displayname= 'ADR($) Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget$';
                                statObject.displayname= 'ADR($) Budget YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget$';
                                statObject.displayname= 'ADR($) Budget TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget$';
                                statObject.displayname= 'ADR($) Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="adrbudgetvariance"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adrbudgetvariance';
                                statObject.displayname= 'ADR($) Budget Varience MTD';
                                statObject.actualvalue= data.ADRMTD - (budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adrbudgetvariance';
                                statObject.displayname= 'ADR($) Budget Varience YTD';
                                statObject.actualvalue= data.ADRYTD - (budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adrbudgetvariance';
                                statObject.displayname= 'ADR($) Budget Varience TTM';
                                statObject.actualvalue= data.ADRTTM - (budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adrbudgetvariance';
                                statObject.displayname= 'ADR($) Budget Varience';
                                statObject.actualvalue= data.ADR - (budgetrecords==""?0:budgetrecords[0][index].BudgetADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="lyadrvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyadrvarience';
                                statObject.displayname= 'ADR($) Varience MTD';
                                statObject.actualvalue=data.ADRMTD - (records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyadrvarience';
                                statObject.displayname= 'ADR($) Varience YTD';
                                statObject.actualvalue=data.ADRYTD - (records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyadrvarience';
                                statObject.displayname='ADR($) Varience TTM';
                                statObject.actualvalue= data.ADRTTM - (records_LY==""?0:records_LY[0][index].ADRTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyadrvarience';
                                statObject.displayname= 'ADR($) Varience';
                                statObject.actualvalue=data.ADR - (records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparLY$"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject=new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY$';
                                statObject.displayname='RevPar($) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY$';
                                statObject.displayname='RevPar($) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY$';
                                statObject.displayname='RevPar($) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY$';
                                statObject.displayname='RevPar($) LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }                        
                        else if(kpi=="totalroomrevenueLY$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY$';
                                statObject.displayname= 'Room Revenue($) LY MTD';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY$';
                                statObject.displayname= 'Room Revenue($) LY YTD';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY$';
                                statObject.displayname= 'Room Revenue($) LY TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY$';
                                statObject.displayname= 'Room Revenue($) LY';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="roomrevenueBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenueBudget';
                                statObject.displayname= 'Room Revenue($) Budget MTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenueBudget';
                                statObject.displayname= 'Room Revenue($) Budget YTD';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenueBudget';
                                statObject.displayname= 'Room Revenue($) Budget TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenueBudget';
                                statObject.displayname= 'Room Revenue($) Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="roomrevenuebudgetvarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenuebudgetvarience';
                                statObject.displayname= 'Room Revenue($) Budget Varience MTD';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD)-(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenuebudgetvarience';
                                statObject.displayname= 'Room Revenue($) Budget Varience YTD';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountYTD)-0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenuebudgetvarience';
                                statObject.displayname= 'Room Revenue($) Budget Varience TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenuebudgetvarience';
                                statObject.displayname= 'Room Revenue($) Budget Varience';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)-(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="lyroomrevenuevarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomrevenuevarience';
                                statObject.displayname= 'Room Revenue($) Varience LY MTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'lyroomrevenuevarience';
                                statObject.displayname= 'Room Revenue($) Varience LY YTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountYTD)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'lyroomrevenuevarience';
                                statObject.displayname= 'Room Revenue($) Varience LY TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'lyroomrevenuevarience';
                                statObject.displayname= 'Room Revenue($) Varience LY';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenue$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenue$';
                                statObject.displayname='FANDB Revenue($) MTD';
                                statObject.actualvalue=data.FANDBRevenueMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueMTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenue$';
                                statObject.displayname='FANDB Revenue($) YTD';
                                statObject.actualvalue=data.FANDBRevenueYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueYTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].YTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenue$';
                                statObject.displayname='FANDB Revenue($) TTM';
                                statObject.actualvalue=data.FANDBRevenueTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueTTM);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].TTMForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenue$';
                                statObject.displayname='FANDB Revenue($)';
                                statObject.actualvalue=data.FANDBRevenue;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenue);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenueLY$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='fandbrevenueLY$';
                                statObject.displayname='FANDB Revenue($) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='fandbrevenueLY$';
                                statObject.displayname='FANDB Revenue($) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='fandbrevenueLY$';
                                statObject.displayname='FANDB Revenue($) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='fandbrevenueLY$';
                                statObject.displayname='FANDB Revenue($) LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenueBudget$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueBudget$';
                                statObject.displayname='FANDB Revenue($) Budget MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueBudget$';
                                statObject.displayname='FANDB Revenue($) Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueBudget$';
                                statObject.displayname='FANDB Revenue($) Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueBudget$';
                                statObject.displayname='FANDB Revenue($) Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenueForcast$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueForcast$';
                                statObject.displayname='FANDB Revenue($) Forcast MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueForcast$';
                                statObject.displayname='FANDB Revenue($) Forcast YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].YTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueForcast$';
                                statObject.displayname='FANDB Revenue($) Forcast TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].TTMForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueForcast$';
                                statObject.displayname='FANDB Revenue($) Forcast';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="otherincome$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincome$';
                                statObject.displayname='Other Income($) MTD';
                                statObject.actualvalue=data.OtherRevenueMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueMTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincome$';
                                statObject.displayname='Other Income($) YTD';
                                statObject.actualvalue=data.OtherRevenueYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueYTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincome$';
                                statObject.displayname='Other Income($) TTM';
                                statObject.actualvalue=data.OtherRevenueTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueTTM); 
                                statObject.budgetvalue=0; 
                                statObject.forcastvalue=0; 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincome$';
                                statObject.displayname='Other Income($)';
                                statObject.actualvalue=data.OtherRevenue;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OtherRevenue);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOtherRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }
                        }
                        else if(kpi=="otherincomeLY$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomeLY$';
                                statObject.displayname='Other Income($) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomeLY$';
                                statObject.displayname='Other Income($) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomeLY$';
                                statObject.displayname='Other Income($) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueTTM); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomeLY$';
                                statObject.displayname='Other Income($) LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OtherRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="otherincomeBudget$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeBudget$';
                                statObject.displayname='Other Income($) Budget MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeBudget$';
                                statObject.displayname='Other Income($) Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeBudget$';
                                statObject.displayname='Other Income($) Budget TTM';
                                statObject.actualvalue=0; 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeBudget$';
                                statObject.displayname='Other Income($) Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="otherincomeForcast$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeForcast$';
                                statObject.displayname='Other Income($) Forcast MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeForcast$';
                                statObject.displayname='Other Income($) Forcast YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeForcast$';
                                statObject.displayname='Other Income($) Forcast TTM';
                                statObject.actualvalue=0; 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeForcast$';
                                statObject.displayname='Other Income($) Forcast';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOtherRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalproperty"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalproperty';
                                statObject.displayname='Total Property MTD';
                                statObject.actualvalue=data.TotalRevenueMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueMTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalproperty';
                                statObject.displayname='Total Property YTD';
                                statObject.actualvalue=data.TotalRevenueYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueYTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalproperty';
                                statObject.displayname='Total Property TTM';
                                statObject.actualvalue=data.TotalRevenueTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueTTM);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalproperty';
                                statObject.displayname='Total Property';
                                statObject.actualvalue=data.TotalRevenue;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].TotalRevenue);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetTotalRevenue);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastTotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }
                        }
                        else if(kpi=="totalpropertyLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyLY';
                                statObject.displayname='Total Property LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyLY';
                                statObject.displayname='Total Property LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyLY';
                                statObject.displayname='Total Property LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyLY';
                                statObject.displayname='Total Property LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].TotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalpropertyForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyForcast';
                                statObject.displayname='Total Property Forcast MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyForcast';
                                statObject.displayname='Total Property Forcast YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyForcast';
                                statObject.displayname='Total Property Forcast TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyForcast';
                                statObject.displayname='Total Property Forcast';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastTotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalpropertyBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyBudget';
                                statObject.displayname='Total Property Budget MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyBudget';
                                statObject.displayname='Total Property Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyBudget';
                                statObject.displayname='Total Property Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyBudget';
                                statObject.displayname='Total Property Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetTotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenuevarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuevarience';
                                statObject.displayname='FANDB Revenue Varience MTD';
                                statObject.actualvalue=(data.FANDBRevenueMTD - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueMTD)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueMTD));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuevarience';
                                statObject.displayname='FANDB Revenue Varience YTD';
                                statObject.actualvalue=(data.FANDBRevenueYTD - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueYTD)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueYTD));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuevarience';
                                statObject.displayname='FANDB Revenue Varience TTM';
                                statObject.actualvalue=(data.FANDBRevenueTTM - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueTTM)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueTTM));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuevarience';
                                statObject.displayname='FANDB Revenue Varience';
                                statObject.actualvalue=(data.FANDBRevenue - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenue)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenue));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalpropertyvarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyvarience';
                                statObject.displayname='Total Property Varience MTD';
                                statObject.actualvalue=(data.FANDBRevenueMTD - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueMTD)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueMTD));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyvarience';
                                statObject.displayname='Total Property Varience YTD';
                                statObject.actualvalue=(data.FANDBRevenueYTD - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueYTD)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueYTD));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyvarience';
                                statObject.displayname='Total Property Varience TTM';
                                statObject.actualvalue=(data.FANDBRevenueTTM - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueTTM)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueTTM));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyvarience';
                                statObject.displayname='Total Property Varience';
                                statObject.actualvalue=(data.TotalRevenue - (records_LY==""?0:records_LY[0][index].TotalRevenue))*100/(records_LY==""?0:records_LY[0][index].TotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="lyrevparvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyrevparvarience';
                                statObject.displayname= 'RevPar Varience LY MTD';
                                statObject.actualvalue= data.RevPARMTD - (records_LY==""?0:records_LY[0][index].RevPARMTD); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyrevparvarience';
                                statObject.displayname= 'RevPar Varience LY YTD';
                                statObject.actualvalue= data.RevPARYTD - (records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyrevparvarience';
                                statObject.displayname='RevPar Varience LY TTM';
                                statObject.actualvalue=data.RevPARTTM - (records_LY==""?0:records_LY[0][index].RevPARTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyrevparvarience';
                                statObject.displayname= 'RevPar Varience LY';
                                statObject.actualvalue=data.RevPAR - (records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="fandbrevenuebudgetvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuebudgetvarience';
                                statObject.displayname='F&B Revenue Budget Variance MTD';
                                statObject.actualvalue=data.FANDBRevenueMTD - (budgetrecords==""?0:budgetrecords[0][index].FNBMonthHotelBudget); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuebudgetvarience';
                                statObject.displayname='F&B Revenue Budget Variance YTD';
                                statObject.actualvalue=data.FANDBRevenueYTD - 0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuebudgetvarience';
                                statObject.displayname='F&B Revenue Budget Variance TTM';
                                statObject.actualvalue=data.FANDBRevenueTTM - 0; 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuebudgetvarience';
                                statObject.displayname='F&B Revenue Budget Variance';
                                statObject.actualvalue=data.FANDBRevenue - (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertybudgetvarience"){
                            if(period.toLowerCase()=="mtd"){  
                                let totalbudget = _.sum([(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget),(budgetrecords==""?0:budgetrecords[0][index].FNBMonthHotelBudget),(budgetrecords==""?0:budgetrecords[0][index].OtherMonthHotelBudget)]);                              
                                let totalrevenue= _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntMTD),data.FANDBRevenueMTD,data.OtherRevenueMTD])
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertybudgetvarience';
                                statObject.displayname='Total Property Budget Variance MTD';
                                statObject.actualvalue=(totalrevenue-totalbudget); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let totalrevenue = _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntYTD),data.FANDBRevenueYTD,data.OtherRevenueYTD]);
                                let totalbudget=0;
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertybudgetvarience';
                                statObject.displayname='Total Property Budget Variance YTD';
                                statObject.actualvalue=(totalrevenue-totalbudget);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let totalrevenue= _.sum([0,data.FANDBRevenueTTM,data.OtherRevenueTTM]);
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertybudgetvarience';
                                statObject.displayname='Total Property Budget Variance TTM';
                                statObject.actualvalue=(totalrevenue-0);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let totalbudget = _.sum([(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue),(budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue),(budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)]);
                                let totalrevenue=_.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt),data.FANDBRevenue,data.OtherRevenue])
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertybudgetvarience';
                                statObject.displayname='Total Property Budget Variance ';
                                statObject.actualvalue=(totalrevenue-totalbudget);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparbudgetvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparbudgetvarience';
                                statObject.displayname='Total Property Budget Variance MTD';
                                statObject.actualvalue=0; 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparbudgetvarience';
                                statObject.displayname='Total Property Budget Variance YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparbudgetvarience';
                                statObject.displayname='Total Property Budget Variance TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let x = (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                let y = (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue);
                                let z = (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue);
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparbudgetvarience';
                                statObject.displayname='Total Property Budget Variance ';
                                statObject.actualvalue=0-_.sum[x,y,z];
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="roomrevenueforcastvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomrevenueforcastvarience';
                                statObject.displayname='Room Revenue Forecast Variance MTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD)-(budgetrecords==""?0:budgetrecords[0][index].MTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomrevenueforcastvarience';
                                statObject.displayname='Room Revenue Forecast Variance YTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountYTD)-(budgetrecords==""?0:budgetrecords[0][index].YTDForecastRoomRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomrevenueforcastvarience';
                                statObject.displayname='Room Revenue Forecast Variance TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomrevenueforcastvarience';
                                statObject.displayname='Room Revenue Forecast Variance';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)-(budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="fandbrevenueforcastvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenueforcastvarience';
                                statObject.displayname='FANDB Revenue Forecast Variance MTD';
                                statObject.actualvalue=data.FANDBRevenueMTD - (budgetrecords==""?0:budgetrecords[0][index].MTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenueforcastvarience';
                                statObject.displayname='FANDB Revenue Forecast Variance YTD';
                                statObject.actualvalue=data.FANDBRevenueYTD -(budgetrecords==""?0:budgetrecords[0][index].YTDForecastFANDBRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenueforcastvarience';
                                statObject.displayname='FANDB Revenue Forecast Variance TTM';
                                statObject.actualvalue=data.FANDBRevenueTTM -(budgetrecords==""?0:budgetrecords[0][index].TTMForecastFANDBRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenueforcastvarience';
                                statObject.displayname='FANDB Revenue Forecast Variance';
                                statObject.actualvalue= data.FANDBRevenue - (budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyforcastvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let totalrevenue = _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntMTD),data.OtherRevenueMTD,data.FANDBRevenueMTD]);                               
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyforcastvarience';
                                statObject.displayname='Total Property Forcast Variance MTD';
                                statObject.actualvalue=totalrevenue-0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let totalrevenue = _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntYTD),data.OtherRevenueYTD,data.FANDBRevenueYTD]);
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyforcastvarience';
                                statObject.displayname='Total Property Forcast Variance YTD';
                                statObject.actualvalue=totalrevenue-0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let totalrevenue = _.sum([0,data.OtherRevenueTTM,data.FANDBRevenueTTM]);
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyforcastvarience';
                                statObject.displayname='Total Property Forcast Variance TTM';
                                statObject.actualvalue=totalrevenue-0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let totalrevenue = _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt),data.OtherRevenue,data.FANDBRevenue]);
                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyforcastvarience';
                                statObject.displayname='Total Property Forcast Variance';
                                statObject.actualvalue= totalrevenue - (budgetrecords==""?0:budgetrecords[0][index].ForecastTotalRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="occforcastvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occforcastvarience';
                                statObject.displayname='Occupancy Forcast Variance MTD';
                                statObject.actualvalue=data.OccupancyMTD - (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occforcastvarience';
                                statObject.displayname='Occupancy Forcast Variance YTD';
                                statObject.actualvalue=data.OccupancyYTD - (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occforcastvarience';
                                statObject.displayname='Occupancy Forcast Variance TTM';
                                statObject.actualvalue=data.OccupancyTTM - (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occforcastvarience';
                                statObject.displayname='Occupancy Forcast Variance';
                                statObject.actualvalue=data.Occupancy -  (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancy);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="adrforcastvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrforcastvarience';
                                statObject.displayname='ADR Forcast Variance MTD';
                                statObject.actualvalue=data.ADRMTD - (budgetrecords==""?0:budgetrecords[0][index].ForecastADRMTD); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrforcastvarience';
                                statObject.displayname='ADR Forcast Variance YTD';
                                statObject.actualvalue=data.ADRYTD - (budgetrecords==""?0:budgetrecords[0][index].ForecastADRYTD); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrforcastvarience';
                                statObject.displayname='ADR Forcast Variance TTM';
                                statObject.actualvalue=data.ADRTTM - (budgetrecords==""?0:budgetrecords[0][index].ForecastADRTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrforcastvarience';
                                statObject.displayname='ADR Forcast Variance';
                                statObject.actualvalue=data.ADR - (budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparforcastvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let RevParForcastMTD = ((budgetrecords==""?0:budgetrecords[0][index].ForecastADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyMTD))/100; 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparforcastvarience';
                                statObject.displayname='RevPAR Forcast Variance MTD';
                                statObject.actualvalue=data.RevPARMTD - RevParForcastMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let RevParForcastYTD = ((budgetrecords==""?0:budgetrecords[0][index].ForecastADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyYTD))/100; 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparforcastvarience';
                                statObject.displayname='RevPAR Forcast Variance YTD';
                                statObject.actualvalue=data.RevPARYTD - RevParForcastYTD;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let RevParForcastTTM = ((budgetrecords==""?0:budgetrecords[0][index].ForecastADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyTTM))/100; 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparforcastvarience';
                                statObject.displayname='RevPAR Forcast Variance TTM';
                                statObject.actualvalue=data.RevPARTTM - RevParForcastTTM;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let RevParForcast = ((budgetrecords==""?0:budgetrecords[0][index].ForecastADR) * (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancy))/100;                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparforcastvarience';
                                statObject.displayname='RevPAR Forcast Variance';
                                statObject.actualvalue=data.RevPAR - RevParForcast;
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revenuevariancebObtogoal"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revenuevariancebObtogoal';
                                statObject.displayname='Revenue Variance BOB To Goal($) MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDBudgetBOB) - (budgetrecords==""?0:budgetrecords[0][index].MonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revenuevariancebObtogoal';
                                statObject.displayname='Revenue Variance BOB To Goal($) YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revenuevariancebObtogoal';
                                statObject.displayname='Revenue Variance BOB To Goal($) TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revenuevariancebObtogoal';
                                statObject.displayname='Revenue Variance BOB To Goal($)';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="roomsbudget"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomsbudget';
                                statObject.displayname='Rooms Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomsbudget';
                                statObject.displayname='Rooms Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomsbudget';
                                statObject.displayname='Rooms Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomsbudget';
                                statObject.displayname='Rooms Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="roomrevenuebudgetvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience';
                                statObject.displayname='Rooms Budget Varience MTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD) - (budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience';
                                statObject.displayname='Rooms Budget Varience YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience';
                                statObject.displayname='Rooms Budget Varience TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience';
                                statObject.displayname='Rooms Budget Varience';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt) - (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="gm_login"){
                            let GM_Login_Val='';
                            if(GM_Login!=""){
                                _.filter(GM_Login[0],function(i){
    
                                    let date = Utils.getFormattedDate(i.LastGMLoginDateTime,"YYYY-MM-DD");
                                    let LastGMLoginDate = new Date(date)
                                    
                                    //let CSTtime=Utils.convertLocalTimeCST(i.LastGMLoginDateTime);
                                    if(LastGMLoginDate.getTime()===new Date(Utils.addDays(data.Date,1)).getTime()){
                                        GM_Login_Val=i.LastGMLoginDateTime;
                                        //GM_Login_CST_Val=CSTtime; 
                                    }
                              
                                })                  
                            }
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login';
                                statObject.displayname='Gm Login MTD';
                                statObject.actualvalue=GM_Login_Val;
                                statObject.actualunit=Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login';
                                statObject.displayname='Gm Login YTD';
                                statObject.actualvalue=GM_Login_Val;
                                statObject.actualunit= Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login';
                                statObject.displayname='Gm Login TTM';
                                statObject.actualvalue=GM_Login_Val;
                                statObject.actualunit= Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login';
                                statObject.displayname='Gm Login';
                                statObject.actualvalue=GM_Login_Val;
                                statObject.actualunit= Constants.Units.Text;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="gm_login_CST"){
                            let GM_Login_CST_Val='';
                            if(GM_Login!=""){
                                _.filter(GM_Login[0],function(i){
    
                                    let date = Utils.getFormattedDate(i.LastGMLoginDateTime,"YYYY-MM-DD");
                                    let LastGMLoginDate = new Date(date)
                                    
                                    let CSTtime=Utils.convertLocalTimeCST(i.LastGMLoginDateTime);
                                    if(LastGMLoginDate.getTime()===new Date(Utils.addDays(data.Date,1)).getTime()){
                                        //GM_Login_Val=i.LastGMLoginDateTime;
                                        GM_Login_CST_Val=CSTtime; 
                                    }
                              
                                })                  
                            }
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login_CST';
                                statObject.displayname='Gm Login CST MTD';
                                statObject.actualvalue= GM_Login_CST_Val;
                                statObject.actualunit=Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login_CST';
                                statObject.displayname='Gm Login CST YTD';
                                statObject.actualvalue= GM_Login_CST_Val;
                                statObject.actualunit= Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login_CST';
                                statObject.displayname='Gm Login CST  TTM';
                                statObject.actualvalue= GM_Login_CST_Val;
                                statObject.actualunit= Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login_CST';
                                statObject.displayname='Gm Login CST';
                                statObject.actualvalue= GM_Login_CST_Val;
                                statObject.actualunit= Constants.Units.Text;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="lyroomsold"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomsold';
                                statObject.displayname='LastYear Room Sold MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].AvailableRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomsold';
                                statObject.displayname='LastYear Room Sold YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomsold';
                                statObject.displayname='LastYear Room Sold TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomsold';
                                statObject.displayname='LastYear Room Sold';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSold);
                                statObject.actualunit= Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="roomsoldvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomsoldvarience';
                                statObject.displayname='LastYear Room Sold Variance MTD';
                                statObject.actualvalue=(data.NoOfRoomSoldMTD-(records_LY==""?0:records_LY[0][index].NoOfRoomSoldMTD))*100/(records_LY==""?0:records_LY[0][index].NoOfRoomSoldMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomsoldvarience';
                                statObject.displayname='LastYear Room Sold Variance YTD';
                                statObject.actualvalue=(data.NoOfRoomSoldYTD-(records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD))*100/(records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomsoldvarience';
                                statObject.displayname='LastYear Room Sold Variance TTM';
                                statObject.actualvalue=(data.NoOfRoomSoldTTM-(records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM))*100/(records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomsoldvarience';
                                statObject.displayname='LastYear Room Sold Variance';
                                statObject.actualvalue=(data.NoOfRoomSold-(records_LY==""?0:records_LY[0][index].NoOfRoomSold))*100/(records_LY==""?0:records_LY[0][index].NoOfRoomSold);
                                statObject.actualunit= Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="outofordervarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outofordervarience';
                                statObject.displayname='Out Of Order LY Varience MTD';
                                statObject.actualvalue=(data.OutOfOrderRoomsMTD - (records_LY==""?0:records_LY[0][index].OutOfOrderRoomsMTD))*100/(records_LY==""?0:records_LY[0][index].OutOfOrderRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outofordervarience';
                                statObject.displayname='Out Of Order LY  Varience YTD';
                                statObject.actualvalue=(data.OutOfOrderRoomsYTD - (records_LY==""?0:records_LY[0][index].OutOfOrderRoomsYTD))*100/(records_LY==""?0:records_LY[0][index].OutOfOrderRoomsYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outofordervarience';
                                statObject.displayname='Out Of Order LY Varience TTM';
                                statObject.actualvalue=(data.OutOfOrderRoomsTTM - (records_LY==""?0:records_LY[0][index].OutOfOrderRoomsTTM))*100/(records_LY==""?0:records_LY[0][index].OutOfOrderRoomsTTM);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outofordervarience';
                                statObject.displayname='Out Of Order LY Varience';
                                statObject.actualvalue=(data.OutOfOrderRooms - (records_LY==""?0:records_LY[0][index].OutOfOrderRooms))*100/(records_LY==""?0:records_LY[0][index].OutOfOrderRooms);
                                statObject.actualunit= Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="otherincomebudgetvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomebudgetvarience';
                                statObject.displayname='Other Income Budget Varience MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomebudgetvarience';
                                statObject.displayname='Other Income Budget Varience YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomebudgetvarience';
                                statObject.displayname='Other Income Budget Varience TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomebudgetvarience';
                                statObject.displayname='Other Income Budget Varience ';
                                statObject.actualvalue=data.OtherRevenue- (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="otherincomevarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomevarience';
                                statObject.displayname='Other Income Varience MTD';
                                statObject.actualvalue=(data.OtherRevenueMTD - (records_LY==""?0:records_LY[0][index].OtherRevenueMTD))*100/(records_LY==""?0:records_LY[0][index].OtherRevenueMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomevarience';
                                statObject.displayname='Other Income Varience YTD';
                                statObject.actualvalue=(data.OtherRevenueYTD - (records_LY==""?0:records_LY[0][index].OtherRevenueYTD))*100/(records_LY==""?0:records_LY[0][index].OtherRevenueYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomevarience';
                                statObject.displayname='Other Income Varience TTM';
                                statObject.actualvalue=(data.OtherRevenueTTM  - (records_LY==""?0:records_LY[0][index].OtherRevenueTTM))*100/(records_LY==""?0:records_LY[0][index].OtherRevenueTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomevarience';
                                statObject.displayname='Other Income Varience ';
                                statObject.actualvalue=(data.OtherRevenue - (records_LY==""?0:records_LY[0][index].OtherRevenue))*100/(records_LY==""?0:records_LY[0][index].OtherRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalrevenuebudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalrevenuebudget';
                                statObject.displayname='Total Revenue Budget MTD';
                                statObject.actualvalue=_.sum([(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget),
                                (budgetrecords==""?0:budgetrecords[0][index].FNBMonthHotelBudget),
                                (budgetrecords==""?0:budgetrecords[0][index].OtherMonthHotelBudget)]);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalrevenuebudget';
                                statObject.displayname='Total Revenue Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalrevenuebudget';
                                statObject.displayname='Total Revenue Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalrevenuebudget';
                                statObject.displayname='Total Revenue Budget';                                
                                statObject.actualvalue= _.sum([(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue),
                                (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue),
                                (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)]);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="extendetstayadrLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY';                                
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="extendetstayadrLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY';                                
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="occexcludingooo"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occexcludingooo';
                                statObject.displayname='Occ Excluding OOO MTD';
                                statObject.actualvalue=data.OccupancyExcludingOOOMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occexcludingooo';
                                statObject.displayname='Occ Excluding OOO YTD';
                                statObject.actualvalue=data.OccupancyExcludingOOOYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occexcludingooo';
                                statObject.displayname='Occ Excluding OOO TTM';
                                statObject.actualvalue=data.OccupancyExcludingOOOTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occexcludingooo';
                                statObject.displayname='Occ Excluding OOO';                                
                                statObject.actualvalue=data.OccupancyExcludingOOO;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOO);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }                        
                        else if(kpi=="occexcludingoooLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='occexcludingoooLY';
                                statObject.displayname='Occ Excluding OOO LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='occexcludingoooLY';
                                statObject.displayname='Occ Excluding OOO LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='occexcludingoooLY';
                                statObject.displayname='Occ Excluding OOO LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='occexcludingoooLY';
                                statObject.displayname='Occ Excluding OOO LY';                                
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOO);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparexcludingooo"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingooo';
                                statObject.displayname='RevPar Excluding OOO MTD';
                                statObject.actualvalue=data.RevPARExcludingOOOMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingooo';
                                statObject.displayname='RevPar Excluding OOO YTD';
                                statObject.actualvalue=data.RevPARExcludingOOOYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingooo';
                                statObject.displayname='RevPar Excluding OOO TTM';
                                statObject.actualvalue=data.RevPARExcludingOOOTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingooo';
                                statObject.displayname='RevPar Excluding OOO';                                
                                statObject.actualvalue=data.RevPARExcludingOOO;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOO);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }else if(kpi=="revparexcludingoooLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparexcludingoooLY';
                                statObject.displayname='RevPar Excluding OOO LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparexcludingoooLY';
                                statObject.displayname='RevPar Excluding OOO LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingoooLY';
                                statObject.displayname='RevPar Excluding OOO LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingoooLY';
                                statObject.displayname='RevPar Excluding OOO LY';                                
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOO);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="esroomsold"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='esroomsold';
                                statObject.displayname='ES Room SOld MTD';
                                statObject.actualvalue=data.ESRoomSoldMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='esroomsold';
                                statObject.displayname='ES Room SOld YTD';
                                statObject.actualvalue=data.ESRoomSoldYTD;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='esroomsold';
                                statObject.displayname='ES Room SOld TTM';
                                statObject.actualvalue=data.ESRoomSoldTTM;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='esroomsold';
                                statObject.displayname='ES Room SOld LY';                                
                                statObject.actualvalue=data.ESRoomSold;
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="roomrevenuevarience%"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='roomrevenuevarience%';
                                statObject.displayname='Room Revenue Varience(%) MTD';
                                statObject.actualvalue=((RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntMTD)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AomuntMTD))*100/(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AomuntMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='roomrevenuevarience%';
                                statObject.displayname='Room Revenue Varience(%) YTD';
                                statObject.actualvalue=((RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntYTD)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AomuntYTD))*100/(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AomuntYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='roomrevenuevarience%';
                                statObject.displayname='Room Revenue Varience(%) TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience%';
                                statObject.displayname='Room Revenue Varience(%)';                                
                                statObject.actualvalue=((RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt))*100/(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="adrvarience%"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='adrvarience%';
                                statObject.displayname='ADR Varience(%) MTD';
                                statObject.actualvalue=(data.ADRMTD - (records_LY==""?0:records_LY[0][index].ADRMTD))*100/(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='adrvarience%';
                                statObject.displayname='ADR Varience(%) YTD';
                                statObject.actualvalue=(data.ADRYTD - (records_LY==""?0:records_LY[0][index].ADRYTD))*100/(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='adrvarience%';
                                statObject.displayname='ADR Varience(%) TTM';
                                statObject.actualvalue=(data.ADRTTM - (records_LY==""?0:records_LY[0][index].ADRTTM))*100/(records_LY==""?0:records_LY[0][index].ADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='adrvarience%';
                                statObject.displayname='ADR Varience(%)';                                
                                statObject.actualvalue=(data.ADR - (records_LY==""?0:records_LY[0][index].ADR))*100/(records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strmpi"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpi';
                                statObject.displayname='STR-MPI MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpi';
                                statObject.displayname='STR-MPI YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpi';
                                statObject.displayname='STR-MPI TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpi';
                                statObject.displayname='STR-MPI';                                
                                statObject.actualvalue=(StrData==""?0:data.OccIndex);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strmpirank"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpirank';
                                statObject.displayname='STR-MPI Rank MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpirank';
                                statObject.displayname='STR-MPI Rank YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpirank';
                                statObject.displayname='STR-MPI Rank TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpirank';
                                statObject.displayname='STR-MPI Rank';                                
                                statObject.actualvalue=(StrData==""?"0":data.OccRank);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strari"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strari';
                                statObject.displayname='STR-ARI MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strari';
                                statObject.displayname='STR-ARI YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strari';
                                statObject.displayname='STR-ARI TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strari';
                                statObject.displayname='STR-ARI Rank';                                
                                statObject.actualvalue=(StrData==""?0:data.AdrIndex);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strarirank"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strarirank';
                                statObject.displayname='STR-ARI Rank MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strarirank';
                                statObject.displayname='STR-ARI Rank YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strarirank';
                                statObject.displayname='STR-ARI Rank TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strarirank';
                                statObject.displayname='STR-ARI Rank';                                
                                statObject.actualvalue=(StrData==""?"0":data.AdrRank);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strrgi"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgi';
                                statObject.displayname='STR-RGI MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgi';
                                statObject.displayname='STR-RGI YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgi';
                                statObject.displayname='STR-RGI TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgi';
                                statObject.displayname='STR-RGI';                                
                                statObject.actualvalue=(StrData==""?0:data.RevParIndex);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strrgirank"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgirank';
                                statObject.displayname='STR-RGI Rank MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgirank';
                                statObject.displayname='STR-RGI Rank YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgirank';
                                statObject.displayname='STR-RGI Rank TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgirank';
                                statObject.displayname='STR-RGI Rank';                                
                                statObject.actualvalue=(StrData==""?"0":data.RevParRank);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="monthgoal"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='monthgoal';
                                statObject.displayname='Month Goal MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='monthgoal';
                                statObject.displayname='Month Goal YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='monthgoal';
                                statObject.displayname='Month Goal TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='monthgoal';
                                statObject.displayname='Month Goal';                                
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)*Utils.daysInMonth(data.Date);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="monthforcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=date.Date;
                                statObject.kpikey='monthforecast';
                                statObject.displayname='Month Forecast MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=date.Date;
                                statObject.kpikey='monthforecast';
                                statObject.displayname='Month Forecast YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=date.Date;
                                statObject.kpikey='monthforecast';
                                statObject.displayname='Month Forecast TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=date.Date;
                                statObject.kpikey='monthforecast';
                                statObject.displayname='Month Forecast';                                
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue)*Utils.daysInMonth(data.Date);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
    
                    })
                    cd(null,[{"AllStatsData":AllStatsData}])
                })
            }else{
                
                let startDate = new Date(fromdate);
                let endDate = new Date(todate);
                var startDateLY = Utils.lastYearDate(startDate);
                var endDateLY = Utils.lastYearDate(endDate);

                if (period.toLowerCase()=="mtd"){
                    startDate = Utils.firstDayOfMonth(startDate);
                    endDate = Utils.lastDayOfMonth(endDate);
                    startDateLY = Utils.lastYearDate(startDate);
                    endDateLY = Utils.lastYearDate(endDate);
                }
                else if (period.toLowerCase()=="ytd"){
                    startDate = Utils.firstDayOfYear(startDate);
                    endDate = Utils.lastDayOfYear(endDate);
                    startDateLY = Utils.lastYearDate(startDate);
                    endDateLY = Utils.lastYearDate(endDate);
                }
                else if (period.toLowerCase()=="ttm")
                {
                    startDate = Utils.firstDayOfMonth(startDate);
                    startDate = Utils.lastYearDate(startDate);
        
                    startDateLY = Utils.firstDayOfMonth(startDate);
                    startDateLY = Utils.lastYearDate(startDateLY);
        
                    endDate = Utils.firstDayOfMonth(endDate);
                    endDate.setDate(startDate.getDate() - 1);
        
                    endDateLY = Utils.lastYearDate(endDateLY);
                }


                _.filter(hotels,function(Hoteldata){
                    let data1 = new Promise(function(resolve, reject) {
                        (recordsActive?
                        HoteldashboardcalculationsHelper.GetDataBetweenDate(Hoteldata.ID,startDate,endDate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            records.push(result)
                            resolve()
                            
                        }) : resolve());
                    })
                    let data2 = new Promise(function(resolve, reject) {
                        (budgetrecordsActive?
                        HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(Hoteldata.ID,startDate,endDate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            budgetrecords.push(result)
                            resolve()
                            
                            }) : resolve());
                        })  
                    let data3 = new Promise(function(resolve, reject) {
                        (records_LYActive?
                        HoteldashboardcalculationsHelper.GetDataBetweenDate(Hoteldata.ID,startDateLY,endDateLY,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            records_LY.push(result)
                            resolve()
                            
                            }):resolve());
                        })
                    let data4 = new Promise(function(resolve, reject) {
                        (budgetrecords_LYActive?
                        HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(Hoteldata.ID,startDateLY,endDateLY,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            budgetrecords_LY.push(result)
                            resolve()
                            
                            }) :resolve())
                        }) 

                    let data5 = new Promise(function(resolve, reject) {
                        (roomrecordsActive?
                        HotelroomstatusdashboardcalculationsHelper.GetDataBetweenDate(Hoteldata.ID,startDate,endDate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            roomrecords.push(result)
                            resolve()
                            
                            }) :resolve())
                        }) 
                    let data6 = new Promise(function(resolve, reject) {
                        (roomrecords_LYActive?
                        HotelroomstatusdashboardcalculationsHelper.GetDataBetweenDate(Hoteldata.ID,startDateLY,endDateLY,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            roomrecords_LY.push(result)
                            resolve()
                            
                            }) :resolve())
                        })

                    let data8 = new Promise(function(resolve, reject) {
                        (RoomRevenueRecordsActive?
                        HotelrevenueHelper.GetPayRollData(Hoteldata.ID,startDate,endDate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            RoomRevenueRecords.push(result)
                            resolve()
                            
                            }):resolve())
                        })
                    let data9 = new Promise(function(resolve, reject) {
                        (RoomRevenueRecords_LYActive?
                        HotelrevenueHelper.GetPayRollData(Hoteldata.ID,startDateLY,endDateLY,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            RoomRevenueRecords_LY.push(result)
                            resolve()
                            
                            }):resolve())
                        })
                    let data10 =new Promise(function(resolve, reject) {
                        (GM_LoginActive?
                        HotelgmloginmappingsHelper.GetDataBetweenDate(Hoteldata.ID,startDate,endDate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            GM_Login.push(result)
                            resolve()
                            
                            }):resolve())
                        })
                    let data11=new Promise(function(resolve, reject) {
                        (StrDataActive?
                        StrreportHelper.GetDataBetweenDate(Hoteldata.ID,startDate,endDate,(err,result)=>{
                            if (err) {
                                reject(err)
                            }
                            
                            StrData.push(result)
                            resolve()
                            
                            }):resolve())
                        })                                                        

                                                                                          
                    x.push(data1,data2,data3,data4,data5,data6,data8,data9,data10,data11);
    
                })
                Promise.all(x).then(resp=>{
                    
                    if(RoomRevenueRecords!=""){
                        
                        _.filter(records[0],function(data,index){                        
                            
                            RoomRevenueAomunt.push({"Aomunt":_.sumBy(RoomRevenueRecords[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.Amount;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                }),"AmountMTD":_.sumBy(RoomRevenueRecords[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.AmountMTD;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                }),"AmountYTD":_.sumBy(RoomRevenueRecords[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.AmountYTD;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                })})                                                               
                                
                        })
                    }
                    
                    if(RoomRevenueRecords_LY!=""){
                        
                        _.filter(records_LY[0],function(data,index){                        
                            
                            RoomRevenueAomunt_LY.push({"Aomunt":_.sumBy(RoomRevenueRecords_LY[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.Amount;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                }),"AmountMTD":_.sumBy(RoomRevenueRecords_LY[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.AmountMTD;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                }),"AmountYTD":_.sumBy(RoomRevenueRecords_LY[0], function (roomrevenue) {
                                    if(Utils.getFormattedDate(roomrevenue.Date,"YYYY-MM-DD")==Utils.getFormattedDate(data.Date,"YYYY-MM-DD")){
                                        return roomrevenue.AmountYTD;
                                    }else{
                                        return 0;
                                    }
                                    
                                    
                                })})                                                               
                                
                        })
                    } 

                

                    if(roomrecords!=""){
                        records[0] = _.filter(records[0],function(data,index){
                            let x = _.uniqBy([data, roomrecords[0][index]], 'Date');
                            return _.merge(x[0], x[1]);
                        })
                    }
                    if(roomrecords_LY!=""){
                        records_LY[0] = _.filter(records_LY[0],function(data,index){
                            let x = _.uniqBy([data, roomrecords_LY[0][index]], 'Date');
                            return  _.merge(x[0], x[1]);
                        })
                    }
                    if(StrData!=""){
                        records[0] = _.filter(records[0],function(data,index){
                            let x = _.uniqBy([data, StrData[0][index]], 'Date');
                            return _.merge(x[0], x[1]);
                        })
                    }
                    
                    if(records_LYActive){records[0] = (records!=""?records[0]:records_LY[0]);}
                    else if(budgetrecordsActive){records[0] = (records!=""?records[0]:budgetrecords[0]);}
                    if(roomrecordsActive){records[0] = (records!=""?records[0]:roomrecords[0]);}
                    else if(roomrecords_LYActive){records[0] = (records!=""?records[0]:roomrecords_LY[0]);}
                    _.filter(records[0],function(data,index){
                        if(kpi=="noofroomsold"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'noofroomsold';
                                statObject.displayname= 'No Of Room SoldMTD';
                                statObject.actualvalue= data.NoOfRoomSoldMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldMTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDBudgetRooms);
                                statObject.forcastvalue=0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'noofroomsold';
                                statObject.displayname= 'No Of Room SoldYTD';
                                statObject.actualvalue= data.NoOfRoomSoldYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].YTDBudgetRooms);
                                statObject.forcastvalue=0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                //#TO BE TEST
                                let statObject = new StatsData();
                                statObject.date=data.Date,
                                statObject.kpikey= 'noofroomsold';
                                statObject.displayname= 'No Of Room SoldTTM';
                                statObject.actualvalue= data.NoOfRoomSoldTTM;                             
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].TTMBudgetRooms);
                                statObject.forcastvalue=0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                               
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'noofroomsold';
                                statObject.displayname= 'No Of Room Sold';
                                statObject.actualvalue= data.NoOfRoomSold;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSold);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomSold);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastRoomSold);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                 
                            }
                        }
                        else if(kpi=="noofroomsoldLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'noofroomsoldLY';
                                statObject.displayname= 'No Of Room Sold LY MTD';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].NoOfRoomSoldMTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'noofroomsoldLY';
                                statObject.displayname= 'No Of Room Sold LY YTD';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'noofroomsoldLY';
                                statObject.displayname= 'No Of Room Sold LY TTM';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'noofroomsoldLY';
                                statObject.displayname= 'No Of Room Sold LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].NoOfRoomSold);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="noofroomsoldBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldBudget';
                                statObject.displayname= 'No Of Room Sold Budget MTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].MTDBudgetRooms);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldBudget';
                                statObject.displayname= 'No Of Room Sold Budget YTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].YTDBudgetRooms);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldBudget';
                                statObject.displayname= 'No Of Room Sold Budget TTM';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].TTMBudgetRooms);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldBudget';
                                statObject.displayname= 'No Of Room Sold Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomSold);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }
                        }
                        else if(kpi=="noofroomsoldForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldForcast';
                                statObject.displayname= 'No Of Room Sold Forcast MTD';
                                statObject.actualvalue= 0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldForcast';
                                statObject.displayname= 'No Of Room Sold Forcast YTD';
                                statObject.actualvalue= 0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldForcast';
                                statObject.displayname= 'No Of Room Sold Forcast TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'noofroomsoldForcast';
                                statObject.displayname= 'No Of Room Sold Forcast';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].ForecastRoomSold);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }
                        }else if(kpi=="totalroomrevenue"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'totalroomrevenue';
                                statObject.displayname= 'Total Room Revenue MTD';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD);
                                statObject.lyvalue=(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountMTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'totalroomrevenue';
                                statObject.displayname= 'Total Room Revenue YTD';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountYTD);
                                statObject.lyvalue=(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountYTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].YTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'totalroomrevenue';
                                statObject.displayname= 'Total Room Revenue TTM';
                                statObject.actualvalue= 0;
                                statObject.lyvalue=0;
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].TTMForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'totalroomrevenue';
                                statObject.displayname= 'Total Room Revenue';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt);
                                statObject.lyvalue=(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                 
                            }
                        }                          
                        else if(kpi=="totalroomrevenueLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY';
                                statObject.displayname= 'Total Room Revenue LY MTD';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY';
                                statObject.displayname= 'Total Room Revenue LY YTD';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY';
                                statObject.displayname= 'Total Room Revenue LY TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY';
                                statObject.displayname= 'Total Room Revenue LY';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        } 
                        else if(kpi=="totalroomrevenueBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueBudget';
                                statObject.displayname= 'Total Room Revenue Budget MTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueBudget';
                                statObject.displayname= 'Total Room Revenue Budget YTD';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueBudget';
                                statObject.displayname= 'Total Room Revenue Budget TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueBudget';
                                statObject.displayname= 'Total Room Revenue Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalroomrevenueForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueForcast';
                                statObject.displayname= 'Total Room Revenue Forcast MTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].MTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueForcast';
                                statObject.displayname= 'Total Room Revenue Forcast YTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].YTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueForcast';
                                statObject.displayname= 'Total Room Revenue Forcast TTM';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].TTMForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueForcast';
                                statObject.displayname= 'Total Room Revenue Forcast';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        } 
                        else if(kpi=="numberofavailablerooms"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'numberofavailablerooms';
                                statObject.displayname= 'Number of Available Rooms MTD';
                                statObject.actualvalue= data.AvailableRoomsMTD;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'numberofavailablerooms';
                                statObject.displayname= 'Number of Available Rooms YTD';
                                statObject.actualvalue= data.AvailableRoomsYTD;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'numberofavailablerooms';
                                statObject.displayname= 'Number of Available Rooms TTM';
                                statObject.actualvalue= data.AvailableRoomsTTM;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'numberofavailablerooms';
                                statObject.displayname= 'Number of Available Rooms';
                                statObject.actualvalue= data.AvailableRooms;
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="occ"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occ';
                                statObject.displayname= 'Occupancy MTD';
                                statObject.actualvalue=data.OccupancyMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occ';
                                statObject.displayname= 'Occupancy YTD';
                                statObject.actualvalue=data.OccupancyYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occ';
                                statObject.displayname= 'Occupancy TTM';
                                statObject.actualvalue=data.OccupancyTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occ';
                                statObject.displayname= 'Occupancy ';
                                statObject.actualvalue= data.Occupancy;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                 
                            }
                        }
                        else if(kpi=="occLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLY';
                                statObject.displayname= 'Occupancy LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLY';
                                statObject.displayname= 'Occupancy LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLY';
                                statObject.displayname= 'Occupancy LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLY';
                                statObject.displayname= 'Occupancy LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="occBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudget';
                                statObject.displayname= 'Occupancy Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject)); 
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudget';
                                statObject.displayname= 'Occupancy Budget YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject)); 
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudget';
                                statObject.displayname= 'Occupancy Budget TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudget';
                                statObject.displayname= 'Occupancy Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="occForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occForcast';
                                statObject.displayname= 'Occupancy Forcast MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occForcast';
                                statObject.displayname= 'Occupancy Forcast YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occForcast ';
                                statObject.displayname= 'Occupancy Forcast TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                               
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occForcast ';
                                statObject.displayname= 'Occupancy Forcast';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="occvarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarience';
                                statObject.displayname= 'Occupancy Varience MTD';
                                statObject.actualvalue=(data.OccupancyMTD - (records_LY==""?0:records_LY[0][index].OccupancyMTD))*100/(records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarience';
                                statObject.displayname= 'Occupancy Varience YTD';
                                statObject.actualvalue=(data.OccupancyYTD - (records_LY==""?0:records_LY[0][index].OccupancyYTD))*100/(records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                //# Need to Test
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarience ';
                                statObject.displayname= 'Occupancy Varience TTM';
                                statObject.actualvalue=(data.OccupancyTTM - (records_LY==""?0:records_LY[0][index].OccupancyTTM))*100/(records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarience ';
                                statObject.displayname= 'Occupancy Varience';
                                statObject.actualvalue=(data.Occupancy - (records_LY==""?0:records_LY[0][index].Occupancy))*100/(records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        } 
                        else if(kpi=="extendetstayocc"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'extendetstayocc';
                                statObject.displayname= 'Extendet Stay OCC MTD';
                                statObject.actualvalue=data.ESOccupancyMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'extendetstayocc';
                                statObject.displayname= 'Extendet Stay OCC YTD';
                                statObject.actualvalue=data.ESOccupancyYTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'extendetstayocc';
                                statObject.displayname= 'Extendet Stay OCC TTM';
                                statObject.actualvalue=data.ESOccupancyTTM;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'extendetstayocc';
                                statObject.displayname= 'Extendet Stay OCC ';
                                statObject.actualvalue= data.ESOccupancy;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                          
                            }
                        }
                        else if(kpi=="adr"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adr';
                                statObject.displayname= 'ADR MTD';
                                statObject.actualvalue=data.ADRMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adr';
                                statObject.displayname= 'ADR YTD';
                                statObject.actualvalue=data.ADRYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adr';
                                statObject.displayname= 'ADR TTM';
                                statObject.actualvalue=data.ADRTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].ADRTTM);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                          
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adr';
                                statObject.displayname= 'ADR';
                                statObject.actualvalue= data.ADR;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].ADR);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADR);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                        
                            }
                        }
                        else if(kpi=="adrLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY';
                                statObject.displayname= 'ADR LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY';
                                statObject.displayname= 'ADR LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY';
                                statObject.displayname= 'ADR LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY';
                                statObject.displayname= 'ADR LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }
                        }
                        else if(kpi=="adrBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget';
                                statObject.displayname= 'ADR Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget';
                                statObject.displayname= 'ADR Budget YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget';
                                statObject.displayname= 'ADR Budget TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget';
                                statObject.displayname= 'ADR Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="adrForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='adrForcast';
                                statObject.displayname= 'ADR Forcast MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='adrForcast';
                                statObject.displayname= 'ADR Forcast YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='adrForcast';
                                statObject.displayname='ADR Forcast TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='adrForcast';
                                statObject.displayname= 'ADR Forcast';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="adrvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrvarience';
                                statObject.displayname= 'ADR Varience MTD';
                                statObject.actualvalue=(data.ADRMTD - (records_LY==""?0:records_LY[0][index].ADRMTD))*100/(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrvarience';
                                statObject.displayname= 'ADR Varience YTD';
                                statObject.actualvalue=(data.ADRYTD - (records_LY==""?0:records_LY[0][index].ADRYTD))*100/(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrvarience';
                                statObject.displayname='ADR Varience TTM';
                                statObject.actualvalue=(data.ADRTTM - (records_LY==""?0:records_LY[0][index].ADRTTM))*100/(records_LY==""?0:records_LY[0][index].ADRTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrvarience';
                                statObject.displayname= 'ADR Varience';
                                statObject.actualvalue=(data.ADR - (records_LY==""?0:records_LY[0][index].ADR))*100/(records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="extendetstayadr"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayadr';
                                statObject.displayname= 'Extendet Stay ADR MTD';
                                statObject.actualvalue=data.ESADRMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayadr';
                                statObject.displayname= 'Extendet Stay ADR YTD';
                                statObject.actualvalue=data.ESADRYTD;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayadr';
                                statObject.displayname='Extendet Stay ADR TTM';
                                statObject.actualvalue=data.ESADRTTM; 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayadr';
                                statObject.displayname= 'Extendet Stay ADR';
                                statObject.actualvalue=data.ESADR;
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revpar"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revpar';
                                statObject.displayname='RevPar MTD';
                                statObject.actualvalue=data.RevPARMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARMTD);
                                statObject.budgetvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD))/100;
                                statObject.forcastvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revpar';
                                statObject.displayname='RevPar YTD';
                                statObject.actualvalue=data.RevPARYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.budgetvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD))/100;
                                statObject.forcastvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revpar';
                                statObject.displayname='RevPar TTM';
                                statObject.actualvalue=data.RevPARTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARTTM);
                                statObject.budgetvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM))/100;
                                statObject.forcastvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revpar';
                                statObject.displayname='RevPar';
                                statObject.actualvalue=data.RevPAR;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.budgetvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADR) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy))/100;
                                statObject.forcastvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADR) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }
                        else if(kpi=="revparLY"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject=new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY';
                                statObject.displayname='RevPar LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY';
                                statObject.displayname='RevPar LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY';
                                statObject.displayname='RevPar LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY';
                                statObject.displayname='RevPar LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparBudget"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject=new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparBudget';
                                statObject.displayname='RevPar Budget MTD';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparBudget';
                                statObject.displayname='RevPar Budget YTD';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparBudget';
                                statObject.displayname='RevPar Budget TTM';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparBudget';
                                statObject.displayname='RevPar Budget';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADR) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparForcast"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject=new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparForcast';
                                statObject.displayname='RevPar Forcast MTD';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparForcast';
                                statObject.displayname='RevPar Forcast YTD';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparForcast';
                                statObject.displayname='RevPar Forcast TTM';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM))/100;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='revparForcast';
                                statObject.displayname='RevPar Forcast';
                                statObject.actualvalue=((budgetrecords==""?0:budgetrecords[0][index].BudgetADR) * (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy))/100;
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparvarience';
                                statObject.displayname= 'RevPar Varience MTD';
                                statObject.actualvalue= (data.RevPARMTD - (records_LY==""?0:records_LY[0][index].RevPARMTD))*100/(records_LY==""?0:records_LY[0][index].RevPARMTD); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparvarience';
                                statObject.displayname= 'RevPar Varience YTD';
                                statObject.actualvalue= (data.RevPARYTD - (records_LY==""?0:records_LY[0][index].RevPARYTD))*100/(records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparvarience';
                                statObject.displayname='RevPar Varience TTM';
                                statObject.actualvalue=(data.RevPARTTM - (records_LY==""?0:records_LY[0][index].RevPARTTM))*100/(records_LY==""?0:records_LY[0][index].RevPARTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparvarience';
                                statObject.displayname= 'RevPar Varience';
                                statObject.actualvalue=(data.RevPAR - (records_LY==""?0:records_LY[0][index].RevPAR))*100/(records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="extendetstayrevpar"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayrevpar';
                                statObject.displayname='Extendet Stay RevPAR MTD';
                                statObject.actualvalue=data.ESRevPARMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayrevpar';
                                statObject.displayname='Extendet Stay RevPAR YTD';
                                statObject.actualvalue=data.ESRevPARYTD;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayrevpar';
                                statObject.displayname='Extendet Stay RevPAR TTM';
                                statObject.actualvalue=data.ESRevPARTTM;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='extendetstayrevpar';
                                statObject.displayname='Extendet Stay RevPAR';
                                statObject.actualvalue=data.ESRevPAR;   
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyrevenue"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyrevenue';
                                statObject.displayname='Total Property Revenue MTD';
                                statObject.actualvalue=_.sum([
                                    data.TotalRevenueMTD,
                                    data.FANDBRevenueMTD,
                                    data.OtherRevenueMTD,
                                    data.Outet1OtherRevenueMTD,
                                    data.Outet2OtherRevenueMTD,
                                    data.Outet3OtherRevenueMTD,
                                    data.Outet4OtherRevenueMTD,
                                    data.Outet1FANDBRevenueMTD,
                                    data.Outet2FANDBRevenueMTD,
                                    data.Outet3FANDBRevenueMTD,
                                    data.Outet4FANDBRevenueMTD,
                                    data.RestaurantRevenueMTD,
                                    data.BarRevenueMTD,
                                    data.BanquetRevenueMTD,
                                    data.ParkingRevenueMTD,
                                    data.GiftShopRevenueMTD,
                                    data.BeverageRevenueMTD,
                                    data.FoodRevenueMTD,
                                ]);
                                statObject.lyvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueMTD),
                                ]);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyrevenue';
                                statObject.displayname='Total Property Revenue YTD';
                                statObject.actualvalue=_.sum([
                                    data.TotalRevenueYTD,
                                    data.FANDBRevenueYTD,
                                    data.OtherRevenueYTD,
                                    data.Outet1OtherRevenueYTD,
                                    data.Outet2OtherRevenueYTD,
                                    data.Outet3OtherRevenueYTD,
                                    data.Outet4OtherRevenueYTD,
                                    data.Outet1FANDBRevenueYTD,
                                    data.Outet2FANDBRevenueYTD,
                                    data.Outet3FANDBRevenueYTD,
                                    data.Outet4FANDBRevenueYTD,
                                    data.RestaurantRevenueYTD,
                                    data.BarRevenueYTD,
                                    data.BanquetRevenueYTD,
                                    data.ParkingRevenueYTD,
                                    data.GiftShopRevenueYTD,
                                    data.BeverageRevenueYTD,
                                    data.FoodRevenueYTD,
                                ]);
                                statObject.lyvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueYTD),
                                ]);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyrevenue';
                                statObject.displayname='Total Property Revenue TTM';
                                statObject.actualvalue=_.sum([
                                    data.TotalRevenueTTM,
                                    data.FANDBRevenueTTM,
                                    data.OtherRevenueTTM,
                                    data.Outet1OtherRevenueTTM,
                                    data.Outet2OtherRevenueTTM,
                                    data.Outet3OtherRevenueTTM,
                                    data.Outet4OtherRevenueTTM,
                                    data.Outet1FANDBRevenueTTM,
                                    data.Outet2FANDBRevenueTTM,
                                    data.Outet3FANDBRevenueTTM,
                                    data.Outet4FANDBRevenueTTM,
                                    data.RestaurantRevenueTTM,
                                    data.BarRevenueTTM,
                                    data.BanquetRevenueTTM,
                                    data.ParkingRevenueTTM,
                                    data.GiftShopRevenueTTM,
                                    data.BeverageRevenueTTM,
                                    data.FoodRevenueTTM,
                                ]);
                                statObject.lyvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueTTM),
                                ]);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyrevenue';
                                statObject.displayname='Total Property Revenue';
                                statObject.actualvalue=_.sum([
                                    data.TotalRevenue,
                                    data.FANDBRevenue,
                                    data.OtherRevenue,
                                    data.Outet1OtherRevenue,
                                    data.Outet2OtherRevenue,
                                    data.Outet3OtherRevenue,
                                    data.Outet4OtherRevenue,
                                    data.Outet1FANDBRevenue,
                                    data.Outet2FANDBRevenue,
                                    data.Outet3FANDBRevenue,
                                    data.Outet4FANDBRevenue,
                                    data.RestaurantRevenue,
                                    data.BarRevenue,
                                    data.BanquetRevenue,
                                    data.ParkingRevenue,
                                    data.GiftShopRevenue,
                                    data.BeverageRevenue,
                                    data.FoodRevenue,
                                ]);
                                statObject.lyvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenue),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenue),
                                    (records_LY==""?0:records_LY[0][index].BarRevenue),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenue),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenue),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenue),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenue),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenue),
                                ]);
                                statObject.budgetvalue=_.sum([
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)
                                ]);
                                statObject.forcastvalue=_.sum([
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastOtherRevenue)
                                ]);  
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyrevenueLY"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueLY';
                                statObject.displayname='Total Property Revenue LY MTD';
                                statObject.actualvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueMTD),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueMTD),
                                ]);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueLY';
                                statObject.displayname='Total Property Revenue LY YTD';
                                statObject.actualvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueYTD),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueYTD),
                                ]);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueLY';
                                statObject.displayname='Total Property Revenue LY TTM';
                                statObject.actualvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BarRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenueTTM),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenueTTM),
                                ]);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueLY';
                                statObject.displayname='Total Property Revenue LY';
                                statObject.actualvalue=_.sum([
                                    (records_LY==""?0:records_LY[0][index].TotalRevenue),
                                    (records_LY==""?0:records_LY[0][index].FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet1OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet2OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet3OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet4OtherRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet1FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet2FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet3FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].Outet4FANDBRevenue),
                                    (records_LY==""?0:records_LY[0][index].RestaurantRevenue),
                                    (records_LY==""?0:records_LY[0][index].BarRevenue),
                                    (records_LY==""?0:records_LY[0][index].BanquetRevenue),
                                    (records_LY==""?0:records_LY[0][index].ParkingRevenue),
                                    (records_LY==""?0:records_LY[0][index].GiftShopRevenue),
                                    (records_LY==""?0:records_LY[0][index].BeverageRevenue),
                                    (records_LY==""?0:records_LY[0][index].FoodRevenue),
                                ]);   
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyrevenueBudget"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueBudget';
                                statObject.displayname='Total Property Revenue Budget MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueBudget';
                                statObject.displayname='Total Property Revenue Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueBudget';
                                statObject.displayname='Total Property Revenue Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueBudget';
                                statObject.displayname='Total Property Budget';
                                statObject.actualvalue=_.sum([
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)
                                ]);   
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyrevenueForcast"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueForcast';
                                statObject.displayname='Total Property Revenue Forecast MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueForcast';
                                statObject.displayname='Total Property Revenue Forecast YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueForcast';
                                statObject.displayname='Total Property Revenue Forecast TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyrevenueForcast';
                                statObject.displayname='Total Property Forecast';
                                statObject.actualvalue=_.sum([
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue),
                                    (budgetrecords==""?0:budgetrecords[0][index].ForecastOtherRevenue)
                                ]);   
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="comprooms"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comprooms';
                                statObject.displayname='Comp Rooms MTD';
                                statObject.actualvalue=data.CompRoomsMTD;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comprooms';
                                statObject.displayname='Comp Rooms YTD';
                                statObject.actualvalue=data.CompRoomsYTD;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comprooms';
                                statObject.displayname='Comp Rooms TTM';
                                statObject.actualvalue=data.CompRoomsTTM;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsTTM);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comprooms';
                                statObject.displayname='Comp Rooms';
                                statObject.actualvalue=data.CompRooms;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRooms);
                                statObject.actualunit=Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }                                                                      
                        else if(kpi=="comproomsLY"){
                            if(period.toLowerCase()=="mtd"){                               
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comproomsLY';
                                statObject.displayname='Comp Rooms LY MTD';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comproomsLY';
                                statObject.displayname='Comp Rooms LY YTD';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comproomsLY';
                                statObject.displayname='Comp Rooms LY TTM';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRoomsTTM);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='comproomsLY';
                                statObject.displayname='Comp Rooms LY';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].CompRooms);
                                statObject.actualunit=Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="outoforderrooms"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outoforderrooms';
                                statObject.displayname='Out of Order Rooms MTD';
                                statObject.actualvalue=data.OutOfOrderRoomsMTD;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outoforderrooms';
                                statObject.displayname='Out of Order Rooms YTD';
                                statObject.actualvalue=data.OutOfOrderRoomsYTD;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRoomsYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outoforderrooms';
                                statObject.displayname='Out of Order Rooms TTM';
                                statObject.actualvalue=data.OutOfOrderRoomsTTM;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRoomsTTM);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outoforderrooms';
                                statObject.displayname='Out of Order Rooms';
                                statObject.actualvalue=data.OutOfOrderRooms;
                                statObject.lyvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRooms);
                                statObject.actualunit=Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }
                        else if(kpi=="outoforderroomsLY"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=(roomrecords_LY==""?0:roomrecords_LY[0][index].Date);
                                statObject.kpikey='outoforderroomsLY';
                                statObject.displayname='Out of Order Rooms MTD';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(roomrecords_LY==""?0:roomrecords_LY[0][index].Date);
                                statObject.kpikey='outoforderroomsLY';
                                statObject.displayname='Out of Order Rooms YTD';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRoomsYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(roomrecords_LY==""?0:roomrecords_LY[0][index].Date);
                                statObject.kpikey='outoforderroomsLY';
                                statObject.displayname='Out of Order Rooms TTM';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRoomsTTM);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(roomrecords_LY==""?0:roomrecords_LY[0][index].Date);
                                statObject.kpikey='outoforderroomsLY';
                                statObject.displayname='Out of Order Rooms';
                                statObject.actualvalue=(roomrecords_LY==""?0:roomrecords_LY[0][index].OutOfOrderRooms);
                                statObject.actualunit=Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="occLYper"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLYper';
                                statObject.displayname= 'Occupancy(%) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLYper';
                                statObject.displayname= 'Occupancy(%) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLYper';
                                statObject.displayname= 'Occupancy(%) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'occLYper';
                                statObject.displayname= 'Occupancy(%) LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="occvarienceper"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarienceper';
                                statObject.displayname= 'Occupancy(%) Varience MTD ';
                                statObject.actualvalue=data.OccupancyMTD - (records_LY==""?0:records_LY[0][index].OccupancyMTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarienceper';
                                statObject.displayname= 'Occupancy(%) Varience YTD';
                                statObject.actualvalue=data.OccupancyYTD - (records_LY==""?0:records_LY[0][index].OccupancyYTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                //# Need to Test
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarienceper ';
                                statObject.displayname= 'Occupancy(%) Varience TTM';
                                statObject.actualvalue=data.OccupancyTTM - (records_LY==""?0:records_LY[0][index].OccupancyTTM);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'occvarienceper ';
                                statObject.displayname= 'Occupancy(%) Varience';
                                statObject.actualvalue=data.Occupancy - (records_LY==""?0:records_LY[0][index].Occupancy);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="occBudgetper"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudgetper';
                                statObject.displayname= 'Occupancy(%) Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyMTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject)); 
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudgetper';
                                statObject.displayname= 'Occupancy(%) Budget YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyYTD);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject)); 
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudgetper';
                                statObject.displayname= 'Occupancy(%) Budget TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancyTTM);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'occBudgetper';
                                statObject.displayname= 'Occupancy(%) Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetOccupancy);
                                statObject.actualunit=Constants.Units.Percentage;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="adrLY$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY$';
                                statObject.displayname= 'ADR($) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY$';
                                statObject.displayname= 'ADR($) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY$';
                                statObject.displayname= 'ADR($) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ADRTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'adrLY$';
                                statObject.displayname= 'ADR($) LY';
                                statObject.actualvalue= (records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                              
                            }
                        }
                        else if(kpi=="extendetstayoccLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayoccLY';
                                statObject.displayname= 'ExtendetStay OCC LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayoccLY';
                                statObject.displayname= 'ExtendetStay OCC LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESOccupancyYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'extendetstayoccLY';
                                statObject.displayname= 'ExtendetStay OCC LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESOccupancyTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'extendetstayoccLY';
                                statObject.displayname= 'ExtendetStay LY OCC ';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESOccupancy);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                          
                            }
                        }
                        else if(kpi=="adrBudget$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget$';
                                statObject.displayname= 'ADR($) Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget$';
                                statObject.displayname= 'ADR($) Budget YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget$';
                                statObject.displayname= 'ADR($) Budget TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'adrBudget$';
                                statObject.displayname= 'ADR($) Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="adrbudgetvariance"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adrbudgetvariance';
                                statObject.displayname= 'ADR($) Budget Varience MTD';
                                statObject.actualvalue= data.ADRMTD - (budgetrecords==""?0:budgetrecords[0][index].BudgetADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adrbudgetvariance';
                                statObject.displayname= 'ADR($) Budget Varience YTD';
                                statObject.actualvalue= data.ADRYTD - (budgetrecords==""?0:budgetrecords[0][index].BudgetADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adrbudgetvariance';
                                statObject.displayname= 'ADR($) Budget Varience TTM';
                                statObject.actualvalue= data.ADRTTM - (budgetrecords==""?0:budgetrecords[0][index].BudgetADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey= 'adrbudgetvariance';
                                statObject.displayname= 'ADR($) Budget Varience';
                                statObject.actualvalue= data.ADR - (budgetrecords==""?0:budgetrecords[0][index].BudgetADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="lyadrvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyadrvarience';
                                statObject.displayname= 'ADR($) Varience MTD';
                                statObject.actualvalue=data.ADRMTD - (records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyadrvarience';
                                statObject.displayname= 'ADR($) Varience YTD';
                                statObject.actualvalue=data.ADRYTD - (records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyadrvarience';
                                statObject.displayname='ADR($) Varience TTM';
                                statObject.actualvalue= data.ADRTTM - (records_LY==""?0:records_LY[0][index].ADRTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyadrvarience';
                                statObject.displayname= 'ADR($) Varience';
                                statObject.actualvalue=data.ADR - (records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparLY$"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject=new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY$';
                                statObject.displayname='RevPar($) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY$';
                                statObject.displayname='RevPar($) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY$';
                                statObject.displayname='RevPar($) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparLY$';
                                statObject.displayname='RevPar($) LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.actualunit=Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }                        
                        else if(kpi=="totalroomrevenueLY$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY$';
                                statObject.displayname= 'Room Revenue($) LY MTD';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY$';
                                statObject.displayname= 'Room Revenue($) LY YTD';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY$';
                                statObject.displayname= 'Room Revenue($) LY TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'totalroomrevenueLY$';
                                statObject.displayname= 'Room Revenue($) LY';
                                statObject.actualvalue= (RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                 
                            }
                        }
                        else if(kpi=="roomrevenueBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenueBudget';
                                statObject.displayname= 'Room Revenue($) Budget MTD';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenueBudget';
                                statObject.displayname= 'Room Revenue($) Budget YTD';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenueBudget';
                                statObject.displayname= 'Room Revenue($) Budget TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenueBudget';
                                statObject.displayname= 'Room Revenue($) Budget';
                                statObject.actualvalue= (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="roomrevenuebudgetvarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenuebudgetvarience';
                                statObject.displayname= 'Room Revenue($) Budget Varience MTD';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD)-(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenuebudgetvarience';
                                statObject.displayname= 'Room Revenue($) Budget Varience YTD';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountYTD)-0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenuebudgetvarience';
                                statObject.displayname= 'Room Revenue($) Budget Varience TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey= 'roomrevenuebudgetvarience';
                                statObject.displayname= 'Room Revenue($) Budget Varience';
                                statObject.actualvalue= (RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)-(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="lyroomrevenuevarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomrevenuevarience';
                                statObject.displayname= 'Room Revenue($) Varience LY MTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'lyroomrevenuevarience';
                                statObject.displayname= 'Room Revenue($) Varience LY YTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountYTD)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AmountYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'lyroomrevenuevarience';
                                statObject.displayname= 'Room Revenue($) Varience LY TTM';
                                statObject.actualvalue= 0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey= 'lyroomrevenuevarience';
                                statObject.displayname= 'Room Revenue($) Varience LY';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenue$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenue$';
                                statObject.displayname='FANDB Revenue($) MTD';
                                statObject.actualvalue=data.FANDBRevenueMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueMTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenue$';
                                statObject.displayname='FANDB Revenue($) YTD';
                                statObject.actualvalue=data.FANDBRevenueYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueYTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].YTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenue$';
                                statObject.displayname='FANDB Revenue($) TTM';
                                statObject.actualvalue=data.FANDBRevenueTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueTTM);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].TTMForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenue$';
                                statObject.displayname='FANDB Revenue($)';
                                statObject.actualvalue=data.FANDBRevenue;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenue);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenueLY$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='fandbrevenueLY$';
                                statObject.displayname='FANDB Revenue($) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='fandbrevenueLY$';
                                statObject.displayname='FANDB Revenue($) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='fandbrevenueLY$';
                                statObject.displayname='FANDB Revenue($) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenueTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='fandbrevenueLY$';
                                statObject.displayname='FANDB Revenue($) LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].FANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenueBudget$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueBudget$';
                                statObject.displayname='FANDB Revenue($) Budget MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueBudget$';
                                statObject.displayname='FANDB Revenue($) Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueBudget$';
                                statObject.displayname='FANDB Revenue($) Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueBudget$';
                                statObject.displayname='FANDB Revenue($) Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenueForcast$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueForcast$';
                                statObject.displayname='FANDB Revenue($) Forcast MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueForcast$';
                                statObject.displayname='FANDB Revenue($) Forcast YTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].YTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueForcast$';
                                statObject.displayname='FANDB Revenue($) Forcast TTM';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].TTMForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='fandbrevenueForcast$';
                                statObject.displayname='FANDB Revenue($) Forcast';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="otherincome$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincome$';
                                statObject.displayname='Other Income($) MTD';
                                statObject.actualvalue=data.OtherRevenueMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueMTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincome$';
                                statObject.displayname='Other Income($) YTD';
                                statObject.actualvalue=data.OtherRevenueYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueYTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincome$';
                                statObject.displayname='Other Income($) TTM';
                                statObject.actualvalue=data.OtherRevenueTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueTTM); 
                                statObject.budgetvalue=0; 
                                statObject.forcastvalue=0; 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincome$';
                                statObject.displayname='Other Income($)';
                                statObject.actualvalue=data.OtherRevenue;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OtherRevenue);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOtherRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }
                        }
                        else if(kpi=="otherincomeLY$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomeLY$';
                                statObject.displayname='Other Income($) LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomeLY$';
                                statObject.displayname='Other Income($) LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomeLY$';
                                statObject.displayname='Other Income($) LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OtherRevenueTTM); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomeLY$';
                                statObject.displayname='Other Income($) LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OtherRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="otherincomeBudget$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeBudget$';
                                statObject.displayname='Other Income($) Budget MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeBudget$';
                                statObject.displayname='Other Income($) Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeBudget$';
                                statObject.displayname='Other Income($) Budget TTM';
                                statObject.actualvalue=0; 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeBudget$';
                                statObject.displayname='Other Income($) Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="otherincomeForcast$"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeForcast$';
                                statObject.displayname='Other Income($) Forcast MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeForcast$';
                                statObject.displayname='Other Income($) Forcast YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeForcast$';
                                statObject.displayname='Other Income($) Forcast TTM';
                                statObject.actualvalue=0; 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='otherincomeForcast$';
                                statObject.displayname='Other Income($) Forcast';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastOtherRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalproperty"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalproperty';
                                statObject.displayname='Total Property MTD';
                                statObject.actualvalue=data.TotalRevenueMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueMTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalproperty';
                                statObject.displayname='Total Property YTD';
                                statObject.actualvalue=data.TotalRevenueYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueYTD);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalproperty';
                                statObject.displayname='Total Property TTM';
                                statObject.actualvalue=data.TotalRevenueTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueTTM);
                                statObject.budgetvalue=0;
                                statObject.forcastvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalproperty';
                                statObject.displayname='Total Property';
                                statObject.actualvalue=data.TotalRevenue;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].TotalRevenue);
                                statObject.budgetvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetTotalRevenue);
                                statObject.forcastvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastTotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                                
                            }
                        }
                        else if(kpi=="totalpropertyLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyLY';
                                statObject.displayname='Total Property LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyLY';
                                statObject.displayname='Total Property LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueYTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyLY';
                                statObject.displayname='Total Property LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].TotalRevenueTTM);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='totalpropertyLY';
                                statObject.displayname='Total Property LY';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].TotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalpropertyForcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyForcast';
                                statObject.displayname='Total Property Forcast MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyForcast';
                                statObject.displayname='Total Property Forcast YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyForcast';
                                statObject.displayname='Total Property Forcast TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyForcast';
                                statObject.displayname='Total Property Forcast';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastTotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalpropertyBudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyBudget';
                                statObject.displayname='Total Property Budget MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyBudget';
                                statObject.displayname='Total Property Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyBudget';
                                statObject.displayname='Total Property Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='totalpropertyBudget';
                                statObject.displayname='Total Property Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetTotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="fandbrevenuevarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuevarience';
                                statObject.displayname='FANDB Revenue Varience MTD';
                                statObject.actualvalue=(data.FANDBRevenueMTD - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueMTD)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueMTD));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuevarience';
                                statObject.displayname='FANDB Revenue Varience YTD';
                                statObject.actualvalue=(data.FANDBRevenueYTD - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueYTD)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueYTD));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuevarience';
                                statObject.displayname='FANDB Revenue Varience TTM';
                                statObject.actualvalue=(data.FANDBRevenueTTM - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueTTM)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueTTM));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuevarience';
                                statObject.displayname='FANDB Revenue Varience';
                                statObject.actualvalue=(data.FANDBRevenue - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenue)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenue));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="totalpropertyvarience"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyvarience';
                                statObject.displayname='Total Property Varience MTD';
                                statObject.actualvalue=(data.FANDBRevenueMTD - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueMTD)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueMTD));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyvarience';
                                statObject.displayname='Total Property Varience YTD';
                                statObject.actualvalue=(data.FANDBRevenueYTD - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueYTD)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueYTD));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyvarience';
                                statObject.displayname='Total Property Varience TTM';
                                statObject.actualvalue=(data.FANDBRevenueTTM - (records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueTTM)))*100/(records_LY==""?0:(records_LY[0][index]==undefined?0:records_LY[0][index].FANDBRevenueTTM));
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyvarience';
                                statObject.displayname='Total Property Varience';
                                statObject.actualvalue=(data.TotalRevenue - (records_LY==""?0:records_LY[0][index].TotalRevenue))*100/(records_LY==""?0:records_LY[0][index].TotalRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                                
                            }
                        }
                        else if(kpi=="lyrevparvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyrevparvarience';
                                statObject.displayname= 'RevPar Varience LY MTD';
                                statObject.actualvalue= data.RevPARMTD - (records_LY==""?0:records_LY[0][index].RevPARMTD); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyrevparvarience';
                                statObject.displayname= 'RevPar Varience LY YTD';
                                statObject.actualvalue= data.RevPARYTD - (records_LY==""?0:records_LY[0][index].RevPARYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyrevparvarience';
                                statObject.displayname='RevPar Varience LY TTM';
                                statObject.actualvalue=data.RevPARTTM - (records_LY==""?0:records_LY[0][index].RevPARTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='lyrevparvarience';
                                statObject.displayname= 'RevPar Varience LY';
                                statObject.actualvalue=data.RevPAR - (records_LY==""?0:records_LY[0][index].RevPAR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="fandbrevenuebudgetvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuebudgetvarience';
                                statObject.displayname='F&B Revenue Budget Variance MTD';
                                statObject.actualvalue=data.FANDBRevenueMTD - (budgetrecords==""?0:budgetrecords[0][index].FNBMonthHotelBudget); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuebudgetvarience';
                                statObject.displayname='F&B Revenue Budget Variance YTD';
                                statObject.actualvalue=data.FANDBRevenueYTD - 0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuebudgetvarience';
                                statObject.displayname='F&B Revenue Budget Variance TTM';
                                statObject.actualvalue=data.FANDBRevenueTTM - 0; 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenuebudgetvarience';
                                statObject.displayname='F&B Revenue Budget Variance';
                                statObject.actualvalue=data.FANDBRevenue - (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertybudgetvarience"){
                            if(period.toLowerCase()=="mtd"){  
                                let totalbudget = _.sum([(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget),(budgetrecords==""?0:budgetrecords[0][index].FNBMonthHotelBudget),(budgetrecords==""?0:budgetrecords[0][index].OtherMonthHotelBudget)]);                              
                                let totalrevenue= _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntMTD),data.FANDBRevenueMTD,data.OtherRevenueMTD])
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertybudgetvarience';
                                statObject.displayname='Total Property Budget Variance MTD';
                                statObject.actualvalue=(totalrevenue-totalbudget); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let totalrevenue = _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntYTD),data.FANDBRevenueYTD,data.OtherRevenueYTD]);
                                let totalbudget=0;
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertybudgetvarience';
                                statObject.displayname='Total Property Budget Variance YTD';
                                statObject.actualvalue=(totalrevenue-totalbudget);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let totalrevenue= _.sum([0,data.FANDBRevenueTTM,data.OtherRevenueTTM]);
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertybudgetvarience';
                                statObject.displayname='Total Property Budget Variance TTM';
                                statObject.actualvalue=(totalrevenue-0);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let totalbudget = _.sum([(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue),(budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue),(budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)]);
                                let totalrevenue=_.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt),data.FANDBRevenue,data.OtherRevenue])
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertybudgetvarience';
                                statObject.displayname='Total Property Budget Variance ';
                                statObject.actualvalue=(totalrevenue-totalbudget);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparbudgetvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparbudgetvarience';
                                statObject.displayname='Total Property Budget Variance MTD';
                                statObject.actualvalue=0; 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparbudgetvarience';
                                statObject.displayname='Total Property Budget Variance YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparbudgetvarience';
                                statObject.displayname='Total Property Budget Variance TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let x = (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                let y = (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue);
                                let z = (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue);
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparbudgetvarience';
                                statObject.displayname='Total Property Budget Variance ';
                                statObject.actualvalue=0-_.sum[x,y,z];
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="roomrevenueforcastvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomrevenueforcastvarience';
                                statObject.displayname='Room Revenue Forecast Variance MTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD)-(budgetrecords==""?0:budgetrecords[0][index].MTDForecastRoomRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomrevenueforcastvarience';
                                statObject.displayname='Room Revenue Forecast Variance YTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountYTD)-(budgetrecords==""?0:budgetrecords[0][index].YTDForecastRoomRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomrevenueforcastvarience';
                                statObject.displayname='Room Revenue Forecast Variance TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomrevenueforcastvarience';
                                statObject.displayname='Room Revenue Forecast Variance';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)-(budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="fandbrevenueforcastvarience"){
                            if(period.toLowerCase()=="mtd"){                                
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenueforcastvarience';
                                statObject.displayname='FANDB Revenue Forecast Variance MTD';
                                statObject.actualvalue=data.FANDBRevenueMTD - (budgetrecords==""?0:budgetrecords[0][index].MTDForecastFANDBRevenue);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenueforcastvarience';
                                statObject.displayname='FANDB Revenue Forecast Variance YTD';
                                statObject.actualvalue=data.FANDBRevenueYTD -(budgetrecords==""?0:budgetrecords[0][index].YTDForecastFANDBRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenueforcastvarience';
                                statObject.displayname='FANDB Revenue Forecast Variance TTM';
                                statObject.actualvalue=data.FANDBRevenueTTM -(budgetrecords==""?0:budgetrecords[0][index].TTMForecastFANDBRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='fandbrevenueforcastvarience';
                                statObject.displayname='FANDB Revenue Forecast Variance';
                                statObject.actualvalue= data.FANDBRevenue - (budgetrecords==""?0:budgetrecords[0][index].ForecastFANDBRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalpropertyforcastvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let totalrevenue = _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntMTD),data.OtherRevenueMTD,data.FANDBRevenueMTD]);                               
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyforcastvarience';
                                statObject.displayname='Total Property Forcast Variance MTD';
                                statObject.actualvalue=totalrevenue-0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let totalrevenue = _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntYTD),data.OtherRevenueYTD,data.FANDBRevenueYTD]);
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyforcastvarience';
                                statObject.displayname='Total Property Forcast Variance YTD';
                                statObject.actualvalue=totalrevenue-0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let totalrevenue = _.sum([0,data.OtherRevenueTTM,data.FANDBRevenueTTM]);
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyforcastvarience';
                                statObject.displayname='Total Property Forcast Variance TTM';
                                statObject.actualvalue=totalrevenue-0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let totalrevenue = _.sum([(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt),data.OtherRevenue,data.FANDBRevenue]);
                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalpropertyforcastvarience';
                                statObject.displayname='Total Property Forcast Variance';
                                statObject.actualvalue= totalrevenue - (budgetrecords==""?0:budgetrecords[0][index].ForecastTotalRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="occforcastvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occforcastvarience';
                                statObject.displayname='Occupancy Forcast Variance MTD';
                                statObject.actualvalue=data.OccupancyMTD - (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occforcastvarience';
                                statObject.displayname='Occupancy Forcast Variance YTD';
                                statObject.actualvalue=data.OccupancyYTD - (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occforcastvarience';
                                statObject.displayname='Occupancy Forcast Variance TTM';
                                statObject.actualvalue=data.OccupancyTTM - (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occforcastvarience';
                                statObject.displayname='Occupancy Forcast Variance';
                                statObject.actualvalue=data.Occupancy -  (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancy);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="adrforcastvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrforcastvarience';
                                statObject.displayname='ADR Forcast Variance MTD';
                                statObject.actualvalue=data.ADRMTD - (budgetrecords==""?0:budgetrecords[0][index].ForecastADRMTD); 
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrforcastvarience';
                                statObject.displayname='ADR Forcast Variance YTD';
                                statObject.actualvalue=data.ADRYTD - (budgetrecords==""?0:budgetrecords[0][index].ForecastADRYTD); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrforcastvarience';
                                statObject.displayname='ADR Forcast Variance TTM';
                                statObject.actualvalue=data.ADRTTM - (budgetrecords==""?0:budgetrecords[0][index].ForecastADRTTM); 
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='adrforcastvarience';
                                statObject.displayname='ADR Forcast Variance';
                                statObject.actualvalue=data.ADR - (budgetrecords==""?0:budgetrecords[0][index].ForecastADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparforcastvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let RevParForcastMTD = ((budgetrecords==""?0:budgetrecords[0][index].ForecastADRMTD) * (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyMTD))/100; 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparforcastvarience';
                                statObject.displayname='RevPAR Forcast Variance MTD';
                                statObject.actualvalue=data.RevPARMTD - RevParForcastMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let RevParForcastYTD = ((budgetrecords==""?0:budgetrecords[0][index].ForecastADRYTD) * (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyYTD))/100; 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparforcastvarience';
                                statObject.displayname='RevPAR Forcast Variance YTD';
                                statObject.actualvalue=data.RevPARYTD - RevParForcastYTD;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){
                                let RevParForcastTTM = ((budgetrecords==""?0:budgetrecords[0][index].ForecastADRTTM) * (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancyTTM))/100; 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparforcastvarience';
                                statObject.displayname='RevPAR Forcast Variance TTM';
                                statObject.actualvalue=data.RevPARTTM - RevParForcastTTM;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let RevParForcast = ((budgetrecords==""?0:budgetrecords[0][index].ForecastADR) * (budgetrecords==""?0:budgetrecords[0][index].ForecastOccupancy))/100;                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparforcastvarience';
                                statObject.displayname='RevPAR Forcast Variance';
                                statObject.actualvalue=data.RevPAR - RevParForcast;
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revenuevariancebObtogoal"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revenuevariancebObtogoal';
                                statObject.displayname='Revenue Variance BOB To Goal($) MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].MTDBudgetBOB) - (budgetrecords==""?0:budgetrecords[0][index].MonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revenuevariancebObtogoal';
                                statObject.displayname='Revenue Variance BOB To Goal($) YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revenuevariancebObtogoal';
                                statObject.displayname='Revenue Variance BOB To Goal($) TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revenuevariancebObtogoal';
                                statObject.displayname='Revenue Variance BOB To Goal($)';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="roomsbudget"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomsbudget';
                                statObject.displayname='Rooms Budget MTD';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomsbudget';
                                statObject.displayname='Rooms Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomsbudget';
                                statObject.displayname='Rooms Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomsbudget';
                                statObject.displayname='Rooms Budget';
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="roomrevenuebudgetvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience';
                                statObject.displayname='Rooms Budget Varience MTD';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AmountMTD) - (budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience';
                                statObject.displayname='Rooms Budget Varience YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience';
                                statObject.displayname='Rooms Budget Varience TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{
                                let statObject = new StatsData();
                                statObject.date=(budgetrecords==""?0:budgetrecords[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience';
                                statObject.displayname='Rooms Budget Varience';
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt) - (budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="gm_login"){
                            let GM_Login_Val='';
                            if(GM_Login!=""){
                                _.filter(GM_Login[0],function(i){
    
                                    let date = Utils.getFormattedDate(i.LastGMLoginDateTime,"YYYY-MM-DD");
                                    let LastGMLoginDate = new Date(date)
                                    
                                    //let CSTtime=Utils.convertLocalTimeCST(i.LastGMLoginDateTime);
                                    if(LastGMLoginDate.getTime()===new Date(Utils.addDays(data.Date,1)).getTime()){
                                        GM_Login_Val=i.LastGMLoginDateTime;
                                        //GM_Login_CST_Val=CSTtime; 
                                    }
                              
                                })                  
                            }
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login';
                                statObject.displayname='Gm Login MTD';
                                statObject.actualvalue=GM_Login_Val;
                                statObject.actualunit=Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login';
                                statObject.displayname='Gm Login YTD';
                                statObject.actualvalue=GM_Login_Val;
                                statObject.actualunit= Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login';
                                statObject.displayname='Gm Login TTM';
                                statObject.actualvalue=GM_Login_Val;
                                statObject.actualunit= Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login';
                                statObject.displayname='Gm Login';
                                statObject.actualvalue=GM_Login_Val;
                                statObject.actualunit= Constants.Units.Text;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="gm_login_CST"){
                            let GM_Login_CST_Val='';
                            if(GM_Login!=""){
                                _.filter(GM_Login[0],function(i){
    
                                    let date = Utils.getFormattedDate(i.LastGMLoginDateTime,"YYYY-MM-DD");
                                    let LastGMLoginDate = new Date(date)
                                    
                                    let CSTtime=Utils.convertLocalTimeCST(i.LastGMLoginDateTime);
                                    if(LastGMLoginDate.getTime()===new Date(Utils.addDays(data.Date,1)).getTime()){
                                        //GM_Login_Val=i.LastGMLoginDateTime;
                                        GM_Login_CST_Val=CSTtime; 
                                    }
                              
                                })                  
                            }
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login_CST';
                                statObject.displayname='Gm Login CST MTD';
                                statObject.actualvalue= GM_Login_CST_Val;
                                statObject.actualunit=Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login_CST';
                                statObject.displayname='Gm Login CST YTD';
                                statObject.actualvalue= GM_Login_CST_Val;
                                statObject.actualunit= Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login_CST';
                                statObject.displayname='Gm Login CST  TTM';
                                statObject.actualvalue= GM_Login_CST_Val;
                                statObject.actualunit= Constants.Units.Text;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='gm_login_CST';
                                statObject.displayname='Gm Login CST';
                                statObject.actualvalue= GM_Login_CST_Val;
                                statObject.actualunit= Constants.Units.Text;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="lyroomsold"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomsold';
                                statObject.displayname='LastYear Room Sold MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].AvailableRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomsold';
                                statObject.displayname='LastYear Room Sold YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomsold';
                                statObject.displayname='LastYear Room Sold TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='lyroomsold';
                                statObject.displayname='LastYear Room Sold';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].NoOfRoomSold);
                                statObject.actualunit= Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="roomsoldvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomsoldvarience';
                                statObject.displayname='LastYear Room Sold Variance MTD';
                                statObject.actualvalue=(data.NoOfRoomSoldMTD-(records_LY==""?0:records_LY[0][index].NoOfRoomSoldMTD))*100/(records_LY==""?0:records_LY[0][index].NoOfRoomSoldMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomsoldvarience';
                                statObject.displayname='LastYear Room Sold Variance YTD';
                                statObject.actualvalue=(data.NoOfRoomSoldYTD-(records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD))*100/(records_LY==""?0:records_LY[0][index].NoOfRoomSoldYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomsoldvarience';
                                statObject.displayname='LastYear Room Sold Variance TTM';
                                statObject.actualvalue=(data.NoOfRoomSoldTTM-(records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM))*100/(records_LY==""?0:records_LY[0][index].NoOfRoomSoldTTM);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='roomsoldvarience';
                                statObject.displayname='LastYear Room Sold Variance';
                                statObject.actualvalue=(data.NoOfRoomSold-(records_LY==""?0:records_LY[0][index].NoOfRoomSold))*100/(records_LY==""?0:records_LY[0][index].NoOfRoomSold);
                                statObject.actualunit= Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="outofordervarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outofordervarience';
                                statObject.displayname='Out Of Order LY Varience MTD';
                                statObject.actualvalue=(data.OutOfOrderRoomsMTD - (records_LY==""?0:records_LY[0][index].OutOfOrderRoomsMTD))*100/(records_LY==""?0:records_LY[0][index].OutOfOrderRoomsMTD);
                                statObject.actualunit=Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outofordervarience';
                                statObject.displayname='Out Of Order LY  Varience YTD';
                                statObject.actualvalue=(data.OutOfOrderRoomsYTD - (records_LY==""?0:records_LY[0][index].OutOfOrderRoomsYTD))*100/(records_LY==""?0:records_LY[0][index].OutOfOrderRoomsYTD);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outofordervarience';
                                statObject.displayname='Out Of Order LY Varience TTM';
                                statObject.actualvalue=(data.OutOfOrderRoomsTTM - (records_LY==""?0:records_LY[0][index].OutOfOrderRoomsTTM))*100/(records_LY==""?0:records_LY[0][index].OutOfOrderRoomsTTM);
                                statObject.actualunit= Constants.Units.Number;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='outofordervarience';
                                statObject.displayname='Out Of Order LY Varience';
                                statObject.actualvalue=(data.OutOfOrderRooms - (records_LY==""?0:records_LY[0][index].OutOfOrderRooms))*100/(records_LY==""?0:records_LY[0][index].OutOfOrderRooms);
                                statObject.actualunit= Constants.Units.Number;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="otherincomebudgetvarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomebudgetvarience';
                                statObject.displayname='Other Income Budget Varience MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomebudgetvarience';
                                statObject.displayname='Other Income Budget Varience YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomebudgetvarience';
                                statObject.displayname='Other Income Budget Varience TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomebudgetvarience';
                                statObject.displayname='Other Income Budget Varience ';
                                statObject.actualvalue=data.OtherRevenue- (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="otherincomevarience"){
                            if(period.toLowerCase()=="mtd"){ 
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomevarience';
                                statObject.displayname='Other Income Varience MTD';
                                statObject.actualvalue=(data.OtherRevenueMTD - (records_LY==""?0:records_LY[0][index].OtherRevenueMTD))*100/(records_LY==""?0:records_LY[0][index].OtherRevenueMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomevarience';
                                statObject.displayname='Other Income Varience YTD';
                                statObject.actualvalue=(data.OtherRevenueYTD - (records_LY==""?0:records_LY[0][index].OtherRevenueYTD))*100/(records_LY==""?0:records_LY[0][index].OtherRevenueYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomevarience';
                                statObject.displayname='Other Income Varience TTM';
                                statObject.actualvalue=(data.OtherRevenueTTM  - (records_LY==""?0:records_LY[0][index].OtherRevenueTTM))*100/(records_LY==""?0:records_LY[0][index].OtherRevenueTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{                                
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='otherincomevarience';
                                statObject.displayname='Other Income Varience ';
                                statObject.actualvalue=(data.OtherRevenue - (records_LY==""?0:records_LY[0][index].OtherRevenue))*100/(records_LY==""?0:records_LY[0][index].OtherRevenue);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="totalrevenuebudget"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalrevenuebudget';
                                statObject.displayname='Total Revenue Budget MTD';
                                statObject.actualvalue=_.sum([(budgetrecords==""?0:budgetrecords[0][index].RoomRevenueMonthHotelBudget),
                                (budgetrecords==""?0:budgetrecords[0][index].FNBMonthHotelBudget),
                                (budgetrecords==""?0:budgetrecords[0][index].OtherMonthHotelBudget)]);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalrevenuebudget';
                                statObject.displayname='Total Revenue Budget YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalrevenuebudget';
                                statObject.displayname='Total Revenue Budget TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='totalrevenuebudget';
                                statObject.displayname='Total Revenue Budget';                                
                                statObject.actualvalue= _.sum([(budgetrecords==""?0:budgetrecords[0][index].BudgetRoomRevenue),
                                (budgetrecords==""?0:budgetrecords[0][index].BudgetFANDBRevenue),
                                (budgetrecords==""?0:budgetrecords[0][index].BudgetOtherRevenue)]);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="extendetstayadrLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY';                                
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="extendetstayadrLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='extendetstayadrLY';
                                statObject.displayname='Extendet Stay ADR LY';                                
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].ESADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="occexcludingooo"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occexcludingooo';
                                statObject.displayname='Occ Excluding OOO MTD';
                                statObject.actualvalue=data.OccupancyExcludingOOOMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occexcludingooo';
                                statObject.displayname='Occ Excluding OOO YTD';
                                statObject.actualvalue=data.OccupancyExcludingOOOYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occexcludingooo';
                                statObject.displayname='Occ Excluding OOO TTM';
                                statObject.actualvalue=data.OccupancyExcludingOOOTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='occexcludingooo';
                                statObject.displayname='Occ Excluding OOO';                                
                                statObject.actualvalue=data.OccupancyExcludingOOO;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOO);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }                        
                        else if(kpi=="occexcludingoooLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='occexcludingoooLY';
                                statObject.displayname='Occ Excluding OOO LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='occexcludingoooLY';
                                statObject.displayname='Occ Excluding OOO LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='occexcludingoooLY';
                                statObject.displayname='Occ Excluding OOO LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOOTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='occexcludingoooLY';
                                statObject.displayname='Occ Excluding OOO LY';                                
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].OccupancyExcludingOOO);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="revparexcludingooo"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingooo';
                                statObject.displayname='RevPar Excluding OOO MTD';
                                statObject.actualvalue=data.RevPARExcludingOOOMTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingooo';
                                statObject.displayname='RevPar Excluding OOO YTD';
                                statObject.actualvalue=data.RevPARExcludingOOOYTD;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingooo';
                                statObject.displayname='RevPar Excluding OOO TTM';
                                statObject.actualvalue=data.RevPARExcludingOOOTTM;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormatGroup(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingooo';
                                statObject.displayname='RevPar Excluding OOO';                                
                                statObject.actualvalue=data.RevPARExcludingOOO;
                                statObject.lyvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOO);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormatGroup(statObject));                             
                            }
                        }else if(kpi=="revparexcludingoooLY"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparexcludingoooLY';
                                statObject.displayname='RevPar Excluding OOO LY MTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='revparexcludingoooLY';
                                statObject.displayname='RevPar Excluding OOO LY YTD';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingoooLY';
                                statObject.displayname='RevPar Excluding OOO LY TTM';
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOOTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='revparexcludingoooLY';
                                statObject.displayname='RevPar Excluding OOO LY';                                
                                statObject.actualvalue=(records_LY==""?0:records_LY[0][index].RevPARExcludingOOO);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="esroomsold"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='esroomsold';
                                statObject.displayname='ES Room SOld MTD';
                                statObject.actualvalue=data.ESRoomSoldMTD;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='esroomsold';
                                statObject.displayname='ES Room SOld YTD';
                                statObject.actualvalue=data.ESRoomSoldYTD;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='esroomsold';
                                statObject.displayname='ES Room SOld TTM';
                                statObject.actualvalue=data.ESRoomSoldTTM;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='esroomsold';
                                statObject.displayname='ES Room SOld LY';                                
                                statObject.actualvalue=data.ESRoomSold;
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="roomrevenuevarience%"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='roomrevenuevarience%';
                                statObject.displayname='Room Revenue Varience(%) MTD';
                                statObject.actualvalue=((RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntMTD)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AomuntMTD))*100/(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AomuntMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='roomrevenuevarience%';
                                statObject.displayname='Room Revenue Varience(%) YTD';
                                statObject.actualvalue=((RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].AomuntYTD)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AomuntYTD))*100/(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].AomuntYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='roomrevenuevarience%';
                                statObject.displayname='Room Revenue Varience(%) TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='roomrevenuebudgetvarience%';
                                statObject.displayname='Room Revenue Varience(%)';                                
                                statObject.actualvalue=((RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)-(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt))*100/(RoomRevenueAomunt_LY==""?0:RoomRevenueAomunt_LY[index].Aomunt);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="adrvarience%"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='adrvarience%';
                                statObject.displayname='ADR Varience(%) MTD';
                                statObject.actualvalue=(data.ADRMTD - (records_LY==""?0:records_LY[0][index].ADRMTD))*100/(records_LY==""?0:records_LY[0][index].ADRMTD);
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='adrvarience%';
                                statObject.displayname='ADR Varience(%) YTD';
                                statObject.actualvalue=(data.ADRYTD - (records_LY==""?0:records_LY[0][index].ADRYTD))*100/(records_LY==""?0:records_LY[0][index].ADRYTD);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='adrvarience%';
                                statObject.displayname='ADR Varience(%) TTM';
                                statObject.actualvalue=(data.ADRTTM - (records_LY==""?0:records_LY[0][index].ADRTTM))*100/(records_LY==""?0:records_LY[0][index].ADRTTM);
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=(records_LY==""?0:records_LY[0][index].Date);
                                statObject.kpikey='adrvarience%';
                                statObject.displayname='ADR Varience(%)';                                
                                statObject.actualvalue=(data.ADR - (records_LY==""?0:records_LY[0][index].ADR))*100/(records_LY==""?0:records_LY[0][index].ADR);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strmpi"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpi';
                                statObject.displayname='STR-MPI MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpi';
                                statObject.displayname='STR-MPI YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpi';
                                statObject.displayname='STR-MPI TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpi';
                                statObject.displayname='STR-MPI';                                
                                statObject.actualvalue=(StrData==""?0:data.OccIndex);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strmpirank"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpirank';
                                statObject.displayname='STR-MPI Rank MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpirank';
                                statObject.displayname='STR-MPI Rank YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpirank';
                                statObject.displayname='STR-MPI Rank TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strmpirank';
                                statObject.displayname='STR-MPI Rank';                                
                                statObject.actualvalue=(StrData==""?"0":data.OccRank);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strari"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strari';
                                statObject.displayname='STR-ARI MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strari';
                                statObject.displayname='STR-ARI YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strari';
                                statObject.displayname='STR-ARI TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strari';
                                statObject.displayname='STR-ARI Rank';                                
                                statObject.actualvalue=(StrData==""?0:data.AdrIndex);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strarirank"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strarirank';
                                statObject.displayname='STR-ARI Rank MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strarirank';
                                statObject.displayname='STR-ARI Rank YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strarirank';
                                statObject.displayname='STR-ARI Rank TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strarirank';
                                statObject.displayname='STR-ARI Rank';                                
                                statObject.actualvalue=(StrData==""?"0":data.AdrRank);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strrgi"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgi';
                                statObject.displayname='STR-RGI MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgi';
                                statObject.displayname='STR-RGI YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgi';
                                statObject.displayname='STR-RGI TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgi';
                                statObject.displayname='STR-RGI';                                
                                statObject.actualvalue=(StrData==""?0:data.RevParIndex);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="strrgirank"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgirank';
                                statObject.displayname='STR-RGI Rank MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgirank';
                                statObject.displayname='STR-RGI Rank YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgirank';
                                statObject.displayname='STR-RGI Rank TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='strrgirank';
                                statObject.displayname='STR-RGI Rank';                                
                                statObject.actualvalue=(StrData==""?"0":data.RevParRank);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }
                        else if(kpi=="monthgoal"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='monthgoal';
                                statObject.displayname='Month Goal MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='monthgoal';
                                statObject.displayname='Month Goal YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='monthgoal';
                                statObject.displayname='Month Goal TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=data.Date;
                                statObject.kpikey='monthgoal';
                                statObject.displayname='Month Goal';                                
                                statObject.actualvalue=(RoomRevenueAomunt==""?0:RoomRevenueAomunt[index].Aomunt)*Utils.daysInMonth(data.Date);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }else if(kpi=="monthforcast"){
                            if(period.toLowerCase()=="mtd"){
                                let statObject =new StatsData();
                                statObject.date=date.Date;
                                statObject.kpikey='monthforecast';
                                statObject.displayname='Month Forecast MTD';
                                statObject.actualvalue=0;
                                statObject.actualunit=Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ytd"){
                                let statObject = new StatsData();
                                statObject.date=date.Date;
                                statObject.kpikey='monthforecast';
                                statObject.displayname='Month Forecast YTD';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));
                            }else if(period.toLowerCase()=="ttm"){ 
                                let statObject = new StatsData();
                                statObject.date=date.Date;
                                statObject.kpikey='monthforecast';
                                statObject.displayname='Month Forecast TTM';
                                statObject.actualvalue=0;
                                statObject.actualunit= Constants.Units.DecimalNumber;
                                AllStatsData.push(statObject.setFormat(statObject));                            
                            }else{ 
                                let statObject = new StatsData();
                                statObject.date=date.Date;
                                statObject.kpikey='monthforecast';
                                statObject.displayname='Month Forecast';                                
                                statObject.actualvalue=(budgetrecords==""?0:budgetrecords[0][index].ForecastRoomRevenue)*Utils.daysInMonth(data.Date);
                                statObject.actualunit= Constants.Units.DecimalNumber;                               
                                AllStatsData.push(statObject.setFormat(statObject));                             
                            }
                        }                                                                 
                    })
                    cd(null,[{"AllStatsData":AllStatsData}])
                    
                })                
            }

    
    }
    static getChartData(userid,fromdate ,todate ,type ,id ,period,kpi,cd ){
        fromdate = (!fromdate?null:fromdate);
        todate = (!fromdate?null:todate);
        let hotels;
            if (type == "group"){
                let hotelgroupid = parseInt(id);
                return new Promise(function(resolve, reject) {
                    HotelGroupXrefHelper.GetHotelModelByGroupIdNew(hotelgroupid,userid,(err,result)=>{
                        if(err){
                            reject(err)
                            log.debug('get hotel models for type group is not exsisting ');
                        }
                        
                        hotels = result;
                        resolve();
                    });
                }).then(resp=>{
                    let promises = [];let y = [];
                                    
                    if(hotels.length>0){
                        _.filter(hotels,function(data){
                            let x=new Promise(function(resolve, reject) {
                                PersonalViewHelper.getChartDataResult([data],fromdate,todate,period,kpi,(err,result)=>{                                                    
                                    _.filter(result,function(x){
                                        
                                        promises.push(x);
                                        resolve();
                                    })
                                })
                            })
                            y.push(x);

                           
                            
                        })
                        Promise.all(y).then(resp => {
                            cd(null,promises);
                        })
                        
                    }else{
                        return PersonalViewHelper.getChartDataResult(hotels,fromdate,todate,period,kpi,cd);
                    }
                })

            }else if (type == "hotel"){

                return new Promise(function(resolve, reject) {
                    Hotelshelper.GetHotels(id, 0,(err,result)=>{
                        if(err){
                            reject(err)
                            log.debug('listing  hotels made error');
                        }
                        hotels = result;
                        resolve();
                        

                    })
                }).then(resp=>{
                    let kpiArray = [];
                    let kpiResults = [];
                    if (kpi.indexOf(',') != -1) {
                        kpiArray = kpi.split(',');
                    }
                    
                    if(hotels.length>0){
                        let um = hotels.filter(function(data){
                            return _.map(_.sortBy(data, data.ID), _.values);
                        })
                        return new Promise(function(resolve, reject) {                            
                            resolve(um)
                        }).then(um=>{
                            if(kpiArray!=null && kpiArray.length>0){
                                _.filter(kpiArray,(key)=>{
                                    let y = new Promise(function(resolve, reject) {
                                        PersonalViewHelper.getChartDataResult(um,fromdate,todate, period,key,(err,result)=>{
                                            resolve(result)
                                        });
                                    })
                                    kpiResults.push(y);
                                })
                                

                                Promise.all(kpiResults).then(result=>{
                                    let statsarray = [];
                                    _.filter(result,(key)=>{

                                        _.filter(key,(i)=>{

                                            _.filter(i.AllStatsData,(element)=>{                                                

                                                statsarray.push(element)
                                            })
                                            
                                            
                                        })

                                    })
                                    cd(null,[{"AllStatsData":statsarray}])
                                })

                            }else{
                                return PersonalViewHelper.getChartDataResult(um,fromdate,todate, period,kpi,cd);
                            }
                            //return PersonalViewHelper.getChartDataResult(um,fromdate,todate, period,kpi,cd);
                        })                        

                    }else{
                        return new Promise(function(resolve, reject) {                            
                            resolve(hotels)
                        }).then(hotels=>{
                            if(kpiArray!=null && kpiArray.length>0){
                                _.filter(kpiArray,(key)=>{
                                    let y = new Promise(function(resolve, reject) {
                                        PersonalViewHelper.getChartDataResult(um,fromdate,todate, period,key,(err,result)=>{
                                            resolve(result)
                                        });
                                    })
                                    kpiResults.push(y);
                                })
                                

                                Promise.all(kpiResults).then(result=>{

                                    let statsarray = [];
                                    _.filter(result,(key)=>{

                                        _.filter(key,(i)=>{

                                            _.filter(i.AllStatsData,(element)=>{                                                

                                                statsarray.push(element)
                                            })
                                            
                                            
                                        })

                                    })
                                    cd(null,[{"AllStatsData":statsarray}])
                                })

                            }else{
                                return PersonalViewHelper.getChartDataResult(um,fromdate,todate, period,kpi,cd);
                            }
                            //return PersonalViewHelper.getChartDataResult(hotels,fromdate,todate,period,kpi,cd);
                        })
                    }
                })
            }


    }

    static editTemplate(_id,userid,templateid,graphid,cd){
        let chartArray = [];
        let chart = new ChartData();
        PersonalviewsSchema.findById(templateid).exec((err,templatedata)=>{
            
            if(err || templatedata==undefined || templatedata==null){
                cd(null,null);
            } 
            
            if(_id=="0"){
                let TemplatemasterMappingsData = {
                    [TemplateMasterMappingsSchemaFields.userid]: userid,
                    [TemplateMasterMappingsSchemaFields.templateid]: templateid,
                    [TemplateMasterMappingsSchemaFields.graphid]: graphid,
                    [TemplateMasterMappingsSchemaFields.updated]: new Date().toISOString()
                };
        
                let TemplatemasterMappings = new TemplateMasterMappingsSchema(TemplatemasterMappingsData);
        
                TemplatemasterMappings.save((err, savedchartdata) => {
                    if(err){
                        cd(null,null);
                    } 
                    
                    if(savedchartdata!=undefined && templatedata!=undefined){                       
                        chart._id=savedchartdata._id;
                        chart.userid=savedchartdata.userid;
                        chart.templateid=savedchartdata.templateid;
                        chart.graphid=savedchartdata.graphid;
                        chart.tempname=templatedata.name;
                        chartArray.push(chart);
                    
                    }else{
                        chartArray.push(chart);
                    }
                    cd(null,chartArray)
        
                })
            }else{
                TemplateMasterMappingsSchema.findByIdAndUpdate(
                    {
                        _id,
                    },
                    { $set:  
                        {
                        [TemplateMasterMappingsSchemaFields.userid]: userid,
                        [TemplateMasterMappingsSchemaFields.templateid]: templateid,
                        [TemplateMasterMappingsSchemaFields.graphid]: graphid,
                        [TemplateMasterMappingsSchemaFields.updated]: new Date().toISOString()
                        }                
                    },
                    {  new: true,
                    upsert: true
                    }                      
                    ).exec((err,editchartdata)=>{
                        if(err){
                            cd(null,null);
                        } 
                        if(editchartdata!=undefined && templatedata!=undefined){

                            chart._id=editchartdata._id;
                            chart.userid=editchartdata.userid;
                            chart.templateid=editchartdata.templateid;
                            chart.graphid=editchartdata.graphid;
                            chart.tempname=templatedata.name;
                            chartArray.push(chart);
                        
                        }else{
                            chartArray.push(chart);
                        }
                        cd(null,chartArray)
                    })
            }
        })
               
    }

    static getSavedTemplatetData(userid,cd){
        PersonalviewsSchema.find({[PersonalviewsSchemaFields.userid]: userid}).sort({[PersonalviewsSchemaFields.nameforsort]:1}).exec((err,result)=>{
            if(err){
                cd(null,null);
            } 
            if(result!=undefined){
                cd(null,result)
            }else{
                cd(null,[result])
            }
            
        })
    }
    
    static getSavedChartData(userid,templateid,cd){
        let chartArray = [];
        let chart = new ChartData();
        let flag=false;
        PersonalviewsSchema.findById(templateid).exec((err,templatedata)=>{
            if(err){
                cd(null,null);
            } 
            TemplateMasterMappingsSchema.find({
                [TemplateMasterMappingsSchemaFields.userid]: userid,
                [TemplateMasterMappingsSchemaFields.templateid]: mongoose.Types.ObjectId(templateid)
            }).exec((err,result)=>{
                if(err){
                    cd(null,null);
                } 
                if(result!=undefined){
                    if(result.length>0){flag=true;}
                        if(flag){
                            chart._id=result[0]._id;
                            chart.userid=result[0].userid;
                            chart.templateid=result[0].templateid;
                            chart.graphid=result[0].graphid;
                        }else{
                            chart._id=result._id;
                            chart.userid=result.userid;
                            chart.templateid=result.templateid;
                            chart.graphid=result.graphid;
                        }

                        chart.tempname=templatedata.name;
                        chartArray.push(chart);
                        cd(null,chartArray)                    
                }else{                    
                    chartArray.push(chart);
                    cd(null,chartArray);
                }
                
            })            

        })

    }
    static deleteSavedChart(id,cd){
        let chartArray = [];
        let chart = new ChartData();

        TemplateMasterMappingsSchema.findOneAndRemove({[TemplateMasterMappingsSchemaFields._id]:id}, function(err, result) {
            if(err){
                cd(null,null);
            }             
            chartArray.push(chart)
            cd(null,chartArray)
        })
    }

    static getGraphData(cd){
        GraphmastersSchema.find({},function(err, result) {
            cd(null,result)
        })
    }

}

module.exports = PersonalViewHelper;