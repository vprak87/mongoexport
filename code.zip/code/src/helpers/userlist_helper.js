const _ = require('lodash');
const request = require('request');
const axios = require('axios').default;

const { Hotels: HotelsSchema, SchemaField: HotelsSchemaFields } = require('../models/hotels');
const { User: UserSchema, SchemaField: UserSchemaFields } = require('../models/user');

const UserHelper = require('./user_helper');
const HotelsHelper = require('./hotels_helper');
var log = require('log4js').getLogger("hotellist_helper");

const dotenv = require('dotenv');
dotenv.config();

class UserListHelper {
  static getUserList(cb) {
      axios({
        method: 'get',
        headers: {'Token': 'dummytoken'},
        url: process.env.SM_UL_URL,
        params: {
            solution: 'myp'
        }
        // responseType: 'stream'
      })
      .then(function (response) {
        // console.log(response.data, 'resp')
        if(response.data.error) {
          return cb(response.data.message);
        } else {
          return cb(null, response.data);
        }
      }).catch(function (error) {
        return cb(null, 'Invalid Solution !');
      });
      
    }
  

  static getUserList_GraphQL(cb) {
    return UserListHelper.getUserList(cb, (err, result) => {
      // console.log(result, 'called')
      if (err) {
        cb(err, null);
      }
      cb(null, result);
    });
  }

}

module.exports = UserListHelper;
