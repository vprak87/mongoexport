const { Hotelbudgetexpenseform : HotelbudgetexpenseformSchema, SchemaField: HotelbudgetexpenseformSchemaFields } = require('../models/hotelbudgetexpenseform');
const dbtable = require('../schema/db_table');

var log = require('log4js').getLogger("hotels_helper");

class HotelBudgetExpenseFormsHelper {
   static GetHotelBudgetExpenseFormsDataCal0(hotelId,dt,cd){
    HotelbudgetexpenseformSchema.find({$and:[
            {[HotelbudgetexpenseformSchemaFields.HotelID]: hotelId},
            {[HotelbudgetexpenseformSchemaFields.IsDelete]: false},
            {[HotelbudgetexpenseformSchemaFields.IsGLCodeBudget]: true},
            {[HotelbudgetexpenseformSchemaFields.DateTo]: { $gte: dt }},
            {[HotelbudgetexpenseformSchemaFields.DateFrom]: { $lte: dt }}

            ]}
              
    ).exec((err,result)=>{
            cd(null,result);
    }) 

    }
    static GetHotelBudgetExpenseFormsDataCal1(hotelId,dt,cd){
    HotelbudgetexpenseformSchema.find(
            {[HotelbudgetexpenseformSchemaFields.HotelID]: hotelId,
            [HotelbudgetexpenseformSchemaFields.IsDelete]: false,
            [HotelbudgetexpenseformSchemaFields.DepartmentID]: { $gt: 0 },
            [HotelbudgetexpenseformSchemaFields.DateFrom]: { $lte: dt },
            [HotelbudgetexpenseformSchemaFields.ToDate]: { $gte: dt }
        }
              
    ).exec((err,result)=>{
   
            cd(null,result);
    })

   }
   static GetHotelBudgetExpenseFormsDataCal1(hotelId,dt,cd){
    
    HotelbudgetexpenseformSchema.find(
            {[HotelbudgetexpenseformSchemaFields.HotelID]: hotelId,
            [HotelbudgetexpenseformSchemaFields.IsDelete]: false,
            [HotelbudgetexpenseformSchemaFields.DepartmentID]: { $gt: 0 },
            [HotelbudgetexpenseformSchemaFields.DateFrom]: { $lte: dt },
            [HotelbudgetexpenseformSchemaFields.ToDate]: { $gte: dt }
        },
            
    ).exec((err,result)=>{

            cd(null,result);
    }) 

    }
   static GetHotelBudgetExpenseFormsDataCal2(hsHotelBudget,hotelbudgetlist,cd){


    HotelbudgetexpenseformSchema.aggregate(
            [  { "$group": { [HotelbudgetexpenseformSchemaFields._id]: "$DepartmentID",
                             [HotelbudgetexpenseformSchemaFields.HotelID]:  { $first :"$HotelID" },
                             [HotelbudgetexpenseformSchemaFields.GLCode]:{ $first :"$GLCode"},
                             [HotelbudgetexpenseformSchemaFields.TotalHotelBudget]:{$sum:"$TotalHotelBudget"} 
                           } 
                }
            ]      
    ).exec(function(err,result){        
        cd(null,result);
    }) 

    

    }       
}
module.exports = HotelBudgetExpenseFormsHelper;

