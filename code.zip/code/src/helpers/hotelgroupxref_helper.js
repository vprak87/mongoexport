const { Hotelgroupxref: hotelgroupxrefSchema, SchemaField: hotelgroupxrefSchemaFields } = require('../models/hotelgroupxref');
const { Hotels: HotelsSchema, SchemaField: HotelsSchemaFields } = require('../models/hotels');
const UserHotelXrefHelper = require('../helpers/userhotelxref_helper');
var log = require('log4js').getLogger("HotelGroupXrefs_helper");
const Hotelshelper = require('../helpers/hotels_helper');


const _ = require('lodash');
class HotelGroupXrefHelper {
    static async getHotelByGroupId(hotelGroupId, cb) {

        return await hotelgroupxrefSchema.find({
            [hotelgroupxrefSchemaFields.Group_Id]: hotelGroupId
        }).exec(function (err, result) {
            if (err) { log.error(err); }

            if (!result) { return cb("data not found", null); }
            else {
                return cb(null, result);
            }
        });

    }
}
module.exports = HotelGroupXrefHelper;
