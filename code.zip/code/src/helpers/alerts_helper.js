const HoteldashboardcalculationsHelper = require('./hoteldashboardcalculations_helper');
const HotelroomstatusdashboardcalculationsHelper = require('./hotelroomstatusdashboardcalculations_helper');

const Hotelshelper = require('./hotels_helper');
const UserHelper = require('./user_helper');
const Commentshelper = require('./comments_helper');
const Constants = require('../common/constants');
const Alertnotifylineitem = require('../alerts/models/alertnotifylineitem');
const Hoteldataitem = require('../alerts/models/hoteldataitem');

const Utils = require('../common/utils');

var log = require('log4js').getLogger("alerts_helper");

class AlertsHelper {

    static getPropertyData(userid, hotelid, reportdate, userconfigdata, cb) {

        var dtreportdate = new Date(reportdate);
        var startDate = new Date(dtreportdate);
        let hoteldashboardcalculationsData = [];
        let hotelroomstatusdashboardcalculationsData = [];
        let hoteldata = [];
        let usercommentsdata = [];


        return Promise.all([
            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations data
                HoteldashboardcalculationsHelper.GetLatestMTDData(hotelid, dtreportdate, startDate, (err, hoteldashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_result) {
                        hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                    }
                    resolve();

                });
            }),
            new Promise((resolve, reject) => {

                //#CURYEROOORooms
                HotelroomstatusdashboardcalculationsHelper.GetLatestMTDData(hotelid, dtreportdate, startDate, (err, hotelroomstatusdashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelroomstatusdashboardcalculations_result) {
                        hotelroomstatusdashboardcalculationsData = hotelroomstatusdashboardcalculations_result;
                    }
                    resolve();

                });

            }),
            new Promise((resolve, reject) => {
                // get hotel data
                Hotelshelper.getHotelDataByCMPID(hotelid, (err, hoteldata_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldata_result) {
                        hoteldata = hoteldata_result;
                    }
                    resolve();

                });
            }),
            new Promise((resolve, reject) => {
                // get hotel comment data
                Commentshelper.GetCommentsByUserTagsId(userid, dtreportdate, (err, usercommentsdata_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (usercommentsdata_result) {
                        usercommentsdata = usercommentsdata_result;
                    }
                    resolve();

                });
            })
        ]).then(resp => {


            var lstAlertnotifylineitem = [];

            var hotelname = '';

            if (hoteldata) {
                hotelname = hoteldata.HotelName;
            }

            if (hoteldashboardcalculationsData) {

                //#region Occupancy
                let objAlertOccMin = Constants.DefaultValues.AlertOccMin;
                if (userconfigdata != null && userconfigdata.AlertOccMin != 0) {
                    objAlertOccMin = userconfigdata.AlertOccMin;
                }
                let objAlertOccMax = Constants.DefaultValues.AlertOccMax;
                if (userconfigdata != null && userconfigdata.AlertOccMax != 0) {
                    objAlertOccMax = userconfigdata.AlertOccMax;
                }

                let objAlertOccMTDMin = Constants.DefaultValues.AlertOccMTDMin;
                if (userconfigdata != null && userconfigdata.AlertOccMTDMin != 0) {
                    objAlertOccMTDMin = userconfigdata.AlertOccMTDMin;
                }
                let objAlertOccMTDMax = Constants.DefaultValues.AlertOccMTDMax;
                if (userconfigdata != null && userconfigdata.AlertOccMTDMax != 0) {
                    objAlertOccMTDMax = userconfigdata.AlertOccMTDMax;
                }

                if (hoteldashboardcalculationsData.Occupancy) {

                    if (objAlertOccMin == 0 && objAlertOccMax == 0) {
                        log.info("not configured");
                    }
                    else {

                        if (hoteldashboardcalculationsData.Occupancy > 0
                            && hoteldashboardcalculationsData.Occupancy >= objAlertOccMin
                            && hoteldashboardcalculationsData.Occupancy <= objAlertOccMax) {

                            var objAlertnotifylineitem = new Alertnotifylineitem();

                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "Occupancy: Current "
                                + Utils.formatValue(hoteldashboardcalculationsData.Occupancy, Constants.NumeralFormats.NoComma2Decimal)
                                + "%";

                            objAlertnotifylineitem.message = "Occupancy is between " + objAlertOccMin + " and " + objAlertOccMax;
                            objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData.Occupancy);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);

                        }
                    }
                }
                if (hoteldashboardcalculationsData.OccupancyMTD) {

                    if (objAlertOccMTDMin == 0 && objAlertOccMTDMax == 0) {
                        log.info("not configured");
                    }
                    else {

                        if (hoteldashboardcalculationsData.OccupancyMTD > 0
                            && hoteldashboardcalculationsData.OccupancyMTD >= objAlertOccMTDMin
                            && hoteldashboardcalculationsData.OccupancyMTD <= objAlertOccMTDMax) {

                            var objAlertnotifylineitem = new Alertnotifylineitem();

                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "Occupancy: MTD "
                                + Utils.formatValue(hoteldashboardcalculationsData.OccupancyMTD, Constants.NumeralFormats.NoComma2Decimal)
                                + "%";

                            objAlertnotifylineitem.message = "Occupancy is between " + objAlertOccMTDMin + " and " + objAlertOccMTDMax;
                            objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData.OccupancyMTD);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);

                        }
                    }
                }
                //#endregion


                //#region ADR
                let objAlertADRMin = Constants.DefaultValues.AlertADRMin;
                if (userconfigdata != null && userconfigdata.AlertADRMin != 0) {
                    objAlertADRMin = userconfigdata.AlertADRMin;
                }
                let objAlertADRMax = Constants.DefaultValues.AlertADRMax;
                if (userconfigdata != null && userconfigdata.AlertADRMax != 0) {
                    objAlertADRMax = userconfigdata.AlertADRMax;
                }

                let objAlertADRMTDMin = Constants.DefaultValues.AlertADRMTDMin;
                if (userconfigdata != null && userconfigdata.AlertADRMTDMin != 0) {
                    objAlertADRMTDMin = userconfigdata.AlertADRMTDMin;
                }
                let objAlertADRMTDMax = Constants.DefaultValues.AlertADRMTDMax;
                if (userconfigdata != null && userconfigdata.AlertADRMTDMax != 0) {
                    objAlertADRMTDMax = userconfigdata.AlertADRMTDMax;
                }

                if (hoteldashboardcalculationsData.ADR) {

                    if (objAlertADRMin == 0 && objAlertADRMax == 0) {
                        log.info("not configured");
                    }
                    else {

                        if (hoteldashboardcalculationsData.ADR > 0
                            && hoteldashboardcalculationsData.ADR >= objAlertADRMin
                            && hoteldashboardcalculationsData.ADR <= objAlertADRMax) {

                            var objAlertnotifylineitem = new Alertnotifylineitem();
                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "ADR: Current $"
                                + Utils.formatValue(hoteldashboardcalculationsData.ADR, Constants.NumeralFormats.Comma2Decimal);

                            objAlertnotifylineitem.message = "ADR is between " + objAlertADRMin + " and " + objAlertADRMax;
                            objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData.ADR);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);

                        }
                    }
                }
                if (hoteldashboardcalculationsData.ADRMTD) {

                    if (objAlertADRMTDMin == 0 && objAlertADRMTDMax == 0) {
                        log.info("not configured");
                    }
                    else {

                        if (hoteldashboardcalculationsData.ADRMTD > 0
                            && hoteldashboardcalculationsData.ADRMTD >= objAlertADRMTDMin
                            && hoteldashboardcalculationsData.ADRMTD <= objAlertADRMTDMax) {

                            var objAlertnotifylineitem = new Alertnotifylineitem();

                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "ADR: MTD $"
                                + Utils.formatValue(hoteldashboardcalculationsData.ADRMTD, Constants.NumeralFormats.Comma2Decimal);

                            objAlertnotifylineitem.message = "ADR is between " + objAlertADRMTDMin + " and " + objAlertADRMTDMax;
                            objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData.ADRMTD);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);

                        }
                    }
                }
                //#endregion


                //#region RevPAR
                let objAlertRevParMin = Constants.DefaultValues.AlertRevParMin;
                if (userconfigdata != null && userconfigdata.AlertRevParMin != 0) {
                    objAlertRevParMin = userconfigdata.AlertRevParMin;
                }
                let objAlertRevParMax = Constants.DefaultValues.AlertRevParMax;
                if (userconfigdata != null && userconfigdata.AlertRevParMax != 0) {
                    objAlertRevParMax = userconfigdata.AlertRevParMax;
                }

                let objAlertRevParMTDMin = Constants.DefaultValues.AlertRevParMTDMin;
                if (userconfigdata != null && userconfigdata.AlertRevParMTDMin != 0) {
                    objAlertRevParMTDMin = userconfigdata.AlertRevParMTDMin;
                }
                let objAlertRevParMTDMax = Constants.DefaultValues.AlertRevParMTDMax;
                if (userconfigdata != null && userconfigdata.AlertRevParMTDMax != 0) {
                    objAlertRevParMTDMax = userconfigdata.AlertRevParMTDMax;
                }

                if (hoteldashboardcalculationsData.RevPAR) {

                    if (objAlertRevParMin == 0 && objAlertRevParMax == 0) {
                        log.info("not configured");
                    }
                    else {

                        if (hoteldashboardcalculationsData.RevPAR > 0
                            && hoteldashboardcalculationsData.RevPAR >= objAlertRevParMin
                            && hoteldashboardcalculationsData.RevPAR <= objAlertRevParMax) {

                            var objAlertnotifylineitem = new Alertnotifylineitem();
                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "RevPAR: Current $"
                                + Utils.formatValue(hoteldashboardcalculationsData.RevPAR, Constants.NumeralFormats.Comma2Decimal);

                            objAlertnotifylineitem.message = "RevPAR is between " + objAlertRevParMin + " and " + objAlertRevParMax;
                            objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData.RevPAR);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);

                        }
                    }
                }
                if (hoteldashboardcalculationsData.RevPARMTD) {

                    if (objAlertRevParMTDMin == 0 && objAlertRevParMTDMax == 0) {
                        log.info("not configured");
                    }
                    else {

                        if (hoteldashboardcalculationsData.RevPARMTD > 0
                            && hoteldashboardcalculationsData.RevPARMTD >= objAlertRevParMTDMin
                            && hoteldashboardcalculationsData.RevPARMTD <= objAlertRevParMTDMax) {

                            var objAlertnotifylineitem = new Alertnotifylineitem();

                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "RevPAR: MTD $"
                                + Utils.formatValue(hoteldashboardcalculationsData.RevPARMTD, Constants.NumeralFormats.Comma2Decimal);

                            objAlertnotifylineitem.message = "RevPAR is between " + objAlertRevParMTDMin + " and " + objAlertRevParMTDMax;
                            objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData.RevPARMTD);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);

                        }
                    }
                }
                //#endregion



            }

            if (hotelroomstatusdashboardcalculationsData) {

                //#region Out Of Order  
                let objAlertOOOMin = Constants.DefaultValues.AlertOOOMin;
                if (userconfigdata != null && userconfigdata.AlertOOOMin != 0) {
                    objAlertOOOMin = userconfigdata.AlertOOOMin;
                }

                let objAlertOOOMax = Constants.DefaultValues.AlertOOOMax;
                if (userconfigdata != null && userconfigdata.AlertOOOMax != 0) {
                    objAlertOOOMax = userconfigdata.AlertOOOMax;
                }

                if (hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc) {
                    if (objAlertOOOMin == 0 && objAlertOOOMax == 0) {
                        if (hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc > 0) {
                            var objAlertnotifylineitem = new Alertnotifylineitem();
                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "OOO: Current "
                                + Utils.formatValue(hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc, Constants.NumeralFormats.NoDecimal);
                            objAlertnotifylineitem.message = "OOO is greater than 0.";
                            objAlertnotifylineitem.type = Utils.getNoficationTypeOOO(hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);
                        }
                    }
                    else {

                        if (hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc > 0
                            && hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc >= objAlertOOOMin
                            && hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc <= objAlertOOOMax) {
                            var objAlertnotifylineitem = new Alertnotifylineitem();
                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "OOO: Current "
                                + Utils.formatValue(hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc, Constants.NumeralFormats.NoDecimal);
                            objAlertnotifylineitem.message = "OOO is between " + objAlertOOOMin + " and " + objAlertOOOMax;
                            objAlertnotifylineitem.type = Utils.getNoficationTypeOOO(hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);

                        }
                    }
                }
                //#endregion


                //#region Out Of Order MTD
                let objAlertOOOMTDMin = Constants.DefaultValues.AlertOOOMTDMin;
                if (userconfigdata != null && userconfigdata.AlertOOOMTDMin != 0) {
                    objAlertOOOMTDMin = userconfigdata.AlertOOOMTDMin;
                }

                let objAlertOOOMTDMax = Constants.DefaultValues.AlertOOOMTDMax;
                if (userconfigdata != null && userconfigdata.AlertOOOMTDMax != 0) {
                    objAlertOOOMTDMax = userconfigdata.AlertOOOMTDMax;
                }

                if (hotelroomstatusdashboardcalculationsData.OutOfOrderRoomsMTD_NoCalc) {
                    if (objAlertOOOMTDMin == 0 && objAlertOOOMTDMax == 0) {
                        if (hotelroomstatusdashboardcalculationsData.OutOfOrderRoomsMTD_NoCalc > 0) {
                            var objAlertnotifylineitem = new Alertnotifylineitem();
                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "OOO: MTD "
                                + Utils.formatValue(hotelroomstatusdashboardcalculationsData.OutOfOrderRoomsMTD_NoCalc, Constants.NumeralFormats.NoDecimal);
                            objAlertnotifylineitem.message = "OOO is greater than 0.";
                            objAlertnotifylineitem.type = Utils.getNoficationTypeOOO(hotelroomstatusdashboardcalculationsData.OutOfOrderRoomsMTD_NoCalc);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);
                        }
                    }
                    else {

                        if (hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc > 0
                            && hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc >= objAlertOOOMin
                            && hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc <= objAlertOOOMax) {
                            var objAlertnotifylineitem = new Alertnotifylineitem();
                            objAlertnotifylineitem.issuccess = true;
                            objAlertnotifylineitem.title = "OOO: MTD "
                                + Utils.formatValue(hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc, Constants.NumeralFormats.NoDecimal);
                            objAlertnotifylineitem.message = "OOO is between " + objAlertOOOMin + " and " + objAlertOOOMax;
                            objAlertnotifylineitem.type = Utils.getNoficationTypeOOO(hotelroomstatusdashboardcalculationsData.OutOfOrderRooms_NoCalc);
                            objAlertnotifylineitem.hotelname = hotelname;
                            lstAlertnotifylineitem.push(objAlertnotifylineitem);

                        }
                    }
                }
                //#endregion
            }

            //#region get User Tag Comments alerts
            if (usercommentsdata) {
                usercommentsdata.forEach(function (item) {
                    var objAlertnotifylineitem = new Alertnotifylineitem();
                    objAlertnotifylineitem.issuccess = true;
                    objAlertnotifylineitem.title = "View Comment";
                    objAlertnotifylineitem.message = item.Description;
                    objAlertnotifylineitem.hotelname = item.hotel[0].HotelName;
                    lstAlertnotifylineitem.push(objAlertnotifylineitem);
                });
            }
            //#endregion


            cb(null, lstAlertnotifylineitem);
            //cb(null, usercommentsdata);

        }, err => {
            return cb(err);
        })
    }

    static getPortfolioData(userid, reportdate, userconfigdata, cb) {

        var dtreportdate = new Date(reportdate);
        var startDate = new Date(dtreportdate);
        let hoteldashboardcalculationsData = [];
        let hotelroomstatusdashboardcalculationsData = [];
        let usercommentsdata = [];
        let hotelsdata = [];
        let hotelgrpsdata = [];

        //get user information 
        UserHelper.getUserData(userid, (err, userinfo) => {

            if (err) {
                log.error(err);
            }
            if (!userinfo) {
                cb(null, null);
            }
            else {

                return Promise.all([
                    new Promise((resolve, reject) => {
                        //we are not showing all comments for superadmin user 
                        if (userinfo.RoleID != 1) {

                            let orgId = userinfo.OrganizationId == null ? userinfo.ID : userinfo.OrganizationId;
                            let secondaryorgid = userinfo.SecondaryOrganizationId > 0 ? userinfo.SecondaryOrganizationId : orgId;
                            //get hotels
                            Hotelshelper.GetHotelsByOrganizationId(userinfo.ID, orgId, secondaryorgid, (err, hotels_result) => {
                                if (err) {
                                    cb(err, null);
                                }
                                if (hotels_result && hotels_result.length > 0) {
                                    hotelsdata = hotels_result;
                                }

                                //get hotel grps
                                Hotelshelper.GetHotelGroupsByOrganizationId(userinfo.ID, orgId, (err, hotelgrps_result) => {
                                    if (err) {
                                        cb(err, null);
                                    }
                                    if (hotelgrps_result && hotelgrps_result.length > 0) {
                                        hotelgrpsdata = hotelgrps_result;
                                    }
                                    resolve();
                                });

                            });

                        }
                        else {
                            cb(null, null);
                        }
                    })
                ]).then(resp => {

                    let lstCompanyNamesdata = [];
                    //get all DashboardData
                    let lsthotelids = [];
                    let lsthotels = [];
                    hotelsdata.forEach(function (item) {
                        if (item.CompanyName && item.CompanyName.length > 0) {

                            lstCompanyNamesdata.push(item.CompanyName[0]);
                        }
                        var objHoteldataitem = new Hoteldataitem();
                        objHoteldataitem.id = item.ID;
                        objHoteldataitem.name = item.HotelName;
                        lsthotelids.push(objHoteldataitem.id);
                        lsthotels.push(objHoteldataitem);
                    });

                    if (lsthotelids && lsthotelids.length > 0) {

                        lsthotels = Utils.sort(lsthotels, "name");
                        return Promise.all([
                            new Promise((resolve, reject) => {
                                // get Hoteldashboardcalculations data
                                HoteldashboardcalculationsHelper.GetLatestPortfolioData(lsthotelids, dtreportdate, (err, hoteldashboardcalculations_result) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    if (hoteldashboardcalculations_result) {
                                        hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                                    }
                                    resolve();
                                });
                            }),
                            new Promise((resolve, reject) => {

                                //#CURYEROOORooms
                                HotelroomstatusdashboardcalculationsHelper.GetLatestPortfolioData(lsthotelids, dtreportdate, (err, hotelroomstatusdashboardcalculations_result) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    if (hotelroomstatusdashboardcalculations_result) {
                                        hotelroomstatusdashboardcalculationsData = hotelroomstatusdashboardcalculations_result;
                                    }
                                    resolve();
                                });

                            }),
                            new Promise((resolve, reject) => {
                                // get hotel comment data
                                Commentshelper.GetCommentsByUserTagsId(userid, dtreportdate, (err, usercommentsdata_result) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    if (usercommentsdata_result) {
                                        usercommentsdata = usercommentsdata_result;
                                    }
                                    resolve();
                                });
                            })
                        ]).then(resp => {


                            var lstAlertnotifylineitem = [];

                            if (hoteldashboardcalculationsData) {

                                let objAlertOccMin = Constants.DefaultValues.AlertOccMin;
                                if (userconfigdata != null && userconfigdata.AlertOccMin != 0) {
                                    objAlertOccMin = userconfigdata.AlertOccMin;
                                }
                                let objAlertOccMax = Constants.DefaultValues.AlertOccMax;
                                if (userconfigdata != null && userconfigdata.AlertOccMax != 0) {
                                    objAlertOccMax = userconfigdata.AlertOccMax;
                                }

                                let objAlertOccMTDMin = Constants.DefaultValues.AlertOccMTDMin;
                                if (userconfigdata != null && userconfigdata.AlertOccMTDMin != 0) {
                                    objAlertOccMTDMin = userconfigdata.AlertOccMTDMin;
                                }
                                let objAlertOccMTDMax = Constants.DefaultValues.AlertOccMTDMax;
                                if (userconfigdata != null && userconfigdata.AlertOccMTDMax != 0) {
                                    objAlertOccMTDMax = userconfigdata.AlertOccMTDMax;
                                }


                                let objAlertADRMin = Constants.DefaultValues.AlertADRMin;
                                if (userconfigdata != null && userconfigdata.AlertADRMin != 0) {
                                    objAlertADRMin = userconfigdata.AlertADRMin;
                                }
                                let objAlertADRMax = Constants.DefaultValues.AlertADRMax;
                                if (userconfigdata != null && userconfigdata.AlertADRMax != 0) {
                                    objAlertADRMax = userconfigdata.AlertADRMax;
                                }

                                let objAlertADRMTDMin = Constants.DefaultValues.AlertADRMTDMin;
                                if (userconfigdata != null && userconfigdata.AlertADRMTDMin != 0) {
                                    objAlertADRMTDMin = userconfigdata.AlertADRMTDMin;
                                }
                                let objAlertADRMTDMax = Constants.DefaultValues.AlertADRMTDMax;
                                if (userconfigdata != null && userconfigdata.AlertADRMTDMax != 0) {
                                    objAlertADRMTDMax = userconfigdata.AlertADRMTDMax;
                                }


                                let objAlertRevParMin = Constants.DefaultValues.AlertRevParMin;
                                if (userconfigdata != null && userconfigdata.AlertRevParMin != 0) {
                                    objAlertRevParMin = userconfigdata.AlertRevParMin;
                                }
                                let objAlertRevParMax = Constants.DefaultValues.AlertRevParMax;
                                if (userconfigdata != null && userconfigdata.AlertRevParMax != 0) {
                                    objAlertRevParMax = userconfigdata.AlertRevParMax;
                                }

                                let objAlertRevParMTDMin = Constants.DefaultValues.AlertRevParMTDMin;
                                if (userconfigdata != null && userconfigdata.AlertRevParMTDMin != 0) {
                                    objAlertRevParMTDMin = userconfigdata.AlertRevParMTDMin;
                                }
                                let objAlertRevParMTDMax = Constants.DefaultValues.AlertRevParMTDMax;
                                if (userconfigdata != null && userconfigdata.AlertRevParMTDMax != 0) {
                                    objAlertRevParMTDMax = userconfigdata.AlertRevParMTDMax;
                                }

                                lsthotels.forEach(function (item) {

                                    var hotelname = item.name;
                                    let hoteldashboardcalculationsData_hotelitem = hoteldashboardcalculationsData.filter(d => {
                                        return (d.HotelID == item.id);
                                    });

                                    if (hoteldashboardcalculationsData_hotelitem) {

                                        if (hoteldashboardcalculationsData_hotelitem.length > 0) {
                                            hoteldashboardcalculationsData_hotelitem = hoteldashboardcalculationsData_hotelitem[0];
                                        }

                                        //#region Occupancy
                                        if (hoteldashboardcalculationsData_hotelitem.Occupancy) {

                                            if (objAlertOccMin == 0 && objAlertOccMax == 0) {
                                                log.info("not configured");
                                            }
                                            else {

                                                if (hoteldashboardcalculationsData_hotelitem.Occupancy > 0
                                                    && hoteldashboardcalculationsData_hotelitem.Occupancy >= objAlertOccMin
                                                    && hoteldashboardcalculationsData_hotelitem.Occupancy <= objAlertOccMax) {

                                                    var objAlertnotifylineitem = new Alertnotifylineitem();

                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "Occupancy: Current "
                                                        + Utils.formatValue(hoteldashboardcalculationsData_hotelitem.Occupancy, Constants.NumeralFormats.NoComma2Decimal)
                                                        + "%";

                                                    objAlertnotifylineitem.message = "Occupancy is between " + objAlertOccMin + " and " + objAlertOccMax;
                                                    objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData_hotelitem.Occupancy);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);
                                                }
                                            }
                                        }
                                        if (hoteldashboardcalculationsData_hotelitem.OccupancyMTD) {

                                            if (objAlertOccMTDMin == 0 && objAlertOccMTDMax == 0) {
                                                log.info("not configured");
                                            }
                                            else {

                                                if (hoteldashboardcalculationsData_hotelitem.OccupancyMTD > 0
                                                    && hoteldashboardcalculationsData_hotelitem.OccupancyMTD >= objAlertOccMTDMin
                                                    && hoteldashboardcalculationsData_hotelitem.OccupancyMTD <= objAlertOccMTDMax) {

                                                    var objAlertnotifylineitem = new Alertnotifylineitem();

                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "Occupancy: MTD "
                                                        + Utils.formatValue(hoteldashboardcalculationsData_hotelitem.OccupancyMTD, Constants.NumeralFormats.NoComma2Decimal)
                                                        + "%";

                                                    objAlertnotifylineitem.message = "Occupancy is between " + objAlertOccMTDMin + " and " + objAlertOccMTDMax;
                                                    objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData_hotelitem.OccupancyMTD);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);

                                                }
                                            }
                                        }
                                        //#endregion

                                        //#region ADR

                                        if (hoteldashboardcalculationsData_hotelitem.ADR) {

                                            if (objAlertADRMin == 0 && objAlertADRMax == 0) {
                                                log.info("not configured");
                                            }
                                            else {

                                                if (hoteldashboardcalculationsData_hotelitem.ADR > 0
                                                    && hoteldashboardcalculationsData_hotelitem.ADR >= objAlertADRMin
                                                    && hoteldashboardcalculationsData_hotelitem.ADR <= objAlertADRMax) {

                                                    var objAlertnotifylineitem = new Alertnotifylineitem();
                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "ADR: Current $"
                                                        + Utils.formatValue(hoteldashboardcalculationsData_hotelitem.ADR, Constants.NumeralFormats.Comma2Decimal);

                                                    objAlertnotifylineitem.message = "ADR is between " + objAlertADRMin + " and " + objAlertADRMax;
                                                    objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData_hotelitem.ADR);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);

                                                }
                                            }
                                        }
                                        if (hoteldashboardcalculationsData_hotelitem.ADRMTD) {

                                            if (objAlertADRMTDMin == 0 && objAlertADRMTDMax == 0) {
                                                log.info("not configured");
                                            }
                                            else {

                                                if (hoteldashboardcalculationsData_hotelitem.ADRMTD > 0
                                                    && hoteldashboardcalculationsData_hotelitem.ADRMTD >= objAlertADRMTDMin
                                                    && hoteldashboardcalculationsData_hotelitem.ADRMTD <= objAlertADRMTDMax) {

                                                    var objAlertnotifylineitem = new Alertnotifylineitem();

                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "ADR: MTD $"
                                                        + Utils.formatValue(hoteldashboardcalculationsData_hotelitem.ADRMTD, Constants.NumeralFormats.Comma2Decimal);

                                                    objAlertnotifylineitem.message = "ADR is between " + objAlertADRMTDMin + " and " + objAlertADRMTDMax;
                                                    objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData_hotelitem.ADRMTD);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);

                                                }
                                            }
                                        }
                                        //#endregion

                                        //#region RevPAR

                                        if (hoteldashboardcalculationsData_hotelitem.RevPAR) {

                                            if (objAlertRevParMin == 0 && objAlertRevParMax == 0) {
                                                log.info("not configured");
                                            }
                                            else {

                                                if (hoteldashboardcalculationsData_hotelitem.RevPAR > 0
                                                    && hoteldashboardcalculationsData_hotelitem.RevPAR >= objAlertRevParMin
                                                    && hoteldashboardcalculationsData_hotelitem.RevPAR <= objAlertRevParMax) {

                                                    var objAlertnotifylineitem = new Alertnotifylineitem();
                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "RevPAR: Current $"
                                                        + Utils.formatValue(hoteldashboardcalculationsData_hotelitem.RevPAR, Constants.NumeralFormats.Comma2Decimal);

                                                    objAlertnotifylineitem.message = "RevPAR is between " + objAlertRevParMin + " and " + objAlertRevParMax;
                                                    objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData_hotelitem.RevPAR);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);

                                                }
                                            }
                                        }
                                        if (hoteldashboardcalculationsData_hotelitem.RevPARMTD) {

                                            if (objAlertRevParMTDMin == 0 && objAlertRevParMTDMax == 0) {
                                                log.info("not configured");
                                            }
                                            else {

                                                if (hoteldashboardcalculationsData_hotelitem.RevPARMTD > 0
                                                    && hoteldashboardcalculationsData_hotelitem.RevPARMTD >= objAlertRevParMTDMin
                                                    && hoteldashboardcalculationsData_hotelitem.RevPARMTD <= objAlertRevParMTDMax) {

                                                    var objAlertnotifylineitem = new Alertnotifylineitem();

                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "RevPAR: MTD $"
                                                        + Utils.formatValue(hoteldashboardcalculationsData_hotelitem.RevPARMTD, Constants.NumeralFormats.Comma2Decimal);

                                                    objAlertnotifylineitem.message = "RevPAR is between " + objAlertRevParMTDMin + " and " + objAlertRevParMTDMax;
                                                    objAlertnotifylineitem.type = Utils.getNoficationType(hoteldashboardcalculationsData_hotelitem.RevPARMTD);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);

                                                }
                                            }
                                        }
                                        //#endregion

                                    }

                                });

                            }

                            if (hotelroomstatusdashboardcalculationsData) {


                                let objAlertOOOMin = Constants.DefaultValues.AlertOOOMin;
                                if (userconfigdata != null && userconfigdata.AlertOOOMin != 0) {
                                    objAlertOOOMin = userconfigdata.AlertOOOMin;
                                }

                                let objAlertOOOMax = Constants.DefaultValues.AlertOOOMax;
                                if (userconfigdata != null && userconfigdata.AlertOOOMax != 0) {
                                    objAlertOOOMax = userconfigdata.AlertOOOMax;
                                }


                                let objAlertOOOMTDMin = Constants.DefaultValues.AlertOOOMTDMin;
                                if (userconfigdata != null && userconfigdata.AlertOOOMTDMin != 0) {
                                    objAlertOOOMTDMin = userconfigdata.AlertOOOMTDMin;
                                }

                                let objAlertOOOMTDMax = Constants.DefaultValues.AlertOOOMTDMax;
                                if (userconfigdata != null && userconfigdata.AlertOOOMTDMax != 0) {
                                    objAlertOOOMTDMax = userconfigdata.AlertOOOMTDMax;
                                }



                                lsthotels.forEach(function (item) {

                                    var hotelname = item.name;
                                    let hotelroomstatusdashboardcalculationsData_hotelitem = hotelroomstatusdashboardcalculationsData.filter(d => {
                                        return (d.HotelID == item.id);
                                    });

                                    if (hotelroomstatusdashboardcalculationsData_hotelitem) {

                                        if (hotelroomstatusdashboardcalculationsData_hotelitem.length > 0) {
                                            hotelroomstatusdashboardcalculationsData_hotelitem = hotelroomstatusdashboardcalculationsData_hotelitem[0];
                                        }
                                        //#region Out Of Order  

                                        if (hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc) {
                                            if (objAlertOOOMin == 0 && objAlertOOOMax == 0) {
                                                if (hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc > 0) {
                                                    var objAlertnotifylineitem = new Alertnotifylineitem();
                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "OOO: Current "
                                                        + Utils.formatValue(hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc, Constants.NumeralFormats.NoDecimal);
                                                    objAlertnotifylineitem.message = "OOO is greater than 0.";
                                                    objAlertnotifylineitem.type = Utils.getNoficationTypeOOO(hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);
                                                }
                                            }
                                            else {

                                                if (hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc > 0
                                                    && hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc >= objAlertOOOMin
                                                    && hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc <= objAlertOOOMax) {
                                                    var objAlertnotifylineitem = new Alertnotifylineitem();
                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "OOO: Current "
                                                        + Utils.formatValue(hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc, Constants.NumeralFormats.NoDecimal);
                                                    objAlertnotifylineitem.message = "OOO is between " + objAlertOOOMin + " and " + objAlertOOOMax;
                                                    objAlertnotifylineitem.type = Utils.getNoficationTypeOOO(hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);

                                                }
                                            }
                                        }
                                        //#endregion

                                        //#region Out Of Order MTD

                                        if (hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRoomsMTD_NoCalc) {
                                            if (objAlertOOOMTDMin == 0 && objAlertOOOMTDMax == 0) {
                                                if (hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRoomsMTD_NoCalc > 0) {
                                                    var objAlertnotifylineitem = new Alertnotifylineitem();
                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "OOO: Current "
                                                        + Utils.formatValue(hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRoomsMTD_NoCalc, Constants.NumeralFormats.NoDecimal);
                                                    objAlertnotifylineitem.message = "OOO is greater than 0.";
                                                    objAlertnotifylineitem.type = Utils.getNoficationTypeOOO(hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRoomsMTD_NoCalc);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);
                                                }
                                            }
                                            else {

                                                if (hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc > 0
                                                    && hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc >= objAlertOOOMin
                                                    && hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc <= objAlertOOOMax) {
                                                    var objAlertnotifylineitem = new Alertnotifylineitem();
                                                    objAlertnotifylineitem.issuccess = true;
                                                    objAlertnotifylineitem.title = "OOO: Current "
                                                        + Utils.formatValue(hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc, Constants.NumeralFormats.NoDecimal);
                                                    objAlertnotifylineitem.message = "OOO is between " + objAlertOOOMin + " and " + objAlertOOOMax;
                                                    objAlertnotifylineitem.type = Utils.getNoficationTypeOOO(hotelroomstatusdashboardcalculationsData_hotelitem.OutOfOrderRooms_NoCalc);
                                                    objAlertnotifylineitem.hotelname = hotelname;
                                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);

                                                }
                                            }
                                        }
                                        //#endregion
                                    }
                                });

                            }


                            //#region get User Tag Comments alerts
                            if (usercommentsdata) {
                                usercommentsdata.forEach(function (item) {
                                    var objAlertnotifylineitem = new Alertnotifylineitem();
                                    objAlertnotifylineitem.issuccess = true;
                                    objAlertnotifylineitem.title = "View Comment";
                                    objAlertnotifylineitem.message = item.Description;
                                    objAlertnotifylineitem.hotelname = item.hotel[0].HotelName;
                                    lstAlertnotifylineitem.push(objAlertnotifylineitem);
                                });
                            }
                            //#endregion

                            cb(null, lstAlertnotifylineitem);
                            //cb(null, usercommentsdata);

                        }, err => {
                            return cb(err);
                        })
                    }
                    else {
                        cb(null, null);
                    }
                }, err => {
                    return cb(err);
                })
            }

        });





    }

    static getPropertyData_GraphQL(userid, hotelid, reportdate, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            Hotelshelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    AlertsHelper.getPropertyData(userid, hoteldata.ID, reportdate, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }


    static getPortfolioData_GraphQL(userid, reportdate, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            AlertsHelper.getPortfolioData(userid, reportdate, userconfigdata, cb, (err, result) => {
                if (err) {
                    cb(err, null);
                }
                cb(null, result);
            });
        });
    }
}

module.exports = AlertsHelper;
