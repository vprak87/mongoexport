const Constants = require('../common/constants');
const Utils = require('../common/utils');
const moment = require('moment');
const _ = require('lodash');

const PlStatementMonthWiseDataModel = require('../pnl/models/plstatementmonthwisedata');
const PLStatementMonthWiseitemDataModel = require('../pnl/models/plstatementmonthwiseitemdata');
const PLStatementRevenueItemDataModel = require('../pnl/models/plstatementrevenueitemdata');

const { Hotelsourcetitles: HotelsourcetitlesSchema, SchemaField: HotelsourcetitlesSchemaFields } = require('../models/hotelsourcetitles');
const { Hotelrevenue: HotelrevenueSchema, SchemaField: HotelrevenueSchemaFields } = require('../models/hotelrevenue');
const { Hotelexternaldata: HotelexternaldataSchema, SchemaField: HotelexternaldataSchemaFields } = require('../models/hotelexternaldata');
const { Qbdescriptionmapping: QbdescriptionmappingSchema, SchemaField: QbdescriptionmappingSchemaFields } = require('../models/qbdescriptionmapping');
const { Hoteldashboardcalculations: HoteldashboardcalculationsSchema, SchemaField: HoteldashboardcalculationsSchemaFields } = require('../models/hoteldashboardcalculations');
const { Glcodehotelrevenue: GlcodehotelrevenueSchema, SchemaField: GlcodehotelrevenueSchemaFields } = require('../models/glcodehotelrevenue');
const { Glcodemaster: GlcodemasterSchema, SchemaField: GlcodemasterSchemaFields } = require('../models/glcodemaster');
const { User: UserSchema, SchemaField: UserSchemaFields } = require('../models/user');
const { Hotels: HotelsSchema, SchemaField: HotelsSchemaFields } = require('../models/hotels');
const { Organisationcredentials: OrganisationcredentialsSchema, SchemaField: OrganisationcredentialsSchemaFields } = require('../models/organisationcredentials');
const { Hoteleffectivenesscalculations: HoteleffectivenesscalculationsSchema, SchemaField: HoteleffectivenesscalculationsSchemaFields } = require('../models/hoteleffectivenesscalculations');

const { PnlcustomRaw: PnlcustomizeRawSchema, SchemaField: PnlcustomizeRawSchemaField } = require('../models/pnlcustomizeview');

const HotelsHelper = require('./hotels_helper');

var log = require('log4js').getLogger("pnlyear_helper");

class PnlYearHelper {
  static async getYearPnlData(hotelid, year, userconfigdata, cb) {

    let model = new PlStatementMonthWiseDataModel();
    model.setFormat();

    if(!year) {
      year = new Date().getFullYear();
    }
    hotelid = parseInt(hotelid);
    let hcode = '';
    Promise.all([
      new Promise((resolve, reject) => {
        HotelsHelper.GetHotelRevenueData(hotelid,  (err, res) => {
          if(err) {
            reject(err);
          }
          if(res != null) {
            model.HotelId = res.ID;
            model.OrgId = res.OrganizationID;
            hcode = res.HotelCode;
          }
          resolve();
        });
      })
    ]).then(resp => {
      (async() => {

      model.Year = year;
      let startDate = new Date(year, 1, 1);
      startDate = moment(startDate).startOf('year').format('YYYY-MM-DD');
      // let endDate = new Date(year, 12, 31);
      let endDate = moment(startDate).endOf('year').format('YYYY-MM-DD');

      let hotelids = [];
      hotelids.push(hotelid);
  
      let hotel = await PnlYearHelper.getHotelbyId(hotelid);
      let islabordataavailable = await PnlYearHelper.isActiveOrganisation(hotel.OrganizationId);
      let outlet1otherrevenueTotal = 0;
      let outlet2otherrevenueTotal = 0;
      let outlet3otherrevenueTotal = 0;
      let outlet4otherrevenueTotal = 0;
      let outlet1fandbrevenueTotal = 0;
      let outlet2fandbrevenueTotal = 0;
      let outlet3fandbrevenueTotal = 0;
      let outlet4fandbrevenueTotal = 0;
      let restaurantrevenueTotal = 0;
      let barrevenueTotal = 0;
      let banquetrevenueTotal = 0;
      let parkingrevenueTotal = 0;
      let giftshoprevenueTotal = 0;
      let beveragerevenueTotal = 0;
      let foodrevenueTotal = 0;
      let Totalopexpense = 0;
      let TotalundistDataAmount = 0;
      let TotalitdaDataAmount = 0;
      let TotalfixedDataAmount = 0;
  
      let externalDataList = [];
      let externalDataListOperatingExpenseList = [];
      let externalDataListUndistributedExpenseList = [];
      let externalDataListFixedExpenseList = [];
      let externalDataListITDAExpenseList = [];
      let TaxDataList = [];
      let PurchaseItemlist = [];
  
      let lsthst = [];

      externalDataList = await PnlYearHelper.getExternalData(hotelid, startDate, endDate);
      externalDataListOperatingExpenseList = await PnlYearHelper.getExternalDataOperatingExpense(hotelid, startDate, endDate);
      externalDataListUndistributedExpenseList = await PnlYearHelper.getExternalDataUndistributedExpense(hotelid, startDate, endDate);
      externalDataListFixedExpenseList = await PnlYearHelper.getExternalDataFixedExpense(hotelid, startDate, endDate);
      externalDataListITDAExpenseList = await PnlYearHelper.getExternalDataITDAExpense(hotelid, startDate, endDate);
      TaxDataList = await PnlYearHelper.getTaxData(hotelid, startDate, endDate);
      PurchaseItemlist = await PnlYearHelper.getPurchaseItemData(hcode, startDate, endDate);
      lsthst = await PnlYearHelper.getHotelSourceTitle(hotelid);

      let Outlet1Other = "Outlet 1 - Other";
      let Outlet2Other = "Outlet 2 - Other";
      let Outlet3Other = "Outlet 3 - Other";
      let Outlet4Other = "Outlet 4 - Other";
      let Outlet1FNB = "Outlet 1 - F&B";
      let Outlet2FNB = "Outlet 2 - F&B";
      let Outlet3FNB = "Outlet 3 - F&B";
      let Outlet4FNB = "Outlet 4 - F&B";
      let Restaurant = "Restaurant";
      let Bar = "Bar";
      let Banquet = "Banquet";
      let Parking = "Parking";
      let Beverage = "Beverage";
      let Food = "Food";
      let GiftShop = "Gift Shop";

      if (lsthst != null && lsthst.length > 0)
      {
        // let parentOutlet1Other = model.RevenueList.Where(x => x.Name == Outlet1Other).FirstOrDefault();
        let parentOutlet1Other = _.find(model.RevenueList, function(o) { return o.Name == Outlet1Other; });
        Outlet1Other = getCategoryDataTitle(lsthst[0], Outlet1Other);
        if (parentOutlet1Other != null)
        {
            parentOutlet1Other.Name = Outlet1Other;
        }

        // var parentOutlet2Other = model.RevenueList.Where(x => x.Name == Outlet2Other).FirstOrDefault();
        let parentOutlet2Other = _.find(model.RevenueList, function(o) { return o.Name == Outlet2Other; });
        Outlet2Other = getCategoryDataTitle(lsthst[0], Outlet2Other);
        if (parentOutlet2Other != null)
        {
            parentOutlet2Other.Name = Outlet2Other;
        }

        // let parentOutlet3Other = model.RevenueList.Where(x => x.Name == Outlet3Other).FirstOrDefault();
        let parentOutlet3Other = _.find(model.RevenueList, function(o) { return o.Name == Outlet3Other; });
        Outlet3Other = getCategoryDataTitle(lsthst[0], Outlet3Other);
        if (parentOutlet3Other != null)
        {
            parentOutlet3Other.Name = Outlet3Other;
        }

        // let parentOutlet4Other = model.RevenueList.Where(x => x.Name == Outlet4Other).FirstOrDefault();
        let parentOutlet4Other = _.find(model.RevenueList, function(o) { return o.Name == Outlet4Other; });
        Outlet4Other = getCategoryDataTitle(lsthst[0], Outlet4Other);
        if (parentOutlet4Other != null)
        {
            parentOutlet4Other.Name = Outlet4Other;
        }

        // let parentOutlet1FNB = model.RevenueList.Where(x => x.Name == Outlet1FNB).FirstOrDefault();
        let parentOutlet1FNB = _.find(model.RevenueList, function(o) { return o.Name == Outlet1FNB; });
        Outlet1FNB = getCategoryDataTitle(lsthst[0], Outlet1FNB);
        if (parentOutlet1FNB != null)
        {
            parentOutlet1FNB.Name = Outlet1FNB;
        }

        // let parentOutlet2FNB = model.RevenueList.Where(x => x.Name == Outlet2FNB).FirstOrDefault();
        let parentOutlet2FNB = _.find(model.RevenueList, function(o) { return o.Name == Outlet2FNB; });
        Outlet2FNB = getCategoryDataTitle(lsthst[0], Outlet2FNB);
        if (parentOutlet2FNB != null)
        {
            parentOutlet2FNB.Name = Outlet2FNB;
        }

        // let parentOutlet3FNB = model.RevenueList.Where(x => x.Name == Outlet3FNB).FirstOrDefault();
        let parentOutlet3FNB = _.find(model.RevenueList, function(o) { return o.Name == Outlet3FNB; });
        Outlet3FNB = getCategoryDataTitle(lsthst[0], Outlet3FNB);
        if (parentOutlet3FNB != null)
        {
            parentOutlet3FNB.Name = Outlet3FNB;
        }

        // let parentOutlet4FNB = model.RevenueList.Where(x => x.Name == Outlet4FNB).FirstOrDefault();
        let parentOutlet4FNB = _.find(model.RevenueList, function(o) { return o.Name == Outlet4FNB; });
        Outlet4FNB = getCategoryDataTitle(lsthst[0], Outlet4FNB);
        if (parentOutlet4FNB != null)
        {
            parentOutlet4FNB.Name = Outlet4FNB;
        }

        // let parentRestaurant = model.RevenueList.Where(x => x.Name == Restaurant).FirstOrDefault();
        let parentRestaurant = _.find(model.RevenueList, function(o) { return o.Name == Restaurant; });
        Restaurant = getCategoryDataTitle(lsthst[0], Restaurant);
        if (parentRestaurant != null)
        {
            parentRestaurant.Name = Restaurant;
        }

        // let parentBar = model.RevenueList.Where(x => x.Name == Bar).FirstOrDefault();
        let parentBar = _.find(model.RevenueList, function(o) { return o.Name == Bar; });
        Bar = getCategoryDataTitle(lsthst[0], Bar);
        if (parentBar != null)
        {
            parentBar.Name = Bar;
        }

        // let parentBanquet = model.RevenueList.Where(x => x.Name == Banquet).FirstOrDefault();
        let parentBanquet = _.find(model.RevenueList, function(o) { return o.Name == Banquet; });
        Banquet = getCategoryDataTitle(lsthst[0], Banquet);
        if (parentBanquet != null)
        {
            parentBanquet.Name = Banquet;
        }

        // let parentParking = model.RevenueList.Where(x => x.Name == Parking).FirstOrDefault();
        let parentParking = _.find(model.RevenueList, function(o) { return o.Name == Parking; });
        Parking = getCategoryDataTitle(lsthst[0], Parking);
        if (parentParking != null)
        {
            parentParking.Name = Parking;
        }

        // let parentGiftShop = model.RevenueList.Where(x => x.Name == GiftShop).FirstOrDefault();
        let parentGiftShop = _.find(model.RevenueList, function(o) { return o.Name == GiftShop; });
        GiftShop = getCategoryDataTitle(lsthst[0], GiftShop);
        if (parentGiftShop != null)
        {
            parentGiftShop.Name = GiftShop;
        }

        // let parentBeverage = model.RevenueList.Where(x => x.Name == Beverage).FirstOrDefault();
        let parentBeverage = _.find(model.RevenueList, function(o) { return o.Name == Beverage; });
        Beverage = getCategoryDataTitle(lsthst[0], Beverage);
        if (parentBeverage != null)
        {
            parentBeverage.Name = Beverage;
        }

        let parentFood = _.find(model.RevenueList, function(o) { return o.Name == Food; });
        Food = getCategoryDataTitle(lsthst[0], Food);
        if (parentFood != null)
        {
            parentFood.Name = Food;
        } 
      }

      let tempDates = [];
      for (var m = moment(startDate); m.isBefore(moment(endDate)); m.add(1, 'months')) {
        tempDates.push(m);
      }

      let pArrr = [];
      // tempDates.forEach(async (m) => {
      for (var m = moment(startDate); m.isBefore(moment(endDate)); m.add(1, 'months')) {
        pArrr.push(
          new Promise(async (resolve, reject) => {
      // for (var m = moment(startDate); m.isBefore(moment(endDate)); m.add(1, 'months')) {
        let item = {
          MonthName: '',
          TotalSales: 0.00,
          TotalExpenses: 0.00,
          NetProfitBeforeTax: 0.00,
          TotalTaxes: 0.00,
          NetProfit: 0.00,
          RevenueList: [],
          TaxList: [],
          ExpenseList: [],
          OperatingExpenseList: [],
          FixedExpensesList: [],
          UndistcostExpensesList: [],
          ITDAExpensesList: [],
          LabourExpenseList: [] 
        };

        item.MonthName = moment(m).format("MMMM");
        let monthEndDate = moment(m).endOf('month').format("YYYY-MM-DD");

        let roomrevenueData = {};
        roomrevenueData.Name = "Room Revenue";
        roomrevenueData.Category = "Revenue";
        roomrevenueData.MonthName = item.MonthName;
        roomrevenueData.GLCode = "000.00";
        roomrevenueData.Amount = 0;

        let fnbrevenueData = {};
        fnbrevenueData.Name = "F&B Revenue";
        fnbrevenueData.Category = "Revenue";
        fnbrevenueData.MonthName = item.MonthName;
        fnbrevenueData.GLCode = "000.00";
        fnbrevenueData.Amount = 0;

        let otherrevenueData = {};
        otherrevenueData.Name = "Other Revenue";
        otherrevenueData.Category = "Revenue";
        otherrevenueData.MonthName = item.MonthName;
        otherrevenueData.GLCode = "000.00";
        otherrevenueData.Amount = 0;

        let outlet1otherrevenue = {};
        outlet1otherrevenue.Name = Outlet1Other;
        outlet1otherrevenue.Category = "Revenue";
        outlet1otherrevenue.MonthName = item.MonthName;
        outlet1otherrevenue.GLCode = "000.00";
        outlet1otherrevenue.Amount = 0;

        let outlet2otherrevenue = {};
        outlet2otherrevenue.Name = Outlet2Other;
        outlet2otherrevenue.Category = "Revenue";
        outlet2otherrevenue.MonthName = item.MonthName;
        outlet2otherrevenue.GLCode = "000.00";
        outlet2otherrevenue.Amount = 0;

        let outlet3otherrevenue = {};
        outlet3otherrevenue.Name = Outlet3Other;
        outlet3otherrevenue.Category = "Revenue";
        outlet3otherrevenue.MonthName = item.MonthName;
        outlet3otherrevenue.GLCode = "000.00";

        let outlet4otherrevenue = {};
        outlet4otherrevenue.Name = Outlet4Other;
        outlet4otherrevenue.Category = "Revenue";
        outlet4otherrevenue.MonthName = item.MonthName;
        outlet4otherrevenue.GLCode = "000.00";

        let outlet1fandbrevenue = {};
        outlet1fandbrevenue.Name = Outlet1FNB;
        outlet1fandbrevenue.Category = "Revenue";
        outlet1fandbrevenue.MonthName = item.MonthName;
        outlet1fandbrevenue.GLCode = "000.00";

        let outlet2fandbrevenue = {};
        outlet2fandbrevenue.Name = Outlet2FNB;
        outlet2fandbrevenue.Category = "Revenue";
        outlet2fandbrevenue.MonthName = item.MonthName;
        outlet2fandbrevenue.GLCode = "000.00";

        let outlet3fandbrevenue = {};
        outlet3fandbrevenue.Name = Outlet3FNB;
        outlet3fandbrevenue.Category = "Revenue";
        outlet3fandbrevenue.MonthName = item.MonthName;
        outlet3fandbrevenue.GLCode = "000.00";

        let outlet4fandbrevenue = {};
        outlet4fandbrevenue.Name = Outlet4FNB;
        outlet4fandbrevenue.Category = "Revenue";
        outlet4fandbrevenue.MonthName = item.MonthName;
        outlet4fandbrevenue.GLCode = "000.00";

        let restaurantrevenue = {};
        restaurantrevenue.Name = Restaurant;
        restaurantrevenue.Category = "Revenue";
        restaurantrevenue.MonthName = item.MonthName;
        restaurantrevenue.GLCode = "000.00";

        let barrevenue = {};
        barrevenue.Name = Bar;
        barrevenue.Category = "Revenue";
        barrevenue.MonthName = item.MonthName;
        barrevenue.GLCode = "000.00";

        let banquetrevenue = {};
        banquetrevenue.Name = Banquet;
        banquetrevenue.Category = "Revenue";
        banquetrevenue.MonthName = item.MonthName;
        banquetrevenue.GLCode = "000.00";

        let parkingrevenue = {};
        parkingrevenue.Name = Parking;
        parkingrevenue.Category = "Revenue";
        parkingrevenue.MonthName = item.MonthName;
        parkingrevenue.GLCode = "000.00";

        let giftshoprevenue = {};
        giftshoprevenue.Name = GiftShop;
        giftshoprevenue.Category = "Revenue";
        giftshoprevenue.MonthName = item.MonthName;
        giftshoprevenue.GLCode = "000.00";

        let beveragerevenue = {};
        beveragerevenue.Name = Beverage;
        beveragerevenue.Category = "Revenue";
        beveragerevenue.MonthName = item.MonthName;
        beveragerevenue.GLCode = "000.00";

        let foodrevenue = {};
        foodrevenue.Name = Food;
        foodrevenue.Category = "Revenue";
        foodrevenue.MonthName = item.MonthName;
        foodrevenue.GLCode = "000.00";

        let totalrevenueData = {};
        totalrevenueData.Name = "TOTAL SALES";
        totalrevenueData.Category = "Revenue";
        totalrevenueData.MonthName = item.MonthName;
        // console.log(totalrevenueData, 'totalrevenueData');

        let objRevenueData = await PnlYearHelper.getPLStatementMonthWiseRevenueData(hotelid, monthEndDate, "MTD");
        // let objRevenueData = await PnlYearHelper.getTaxData(hotelid, startDate, endDate);
        // console.log(objRevenueData, 'objRevenueData');

        if (objRevenueData != null && objRevenueData.length > 0)
        {
            // roomrevenueData.Amount = objRevenueData.Sum(x => x.RoomRevenue);
            roomrevenueData.Amount = (_.sumBy(objRevenueData, function(o) { return o.RoomRevenue; })) == undefined ? 0 : _.sumBy(objRevenueData, function(o) { return o.RoomRevenue; });
            // fnbrevenueData.Amount = objRevenueData.Sum(x => x.FANDBRevenue);
            fnbrevenueData.Amount = (_.sumBy(objRevenueData, function(o) { return o.FANDBRevenue; })) == undefined ? 0 : _.sumBy(objRevenueData, function(o) { return o.FANDBRevenue; });
            // otherrevenueData.Amount = objRevenueData.Sum(x => x.OtherRevenue);
            otherrevenueData.Amount = (_.sumBy(objRevenueData, function(o) { return o.OtherRevenue; })) == undefined ? 0 : _.sumBy(objRevenueData, function(o) { return o.OtherRevenue; });
            // outlet1otherrevenue.Amount = objRevenueData.Sum(x => x.Outet1OtherRevenue);
            outlet1otherrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.Outet1OtherRevenue; })) == undefined ? 0 : _.sumBy(objRevenueData, function(o) { return o.Outet1OtherRevenue; });
            // outlet2otherrevenue.Amount = objRevenueData.Sum(x => x.Outet2OtherRevenue);
            outlet2otherrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.Outet2OtherRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.Outet2OtherRevenue; });
            // outlet3otherrevenue.Amount = objRevenueData.Sum(x => x.Outet3OtherRevenue);
            outlet3otherrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.Outet3OtherRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.Outet3OtherRevenue; });
            // outlet4otherrevenue.Amount = objRevenueData.Sum(x => x.Outet4OtherRevenue);
            outlet4otherrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.Outet4OtherRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.Outet4OtherRevenue; });
            // outlet1fandbrevenue.Amount = objRevenueData.Sum(x => x.Outet1FANDBRevenue);
            outlet1fandbrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.Outet1FANDBRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.Outet1FANDBRevenue; });
            // outlet2fandbrevenue.Amount = objRevenueData.Sum(x => x.Outet2FANDBRevenue);
            outlet2fandbrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.Outet2FANDBRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.Outet2FANDBRevenue; });
            // outlet3fandbrevenue.Amount = objRevenueData.Sum(x => x.Outet3FANDBRevenue);
            outlet3fandbrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.Outet3FANDBRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.Outet3FANDBRevenue; });
            // outlet4fandbrevenue.Amount = objRevenueData.Sum(x => x.Outet4FANDBRevenue);
            outlet4fandbrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.Outet4FANDBRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.Outet4FANDBRevenue; });
            // restaurantrevenue.Amount = objRevenueData.Sum(x => x.RestaurantRevenue);
            restaurantrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.RestaurantRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.RestaurantRevenue; });
            // barrevenue.Amount = objRevenueData.Sum(x => x.BarRevenue);
            barrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.BarRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.BarRevenue; });
            // banquetrevenue.Amount = objRevenueData.Sum(x => x.BanquetRevenue);
            banquetrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.BanquetRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.BanquetRevenue; });
            // parkingrevenue.Amount = objRevenueData.Sum(x => x.ParkingRevenue);
            parkingrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.ParkingRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.ParkingRevenue; });
            // giftshoprevenue.Amount = objRevenueData.Sum(x => x.GiftShopRevenue);
            giftshoprevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.GiftShopRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.GiftShopRevenue; });
            // beveragerevenue.Amount = objRevenueData.Sum(x => x.BeverageRevenue);
            beveragerevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.BeverageRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.BeverageRevenue; });
            // foodrevenue.Amount = objRevenueData.Sum(x => x.FoodRevenue);
            foodrevenue.Amount = (_.sumBy(objRevenueData, function(o) { return o.FoodRevenue; })) == undefined ? 0: _.sumBy(objRevenueData, function(o) { return o.FoodRevenue; });
            totalrevenueData.Amount = roomrevenueData.Amount + fnbrevenueData.Amount + otherrevenueData.Amount + outlet1otherrevenue.Amount + outlet2otherrevenue.Amount + outlet3otherrevenue.Amount + outlet4otherrevenue.Amount + outlet1fandbrevenue.Amount + outlet2fandbrevenue.Amount + outlet3fandbrevenue.Amount + outlet4fandbrevenue.Amount + restaurantrevenue.Amount + barrevenue.Amount + banquetrevenue.Amount + parkingrevenue.Amount + giftshoprevenue.Amount + beveragerevenue.Amount + foodrevenue.Amount;

        }
        // console.log(roomrevenueData);

        item.RevenueList.push(roomrevenueData);
        item.RevenueList.push(fnbrevenueData);
        item.RevenueList.push(otherrevenueData);

        if (outlet1otherrevenue.Amount != 0)
        {
            item.RevenueList.push(outlet1otherrevenue);
            outlet1otherrevenueTotal += outlet1otherrevenue.Amount;
        }
        if (outlet2otherrevenue.Amount != 0)
        {
            item.RevenueList.push(outlet2otherrevenue);
            outlet2otherrevenueTotal += outlet2otherrevenue.Amount;
        }
        if (outlet3otherrevenue.Amount != 0)
        {
            item.RevenueList.push(outlet3otherrevenue);
            outlet3otherrevenueTotal += outlet3otherrevenue.Amount;
        }
        if (outlet4otherrevenue.Amount != 0)
        {
            item.RevenueList.push(outlet4otherrevenue);
            outlet4otherrevenueTotal += outlet4otherrevenue.Amount;
        }
        if (outlet1fandbrevenue.Amount != 0)
        {
            item.RevenueList.push(outlet1fandbrevenue);
            outlet1fandbrevenueTotal += outlet1fandbrevenue.Amount;
        }
        if (outlet2fandbrevenue.Amount != 0)
        {
            item.RevenueList.push(outlet2fandbrevenue);
            outlet2fandbrevenueTotal += outlet2fandbrevenue.Amount;
        }
        if (outlet3fandbrevenue.Amount != 0)
        {
            item.RevenueList.push(outlet3fandbrevenue);
            outlet3fandbrevenueTotal += outlet3fandbrevenue.Amount;
        }
        if (outlet4fandbrevenue.Amount != 0)
        {
            item.RevenueList.push(outlet4fandbrevenue);
            outlet4fandbrevenueTotal += outlet4fandbrevenue.Amount;
        }
        if (restaurantrevenue.Amount != 0)
        {
            item.RevenueList.push(restaurantrevenue);
            restaurantrevenueTotal += restaurantrevenue.Amount;
        }
        if (barrevenue.Amount != 0)
        {
            item.RevenueList.push(barrevenue);
            barrevenueTotal += barrevenue.Amount;
        }
        if (banquetrevenue.Amount != 0)
        {
            item.RevenueList.push(banquetrevenue);
            banquetrevenueTotal += banquetrevenue.Amount;
        }
        if (parkingrevenue.Amount != 0)
        {
            item.RevenueList.push(parkingrevenue);
            parkingrevenueTotal += parkingrevenue.Amount;
        }
        if (giftshoprevenue.Amount != 0)
        {
            item.RevenueList.push(giftshoprevenue);
            giftshoprevenueTotal += giftshoprevenue.Amount;
        }
        if (beveragerevenue.Amount != 0)
        {
            item.RevenueList.push(beveragerevenue);
            beveragerevenueTotal += beveragerevenue.Amount;
        }
        if (foodrevenue.Amount != 0)
        {
            item.RevenueList.push(foodrevenue);
            foodrevenueTotal += foodrevenue.Amount;
        }

        item.RevenueList.push(totalrevenueData);

        let TotalefDataAmount = 0;
        let eflist = _.filter(PurchaseItemlist, function(o) { return new Date(moment(o.PoDate).format('YYYY-MM-DD')).toISOString() >= new Date(moment(m).fomat('YYYY-MM-DD')).toISOString() && new Date(moment(t.PoDate).format('YYYY-MM-DD')) <= new Date(moment(monthEndDate).format('YYYY-MM-DD')).toISOString(); });
        eflist = await PnlYearHelper.filterInactiveDesc(eflist, "Expense");
        eflist = groupByGLCode(eflist);

        eflist.forEach(async element => { 
          let efData = new PLStatementRevenueItemDataModel();
          efData.Name = element.AccountNumber;
          efData.Category = "Expense";
          efData.MonthName = item.MonthName;
          efData.Amount = parseFloat(element.UnitPrice);
          efData.IsActive = true;
          efData.GLCode = await PnlYearHelper.getGLCodePL(efData.Name, hotelid);
          // console.log(efData.GLCode, 'efData.GLCode');
          item.ExpenseList.push(efData);
          model.ExpenseList.push(efData);
        });


        let externalDatas = _.filter(externalDataList, function(o) { return new Date(moment(o.Date).format('YYYY-MM-DD')).toISOString() >= new Date(moment(m).format('YYYY-MM-DD')).toISOString() && new Date(moment(o.Date).format('YYYY-MM-DD')).toISOString() <= new Date(moment(monthEndDate).format('YYYY-MM-DD')).toISOString(); });
        if (externalDatas != null && externalDatas.length > 0)
        {
          externalDatas = groupByDescription(externalDatas);
          externalDatas.forEach(async element => {
            let efData = new PLStatementRevenueItemDataModel();
            efData.Name = element.Description;
            efData.Category = "Expense";
            efData.MonthName = item.MonthName;
            efData.Amount = parseFloat(element.Amount);
            efData.IsActive = true;
            efData.GLCode = await PnlYearHelper.getGLCodePL(efData.Name, hotelid);

            item.ExpenseList.push(efData);
            model.ExpenseList.push(efData);
          });
        }

        let efTotal = (item.ExpenseList != null && item.ExpenseList.length > 0) ? _.sumBy(_.filter(item.ExpenseList, function(o) { return o.IsActive == true; }), function(o) { return o.Amount; }) : 0;
        let Bistro = _.filter(model.ExpenseList, function(o) { return  o.Name == "Rebate" || o.Name == "Bistro:Rebate" || o.Name == "Breakfast:Rebate" || o.Name == "Breakfast/Social Hour:Rebate" || o.Name == "Breakfast" || o.Name == "Breakfast:Rebates" || o.Name == "Breakfast Rebate"});
        
        if (Bistro.length > 0 && Bistro != null)
        {
          Bistro.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            if (hotelid == 133 || hotelid == 136)
            {
                mar1.Name = "Breakfast/Social Hour";
            }
            else if (hotelid == 256 || hotelid == 120 || hotelid == 121 || hotelid == 123 || hotelid == 841 || hotelid == 126)
            {
                mar1.Name = "Breakfast";
            }
            else if (hotelid == 127 || hotelid == 132 || hotelid == 188)
            {
                mar1.Name = "Breakfast Expense";
            }
            else
            {
                mar1.Name = "Bistro";
            }
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ExpenseList.push(mar1);
            item.ExpenseList = _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });

            model.ExpenseList.push(mar1);
            model.ExpenseList = _.remove(model.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Resturant = _.filter(model.ExpenseList, function(x) { return x.Name == "Restaurant Foods:Rebate" || x.Name == "Restaurant Foods"});

        if (Resturant.length > 0 && Resturant != null)
        {
          Resturant.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Restaurant Foods";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ExpenseList.push(mar1);
            item.ExpenseList = _.remove(item.ExpenseList, function(n) {
                                    return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
                                  });
            model.ExpenseList.push(mar1);
            model.ExpenseList = _.remove(model.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let EmployeeAp = _.filter(model.ExpenseList, function(x) { return x.Name == "Employee Appreciation" || x.Name == "Employee Appreciation Franchise Fees"});

        if (EmployeeAp.length > 0 && EmployeeAp != null)
        {
          EmployeeAp.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Employee Appreciation";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ExpenseList.push(mar1);

            // item.ExpenseList.pop(item1);
            item.ExpenseList = _.remove(item.ExpenseList, function(n) {
                                    return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
                                  });
            model.ExpenseList.push(mar1);
            model.ExpenseList = _.remove(model.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Insurance = _.filter(model.ExpenseList, function(x) { return x.Name == "Admin Fee" || x.Name == "Insurance Expense:Auto" || x.Name == "Crime" || x.Name == "Insurance Expense:Cyber Liability" || x.Name == "Insurance Expense:EPLI" || x.Name == "Excess Liability" || x.Name == "Insurance Expense:Flood coverage" || x.Name == "Insurance Expense:General Liability" || x.Name == "Liquor Liability" || x.Name == "Package" || x.Name == "Insurance Expense:Property" || x.Name == "Insurance Expense:Umbrella" || x.Name == "Wind Buyback" || x.Name == "Insurance Expense:Wind/Hail at Houston/Katy" || x.Name == "Insurance Expense:Wind/Hail Master" || x.Name == "Insurance Expense:Workers Compensation" || x.Name == "Employment Practice Liability" || x.Name == "Property" || x.Name == "Insurance Expense:Workers Comp" || x.Name == "Insurance Expense:Worker's Comp" || x.Name == "Cyber Liability" || x.Name == "EPLI" || x.Name == "Insurance Expense:Employment Practices Liability" || x.Name == "Insurance Expense:Flood Coverage" || x.Name == "Insurance Expense:Worker's Compensation" || x.Name == "Insurance Expense:Admin Fee" || x.Name == "Insurance Expense:Crime" || x.Name == "Insurance Expense:Excess Liability" || x.Name == "Insurance Expense:Liquor Liability" || x.Name == "Insurance Expense:Package" || x.Name == "Insurance Expense:Wind Buyback" || x.Name == "Auto" || x.Name == "General Liability" || x.Name == "Umbrella" || x.Name == "Wind/Hail Master" || x.Name == "Workers Comp" || x.Name == "Flood coverage" || x.Name == "Wind/Hail at Houston/Katy" || x.Name == "Workers Compensation" || x.Name == "Worker's Compensation" || x.Name == "Worker's Comp" || x.Name == "Insurance Expense:Flood Liability"});
        if (Insurance.length > 0 && Insurance != null)
        {
          Insurance.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Insurance Expense";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ExpenseList.push(mar1);

            item.ExpenseList = _.remove(item.ExpenseList, function(n) {
                                    return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
                                  });
            model.ExpenseList.push(mar1);
            model.ExpenseList = _.remove(model.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Maintenance = _.filter(model.ExpenseList, function(x) { return x.Name == "Tools/Equipment" || x.Name == "Maintenance Supplies:Tools/Equipment"});
        if (Maintenance.length > 0 && Maintenance != null)
        {
          Maintenance.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Maintenance Supplies";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ExpenseList.push(mar1);

            item.ExpenseList = _.remove(item.ExpenseList, function(n) {
                                    return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
                                  });
            model.ExpenseList.push(mar1);
            model.ExpenseList = _.remove(model.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let marriot = _.filter(model.ExpenseList, function(x) { return x.Name == "Rewards Program Expenses" || x.Name == "Marriott Rewards:Rewards Program Expenses"});
        if (marriot.length > 0 && marriot != null)
        {
          marriot.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Marriott Rewards";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ExpenseList.push(mar1);

            item.ExpenseList = _.remove(item.ExpenseList, function(n) {
                                    return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
                                  });
            model.ExpenseList.push(mar1);
            model.ExpenseList = _.remove(model.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Travel = _.filter(model.ExpenseList, function(x) { return x.Name == "Meals" || x.Name == "Travel/Conference:Meals"});
        if (Travel.length > 0 && Travel != null)
        {
          Travel.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Travel/Conference";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ExpenseList.push(mar1);

            item.ExpenseList = _.remove(item.ExpenseList, function(n) {
                                    return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
                                  });
            model.ExpenseList.push(mar1);
            model.ExpenseList = _.remove(model.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let TotalefData = new PLStatementRevenueItemDataModel();
        TotalefData.Name = "TOTAL EXPENSES";
        TotalefData.Category = "Expense";
        TotalefData.MonthName = item.MonthName;
        TotalefData.Amount = efTotal;
        TotalefDataAmount = TotalefData.Amount;
        item.ExpenseList.push(TotalefData);
        model.ExpenseList.push(TotalefData);

        item.ExpenseList = _(item.ExpenseList)
        .groupBy('Name', 'MonthName', 'GLCode')
        .map((objs, key) => ({
            'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
            'Amount': _.sumBy(objs, 'Amount'),
            'Name': key,
            'MonthName': _.get(_.find(objs, function(o) { return true; }), 'MonthName'),
            'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode'),
            }))
        .value();

        let externalDatas1 = _.filter(externalDataListOperatingExpenseList, function(t) { return t.Date.toISOString() >= m.toISOString() && t.Date.toISOString() <= moment(monthEndDate).toISOString()});

        if (externalDatas1 != null && externalDatas1.length > 0)
        {
            externalDatas1 = groupByDescription(externalDatas1);
            externalDatas1.forEach(async ef => {
              let efData = new PLStatementRevenueItemDataModel();
              efData.Name = await PnlYearHelper.getGLCodePLV2(ef.Description, hotelid);
              efData.Category = "Expense";
              efData.MonthName = item.MonthName;
              efData.Amount = parseFloat(ef.Amount);
              efData.GLCode = await PnlYearHelper.getGLCodePL(efData.Name, hotelid);
              efData.IsActive = true;
              item.OperatingExpenseList.push(efData);
              model.OperatingExpenseList.push(efData);
            });
        }

        let tempgilt = (item.OperatingExpenseList != null && item.OperatingExpenseList.length > 0) ? _.filter(item.OperatingExpenseList, function(o) { return o.IsActive == true; }) : null ;
        let efTotal1 = (item.OperatingExpenseList != null && item.OperatingExpenseList.length > 0) ? _.sumBy(tempgilt, function(x) { return x.Amount; }) : 0;

        let Bistro1 = _.filter(model.OperatingExpenseList, function(x) { return x => x.Name == "Rebate" || x.Name == "Bistro:Rebate" || x.Name == "Breakfast:Rebate" || x.Name == "Breakfast/Social Hour:Rebate" || x.Name == "Breakfast/Social Hour" || x.Name == "Breakfast" || x.Name == "Bistro" || x.Name == "Breakfast:Rebates" || x.Name == "Breakfast Rebate"});
    
        if (Bistro1.length > 0 && Bistro1 != null)
        {
          Bistro1.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            if (hotelid == 133 || hotelid == 136)
            {
                mar1.Name = "Breakfast/Social Hour";
            }
            else if (hotelid == 256 || hotelid == 120 || hotelid == 121 || hotelid == 123 || hotelid == 841 || hotelid == 126)
            {
                mar1.Name = "Breakfast";
            }
            else if (hotelid == 127 || hotelid == 132 || hotelid == 188)
            {
                mar1.Name = "Breakfast Expense";
            }
            else
            {
                mar1.Name = "Bistro";
            }
            mar1.Category = "Expense";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.OperatingExpenseList.push(mar1);
            item.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.OperatingExpenseList.push(mar1);
            model.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Resturant1 = _.filter(model.OperatingExpenseList, function(x) { return  x.Name == "Restaurant Foods:Rebate" || x.Name == "Restaurant Foods" });
        if (Resturant1.length > 0 && Resturant1 != null)
        {
          Resturant1.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Restaurant Foods";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.OperatingExpenseList.push(mar1);
            item.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.OperatingExpenseList.push(mar1);
            model.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let EmployeeAp1 = _.filter(model.OperatingExpenseList, function(x) { return x.Name == "Employee Appreciation" || x.Name == "Employee Appreciation Franchise Fees" });
        if (EmployeeAp1.length > 0 && EmployeeAp1 != null)
        {
          EmployeeAp1.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Employee Appreciation";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = Convert.ToDouble(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.OperatingExpenseList.push(mar1);
            item.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.OperatingExpenseList.push(mar1);
            model.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Insurance1 = _.filter(model.OperatingExpenseList, function(x) { return x.Name == "Admin Fee" || x.Name == "Insurance Expense:Auto" || x.Name == "Crime" || x.Name == "Insurance Expense:Cyber Liability" || x.Name == "Insurance Expense:EPLI" || x.Name == "Excess Liability" || x.Name == "Insurance Expense:Flood coverage" || x.Name == "Insurance Expense:General Liability" || x.Name == "Liquor Liability" || x.Name == "Package" || x.Name == "Insurance Expense:Property" || x.Name == "Insurance Expense:Umbrella" || x.Name == "Wind Buyback" || x.Name == "Insurance Expense:Wind/Hail at Houston/Katy" || x.Name == "Insurance Expense:Wind/Hail Master" || x.Name == "Insurance Expense:Workers Compensation" || x.Name == "Employment Practice Liability" || x.Name == "Property" || x.Name == "Insurance Expense:Workers Comp" || x.Name == "Insurance Expense:Worker's Comp" || x.Name == "Cyber Liability" || x.Name == "EPLI" || x.Name == "Insurance Expense:Employment Practices Liability" || x.Name == "Insurance Expense:Flood Coverage" || x.Name == "Insurance Expense:Worker's Compensation" || x.Name == "Insurance Expense:Admin Fee" || x.Name == "Insurance Expense:Crime" || x.Name == "Insurance Expense:Excess Liability" || x.Name == "Insurance Expense:Liquor Liability" || x.Name == "Insurance Expense:Package" || x.Name == "Insurance Expense:Wind Buyback" || x.Name == "Auto" || x.Name == "General Liability" || x.Name == "Umbrella" || x.Name == "Wind/Hail Master" || x.Name == "Workers Comp" || x.Name == "Flood coverage" || x.Name == "Wind/Hail at Houston/Katy" || x.Name == "Workers Compensation" || x.Name == "Worker's Compensation" || x.Name == "Worker's Comp" || x.Name == "Insurance Expense:Flood Liability" });
        if (Insurance1.length > 0 && Insurance1 != null)
        {
          Insurance1.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Insurance Expense";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = Convert.ToDouble(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.OperatingExpenseList.push(mar1);
            item.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.OperatingExpenseList.push(mar1);
            model.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Maintenance1 = _.filter(model.OperatingExpenseList, function(x) { return x.Name == "Tools/Equipment" || x.Name == "Maintenance Supplies:Tools/Equipment" });
        if (Maintenance1.length > 0 && Maintenance1 != null)
        {
          Maintenance1.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Maintenance Supplies";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = Convert.ToDouble(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.OperatingExpenseList.push(mar1);
            item.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.OperatingExpenseList.push(mar1);
            model.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let marriot1 = _.filter(model.OperatingExpenseList, function(x) { return x.Name == "Rewards Program Expenses" || x.Name == "Marriott Rewards:Rewards Program Expenses" });
        if (marriot1.length > 0 && marriot1 != null)
        {
          marriot1.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Marriott Rewards";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = Convert.ToDouble(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.OperatingExpenseList.push(mar1);
            item.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.OperatingExpenseList.push(mar1);
            model.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Travel1 = _.filter(model.OperatingExpenseList, function(x) { return x.Name == "Meals" || x.Name == "Travel/Conference:Meals" });
        if (Travel1.length > 0 && Travel1 != null)
        {
          Travel1.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Travel/Conference";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = Convert.ToDouble(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.OperatingExpenseList.push(mar1);
            item.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.OperatingExpenseList.push(mar1);
            model.OperatingExpenseList =  _.remove(item.ExpenseList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let TotalefData1 = new PLStatementRevenueItemDataModel();
        TotalefData1.Name = "TOTAL OPERATING EXPENSES";
        TotalefData1.Category = "Expense";
        TotalefData1.MonthName = item.MonthName;
        TotalefData1.Amount = efTotal1;
        Totalopexpense = TotalefData1.Amount;
        item.OperatingExpenseList.push(TotalefData1);
        model.OperatingExpenseList.push(TotalefData1);

        item.OperatingExpenseList = _(item.OperatingExpenseList)
        .groupBy('Name', 'MonthName', 'GLCode')
        .map((objs, key) => ({
            'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
            'Amount': _.sumBy(objs, 'Amount'),
            'Name': key,
            'MonthName': _.get(_.find(objs, function(o) { return true; }), 'MonthName'),
            'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode'),
            }))
        .value();

        let externalDataList3 = _.filter(externalDataListUndistributedExpenseList, function(x) { return t.Date >= dt && t.Date <= monthEndDate });
        
        if (externalDataList3 != null && externalDataList3.length > 0)
        {
          externalDataList3 = groupByDescription(externalDataList3);
          externalDataList3.forEach(async ef => {
            efData.Name = await PnlYearHelper.getGLCodePLV2(ef.Description, hotelid);
            efData.Category = "UndistributedExpense";
            efData.MonthName = item.MonthName;
            efData.Amount = parseFloat(ef.Amount);
            efData.GLCode = await PnlYearHelper.getGLCodePL(efData.Name, hotelid);
            efData.IsActive = true;
            item.UndistcostExpensesList.push(efData);
            model.UndistcostExpensesList.push(efData);
          });
        }

        let tempgilt2 = (item.UndistcostExpensesList != null && item.UndistcostExpensesList.length > 0) ? _.filter(item.UndistcostExpensesList, function(o) { return o.IsActive == true; }) : null ;
        let efTotal3 = (item.UndistcostExpensesList != null && item.UndistcostExpensesList.length > 0) ? _.sumBy(tempgilt2, function(x) { return x.Amount; }) : 0;

        let Bistro2 = _.filter(model.UndistcostExpensesList, function(x) { return x.Name == "Rebate" || x.Name == "Bistro:Rebate" || x.Name == "Breakfast:Rebate" || x.Name == "Breakfast/Social Hour:Rebate" || x.Name == "Breakfast:Rebates" || x.Name == "Breakfast Rebate" });
        if (Bistro2.length > 0 && Bistro2 != null)
        {
          Bistro2.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            if (hotelid == 133 || hotelid == 136)
            {
                mar1.Name = "Breakfast/Social Hour";
            }
            else if (hotelid == 256 || hotelid == 120 || hotelid == 121 || hotelid == 123 || hotelid == 841 || hotelid == 126)
            {
                mar1.Name = "Breakfast";
            }
            else if (hotelid == 127 || hotelid == 132 || hotelid == 188)
            {
                mar1.Name = "Breakfast Expense";
            }
            else
            {
                mar1.Name = "Bistro";
            }
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.UndistcostExpensesList.push(mar1);
            item.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.UndistcostExpensesList.push(mar1);
            model.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Resturant2 = _.filter(model.UndistcostExpensesList, function(x) { return x.Name == "Restaurant Foods:Rebate" || x.Name == "Restaurant Foods" });
        
        if (Resturant2 != null && Resturant2.length > 0)
        {
          Resturant1.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Restaurant Foods";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.UndistcostExpensesList.push(mar1);
            item.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.UndistcostExpensesList.push(mar1);
            model.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }
        
        let EmployeeAp2 = _.filter(model.UndistcostExpensesList, function(x) { return x.Name == "Employee Appreciation" || x.Name == "Employee Appreciation Franchise Fees" });
        if (EmployeeAp2 != null && EmployeeAp2.length > 0)
        {
          EmployeeAp2.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Employee Appreciation";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.UndistcostExpensesList.push(mar1);
            item.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.UndistcostExpensesList.push(mar1);
            model.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Insurance2 = _.filter(model.UndistcostExpensesList, function(x) { return  x.Name == "Admin Fee" || x.Name == "Insurance Expense:Auto" || x.Name == "Crime" || x.Name == "Insurance Expense:Cyber Liability" || x.Name == "Insurance Expense:EPLI" || x.Name == "Excess Liability" || x.Name == "Insurance Expense:Flood coverage" || x.Name == "Insurance Expense:General Liability" || x.Name == "Liquor Liability" || x.Name == "Package" || x.Name == "Insurance Expense:Property" || x.Name == "Insurance Expense:Umbrella" || x.Name == "Wind Buyback" || x.Name == "Insurance Expense:Wind/Hail at Houston/Katy" || x.Name == "Insurance Expense:Wind/Hail Master" || x.Name == "Insurance Expense:Workers Compensation" || x.Name == "Employment Practice Liability" || x.Name == "Property" || x.Name == "Insurance Expense:Workers Comp" || x.Name == "Insurance Expense:Worker's Comp" || x.Name == "Cyber Liability" || x.Name == "EPLI" || x.Name == "Insurance Expense:Employment Practices Liability" || x.Name == "Insurance Expense:Flood Coverage" || x.Name == "Insurance Expense:Worker's Compensation" || x.Name == "Insurance Expense:Admin Fee" || x.Name == "Insurance Expense:Crime" || x.Name == "Insurance Expense:Excess Liability" || x.Name == "Insurance Expense:Liquor Liability" || x.Name == "Insurance Expense:Package" || x.Name == "Insurance Expense:Wind Buyback" || x.Name == "Auto" || x.Name == "General Liability" || x.Name == "Umbrella" || x.Name == "Wind/Hail Master" || x.Name == "Workers Comp" || x.Name == "Flood coverage" || x.Name == "Wind/Hail at Houston/Katy" || x.Name == "Workers Compensation" || x.Name == "Worker's Compensation" || x.Name == "Worker's Comp" || x.Name == "Insurance Expense:Flood Liability"})
        if (Insurance2 != null && Insurance2.length > 0)
        {
          Insurance2.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Insurance Expense";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.UndistcostExpensesList.push(mar1);
            item.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.UndistcostExpensesList.push(mar1);
            model.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Maintenance2 = _.filter(model.UndistcostExpensesList, function(x) { return x.Name == "Tools/Equipment" || x.Name == "Maintenance Supplies:Tools/Equipment" });
        if (Maintenance2 != null && Maintenance2.length > 0)
        {
          Maintenance2.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Maintenance Supplies";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.UndistcostExpensesList.push(mar1);
            item.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.UndistcostExpensesList.push(mar1);
            model.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let marriot2 = _.filter(model.UndistcostExpensesList, function(x) { return x.Name == "Rewards Program Expenses" || x.Name == "Marriott Rewards:Rewards Program Expenses" });
        if (marriot2 != null && marriot2.length > 0)
        {
          marriot2.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Marriott Rewards";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.UndistcostExpensesList.push(mar1);
            item.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.UndistcostExpensesList.push(mar1);
            model.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Travel2 = _.filter(model.UndistcostExpensesList, function(x) { return x.Name == "Meals" || x.Name == "Travel/Conference:Meals" });
        if (Travel2 != null && Travel2.length > 0)
        {
          Travel2.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Travel/Conference";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.UndistcostExpensesList.push(mar1);
            item.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.UndistcostExpensesList.push(mar1);
            model.UndistcostExpensesList =  _.remove(item.UndistcostExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let TotalefData3 = new PLStatementRevenueItemDataModel();
        TotalefData3.Name = "TOTAL UNDISTRIBUTED COSTS EXPENSES";
        TotalefData3.Category = "Expense";
        TotalefData3.MonthName = item.MonthName;
        TotalefData3.Amount = efTotal3;
        TotalundistDataAmount = TotalefData3.Amount;
        item.UndistcostExpensesList.push(TotalefData3);
        model.UndistcostExpensesList.push(TotalefData3);

        item.UndistcostExpensesList = _(item.UndistcostExpensesList)
        .groupBy('Name', 'MonthName', 'GLCode')
        .map((objs, key) => ({
            'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
            'Amount': _.sumBy(objs, 'Amount'),
            'Name': key,
            'MonthName': _.get(_.find(objs, function(o) { return true; }), 'MonthName'),
            'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode'),
            }))
        .value();

        let externalDataList2 = _.filter(externalDataListFixedExpenseList, function(t) { return t.Date.toISOString() >= m.toISOString() && t.Date.toISOString() <= monthEndDate.toISOString() });
        if (externalDataList2 != null && externalDataList2.length > 0)
        {
            externalDataList2 = groupByDescription(externalDataList2);
            externalDataList2.forEach(async ef => {
              efData = new PLStatementRevenueItemDataModel();
              efData.Name = await PnlYearHelper.getGLCodePLV2(ef.Description, hotelid);
              efData.Category = "UndistributedExpense";
              efData.MonthName = item.MonthName;
              efData.Amount = parseFloat(ef.Amount);
              efData.GLCode = await PnlYearHelper.getGLCodePL(efData.Name, hotelid);
              efData.IsActive = true;
              item.FixedExpensesList.push(efData);
              model.FixedExpensesList.push(efData);
            });
        }

        let tempgilt3 = (item.FixedExpensesList != null && item.FixedExpensesList.length > 0) ? _.filter(item.FixedExpensesList, function(o) { return o.IsActive == true; }) : null ;
        let efTotal2 = (item.FixedExpensesList != null && item.FixedExpensesList.length > 0) ? _.sumBy(tempgilt3, function(x) { return x.Amount; }) : 0;

        let Bistro3 = _.filter(model.FixedExpensesList, function(x) { return x.Name == "Rebate" || x.Name == "Bistro:Rebate" || x.Name == "Breakfast:Rebate" || x.Name == "Breakfast/Social Hour:Rebate" || x.Name == "Breakfast:Rebates" || x.Name == "Breakfast Rebate" });
        if (Bistro3 != null && Bistro3.length > 0)
        {
          Bistro3.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemModel();
            if (hotelid == 133 || hotelid == 136)
            {
                mar1.Name = "Breakfast/Social Hour";
            }
            else if (hotelid == 256 || hotelid == 120 || hotelid == 121 || hotelid == 123 || hotelid == 841 || hotelid == 126)
            {
                mar1.Name = "Breakfast";
            }
            else if (hotelid == 127 || hotelid == 132 || hotelid == 188)
            {
                mar1.Name = "Breakfast Expense";
            }
            else
            {
                mar1.Name = "Bistro";
            }
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.FixedExpensesList.push(mar1);
            item.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.FixedExpensesList.push(mar1);
            model.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Resturant3 = _.filter(model.FixedExpensesList, function(x) { return x.Name == "Restaurant Foods:Rebate" || x.Name == "Restaurant Foods" });
        if (Resturant3 != null && Resturant3.length > 0)
        {
          Resturant3.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Restaurant Foods";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.FixedExpensesList.push(mar1);
            item.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.FixedExpensesList.push(mar1);
            model.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let EmployeeAp3 = _.filter(model.FixedExpensesList, function(x) { return x.Name == "Employee Appreciation" || x.Name == "Employee Appreciation Franchise Fees" });
        if (EmployeeAp3 != null && EmployeeAp3.length > 0)
        {
          EmployeeAp3.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Employee Appreciation";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.FixedExpensesList.push(mar1);
            item.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.FixedExpensesList.push(mar1);
            model.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }
      
        let Insurance3 = _.filter(model.FixedExpensesList, function(x) { return x.Name == "Admin Fee" || x.Name == "Insurance Expense:Auto" || x.Name == "Crime" || x.Name == "Insurance Expense:Cyber Liability" || x.Name == "Insurance Expense:EPLI" || x.Name == "Excess Liability" || x.Name == "Insurance Expense:Flood coverage" || x.Name == "Insurance Expense:General Liability" || x.Name == "Liquor Liability" || x.Name == "Package" || x.Name == "Insurance Expense:Property" || x.Name == "Insurance Expense:Umbrella" || x.Name == "Wind Buyback" || x.Name == "Insurance Expense:Wind/Hail at Houston/Katy" || x.Name == "Insurance Expense:Wind/Hail Master" || x.Name == "Insurance Expense:Workers Compensation" || x.Name == "Employment Practice Liability" || x.Name == "Property" || x.Name == "Insurance Expense:Workers Comp" || x.Name == "Insurance Expense:Worker's Comp" || x.Name == "Cyber Liability" || x.Name == "EPLI" || x.Name == "Insurance Expense:Employment Practices Liability" || x.Name == "Insurance Expense:Flood Coverage" || x.Name == "Insurance Expense:Worker's Compensation" || x.Name == "Insurance Expense:Admin Fee" || x.Name == "Insurance Expense:Crime" || x.Name == "Insurance Expense:Excess Liability" || x.Name == "Insurance Expense:Liquor Liability" || x.Name == "Insurance Expense:Package" || x.Name == "Insurance Expense:Wind Buyback" || x.Name == "Auto" || x.Name == "General Liability" || x.Name == "Umbrella" || x.Name == "Wind/Hail Master" || x.Name == "Workers Comp" || x.Name == "Flood coverage" || x.Name == "Wind/Hail at Houston/Katy" || x.Name == "Workers Compensation" || x.Name == "Worker's Compensation" || x.Name == "Worker's Comp" || x.Name == "Insurance Expense:Flood Liability"});
        if (Insurance3 != null && Insurance3.length > 0)
        {
          Insurance3.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Insurance Expense";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.FixedExpensesList.push(mar1);
            item.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.FixedExpensesList.push(mar1);
            model.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Maintenance3 = _.filter(model.FixedExpensesList, function(x) { return x.Name == "Tools/Equipment" || x.Name == "Maintenance Supplies:Tools/Equipment" });
        if (Maintenance3 != null && Maintenance3.length > 0)
        {
          Maintenance3.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Maintenance Supplies";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.FixedExpensesList.push(mar1);
            item.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.FixedExpensesList.push(mar1);
            model.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let marriot3 = _.filter(model.FixedExpensesList, function(x) { return x.Name == "Rewards Program Expenses" || x.Name == "Marriott Rewards:Rewards Program Expenses" });
        if (marriot3 != null && marriot3.length > 0)
        {
          marriot3.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Marriott Rewards";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.FixedExpensesList.push(mar1);
            item.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.FixedExpensesList.push(mar1);
            model.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Travel3 = _.filter(model.FixedExpensesList, function(x) { return x.Name == "Meals" || x.Name == "Travel/Conference:Meals" });
        if (Travel3 != null && Travel3.length > 0)
        {
          Travel3.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Travel/Conference";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.FixedExpensesList.push(mar1);
            item.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.FixedExpensesList.push(mar1);
            model.FixedExpensesList =  _.remove(item.FixedExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let TotalefData2 = new PLStatementRevenueItemDataModel();
        TotalefData2.Name = "TOTAL FIXED EXPENSES";
        TotalefData2.Category = "Expense";
        TotalefData2.MonthName = item.MonthName;
        TotalefData2.Amount = efTotal2;
        TotalfixedDataAmount = TotalefData2.Amount;
        item.FixedExpensesList.push(TotalefData2);
        model.FixedExpensesList.push(TotalefData2);

        item.FixedExpensesList = _(item.FixedExpensesList)
        .groupBy('Name', 'MonthName', 'GLCode')
        .map((objs, key) => ({
            'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
            'Amount': _.sumBy(objs, 'Amount'),
            'Name': key,
            'MonthName': _.get(_.find(objs, function(o) { return true; }), 'MonthName'),
            'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode'),
            }))
        .value();

        let externalDataList4 = _.filter(externalDataListITDAExpenseList, function(t) { return t.Date.toISOString() >= m.toISOString() && t.Date.toISOString() <= monthEndDate.toISOString() });
        if (externalDataList4 != null && externalDataList4.length > 0)
        {
            externalDataList4 = groupByDescription(externalDataList4);
            externalDataList4.forEach(async ef => {
              efData = new PLStatementRevenueItemDataModel();
              efData.Name = await PnlYearHelper.getGLCodePLV2(ef.Description, hotelid);
              efData.Category = "Expense";
              efData.MonthName = item.MonthName;
              efData.Amount = parseFloat(ef.Amount);
              efData.GLCode = await PnlYearHelper.getGLCodePL(efData.Name, hotelid);
              efData.IsActive = true;
              item.ITDAExpensesList.push(efData);
              model.ITDAExpensesList.push(efData);
            });
        }

        let tempgilt4 = (item.ITDAExpensesList != null && item.ITDAExpensesList.length > 0) ? _.filter(item.ITDAExpensesList, function(o) { return o.IsActive == true; }) : null ;
        let efTotal4 = (item.ITDAExpensesList != null && item.ITDAExpensesList.length > 0) ? _.sumBy(tempgilt4, function(x) { return x.Amount; }) : 0;
        
        let Bistro4 = _.filter(model.ITDAExpensesList, function(x) { return x.Name == "Rebate" || x.Name == "Bistro:Rebate" || x.Name == "Breakfast:Rebate" || x.Name == "Breakfast/Social Hour:Rebate" || x.Name == "Breakfast:Rebates" || x.Name == "Breakfast Rebate" });
        if (Bistro4.length > 0 && Bistro4 != null)
        {
          Bistro4.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            if (hotelid == 133 || hotelid == 136)
            {
                mar1.Name = "Breakfast/Social Hour";
            }
            else if (hotelid == 256 || hotelid == 120 || hotelid == 121 || hotelid == 123 || hotelid == 841 || hotelid == 126)
            {
                mar1.Name = "Breakfast";
            }
            else if (hotelid == 127 || hotelid == 132 || hotelid == 188)
            {
                mar1.Name = "Breakfast Expense";
            }
            else
            {
                mar1.Name = "Bistro";
            }
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ITDAExpensesList.push(mar1);
            item.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.ITDAExpensesList.push(mar1);
            model.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Resturant4 = _.filter(model.ITDAExpensesList, function(x) { return x.Name == "Restaurant Foods:Rebate" || x.Name == "Restaurant Foods" });
        if (Resturant4 != null && Resturant4.length > 0)
        {
          Resturant4.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Restaurant Foods";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ITDAExpensesList.push(mar1);
            item.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.ITDAExpensesList.push(mar1);
            model.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let EmployeeAp4 = _.filter(model.ITDAExpensesList, function(x) { return x.Name == "Employee Appreciation" || x.Name == "Employee Appreciation Franchise Fees" });
        if (EmployeeAp4 != null && EmployeeAp4.length > 0)
        {
          EmployeeAp4.forEach(item1 => {
            let mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Employee Appreciation";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ITDAExpensesList.push(mar1);
            item.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.ITDAExpensesList.push(mar1);
            model.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Insurance4 = _.filter(model.ITDAExpensesList, function(x) { return x.Name == "Admin Fee" || x.Name == "Insurance Expense:Auto" || x.Name == "Crime" || x.Name == "Insurance Expense:Cyber Liability" || x.Name == "Insurance Expense:EPLI" || x.Name == "Excess Liability" || x.Name == "Insurance Expense:Flood coverage" || x.Name == "Insurance Expense:General Liability" || x.Name == "Liquor Liability" || x.Name == "Package" || x.Name == "Insurance Expense:Property" || x.Name == "Insurance Expense:Umbrella" || x.Name == "Wind Buyback" || x.Name == "Insurance Expense:Wind/Hail at Houston/Katy" || x.Name == "Insurance Expense:Wind/Hail Master" || x.Name == "Insurance Expense:Workers Compensation" || x.Name == "Employment Practice Liability" || x.Name == "Property" || x.Name == "Insurance Expense:Workers Comp" || x.Name == "Insurance Expense:Worker's Comp" || x.Name == "Cyber Liability" || x.Name == "EPLI" || x.Name == "Insurance Expense:Employment Practices Liability" || x.Name == "Insurance Expense:Flood Coverage" || x.Name == "Insurance Expense:Worker's Compensation" || x.Name == "Insurance Expense:Admin Fee" || x.Name == "Insurance Expense:Crime" || x.Name == "Insurance Expense:Excess Liability" || x.Name == "Insurance Expense:Liquor Liability" || x.Name == "Insurance Expense:Package" || x.Name == "Insurance Expense:Wind Buyback" || x.Name == "Auto" || x.Name == "General Liability" || x.Name == "Umbrella" || x.Name == "Wind/Hail Master" || x.Name == "Workers Comp" || x.Name == "Flood coverage" || x.Name == "Wind/Hail at Houston/Katy" || x.Name == "Workers Compensation" || x.Name == "Worker's Compensation" || x.Name == "Worker's Comp" || x.Name == "Insurance Expense:Flood Liability" });
        if (Insurance4 != null && Insurance4.length > 0)
        {
          Insurance4.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Insurance Expense";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ITDAExpensesList.push(mar1);
            item.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.ITDAExpensesList.push(mar1);
            model.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Maintenance4 = _.filter(model.ITDAExpensesList, function(x) { return x.Name == "Tools/Equipment" || x.Name == "Maintenance Supplies:Tools/Equipment" });
        if (Maintenance4 != null && Maintenance4.length > 0)
        {
          Maintenance4.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Maintenance Supplies";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ITDAExpensesList.push(mar1);
            item.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.ITDAExpensesList.push(mar1);
            model.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let marriot4 = _.filter(model.ITDAExpensesList, function(x) { return x.Name == "Rewards Program Expenses" || x.Name == "Marriott Rewards:Rewards Program Expenses" });
        if (marriot4 != null && marriot4.length > 0)
        {
          marriot4.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Marriott Rewards";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ITDAExpensesList.push(mar1);
            item.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.ITDAExpensesList.push(mar1);
            model.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let Travel4 = _.filter(model.ITDAExpensesList, function(x) { return x.Name == "Meals" || x.Name == "Travel/Conference:Meals" });
        if (Travel4 != null && Travel4.length > 0)
        {
          Travel4.forEach(item1 => {
            mar1 = new PLStatementRevenueItemDataModel();
            mar1.Name = "Travel/Conference";
            mar1.Category = "Expense";
            mar1.MonthName = item1.MonthName;
            mar1.Amount = parseFloat(item1.Amount);
            mar1.GLCode = item1.GLCode;
            mar1.IsActive = true;
            item.ITDAExpensesList.push(mar1);
            item.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
            model.ITDAExpensesList.push(mar1);
            model.ITDAExpensesList =  _.remove(item.ITDAExpensesList, function(n) {
              return n.MonthName == item1.MonthName && n.GLCode == item1.GLCode;
            });
          });
        }

        let TotalefData4 = new PLStatementRevenueItemDataModel();
        TotalefData4.Name = "TOTAL ITDA Expenses";
        TotalefData4.Category = "Expense";
        TotalefData4.MonthName = item.MonthName;
        TotalefData4.Amount = efTotal4;
        TotalitdaDataAmount = TotalefData4.Amount;
        item.ITDAExpensesList.push(TotalefData4);
        model.ITDAExpensesList.push(TotalefData4);

        item.ITDAExpensesList = _(item.ITDAExpensesList)
        .groupBy('Name', 'MonthName', 'GLCode')
        .map((objs, key) => ({
            'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
            'Amount': _.sumBy(objs, 'Amount'),
            'Name': key,
            'MonthName': _.get(_.find(objs, function(o) { return true; }), 'MonthName'),
            'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode'),
            }))
        .value();

        let TotallbefDataAmount = 0;
        if (islabordataavailable)
        {
            model.LaborDataType = "(Hotel Effectiveness)";
        }
        else
        {
            model.LaborDataType = "";
        }

        let LabourDataList = await PnlYearHelper.getLabourExpenseData(hotel.ID, m, monthEndDate);
        if (LabourDataList != null && LabourDataList.length > 0)
        {

          LabourDataList = await PnlYearHelper.filterInactiveDescLB(LabourDataList, "LaborExpense");
          LabourDataList.forEach(async lb => {
            efData = new PLStatementRevenueItemDataModel();
            efData.Name = lb.Department;
            efData.Category = "Labour Expense";
            efData.MonthName = item.MonthName;
            efData.Amount = parseFloat(lb.Wages);
            efData.GLCode = await PnlYearHelper.getGLCode(efData.Name, hotelid);
            item.LabourExpenseList.push(efData);
            model.LabourExpenseList.push(efData);
          });

          let lbefTotal = (item.LabourExpenseList != null && item.LabourExpenseList.Count > 0) ? _.sumBy(item.LabourExpenseList, function(x) { x.Amount}) : 0;
          let TotallbefData = new PLStatementRevenueItemDataModel();
          TotallbefData.Name = "TOTAL LABOR EXPENSES";
          TotallbefData.Category = "Labour Expense";
          TotallbefData.MonthName = item.MonthName;
          TotallbefData.Amount = lbefTotal;
          TotallbefDataAmount = TotallbefData.Amount;
          item.LabourExpenseList.push(TotallbefData);
          model.LabourExpenseList.push(TotallbefData);

          item.LabourExpenseList = _(item.LabourExpenseList)
          .groupBy('Name', 'MonthName', 'GLCode')
          .map((objs, key) => ({
              'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
              'Amount': _.sumBy(objs, 'Amount'),
              'Name': key,
              'MonthName': _.get(_.find(objs, function(o) { return true; }), 'MonthName'),
              'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode'),
              }))
          .value();
        }

        let TotaltaxDataAmount = 0;

        let taxList = _.filter(TaxDataList, function(t) { return t.Date >= m.toISOString() && t.Date <= moment(endDate).toISOString() });
        if (taxList != null && taxList.Count > 0)
        {
          taxList.forEach(async tax => {
            let taxData = new PLStatementRevenueItemDataModel();
            taxData.Name = tax.Description;
            taxData.Category = "Tax";
            taxData.MonthName = item.MonthName;
            taxData.Amount = Convert.ToDouble(tax.Amount);
            taxData.GLCode = await PnlYearHelper.getGLCode(taxData.Name, hotelid);
            item.TaxList.push(taxData);
            model.TaxList.push(taxData);
          });

          let TotaltaxData = new PLStatementRevenueItemDataModel();
          TotaltaxData.Name = "TOTAL TAX";
          TotaltaxData.Category = "Tax";
          TotaltaxData.MonthName = item.MonthName;
          TotaltaxData.Amount = (item.TaxList != null && item.TaxList.Count > 0) ?  _.sumBy(item.TaxList, function(x) { x.Amount }) : 0;
          TotaltaxDataAmount = TotaltaxData.Amount;
          item.TaxList.push(TotaltaxData);
          model.TaxList.push(TotaltaxData);
        }

        let expensetotal = new PLStatementRevenueItemDataModel();
        expensetotal.Category = "expensetotal";
        expensetotal.MonthName = item.MonthName;
        expensetotal.Amount = Totalopexpense + TotalundistDataAmount + TotallbefDataAmount;
        expensetotal.Name = "Total Expense";
        model.ExpenseList1.push(expensetotal);

        let GOPtotal = new PLStatementRevenueItemDataModel();
        GOPtotal.Category = "gopexpensetotal";
        GOPtotal.MonthName = item.MonthName;
        GOPtotal.Amount = totalrevenueData.Amount - expensetotal.Amount;
        GOPtotal.Name = "GOP Expense";
        model.GOPList.push(GOPtotal);

        let noptotal = new PLStatementRevenueItemDataModel();
        noptotal.Category = "noptotal";
        noptotal.MonthName = item.MonthName;
        noptotal.Amount = totalrevenueData.Amount - Totalopexpense - TotalundistDataAmount - TotalfixedDataAmount - TotalitdaDataAmount - TotallbefDataAmount;
        noptotal.Name = "Total NOP";
        model.NOPList.push(noptotal);

        let netbeforeTax = new PLStatementRevenueItemDataModel();
        netbeforeTax.Category = "netbeforeTax";
        netbeforeTax.MonthName = item.MonthName;
        netbeforeTax.Amount = totalrevenueData.Amount - Totalopexpense - TotallbefDataAmount;
        netbeforeTax.Name = "Net Profit before Tax";
        model.NetBeforeTaxList.push(netbeforeTax);

        let netprofit = new PLStatementRevenueItemDataModel();
        netprofit.Category = "netprofit";
        netprofit.MonthName = item.MonthName;
        netprofit.Amount = netbeforeTax.Amount;
        netprofit.Name = "Net Profit";
        model.NetProfitList.push(netprofit);

        let netprofitmargin = new PLStatementRevenueItemDataModel();
        netprofitmargin.Category = "netprofitmargin";
        netprofitmargin.MonthName = item.MonthName;
        netprofitmargin.Amount = 0;
        if (netbeforeTax.Amount != 0 && totalrevenueData.Amount != 0)
        {
            netprofitmargin.Amount = (netbeforeTax.Amount / totalrevenueData.Amount) * 100;
        }
        netprofitmargin.Name = "Net Profit Margin";
        model.NetProfitMarginList.push(netprofitmargin);
        model.Items.push(item);

        let Ebidta = new PLStatementRevenueItemDataModel();
        Ebidta.Name = "TOTAL OF EBITDA";
        Ebidta.Category = "Expense";
        Ebidta.MonthName = item.MonthName;
        Ebidta.Amount = GOPtotal.Amount - TotalefData2.Amount;
        model.EBIDTAExpensesList.push(Ebidta);

        let grossprofitmargin = new PLStatementRevenueItemDataModel();
        grossprofitmargin.Category = "grossprofitmargin";
        grossprofitmargin.MonthName = item.MonthName;
        grossprofitmargin.Amount = 0;
        if (netbeforeTax.Amount != 0 && totalrevenueData.Amount != 0)
        {
            grossprofitmargin.Amount = (GOPtotal.Amount / totalrevenueData.Amount) * 100;
        }
        grossprofitmargin.Name = "Gross Profit Margin";
        model.GrossProfitMarginList.push(grossprofitmargin);

        resolve();
        })
      )
    }; // end of for loop :)

      Promise.all(pArrr).then(res =>{

      // })();

      if (outlet1otherrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Outlet 1 - Other" });
          if (matches != undefined)
          {
            model.RevenueList= _.remove(model.RevenueList, function(n) {
              return n.Name == matches.Name;
            });

            // model.RevenueList.Remove(matches);
          }
      }
      if (outlet2otherrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Outlet 2 - Other" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (outlet3otherrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Outlet 3 - Other" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (outlet4otherrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Outlet 4 - Other" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (outlet1fandbrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Outlet 1 - F&B" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (outlet2fandbrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Outlet 2 - F&B" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (outlet3fandbrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Outlet 3 - F&B" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (outlet4fandbrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Outlet 4 - F&B" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (restaurantrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Restaurant" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (barrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Bar" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (banquetrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Banquet" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (parkingrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Parking" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (giftshoprevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Gift Shop" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (beveragerevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Beverage" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }
      if (foodrevenueTotal == 0)
      {
          var matches = _.find(model.RevenueList, function(x) { x.Name == "Food" });
          if (matches != null)
          {
              // model.RevenueList.Remove(matches);
              model.RevenueList= _.remove(model.RevenueList, function(n) {
                return n.Name == matches.Name;
              });
          }
      }

      model.TaxList = _(model.TaxList)
      .groupBy('Name')
      .map((objs, key) => ({
          'Category': _.get(_.findLast(objs, function(o) { return true; }), 'Category'),
          'Amount': _.sumBy(objs, 'Amount'),
          'Name': key,
          'MonthName': _.get(_.findLast(objs, function(o) { return true; }), 'MonthName'),
          'GLCode': _.get(_.findLast(objs, function(o) { return true; }), 'GLCode'),
          }))
      .value();

      model.TaxList = _.orderBy(model.TaxList, ['Name'], ['asc']);

      if (model.ExpenseList != null && model.ExpenseList.length > 0)
      {

          model.ExpenseList = _(model.ExpenseList)
          .groupBy('Name')
          .map((objs, key) => ({
              'Category': _.get(_.findLast(objs, function(o) { return true; }), 'Category'),
              'Amount': _.sumBy(objs, 'Amount'),
              'Name': key,
              'MonthName': _.get(_.findLast(objs, function(o) { return true; }), 'MonthName'),
              'GLCode': _.get(_.findLast(objs, function(o) { return true; }), 'GLCode'),
              }))
          .value();

          model.ExpenseList = _.orderBy(model.ExpenseList, ['Name'], ['asc']);

          //TOTAL EXPENSES MOVE TO LAST
          // var TOTALEXPENSESitem = model.ExpenseList.Single(x => x.Name == "TOTAL EXPENSES");
          let TOTALEXPENSESitem = _.find(model.ExpenseList, function(x) { return x.Name == "TOTAL EXPENSES" });
          // var oldIndex = model.ExpenseList.IndexOf(TOTALEXPENSESitem);
          let oldIndex = model.ExpenseList.findIndex(x => x.Name ==="TOTAL EXPENSES");
          // model.ExpenseList.RemoveAt(oldIndex);
          model.ExpenseList.splice(oldIndex, 1)
          model.ExpenseList.push(TOTALEXPENSESitem);
      }

      if (model.OperatingExpenseList != null && model.OperatingExpenseList.length > 0)
      {

          model.OperatingExpenseList = _(model.OperatingExpenseList)
          .groupBy('Name')
          .map((objs, key) => ({
              'Category': _.get(_.findLast(objs, function(o) { return true; }), 'Category'),
              'Amount': _.sumBy(objs, 'Amount'),
              'Name': key,
              'MonthName': _.get(_.findLast(objs, function(o) { return true; }), 'MonthName'),
              'GLCode': _.get(_.findLast(objs, function(o) { return true; }), 'GLCode'),
              }))
          .value();

          model.OperatingExpenseList = _.orderBy(model.OperatingExpenseList, ['Name'], ['asc']);

          //TOTAL EXPENSES MOVE TO LAST
          // var TOTALEXPENSESitem = model.OperatingExpenseList.Single(x => x.Name == "TOTAL OPERATING EXPENSES");
          let TOTALEXPENSESitem = _.find(model.OperatingExpenseList, function(x) { return x.Name == "TOTAL OPERATING EXPENSES" });
          // var oldIndex = model.OperatingExpenseList.IndexOf(TOTALEXPENSESitem);
          let oldIndex = model.OperatingExpenseList.findIndex(x => x.Name ==="TOTAL OPERATING EXPENSES");
          model.OperatingExpenseList.splice(oldIndex, 1);
          model.OperatingExpenseList.push(TOTALEXPENSESitem);
      }

      if (model.UndistcostExpensesList != null && model.UndistcostExpensesList.length > 0)
      {

          model.UndistcostExpensesList = _(model.UndistcostExpensesList)
          .groupBy('Name')
          .map((objs, key) => ({
              'Category': _.get(_.findLast(objs, function(o) { return true; }), 'Category'),
              'Amount': _.sumBy(objs, 'Amount'),
              'Name': key,
              'MonthName': _.get(_.findLast(objs, function(o) { return true; }), 'MonthName'),
              'GLCode': _.get(_.findLast(objs, function(o) { return true; }), 'GLCode'),
              }))
          .value();

          // model.UndistcostExpensesList = model.UndistcostExpensesList.OrderBy(x => x.Name).ToList();
          model.UndistcostExpensesList = _.orderBy(model.UndistcostExpensesList, ['Name'], ['asc']);

          //TOTAL EXPENSES MOVE TO LAST
          let TOTALEXPENSESitem = _.find(model.UndistcostExpensesList, function(x) { return x.Name == "TOTAL UNDISTRIBUTED COSTS EXPENSES" });
          // var oldIndex = model.OperatingExpenseList.IndexOf(TOTALEXPENSESitem);
          let oldIndex = model.UndistcostExpensesList.findIndex(x => x.Name ==="TOTAL UNDISTRIBUTED COSTS EXPENSES");
          model.UndistcostExpensesList.splice(oldIndex, 1);
          model.UndistcostExpensesList.push(TOTALEXPENSESitem);
      }

      if (model.FixedExpensesList != null && model.FixedExpensesList.length > 0)
      {

         model.FixedExpensesList = _(model.FixedExpensesList)
          .groupBy('Name')
          .map((objs, key) => ({
              'Category': _.get(_.findLast(objs, function(o) { return true; }), 'Category'),
              'Amount': _.sumBy(objs, 'Amount'),
              'Name': key,
              'MonthName': _.get(_.findLast(objs, function(o) { return true; }), 'MonthName'),
              'GLCode': _.get(_.findLast(objs, function(o) { return true; }), 'GLCode'),
              }))
          .value();

          // model.FixedExpensesList = model.FixedExpensesList.OrderBy(x => x.Name).ToList();
          model.FixedExpensesList = _.orderBy(model.FixedExpensesList, ['Name'], ['asc']);

          //TOTAL EXPENSES MOVE TO LAST
          // var TOTALEXPENSESitem = model.FixedExpensesList.Single(x => x.Name == "TOTAL FIXED EXPENSES");
          // var oldIndex = model.FixedExpensesList.IndexOf(TOTALEXPENSESitem);
          // model.FixedExpensesList.RemoveAt(oldIndex);
          // model.FixedExpensesList.Insert(model.FixedExpensesList.count, TOTALEXPENSESitem);

          let TOTALEXPENSESitem = _.find(model.FixedExpensesList, function(x) { return x.Name == "TOTAL FIXED EXPENSES" });
          // var oldIndex = model.OperatingExpenseList.IndexOf(TOTALEXPENSESitem);
          let oldIndex = model.FixedExpensesList.findIndex(x => x.Name ==="TOTAL FIXED EXPENSES");
          model.FixedExpensesList.splice(oldIndex, 1);
          model.FixedExpensesList.push(TOTALEXPENSESitem);
      }

      if (model.ITDAExpensesList != null && model.ITDAExpensesList.length > 0)
      {

          model.ITDAExpensesList = _(model.ITDAExpensesList)
          .groupBy('Name')
          .map((objs, key) => ({
              'Category': _.get(_.findLast(objs, function(o) { return true; }), 'Category'),
              'Amount': _.sumBy(objs, 'Amount'),
              'Name': key,
              'MonthName': _.get(_.findLast(objs, function(o) { return true; }), 'MonthName'),
              'GLCode': _.get(_.findLast(objs, function(o) { return true; }), 'GLCode'),
              }))
          .value();

          // model.ITDAExpensesList = model.ITDAExpensesList.OrderBy(x => x.Name).ToList();
          model.ITDAExpensesList = _.orderBy(model.ITDAExpensesList, ['Name'], ['asc']);

          //TOTAL EXPENSES MOVE TO LAST
          // var TOTALEXPENSESitem = model.ITDAExpensesList.Single(x => x.Name == "TOTAL ITDA Expenses");
          // var oldIndex = model.ITDAExpensesList.IndexOf(TOTALEXPENSESitem);
          // model.ITDAExpensesList.RemoveAt(oldIndex);
          // model.ITDAExpensesList.Insert(model.ITDAExpensesList.Count, TOTALEXPENSESitem);

          let TOTALEXPENSESitem = _.find(model.ITDAExpensesList, function(x) { return x.Name == "TOTAL ITDA Expenses" });
          // var oldIndex = model.OperatingExpenseList.IndexOf(TOTALEXPENSESitem);
          let oldIndex = model.ITDAExpensesList.findIndex(x => x.Name ==="TOTAL ITDA Expenses");
          model.ITDAExpensesList.splice(oldIndex, 1);
          model.ITDAExpensesList.push(TOTALEXPENSESitem);
      }

      if (model.LabourExpenseList != null && model.LabourExpenseList.length > 0)
      {
            model.LabourExpenseList = _(model.LabourExpenseList)
            .groupBy('Name')
            .map((objs, key) => ({
                'Category': _.get(_.findLast(objs, function(o) { return true; }), 'Category'),
                'Amount': _.sumBy(objs, 'Amount'),
                'Name': key,
                'MonthName': _.get(_.findLast(objs, function(o) { return true; }), 'MonthName'),
                'GLCode': _.get(_.findLast(objs, function(o) { return true; }), 'GLCode'),
                }))
            .value();

          // model.LabourExpenseList = model.LabourExpenseList.OrderBy(x => x.Name).ToList();
          model.LabourExpenseList = _.orderBy(model.LabourExpenseList, ['Name'], ['asc']);

          //TOTAL LabourExpenseList EXPENSES MOVE TO LAST
          // var TOTALEXPENSESitem = model.LabourExpenseList.Single(x => x.Name == "TOTAL LABOR EXPENSES");
          // var oldIndex = model.LabourExpenseList.IndexOf(TOTALEXPENSESitem);
          // model.LabourExpenseList.RemoveAt(oldIndex);
          // model.LabourExpenseList.Insert(model.LabourExpenseList.Count, TOTALEXPENSESitem);

          let TOTALEXPENSESitem = _.find(model.LabourExpenseList, function(x) { return x.Name == "TOTAL LABOR EXPENSES" });
          // var oldIndex = model.OperatingExpenseList.IndexOf(TOTALEXPENSESitem);
          let oldIndex = model.LabourExpenseList.findIndex(x => x.Name ==="TOTAL LABOR EXPENSES");
          model.LabourExpenseList.splice(oldIndex, 1);
          model.LabourExpenseList.push(TOTALEXPENSESitem);
      }

      if (model.TaxList != null && model.TaxList.length > 0)
      {
          //TOTAL TAX MOVE TO LAST
          // var TOTALTAXitem = model.TaxList.Single(x => x.Name == "TOTAL TAX");
          let TOTALTAXitem = _.find(model.TaxList, function(x) { return x.Name == "TOTAL TAX" });
          // var TOTALTAXoldIndex = model.TaxList.IndexOf(TOTALTAXitem);
          let TOTALTAXoldIndex = model.TaxList.findIndex(x => x.Name ==="TOTAL TAX");
          // model.TaxList.RemoveAt(TOTALTAXoldIndex);
          model.TaxList.splice(TOTALTAXoldIndex, 1);
          // model.TaxList.Insert(model.TaxList.Count, TOTALTAXitem);
          model.TaxList.push(TOTALTAXitem);
      }

      model.rawOrder = {};

      PnlcustomizeRawSchema.findOne({[PnlcustomizeRawSchemaField.Hotel_ID]: hotelid, [PnlcustomizeRawSchemaField.Pnl_view]: 'Yearly'},
      (err, res) => {
        if(err) {
          log.error(err)
          reject(err)
        }
        model.rawOrder = res;
        return cb(null, model);
      })


      // console.log('waited')
      // return cb(null, model);
          // })
        })
      })()
    })
  }

  static getExternalData(hotelId, startDate, endDate) {
    return new Promise((resolve, reject) => {
      startDate = new Date(startDate).toISOString();
      endDate = new Date(endDate).toISOString();

      let finalData = [];
      let hotelExternalDataList = [];
      Promise.all([
        new Promise((resolve, reject) => {
          HotelexternaldataSchema.find({[HotelexternaldataSchemaFields.HotelID]: hotelId, [HotelexternaldataSchemaFields.Category]: "Expense", [HotelexternaldataSchemaFields.IsDelete]: false, [HotelexternaldataSchemaFields.Date]: { "$gte": startDate, "$lte": endDate}},
          (err, resp) => {
            // console.log(hotelExternalDataList, 'hotelExternalDataList');
            if(err) {
                log.error(err)
                reject(err);
            }
            hotelExternalDataList = resp;
            resolve();
          })
        })
      ]).then(res=> {
        let prArr = [];
        if(hotelExternalDataList.length > 0) {
          hotelExternalDataList.forEach(element => {
            prArr.push(
              new Promise((resolve, reject) => {
                QbdescriptionmappingSchema.find({[QbdescriptionmappingSchemaFields.HotelID]: hotelId, [QbdescriptionmappingSchemaFields.IsActive]: false, [QbdescriptionmappingSchemaFields.Description]: element.Description},
                  (err, result) => {
                    // console.log(result, 'result');
                    if(err) {
                        log.error(err)
                        reject(err);
                    }
                    if (result.length == 0) {
                      finalData.push(element);
                    }
                    resolve();
                });
              })
            )
          })
        } else {
          prArr = [];
        }
        Promise.all(prArr).then(res => {
          // console.log(finalData, 'finalData');
          resolve(finalData);
        });
      })
    })
  }

  static getExternalDataOperatingExpense(hotelId, startDate, endDate) {
    return new Promise((resolve, reject) => {
      startDate = new Date(startDate).toISOString();
      endDate = new Date(endDate).toISOString();

      let finalData = [];
      let hotelExternalDataList = [];
      Promise.all([
        new Promise((resolve, reject) => {
          HotelexternaldataSchema.find({[HotelexternaldataSchemaFields.HotelID]: hotelId, [HotelexternaldataSchemaFields.Category]: "Expense", [HotelexternaldataSchemaFields.IsDelete]: false, [HotelexternaldataSchemaFields.Date]: { "$gte": startDate, "$lte": endDate}},
          (err, res) => {
            // console.log(hotelExternalDataList);
            if(err) {
                log.error(err)
                reject(err);
            }
            hotelExternalDataList = res;
            resolve();
          })
        })
      ]).then(res=> {
        let prArr = [];
        if(hotelExternalDataList.length > 0) {
          hotelExternalDataList.forEach(element => {
            prArr.push(
              new Promise((resolve, reject) => {
                QbdescriptionmappingSchema.find({[QbdescriptionmappingSchemaFields.HotelID]: hotelId, [QbdescriptionmappingSchemaFields.IsActive]: false, [QbdescriptionmappingSchemaFields.Description]: element.Description},
                  (err, result) => {
                    // console.log(result);
                    if(err) {
                        log.error(err);
                        reject(err);
                    }
                    if (result.length == 0) {
                      finalData.push(element);
                    }
                    resolve();
                  }) 
              })
            )
          })
        } else {
          prArr = [];
        }
        Promise.all(prArr).then(res => {
          // console.log(finalData, 'finalData');
          resolve(finalData);
        });
      })
    })
  }

  static getExternalDataUndistributedExpense(hotelId, startDate, endDate) {
    return new Promise((resolve, reject) => {
      startDate = new Date(startDate).toISOString();
      endDate = new Date(endDate).toISOString();

      let finalData = [];
      let hotelExternalDataList = [];
      Promise.all([
        new Promise((resolve, reject) => {
          HotelexternaldataSchema.find({[HotelexternaldataSchemaFields.HotelID]: hotelId, [HotelexternaldataSchemaFields.Category]: "UndistributedExpense", [HotelexternaldataSchemaFields.IsDelete]: false, [HotelexternaldataSchemaFields.Date]: { "$gte": startDate, "$lte": endDate}},
          (err, res) => {
            if(err) {
                log.error(err);
                reject(err);
            }
            hotelExternalDataList = res;
            resolve();
          })
        })
      ]).then(res=> {
        let prArr = [];
        if(hotelExternalDataList.length > 0) {
          hotelExternalDataList.forEach(element => {
            prArr.push(
              new Promise((resolve, reject) => {
                QbdescriptionmappingSchema.find({[QbdescriptionmappingSchemaFields.HotelID]: hotelId, [QbdescriptionmappingSchemaFields.IsActive]: false, [QbdescriptionmappingSchemaFields.Description]: element.Description},
                  (err, result) => {
                    if(err) {
                        log.error(err)
                        reject(err)
                    }
                    if (result.length == 0) {
                      finalData.push(element);
                    }
                    resolve();
                });
              })
            )
          })
        } else {
          prArr = [];
        }
        Promise.all(prArr).then(res => {
          resolve(finalData);
        });
      })
    })
  }
  
  static getExternalDataFixedExpense(hotelId, startDate, endDate) {
    return new Promise((resolve, reject) => {
      startDate = new Date(startDate).toISOString();
      endDate = new Date(endDate).toISOString();

      let finalData = [];
      let hotelExternalDataList = [];
      Promise.all([
        new Promise((resolve, reject) => {
          HotelexternaldataSchema.find({[HotelexternaldataSchemaFields.HotelID]: hotelId, [HotelexternaldataSchemaFields.Category]: "FixedExpense", [HotelexternaldataSchemaFields.IsDelete]: false, [HotelexternaldataSchemaFields.Date]: { "$gte": startDate, "$lte": endDate}},
          (err, res) => {
            if(err) {
                log.error(err)
                reject(err)
            }
            hotelExternalDataList = res;
            resolve();
            })
          })
        ]).then(res=> {
          let prArr = [];
          if(hotelExternalDataList.length > 0) {
            hotelExternalDataList.forEach(element => {
              prArr.push(
                new Promise((resolve, reject) => {
                  QbdescriptionmappingSchema.find({[QbdescriptionmappingSchemaFields.HotelID]: hotelId, [QbdescriptionmappingSchemaFields.IsActive]: false, [QbdescriptionmappingSchemaFields.Description]: element.Description},
                    (err, result) => {
                      if(err) {
                          log.error(err)
                          reject(err)
                      }
                      if (result.length == 0) {
                        finalData.push(element);
                      }
                      resolve();
                  });
                })
              )
            })
          } else {
            prArr = [];
          }
          Promise.all(prArr).then(res => {
            resolve(finalData);
          });
        })
      })
    }

    static getExternalDataITDAExpense(hotelId, startDate, endDate) {
      return new Promise((resolve, reject) => {
        startDate = new Date(startDate).toISOString();
        endDate = new Date(endDate).toISOString();
    
        let finalData = [];
        let hotelExternalDataList = [];
        Promise.all([
          new Promise((resolve, reject) => {
            HotelexternaldataSchema.find({[HotelexternaldataSchemaFields.HotelID]: hotelId, [HotelexternaldataSchemaFields.Category]: "ITDAExpense", [HotelexternaldataSchemaFields.IsDelete]: false, [HotelexternaldataSchemaFields.Date]: { "$gte": startDate, "$lte": endDate}},
            (err, res) => {
              if(err) {
                  log.error(err);
                  reject(err);
              }
              hotelExternalDataList = res;
              resolve();
            })
          })
        ]).then(res=> {
          let prArr = [];
          if(hotelExternalDataList.length > 0) {
            hotelExternalDataList.forEach(element => {
              prArr.push(
                new Promise((resolve, reject) => {
                  QbdescriptionmappingSchema.find({[QbdescriptionmappingSchemaFields.HotelID]: hotelId, [QbdescriptionmappingSchemaFields.IsActive]: false, [QbdescriptionmappingSchemaFields.Description]: element.Description},
                    (err, result) => {
                      if(err) {
                          log.error(err)
                          reject(err)
                      }
                      if (result.length == 0) {
                        finalData.push(element);
                      }
                      resolve();
                  });
                })
              )
            })
          } else {
            prArr = [];
          }
          Promise.all(prArr).then(res => {
            resolve(finalData);
          });
        })
      })
    }

    static getTaxData(hotelId, startDate, endDate) {
      return new Promise((resolve, reject) => {
        startDate = new Date(startDate).toISOString();
        endDate = new Date(endDate).toISOString();
    
        let strTax = "Tax";
        let output = [];
    
        HotelrevenueSchema.find({[HotelrevenueSchemaFields.HotelID]: hotelId, [HotelrevenueSchemaFields.Category]: strTax, [HotelrevenueSchemaFields.Date]: { "$gte": startDate, "$lte": endDate } },
          (err, result) => {
            if(err) {
                log.error(err)
                cb(err, null);
            }
            if (result.length > 0) {
              output =
              _(result)
                .groupBy('Description')
                .map((objs, key) => ({
                    'Description': key,
                    'Amount':  _.sumBy(objs, 'Amount'),
                    'Date': _.last(objs, 'Date'),
                    'Category': _.last(objs, 'Category'),
                    'HotelID': _.last(objs, 'HotelID'),
                    }))
                .value();
            }
            resolve(output);
        })
      });
    }

    static getPurchaseItemData(hotelCode, startDate, endDate) {
      return new Promise((resolve, reject) => {
        startDate = new Date(startDate).toISOString();
        endDate = new Date(endDate).toISOString();
    
        resolve([]);
      })
    }

    static getHotelSourceTitle(hotelId) {
      return new Promise((resolve, reject) => {
        let hotels = [];
        Promise.all([
          new Promise((resolve, reject) => {
            HotelsourcetitlesSchema.find({[HotelsourcetitlesSchemaFields.HotelID]: hotelId },
            (err, result) => {
              if(err) {
                log.error(err);
                reject(err);
              }
              hotels = result;
              resolve();
            })
          })
        ]).then(resp => {
          let um = [];
          let prArr = [];
          hotels.forEach(element => {
            prArr.push(
              new Promise((resolve, reject) => {
                PnlYearHelper.modelConverter(element,  (err, res) => {
                  if(err) {
                    log.error(err);
                    reject(err);
                  }
                  um.push(res);
                  resolve();
                })
              })
            );
          });
    
          Promise.all(prArr).then(res=> {
            console.log()
            resolve(um);
          })
        })
      })
    }

    static modelConverter(user, cb) {
      let userModel = {};
  
      if (user == null)
      {
          userModel.HotelID = 0;
          userModel.HotelName = "";
          userModel.ID = 0;
          userModel.IsDelete = false;
  
          userModel.NumberofRoomsSoldSource1 = "Number of Rooms Sold 1";
          userModel.NumberofRoomsSoldSource2 = "Number of Rooms Sold 2";
          userModel.NumberofRoomsSoldSource3 = "Number of Rooms Sold 3";
          userModel.NumberofRoomsSoldSource4 = "Number of Rooms Sold 4";
          userModel.NumberofRoomsSoldSource5 = "Number of Rooms Sold 5";
          userModel.NumberofRoomsSoldSource6 = "Number of Rooms Sold 6";
          userModel.NumberofRoomsSoldSource7 = "Number of Rooms Sold 7";
          userModel.NumberofRoomsSoldSource8 = "Number of Rooms Sold 8";
          userModel.NumberofRoomsSoldSource9 = "Number of Rooms Sold 9";
          userModel.NumberofRoomsSoldSource10 = "Number of Rooms Sold 10";
          userModel.NumberofRoomsSoldSource11 = "Number of Rooms Sold 11";
          userModel.NumberofRoomsSoldSource12 = "Number of Rooms Sold 12";
          userModel.NumberofRoomsSoldSource13 = "Number of Rooms Sold 13";
          userModel.NumberofRoomsSoldSource14 = "Number of Rooms Sold 14";
          userModel.NumberofRoomsSoldSource15 = "Number of Rooms Sold 15";
          userModel.NumberofRoomsSoldSource16 = "Number of Rooms Sold 16";
          userModel.NumberofRoomsSoldSource17 = "Number of Rooms Sold 17";
          userModel.NumberofRoomsSoldSource18 = "Number of Rooms Sold 18";
          userModel.NumberofRoomsSoldSource19 = "Number of Rooms Sold 19";
          userModel.NumberofRoomsSoldSource20 = "Number of Rooms Sold 20";
  
          userModel.RoomRevenueSource1 = "Room Revenue 1";
          userModel.RoomRevenueSource2 = "Room Revenue 2";
          userModel.RoomRevenueSource3 = "Room Revenue 3";
          userModel.RoomRevenueSource4 = "Room Revenue 4";
          userModel.RoomRevenueSource5 = "Room Revenue 5";
          userModel.RoomRevenueSource6 = "Room Revenue 6";
          userModel.RoomRevenueSource7 = "Room Revenue 7";
          userModel.RoomRevenueSource8 = "Room Revenue 8";
          userModel.RoomRevenueSource9 = "Room Revenue 9";
          userModel.RoomRevenueSource10 = "Room Revenue 10";
          userModel.RoomRevenueSource11 = "Room Revenue 11";
          userModel.RoomRevenueSource12 = "Room Revenue 12";
          userModel.RoomRevenueSource13 = "Room Revenue 13";
          userModel.RoomRevenueSource14 = "Room Revenue 14";
          userModel.RoomRevenueSource15 = "Room Revenue 15";
          userModel.RoomRevenueSource16 = "Room Revenue 16";
          userModel.RoomRevenueSource17 = "Room Revenue 17";
          userModel.RoomRevenueSource18 = "Room Revenue 18";
          userModel.RoomRevenueSource19 = "Room Revenue 19";
          userModel.RoomRevenueSource20 = "Room Revenue 20";
  
          userModel.FoodBeverageRevenueSource1 = " Food & Beverage Revenue Source 1";
          userModel.FoodBeverageRevenueSource2 = " Food & Beverage Revenue Source 2";
          userModel.FoodBeverageRevenueSource3 = " Food & Beverage Revenue Source 3";
          userModel.FoodBeverageRevenueSource4 = " Food & Beverage Revenue Source 4";
          userModel.FoodBeverageRevenueSource5 = " Food & Beverage Revenue Source 5";
          userModel.FoodBeverageRevenueSource6 = " Food & Beverage Revenue Source 6";
          userModel.FoodBeverageRevenueSource7 = " Food & Beverage Revenue Source 7";
          userModel.FoodBeverageRevenueSource8 = " Food & Beverage Revenue Source 8";
          userModel.FoodBeverageRevenueSource9 = " Food & Beverage Revenue Source 9";
          userModel.FoodBeverageRevenueSource10 = " Food & Beverage Revenue Source 10";
          userModel.FoodBeverageRevenueSource11 = " Food & Beverage Revenue Source 11";
          userModel.FoodBeverageRevenueSource12 = " Food & Beverage Revenue Source 12";
          userModel.FoodBeverageRevenueSource13 = " Food & Beverage Revenue Source 13";
          userModel.FoodBeverageRevenueSource14 = " Food & Beverage Revenue Source 14";
          userModel.FoodBeverageRevenueSource15 = " Food & Beverage Revenue Source 15";
          userModel.FoodBeverageRevenueSource16 = " Food & Beverage Revenue Source 16";
          userModel.FoodBeverageRevenueSource17 = " Food & Beverage Revenue Source 17";
          userModel.FoodBeverageRevenueSource18 = " Food & Beverage Revenue Source 18";
          userModel.FoodBeverageRevenueSource19 = " Food & Beverage Revenue Source 19";
          userModel.FoodBeverageRevenueSource20 = " Food & Beverage Revenue Source 20";
  
          userModel.NumberofCoversSoldSource1 = " Number of Covers Sold 1";
          userModel.NumberofCoversSoldSource2 = " Number of Covers Sold 2";
          userModel.NumberofCoversSoldSource3 = " Number of Covers Sold 3";
          userModel.NumberofCoversSoldSource4 = " Number of Covers Sold 4";
          userModel.NumberofCoversSoldSource5 = " Number of Covers Sold 5";
          userModel.NumberofCoversSoldSource6 = " Number of Covers Sold 6";
          userModel.NumberofCoversSoldSource7 = " Number of Covers Sold 7";
          userModel.NumberofCoversSoldSource8 = " Number of Covers Sold 8";
          userModel.NumberofCoversSoldSource9 = " Number of Covers Sold 9";
          userModel.NumberofCoversSoldSource10 = " Number of Covers Sold 10";
          userModel.NumberofCoversSoldSource11 = " Number of Covers Sold 11";
          userModel.NumberofCoversSoldSource12 = " Number of Covers Sold 12";
          userModel.NumberofCoversSoldSource13 = " Number of Covers Sold 13";
          userModel.NumberofCoversSoldSource14 = " Number of Covers Sold 14";
          userModel.NumberofCoversSoldSource15 = " Number of Covers Sold 15";
          userModel.NumberofCoversSoldSource16 = " Number of Covers Sold 16";
          userModel.NumberofCoversSoldSource17 = " Number of Covers Sold 17";
          userModel.NumberofCoversSoldSource18 = " Number of Covers Sold 18";
          userModel.NumberofCoversSoldSource19 = " Number of Covers Sold 19";
          userModel.NumberofCoversSoldSource20 = " Number of Covers Sold 20";
  
          userModel.OtherIncomeSource1 = "Other Income 1";
          userModel.OtherIncomeSource2 = "Other Income 2";
          userModel.OtherIncomeSource3 = "Other Income 3";
          userModel.OtherIncomeSource4 = "Other Income 4";
          userModel.OtherIncomeSource5 = "Other Income 5";
          userModel.OtherIncomeSource6 = "Other Income 6";
          userModel.OtherIncomeSource7 = "Other Income 7";
          userModel.OtherIncomeSource8 = "Other Income 8";
          userModel.OtherIncomeSource9 = "Other Income 9";
          userModel.OtherIncomeSource10 = "Other Income 10";
          userModel.OtherIncomeSource11 = "Other Income 11";
          userModel.OtherIncomeSource12 = "Other Income 12";
          userModel.OtherIncomeSource13 = "Other Income 13";
          userModel.OtherIncomeSource14 = "Other Income 14";
          userModel.OtherIncomeSource15 = "Other Income 15";
          userModel.OtherIncomeSource16 = "Other Income 16";
          userModel.OtherIncomeSource17 = "Other Income 17";
          userModel.OtherIncomeSource18 = "Other Income 18";
          userModel.OtherIncomeSource19 = "Other Income 19";
          userModel.OtherIncomeSource20 = "Other Income 20";
  
          userModel.CashSource1 = "Cash Source 1";
          userModel.CashSource2 = "Cash Source 2";
          userModel.CashSource3 = "Cash Source 3";
          userModel.CashSource4 = "Cash Source 4";
          userModel.CashSource5 = "Cash Source 5";
          userModel.CashSource6 = "Cash Source 6";
          userModel.CashSource7 = "Cash Source 7";
          userModel.CashSource8 = "Cash Source 8";
          userModel.CashSource9 = "Cash Source 9";
          userModel.CashSource10 = "Cash Source 10";
          userModel.CashSource11 = "Cash Source 11";
          userModel.CashSource12 = "Cash Source 12";
          userModel.CashSource13 = "Cash Source 13";
          userModel.CashSource14 = "Cash Source 14";
          userModel.CashSource15 = "Cash Source 15";
          userModel.CashSource16 = "Cash Source 16";
  
          userModel.TaxSource1 = "Tax Source 1";
          userModel.TaxSource2 = "Tax Source 2";
          userModel.TaxSource3 = "Tax Source 3";
          userModel.TaxSource4 = "Tax Source 4";
          userModel.TaxSource5 = "Tax Source 5";
          userModel.TaxSource6 = "Tax Source 6";
          userModel.TaxSource7 = "Tax Source 7";
          userModel.TaxSource8 = "Tax Source 8";
          userModel.TaxSource9 = "Tax Source 9";
          userModel.TaxSource10 = "Tax Source 10";
          userModel.TaxSource11 = "Tax Source 11";
          userModel.TaxSource12 = "Tax Source 12";
          userModel.TaxSource13 = "Tax Source 13";
          userModel.TaxSource14 = "Tax Source 14";
          userModel.TaxSource15 = "Tax Source 15";
          userModel.TaxSource16 = "Tax Source 16";
  
          userModel.GuestLedgerSource1 = "General Ledger Source 1";
          userModel.GuestLedgerSource2 = "General Ledger Source 2";
          userModel.GuestLedgerSource3 = "General Ledger Source 3";
          userModel.GuestLedgerSource4 = "General Ledger Source 4";
          userModel.GuestLedgerSource5 = "General Ledger Source 5";
  
          userModel.Outlet1Other = "Outlet1Other";
          userModel.Outlet2Other = "Outlet2Other";
          userModel.Outlet3Other = "Outlet3Other";
          userModel.Outlet4Other = "Outlet4Other";
          userModel.Outlet1FNB = "Outlet1FNB";
          userModel.Outlet2FNB = "Outlet2FNB";
          userModel.Outlet3FNB = "Outlet3FNB";
          userModel.Outlet4FNB = "Outlet4FNB";
          userModel.Restaurant = "Restaurant";
          userModel.Bar = "Bar";
          userModel.Banquet = "Banquet";
          userModel.Bar = "Bar";
          userModel.Parking = "Parking";
          userModel.GiftShop = "GiftShop";
          userModel.Beverage = "Beverage";
          userModel.Food = "Food";
      } else {
          userModel.HotelID = parseInt(user.HotelID);
          userModel.HotelName = user.HotelName;
          userModel.ID = parseInt(user.ID);
          userModel.IsDelete = user.IsDelete;
  
          userModel.NumberofRoomsSoldSource1 = user.NumberofRoomsSoldSource1;
          userModel.NumberofRoomsSoldSource2 = user.NumberofRoomsSoldSource2;
          userModel.NumberofRoomsSoldSource3 = user.NumberofRoomsSoldSource3;
          userModel.NumberofRoomsSoldSource4 = user.NumberofRoomsSoldSource4;
          userModel.NumberofRoomsSoldSource5 = user.NumberofRoomsSoldSource5;
          userModel.NumberofRoomsSoldSource6 = user.NumberofRoomsSoldSource6;
          userModel.NumberofRoomsSoldSource7 = user.NumberofRoomsSoldSource7;
          userModel.NumberofRoomsSoldSource8 = user.NumberofRoomsSoldSource8;
          userModel.NumberofRoomsSoldSource9 = user.NumberofRoomsSoldSource9;
          userModel.NumberofRoomsSoldSource10 = user.NumberofRoomsSoldSource10;
          userModel.NumberofRoomsSoldSource11 = user.NumberofRoomsSoldSource11;
          userModel.NumberofRoomsSoldSource12 = user.NumberofRoomsSoldSource12;
          userModel.NumberofRoomsSoldSource13 = user.NumberofRoomsSoldSource13;
          userModel.NumberofRoomsSoldSource14 = user.NumberofRoomsSoldSource14;
          userModel.NumberofRoomsSoldSource15 = user.NumberofRoomsSoldSource15;
          userModel.NumberofRoomsSoldSource16 = user.NumberofRoomsSoldSource16;
          userModel.NumberofRoomsSoldSource17 = user.NumberofRoomsSoldSource17;
          userModel.NumberofRoomsSoldSource18 = user.NumberofRoomsSoldSource18;
          userModel.NumberofRoomsSoldSource19 = user.NumberofRoomsSoldSource19;
          userModel.NumberofRoomsSoldSource20 = user.NumberofRoomsSoldSource20;
  
          userModel.RoomRevenueSource1 = user.RoomRevenueSource1;
          userModel.RoomRevenueSource2 = user.RoomRevenueSource2;
          userModel.RoomRevenueSource3 = user.RoomRevenueSource3;
          userModel.RoomRevenueSource4 = user.RoomRevenueSource4;
          userModel.RoomRevenueSource5 = user.RoomRevenueSource5;
          userModel.RoomRevenueSource6 = user.RoomRevenueSource6;
          userModel.RoomRevenueSource7 = user.RoomRevenueSource7;
          userModel.RoomRevenueSource8 = user.RoomRevenueSource8;
          userModel.RoomRevenueSource9 = user.RoomRevenueSource9;
          userModel.RoomRevenueSource10 = user.RoomRevenueSource10;
          userModel.RoomRevenueSource11 = user.RoomRevenueSource11;
          userModel.RoomRevenueSource12 = user.RoomRevenueSource12;
          userModel.RoomRevenueSource13 = user.RoomRevenueSource13;
          userModel.RoomRevenueSource14 = user.RoomRevenueSource14;
          userModel.RoomRevenueSource15 = user.RoomRevenueSource15;
          userModel.RoomRevenueSource16 = user.RoomRevenueSource16;
          userModel.RoomRevenueSource17 = user.RoomRevenueSource17;
          userModel.RoomRevenueSource18 = user.RoomRevenueSource18;
          userModel.RoomRevenueSource19 = user.RoomRevenueSource19;
          userModel.RoomRevenueSource20 = user.RoomRevenueSource20;
  
          userModel.FoodBeverageRevenueSource1 = user.FoodBeverageRevenueSource1;
          userModel.FoodBeverageRevenueSource2 = user.FoodBeverageRevenueSource2;
          userModel.FoodBeverageRevenueSource3 = user.FoodBeverageRevenueSource3;
          userModel.FoodBeverageRevenueSource4 = user.FoodBeverageRevenueSource4;
          userModel.FoodBeverageRevenueSource5 = user.FoodBeverageRevenueSource5;
          userModel.FoodBeverageRevenueSource6 = user.FoodBeverageRevenueSource6;
          userModel.FoodBeverageRevenueSource7 = user.FoodBeverageRevenueSource7;
          userModel.FoodBeverageRevenueSource8 = user.FoodBeverageRevenueSource8;
          userModel.FoodBeverageRevenueSource9 = user.FoodBeverageRevenueSource9;
          userModel.FoodBeverageRevenueSource10 = user.FoodBeverageRevenueSource10;
          userModel.FoodBeverageRevenueSource11 = user.FoodBeverageRevenueSource11;
          userModel.FoodBeverageRevenueSource12 = user.FoodBeverageRevenueSource12;
          userModel.FoodBeverageRevenueSource13 = user.FoodBeverageRevenueSource13;
          userModel.FoodBeverageRevenueSource14 = user.FoodBeverageRevenueSource14;
          userModel.FoodBeverageRevenueSource15 = user.FoodBeverageRevenueSource15;
          userModel.FoodBeverageRevenueSource16 = user.FoodBeverageRevenueSource16;
          userModel.FoodBeverageRevenueSource17 = user.FoodBeverageRevenueSource17;
          userModel.FoodBeverageRevenueSource18 = user.FoodBeverageRevenueSource18;
          userModel.FoodBeverageRevenueSource19 = user.FoodBeverageRevenueSource19;
          userModel.FoodBeverageRevenueSource20 = user.FoodBeverageRevenueSource20;
  
          userModel.NumberofCoversSoldSource1 = user.NumberofCoversSoldSource1;
          userModel.NumberofCoversSoldSource2 = user.NumberofCoversSoldSource2;
          userModel.NumberofCoversSoldSource3 = user.NumberofCoversSoldSource3;
          userModel.NumberofCoversSoldSource4 = user.NumberofCoversSoldSource4;
          userModel.NumberofCoversSoldSource5 = user.NumberofCoversSoldSource5;
          userModel.NumberofCoversSoldSource6 = user.NumberofCoversSoldSource6;
          userModel.NumberofCoversSoldSource7 = user.NumberofCoversSoldSource7;
          userModel.NumberofCoversSoldSource8 = user.NumberofCoversSoldSource8;
          userModel.NumberofCoversSoldSource9 = user.NumberofCoversSoldSource9;
          userModel.NumberofCoversSoldSource10 = user.NumberofCoversSoldSource10;
          userModel.NumberofCoversSoldSource11 = user.NumberofCoversSoldSource11;
          userModel.NumberofCoversSoldSource12 = user.NumberofCoversSoldSource12;
          userModel.NumberofCoversSoldSource13 = user.NumberofCoversSoldSource13;
          userModel.NumberofCoversSoldSource14 = user.NumberofCoversSoldSource14;
          userModel.NumberofCoversSoldSource15 = user.NumberofCoversSoldSource15;
          userModel.NumberofCoversSoldSource16 = user.NumberofCoversSoldSource16;
          userModel.NumberofCoversSoldSource17 = user.NumberofCoversSoldSource17;
          userModel.NumberofCoversSoldSource18 = user.NumberofCoversSoldSource18;
          userModel.NumberofCoversSoldSource19 = user.NumberofCoversSoldSource19;
          userModel.NumberofCoversSoldSource20 = user.NumberofCoversSoldSource20;
  
          userModel.OtherIncomeSource1 = user.OtherIncomeSource1;
          userModel.OtherIncomeSource2 = user.OtherIncomeSource2;
          userModel.OtherIncomeSource3 = user.OtherIncomeSource3;
          userModel.OtherIncomeSource4 = user.OtherIncomeSource4;
          userModel.OtherIncomeSource5 = user.OtherIncomeSource5;
          userModel.OtherIncomeSource6 = user.OtherIncomeSource6;
          userModel.OtherIncomeSource7 = user.OtherIncomeSource7;
          userModel.OtherIncomeSource8 = user.OtherIncomeSource8;
          userModel.OtherIncomeSource9 = user.OtherIncomeSource9;
          userModel.OtherIncomeSource10 = user.OtherIncomeSource10;
          userModel.OtherIncomeSource11 = user.OtherIncomeSource11;
          userModel.OtherIncomeSource12 = user.OtherIncomeSource12;
          userModel.OtherIncomeSource13 = user.OtherIncomeSource13;
          userModel.OtherIncomeSource14 = user.OtherIncomeSource14;
          userModel.OtherIncomeSource15 = user.OtherIncomeSource15;
          userModel.OtherIncomeSource16 = user.OtherIncomeSource16;
          userModel.OtherIncomeSource17 = user.OtherIncomeSource17;
          userModel.OtherIncomeSource18 = user.OtherIncomeSource18;
          userModel.OtherIncomeSource19 = user.OtherIncomeSource19;
          userModel.OtherIncomeSource20 = user.OtherIncomeSource20;
          userModel.UpdatedBy = user.UpdatedBy;
          userModel.UpdatedDateTime = new Date(user.UpdatedDateTime);
  
          userModel.CashSource1 = user.CashSource1;
          userModel.CashSource2 = user.CashSource2;
          userModel.CashSource3 = user.CashSource3;
          userModel.CashSource4 = user.CashSource4;
          userModel.CashSource5 = user.CashSource5;
          userModel.CashSource6 = user.CashSource6;
          userModel.CashSource7 = user.CashSource7;
          userModel.CashSource8 = user.CashSource8;
          userModel.CashSource9 = user.CashSource9;
          userModel.CashSource10 = user.CashSource10;
          userModel.CashSource11 = user.CashSource11;
          userModel.CashSource12 = user.CashSource12;
          userModel.CashSource13 = user.CashSource13;
          userModel.CashSource14 = user.CashSource14;
          userModel.CashSource15 = user.CashSource15;
          userModel.CashSource16 = user.CashSource16;
  
          userModel.TaxSource1 = user.TaxSource1;
          userModel.TaxSource2 = user.TaxSource2;
          userModel.TaxSource3 = user.TaxSource3;
          userModel.TaxSource4 = user.TaxSource4;
          userModel.TaxSource5 = user.TaxSource5;
          userModel.TaxSource6 = user.TaxSource6;
          userModel.TaxSource7 = user.TaxSource7;
          userModel.TaxSource8 = user.TaxSource8;
          userModel.TaxSource9 = user.TaxSource9;
          userModel.TaxSource10 = user.TaxSource10;
          userModel.TaxSource11 = user.TaxSource11;
          userModel.TaxSource12 = user.TaxSource12;
          userModel.TaxSource13 = user.TaxSource13;
          userModel.TaxSource14 = user.TaxSource14;
          userModel.TaxSource15 = user.TaxSource15;
          userModel.TaxSource16 = user.TaxSource16;
  
          userModel.GuestLedgerSource1 = user.GuestLedgerSource1;
          userModel.GuestLedgerSource2 = user.GuestLedgerSource2;
          userModel.GuestLedgerSource3 = user.GuestLedgerSource3;
          userModel.GuestLedgerSource4 = user.GuestLedgerSource4;
          userModel.GuestLedgerSource5 = user.GuestLedgerSource5;
  
          userModel.Outlet1Other = user.Outlet1Other;
          userModel.Outlet2Other = user.Outlet2Other;
          userModel.Outlet3Other = user.Outlet3Other;
          userModel.Outlet4Other = user.Outlet4Other;
          userModel.Outlet1FNB = user.Outlet1FNB;
          userModel.Outlet2FNB = user.Outlet2FNB;
          userModel.Outlet3FNB = user.Outlet3FNB;
          userModel.Outlet4FNB = user.Outlet4FNB;
          userModel.Restaurant = user.Restaurant;
          userModel.Bar = user.Bar;
          userModel.Banquet = user.Banquet;
          userModel.Bar = user.Bar;
          userModel.Parking = user.Parking;
          userModel.GiftShop = user.GiftShop;
          userModel.Beverage = user.Beverage;
          userModel.Food = user.Food;
      }
      return cb(null, userModel);
    }

    static async getPLStatementMonthWiseRevenueData(hotelId, currentDate, period) {
      return new Promise((resolve, reject) => {
        let startdate = new Date(moment(currentDate).startOf('month').format("YYYY-MM-DD")).toISOString();
        currentDate = new Date(moment(currentDate).format("YYYY-MM-DD")).toISOString();
        let resultset = [];
        Promise.all([
          new Promise(async (resolve, reject) => {
            await HoteldashboardcalculationsSchema.find({ [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId, [HoteldashboardcalculationsSchemaFields.Date]: { "$gte": startdate, "$lte": currentDate } },
              (err, result) => {
                if (err) {
                  log.error(err);
                  reject(err);
                }
                result = _.find(_.sortBy(result, [function(o) { return o.Date; }]).reverse(), function(p) { return true; });
                resultset.push(result);
                resolve();
            })
          })
        ]).then(resp => {
          let tempObj = {};
          if(resultset[0] != undefined) {
            // console.log(resultset, 'resultset[0]');
            // if(resultset[0].HotelID == undefined) {
            //   console.log(rtytuyrturtyryry)
            // }
            tempObj = {
              HotelID: resultset[0].HotelID,
              CurrentDT: resultset[0].Date,
              RoomRevenue: (() => {
                if(period == 'MTD'){
                    return resultset[0].TotalRevenueMTD;
                  } else if(period == 'YTD') {
                    return resultset[0].TotalRevenueYTD;
                  } else if(period == 'Current') {
                    return resultset[0].TotalRevenue;
                  } else if (period == 'TTM') {
                    return resultset[0].TotalRevenueTTM;
                  }
              })(),
                              
              FANDBRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].FANDBRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].FANDBRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].FANDBRevenue;
                } else if (period == 'TTM') {
                  return resultset[0].FANDBRevenueTTM;
                }
              })(),
    
              OtherRevenue: (() => {
                if(period == 'MTD'){
                    return resultset[0].OtherRevenueMTD;
                  } else if(period == 'YTD') {
                    return resultset[0].OtherRevenueYTD;
                  } else if(period == 'Current') {
                    return resultset[0].OtherRevenue;
                  } else if (period == 'TTM') {
                    return resultset[0].OtherRevenueTTM;
                  }
                })(),
    
              NoOfRoomSold: (() => {
                if(period == 'MTD'){
                  return resultset[0].NoOfRoomSoldMTD;
                } else if(period == 'YTD') {
                  return resultset[0].NoOfRoomSoldYTD;
                } else if(period == 'Current') {
                  return resultset[0].NoOfRoomSold;
                } else if (period == 'TTM') {
                  return resultset[0].NoOfRoomSoldTTM;
                }
              })(),
    
    
              Outet1OtherRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].Outet1OtherRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].Outet1OtherRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].Outet1OtherRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              Outet2OtherRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].Outet2OtherRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].Outet2OtherRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].Outet2OtherRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              Outet3OtherRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].Outet3OtherRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].Outet3OtherRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].Outet3OtherRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              Outet4OtherRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].Outet4OtherRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].Outet4OtherRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].Outet4OtherRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              Outet1FANDBRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].Outet1FANDBRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].Outet1FANDBRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].Outet1FANDBRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              Outet2FANDBRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].Outet2FANDBRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].Outet2FANDBRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].Outet2FANDBRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              Outet3FANDBRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].Outet3FANDBRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].Outet3FANDBRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].Outet3FANDBRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              Outet4FANDBRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].Outet4FANDBRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].Outet4FANDBRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].Outet4FANDBRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              RestaurantRevenue: (() => {
                // console.log(period, 'period');
                if(period == 'MTD'){
                  return resultset[0].RestaurantRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].RestaurantRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].RestaurantRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),

              BarRevenue: (() => {
                // console.log(period, 'period');
                if(period == 'MTD'){
                  return resultset[0].BarRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].BarRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].BarRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              BanquetRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].BanquetRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].BanquetRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].BanquetRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              ParkingRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].ParkingRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].ParkingRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].ParkingRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              GiftShopRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].GiftShopRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].GiftShopRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].GiftShopRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              BeverageRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].BeverageRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].BeverageRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].BeverageRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              FoodRevenue: (() => {
                if(period == 'MTD'){
                  return resultset[0].FoodRevenueMTD;
                } else if(period == 'YTD') {
                  return resultset[0].FoodRevenueYTD;
                } else if(period == 'Current') {
                  return resultset[0].FoodRevenue;
                } else if (period == 'TTM') {
                  return 0;
                }
              })(),
    
              TotalRevenue: (() => {
                if(period == 'MTD'){
                  return (resultset[0].TotalRevenueMTD + resultset[0].FANDBRevenueMTD + resultset[0].OtherRevenueMTD + resultset[0].Outet1OtherRevenueMTD + resultset[0].Outet2OtherRevenueMTD +  resultset[0].Outet3OtherRevenueMTD +  resultset[0].Outet4OtherRevenueMTD + resultset[0].Outet1FANDBRevenueMTD +  resultset[0].Outet2FANDBRevenueMTD +resultset[0].Outet3FANDBRevenueMTD + resultset[0].Outet4FANDBRevenueMTD + resultset[0].RestaurantRevenueMTD + resultset[0].BarRevenueMTD + resultset[0].BanquetRevenueMTD + resultset[0].ParkingRevenueMTD + resultset[0].GiftShopRevenueMTD + resultset[0].BeverageRevenueMTD + resultset[0].FoodRevenueMTD);
                } else if(period == 'YTD') {
                  return (resultset[0].TotalRevenueYTD + resultset[0].FANDBRevenueYTD + resultset[0].OtherRevenueYTD + resultset[0].Outet1OtherRevenueYTD + resultset[0].Outet2OtherRevenueYTD +  resultset[0].Outet3OtherRevenueYTD +  resultset[0].Outet4OtherRevenueYTD + resultset[0].Outet1FANDBRevenueYTD +  resultset[0].Outet2FANDBRevenueYTD +resultset[0].Outet3FANDBRevenueYTD + resultset[0].Outet4FANDBRevenueYTD + resultset[0].RestaurantRevenueYTD + resultset[0].BarRevenueYTD + resultset[0].BanquetRevenueYTD + resultset[0].ParkingRevenueYTD + resultset[0].GiftShopRevenueYTD + resultset[0].BeverageRevenueYTD + resultset[0].FoodRevenueYTD);
                } else if(period == 'Current') {
                  return (resultset[0].TotalRevenue + resultset[0].FANDBRevenue + resultset[0].OtherRevenue + resultset[0].Outet1OtherRevenue + resultset[0].Outet2OtherRevenue +  resultset[0].Outet3OtherRevenue +  resultset[0].Outet4OtherRevenueYTD + resultset[0].Outet1FANDBRevenueYTD +  resultset[0].Outet2FANDBRevenueYTD +resultset[0].Outet3FANDBRevenueYTD + resultset[0].Outet4FANDBRevenueYTD + resultset[0].RestaurantRevenue + resultset[0].BarRevenue + resultset[0].BanquetRevenue + resultset[0].ParkingRevenue + resultset[0].GiftShopRevenue + resultset[0].BeverageRevenue + resultset[0].FoodRevenue);
                } else if (period == 'TTM') {
                  return (resultset[0].TotalRevenueTTM + resultset[0].FANDBRevenueTTM + resultset[0].OtherRevenueTTM);
                }
              })()
    
            }
          }
          resolve([tempObj]);
        })
      })
    }

    static filterInactiveDesc(eflist, type) {
      return new Promise((resolve, reject) => {
        let pArr = [];
        let resArr = [];
          eflist.forEach(element => {
            pArr.push(
              new Promise((resolve, reject) => {
                QbdescriptionmappingSchema.find({$not: {[QbdescriptionmappingSchemaFields.IsActive]: false, [QbdescriptionmappingSchemaFields.Description]: element.Description, [QbdescriptionmappingSchemaFields.Category]: type}},
                  (err, result) => {
                    if(err) {
                        log.error(err)
                        reject(err)
                    }
                  resArr.push(result);
                  resolve();
                })
              })
            )
          });

          Promise.all(pArr).then(resp =>{
            resolve(resArr);
          })
      });
    }

    static getGLCodePL(DisplayDescription, hotelid) {
      return new Promise((resolve, reject) => {
        let GLCodeData = "000.00";
        let hotelglid = parseInt(hotelid);
        let Data = null;
        
        GlcodehotelrevenueSchema.findOne({[GlcodehotelrevenueSchemaFields.DisplayDescription]: DisplayDescription, [GlcodehotelrevenueSchemaFields.HotelID]: hotelglid, [GlcodehotelrevenueSchemaFields.Category]: {$ne: "ExpenseForm"}},
          (err, result) => {
            if(err) {
                log.error(err)
                reject(err)
            }
            if(result != null) {
              Data = result.GLCode;
            }
            
            if (Data != null) {
              GLCodeData = Data;
            } else {
        
              GlcodemasterSchema.findOne({[GlcodemasterSchemaFields.GLDescripton]: DisplayDescription, [GlcodemasterSchemaFields.HotelID]: hotelglid},
                (err, result) => {
                  if(err) {
                      log.error(err)
                      reject(err)
                  }
                  if(result != null) {
                    Data = result.GLCode;
                  }
              });
        
              if (Data != null)
              {
                  GLCodeData = Data;
              }
            }
            resolve(GLCodeData);
        });
      })
    }

    static getGLCodePLV2(glcode, hotelid) {
      return new Promise((resolve, reject) => {
        let DisplayDescription = glcode;
        let hotelglid = parseInt(hotelid);
        let Data = null;
        
        GlcodehotelrevenueSchema.findOne({[GlcodehotelrevenueSchemaFields.GLCode]: glcode, [GlcodehotelrevenueSchemaFields.HotelID]: hotelglid },
          (err, result) => {
            if(err) {
                log.error(err)
                reject(err)
            }
            if(result != null) {
              Data = result.GLCode;
            }
            
            if (Data != null)
            {
              DisplayDescription = Data.DisplayDescription;
            } else {
        
              GlcodemasterSchema.findOne({[GlcodemasterSchemaFields.GLCode]: glcode, [GlcodemasterSchemaFields.HotelID]: hotelglid},
                (err, result) => {
                  if(err) {
                      log.error(err)
                      reject(err)
                  }
                  if(result != null) {
                    Data = result.GLCode;
                  }
              });
        
              if (Data != null)
              {
                DisplayDescription = Data.DisplayDescription;
              }
            }
            resolve(DisplayDescription);
          });
      })
    }

    static getLabourExpenseData(hotelId, startDate, endDate) {
      return new Promise((resolve, reject) => {
        let hotelEffectivenessMappingModelList = [];
        startDate = new Date(moment(startDate).format("YYYY-MM-DD")).toISOString();
        endDate = new Date(moment(endDate).format("YYYY-MM-DD")).toISOString();
        HoteleffectivenesscalculationsSchema.find({ $or: [{ [HoteleffectivenesscalculationsSchemaFields.ReportName]: "Adams_Keegan_Payroll_Report" }, { [HoteleffectivenesscalculationsSchemaFields.ReportName]: "Labor Allocation Report" }, { [HoteleffectivenesscalculationsSchemaFields.ReportName]: "Manual Entry" } ], [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId, [HoteleffectivenesscalculationsSchemaFields.Date]: { "$gte": startDate, "$lte": endDate }},
        (err, res) => {
          if(err) {
              log.error(err)
              reject(err)
          }
          let results = res;
          let groupdataList = _(results)
            .groupBy('Department')
            .map((objs, key) => ({
                'Department': key,
                'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
                'HotelID': _.get(_.find(objs, function(o) { return true; }), 'HotelID'),
                'Date': _.get(_.find(objs, function(o) { return true; }), 'Date'),
                'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
                'ID': _.get(_.find(objs, function(o) { return true; }), 'ID'),
                'UpdatedBy': _.get(_.find(objs, function(o) { return true; }), 'UpdatedBy'),
                'UpdatedDateTime': _.get(_.find(objs, function(o) { return true; }), 'UpdatedDateTime'),
                'FromDate': _.get(_.find(objs, function(o) { return true; }), 'FromDate'),
                'ToDate': _.get(_.find(objs, function(o) { return true; }), 'ToDate'),
                'Wages': _.sumBy(objs, 'Wages'),
                'Hours': _.sumBy(objs, 'Hours')}))
            .value();

            groupdataList.forEach(element => {
              PnlYearHelper.hotelEffectivemodelConverter(element , (err, res) =>{
                if(err) {
                  log.error(err)
                  reject(err);
                }
                hotelEffectivenessMappingModelList.push(res);
              })
            });
          resolve(hotelEffectivenessMappingModelList);
        })
      })
    }

    static hotelEffectivemodelConverter(data, cb) {
      let newLog = {};

      newLog.HotelID = data.HotelID;
      newLog.ID = data.ID;
      newLog.Date = data.Date;
      newLog.Department = data.Department;
      newLog.Hours = data.Hours;
      newLog.UpdatedBy = data.UpdatedBy;
      newLog.UpdatedDateTime = data.UpdatedDateTime;
      newLog.Wages = data.Wages;
      newLog.Category = data.Category;
      newLog.FromDate = data.FromDate;
      newLog.ToDate = data.ToDate;

      return cb(null, newLog);
    }

    static filterInactiveDescLB(eflist, type) {
      return new Promise((resolve, reject) => {
        let departments = [];
        eflist.forEach(element => {
          if(element.Department) {
            departments.push(element.Department);
          }
        });

        QbdescriptionmappingSchema.find({[QbdescriptionmappingSchemaFields.Description]: { $in: departments}, [QbdescriptionmappingSchemaFields.IsActive]: false, [QbdescriptionmappingSchemaFields.Category]: type},
        (err, result) => {
          if(err) {
              log.error(err)
              reject(err)
          }
          resolve(result);
        })
      })
    }


    static getGLCode(DisplayDescription, hotelid) {
      // console.log('---------------------> start')
      return new Promise((resolve, reject) => {
        let GLCodeData = "000.00";
        hotelid = parseInt(hotelid);
        GlcodehotelrevenueSchema.findOne({[GlcodehotelrevenueSchemaFields.DisplayDescription]: DisplayDescription, [GlcodehotelrevenueSchemaFields.HotelID]: hotelid },
        (err, result) => {
          if(err) {
              log.error(err)
              reject(err)
          }
          if(result != null) {
            GLCodeData = result.GLCode;
          } 
          // console.log('---------------------> end')
          resolve(GLCodeData);
        })
      })
    }

    static isActiveOrganisation(orgId) {
      return new Promise((resolve, reject) => { 
        let organisationCredentials = [];
        let userModels = [];
        let user = [];

        OrganisationcredentialsSchema.find(
          (err, result) => {
            if(err) {
                log.error(err)
                reject(err)
            }
            organisationCredentials = result;
            if (organisationCredentials.length == 0 || organisationCredentials == null) {
              resolve(false);
            }
            organisationCredentials.forEach(item => {
              UserSchema.findOne({[UserSchemaFields.ID]: item.OrganizationID},
                (err, res) => {
                  if(err) {
                      log.error(err)
                      reject(err)
                  }
                user = res;
                let model = [];
                model.IsActive = !item.IsDelete;
                model.OranizationId = item.OrganisationID;
                model.UserName = item.Username;
                model.ID = item.ID;
                if (user != null )
                {
                    model.OranizationName = user.CompanyName;
                }
                userModels.push(model);
              })             
            });

            if (userModels != null && userModels.length > 0)
            {
                userModels = userModels.Where(x => x.OranizationId == orgId).ToList();
            }
            if (userModels != null && userModels.Count > 0)
            {
                resolve(true);
            }
            resolve(false);
          })
      });
    }

    static getHotelbyId(hid) {
      return new Promise((resolve, reject) => { 
        let hotel = [];
        let um = [];

        HotelsSchema.findOne({[HotelsSchemaFields.ID]: hid, [HotelsSchemaFields.IsActive]: true},
        (err, res) => {
          if(err) {
              log.error(err)
              reject(err)
          }
          hotel = res;
          if (hotel == null)
          {
            resolve(null);
          }
          um = convertHotelModel(hotel);
          resolve(um);
        })
      })
    }

    static getYearPnlData_GraphQL(hotelid, year, cb) {
      //get myp hotelid from cmp_id
      return HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
        if (err) {
          cb(err, null);
        }
        if (!hoteldata) {
          cb(Constants.HotelNotFound, null);
        }
        else {
          PnlYearHelper.getYearPnlData(hoteldata.ID, year, cb, (err, result) => {
            if (err) {
              cb(err, null);
            }
            cb(null, result);
          });
        }
      });
    }

    static editOrSavepnlRawOrder(userId, hotelId, view, data, cb) {
      if(data != null) {
        PnlcustomizeRawSchema.findOne({[PnlcustomizeRawSchemaField.Hotel_ID]: hotelId, [PnlcustomizeRawSchemaField.Pnl_view]: view},
        (err, res) => {
          if(err) {
            log.error(err)
            reject(err)
          }
          if(res == null) {
            let customizedData = {
                [PnlcustomizeRawSchemaField.User_ID]: userId,
                [PnlcustomizeRawSchemaField.Hotel_ID]: hotelId,
                [PnlcustomizeRawSchemaField.Pnl_view]: view,
                [PnlcustomizeRawSchemaField.Created_at]: new Date(),
                [PnlcustomizeRawSchemaField.Groups]: data,
              };

            let Pnlcustomize = new PnlcustomizeRawSchema(customizedData);
            Pnlcustomize.save((err, result) => {
              if (err)
                  return cb(err, null);
              else {
                  return cb(null, result);
              }
            });
          } else {

            PnlcustomizeRawSchema.findOneAndUpdate(
              {
                  [PnlcustomizeRawSchemaField.Hotel_ID]: hotelId,
                  [PnlcustomizeRawSchemaField.Pnl_view]: view,
              },
              {
                  [PnlcustomizeRawSchemaField.User_ID]: userId,
                  [PnlcustomizeRawSchemaField.Created_at]: new Date(),
                  [PnlcustomizeRawSchemaField.Groups]: data
              },
              {
                  new: true
              }
          ).exec((err, result) => {
              if(err) {
                return cb(err);
              }
              return cb(null, result);
          })
          }
        })
      } else {
        return cb('Data Required !');
      }
    }

    static editOrSavepnlRawOrder2(userId, hotelId, view, data, cb, next) {
      if(data != null) {
        PnlcustomizeRawSchema.findOne({[PnlcustomizeRawSchemaField.Hotel_ID]: hotelId, [PnlcustomizeRawSchemaField.Pnl_view]: view},
        (err, res) => {
          if(err) {
            log.error(err)
            reject(err)
          }
          if(res == null) {
            let customizedData = {
                [PnlcustomizeRawSchemaField.User_ID]: userId,
                [PnlcustomizeRawSchemaField.Hotel_ID]: hotelId,
                [PnlcustomizeRawSchemaField.Pnl_view]: view,
                [PnlcustomizeRawSchemaField.Created_at]: new Date(),
                [PnlcustomizeRawSchemaField.Groups]: data,
              };

            let Pnlcustomize = new PnlcustomizeRawSchema(customizedData);
            Pnlcustomize.save((err, result) => {
              if (err)
                  return cb(err, null);
              else {
                  next();
              }
            });
          } else {

            PnlcustomizeRawSchema.findOneAndUpdate(
              {
                  [PnlcustomizeRawSchemaField.Hotel_ID]: hotelId,
                  [PnlcustomizeRawSchemaField.Pnl_view]: view,
              },
              {
                  [PnlcustomizeRawSchemaField.User_ID]: userId,
                  [PnlcustomizeRawSchemaField.Created_at]: new Date(),
                  [PnlcustomizeRawSchemaField.Groups]: data
              },
              {
                  new: true
              }
          ).exec((err, result) => {
              if(err) {
                return cb(err);
              }
              next();
          })
          }
        })
      } else {
        return cb('Data Required !');
      }
    }


    static updateOrSaveRawData_GraphQL(userId, hotelid, view, data, cb) {
      //get myp hotelid from cmp_id
      return HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
        if (err) {
          cb(err, null);
        }
        if (!hoteldata) {
          cb(Constants.HotelNotFound, null);
        }
        else {
          PnlYearHelper.editOrSavepnlRawOrder(userId, hoteldata.ID, view, data, cb, (err, result) => {
            if (err) {
              cb(err, null);
            }
            cb(null, result);
          });
        }
      });
    }

}

module.exports = PnlYearHelper;


function convertHotelModel(hotel) {
  let hotelModel =
  {
      ID: hotel.ID,
      OrganizationId: hotel.OrganizationID,
      HotelName: hotel.HotelName,
      IsActive: hotel.IsActive,
      UpdatedBy: hotel.UpdatedBy,
      UpdatedDateTime: hotel.UpdateDateTime,
      NumberofAvailableRooms: parseInt(hotel.NumberofAvailableRooms),
      HotelCode: hotel.HotelCode,
      AddressLine1: hotel.AddressLine1,
      AddressLine2: hotel.AddressLine2,
      City: hotel.City,
      Country: hotel.CountryISO2,
      PMS: hotel.PMS,
      PMSPropertyID: hotel.PMSPropertyID,
      STRID: hotel.STRID,
      PMSPropertyName: hotel.PMSPropertyName,
      AccountingTool: hotel.AccountingTool,
      State: hotel.StateISO2,
      Zip: hotel.Zip,
      Attention: hotel.Attention,
      Property: hotel.Property,
      PropertyCode: hotel.PropertyCode,
      TimeZone: hotel.TimeZone,
      DisplayFor: hotel.DisplayFor,
      IsValidMYP: hotel.IsValidMYP == 1 ? true : false,
      IsMissingDateOtherRevenueEnabled: hotel.IsMissingDateOtherRevenueEnabled,
      IsQuickBooksOnlineEnabled: hotel.AccountingTool == true,
      IsQuickBooksOnlineConnected: true,
      IsMicrosoftDynamicsConnected: hotel.IsMicrosoftDynamicsConnected == 1 ? true : false,
      Cmp_Id: parseInt(hotel.Cmp_Id),
      JoinedDate: hotel.JoinedDate,
      DefaultCurrency: hotel.DefaultCurrency
  };
  return hotelModel;

}



function getCategoryDataTitle(hst, description) {
  if (description == "Outlet 1 - Other")
  {
      return hst.Outlet1Other;
  }
  else if (description == "Outlet 2 - Other")
  {
      return hst.Outlet2Other;
  }
  else if (description == "Outlet 3 - Other")
  {
      return hst.Outlet3Other;
  }
  else if (description == "Outlet 4 - Other")
  {
      return hst.Outlet4Other;
  }
  else if (description == "Outlet 1 - F&B")
  {
      return hst.Outlet1FNB;
  }
  else if (description == "Outlet 2 - F&B")
  {
      return hst.Outlet2FNB;
  }
  else if (description == "Outlet 3 - F&B")
  {
      return hst.Outlet3FNB;
  }
  else if (description == "Outlet 4 - F&B")
  {
      return hst.Outlet4FNB;
  }
  else if (description == "CashSource9")
  {
      return hst.CashSource9;
  }
  else if (description == "Restaurant")
  {
      return hst.Restaurant;
  }
  else if (description == "Bar")
  {
      return hst.Bar;
  }
  else if (description == "Banquet")
  {
      return hst.Banquet;
  }
  else if (description == "Parking")
  {
      return hst.Parking;
  }
  else if (description == "Gift Shop")
  {
      return hst.GiftShop;
  }
  else if (description == "Beverage")
  {
      return hst.Beverage;
  }
  else if (description == "Food")
  {
      return hst.Food;
  }

  return description;
}


function groupByGLCode(items) {

  let grouopedItems = _(items)
    .groupBy('AccountNumber')
    .map((objs, key) => ({
        'AccountNumber': key,
        'UnitPrice': _.sumBy(objs, 'UnitPrice') }))
    .value();

  return grouopedItems;
}

function groupByDescription(items) {

  let grouopedItems = _(items)
    .groupBy('Description')
    .map((objs, key) => ({
        'Description': key,
        'Amount': _.sumBy(objs, 'Amount') }))
    .value();

  return grouopedItems;
}