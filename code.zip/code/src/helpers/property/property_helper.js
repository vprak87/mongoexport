const OccupancyADRvsRevPARData = require('../../property/models/occupancyadrrevpardata');
const ActualVsBudgetVsLastYrData = require('../../property/models/actualvsbudgetvslastyrdata');
const RollingRevenueData = require('../../property/models/rollingrevenuedata');
const ADRVSRevPARData = require('../../property/models/adrvsrevpardata');
const HoteldashboardcalculationsHelper = require('../hoteldashboardcalculations_helper');
const HotelrevenueHelper = require('../hotelrevenue_helper');
const HotelbudgetdashboardcalculationsHelper = require('../hotelbudgetdashboardcalculations_helper');
const DashboardSettingsHelper = require('../dashboardsettings_helper');
const RevenueBreakdownData = require('../../property/models/revenuebreakdowndata');
const MembershipStaysData = require('../../property/models/membershipstaysdata');
const Propertyconfigdata = require('../../property/models/propertyconfigdata');
const RoomSalesVsLastYrData = require('../../property/models/roomsalesvslastyrdata');
const HotelRoomStatusData = require('../../property/models/hotelroomstatusdata');
const HotelGuestLedgerData = require('../../property/models/hotelguestledger');
const HotelroomstatusdashboardcalculationsHelper = require('../hotelroomstatusdashboardcalculations_helper');
const CreatePropertyDashboardTableMappingHelper = require('../createpropertydashboardtablemapping_helper');
const CreateowntablemappingsHelper = require('../createowntablemappings_helper');
const PropertyTableColumData = require('../../property/models/propertytablecolumdata');
const PropertyTableRowData = require('../../property/models/propertytablerowdata');
const WeatherData = require('../../property/models/weatherdata');
const CashDetailHelper = require('../property/cashdetail_helper');
const GSSPriorityData =  require('../../property/models/gssprioritydata');
const MissingDatesContentModel = require('../../exclamation/models/missingdatescontent');
const { Hotelweatherdata: HotelWeatherDataSchema, SchemaField: HotelWeatherDataSchemaFields } = require('../../models/hotelweatherdata');
const { Glcodehotelrevenue: GlcodehotelrevenueSchema, SchemaField: GlcodehotelrevenueSchemaFields } = require('../../models/glcodehotelrevenue');
const { HotelGuestLedger: HotelGuestLedgerSchema, SchemaField: HotelGuestLedgerSchemaFields } = require('../../models/hotelguestledger');
const { Tripadvisorhotelmapping: TripadvisorhotelmappingSchema, SchemaField: TripadvisorhotelmappingSchemaFields } = require('../../models/tripadvisorhotelmapping');
const { Googleplacehotelmapping: GoogleplacehotelmappingSchema, SchemaField: GoogleplacehotelmappingSchemaFields } = require('../../models/googleplacehotelmapping');
const { Fbpagehotelmapping: FbpagehotelmappingSchema, SchemaField: FbpagehotelmappingSchemaFields } = require('../../models/fbpagehotelmapping');
const { Yelphotelmappings: YelphotelmappingsSchema, SchemaField: YelphotelmappingsSchemaFields } = require('../../models/yelphotelmappings');
const { Hotelrevenue: HotelrevenueSchema, SchemaField: HotelrevenueSchemaFields } = require('../../models/hotelrevenue');
const { Otainsightapidataorganisation: OtainsightapidataorganisationSchema, SchemaField: OtainsightapidataorganisationSchemaFields } = require('../../models/otainsightapidataorganisation');
const { Otainsighthotelmapping: OtainsighthotelmappingSchema, SchemaField: OtainsighthotelmappingSchemaFields } = require('../../models/otainsighthotelmapping');
const { Hotelaraging: HotelaragingSchema, SchemaField: HotelaragingSchemaFields } = require('../../models/hotelaraging');
const Constants = require('../../common/constants');
const HotelgssHelper = require('./../hotelgss_helper');
const Utils = require('../../common/utils');
const moment = require('moment');
const _ = require('lodash');
const UserHelper = require('../user_helper');
const HotelsHelper = require('../hotels_helper');
const RESTHelper = require('../rest_helper');
const MissingDatesHelper = require('../missingdates_helper');
const config = require('../../../appsettings.js');

var log = require('log4js').getLogger("PropertyHelper");

class PropertyHelper {

    //#region  Dashboard Occupancy ADR & RevPAR Chart
    static getDashboardOccupancyADRvsRevPARChart(userId, hotelid, currentDate, period, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);
        let lastYear = Utils.sameDayLastYear(yeasterday);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);

        if (period.toLowerCase() == "mtd" || period.toLowerCase() == "ytd") {
            // DateTime yeasterday = DateTime.Now.AddDays(-1);
            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
            lastYear = Utils.addYears(startdate, -1);
            lastYear = new Date(lastYear.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
        }
        else if (period.toLowerCase() == "ttm") {
            var result = Utils.GetTTMDates(yeasterday);
            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
            enddate = result[1];
            lastYear = Utils.lastYearDate(enddate);
        }

        let CurrentHotelsData = [];
        let LYHotelsData = [];
        let CurrentBudgetForeCastData = [];
        let dashboardSettings = [];
        let GaugeChartComparision = '';
        return Promise.all([
            new Promise((resolve, reject) => {
                // get current date Hotel dashboard calculations data
                DashboardSettingsHelper.GetDashboardSetting(userId, (err, dashboardSetting_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (dashboardSetting_result) {
                        dashboardSettings = dashboardSetting_result;
                    }

                    // get current date Hotel dashboard calculations data
                    HoteldashboardcalculationsHelper.GetData(hotelid, startdate, (err, currentHotels_result) => {
                        if (err) {
                            reject(err);
                        }
                        if (currentHotels_result) {
                            CurrentHotelsData = currentHotels_result;
                        }

                        // get LY Hotel dashboard calculations data
                        HoteldashboardcalculationsHelper.GetData(hotelid, lastYear, (err, lyHotel_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (lyHotel_result) {
                                LYHotelsData = lyHotel_result;
                            }
                            // get Hotel budget dashboard calculations data
                            HotelbudgetdashboardcalculationsHelper.GetData(hotelid, startdate, (err, hotelbudget_result) => {
                                if (err) {
                                    reject(err);
                                }
                                if (hotelbudget_result) {
                                    CurrentBudgetForeCastData = hotelbudget_result;
                                }
                                resolve();
                            });
                        });
                    });
                });
            })
        ]).then(resp => {
            let OccupancyChart = '';
            let ADRChart = '';
            let RevPARChart = '';

            let chartData = new OccupancyADRvsRevPARData();
            if(CurrentHotelsData.Occupancy != undefined){
                if (period.toLowerCase() == "current") {
                    chartData.occupancyactual = Utils.evenRound(CurrentHotelsData.Occupancy, 0)
                    chartData.adractual = Utils.evenRound(CurrentHotelsData.ADR, 0)
                    chartData.revparactual = Utils.evenRound(CurrentHotelsData.RevPAR, 0)
                }
                else if (period.toLowerCase() == "mtd") {
                    chartData.occupancyactual = Utils.evenRound(CurrentHotelsData.OccupancyMTD, 0)
                    chartData.adractual = Utils.evenRound(CurrentHotelsData.ADRMTD, 0)
                    chartData.revparactual = Utils.evenRound(CurrentHotelsData.RevPARMTD, 0)
                }
                if (period.toLowerCase() == "ytd") {
                    chartData.occupancyactual = Utils.evenRound(CurrentHotelsData.OccupancyYTD, 0)
                    chartData.adractual = Utils.evenRound(CurrentHotelsData.ADRYTD, 0)
                    chartData.revparactual = Utils.evenRound(CurrentHotelsData.RevPARYTD, 0)
                }
                if (period.toLowerCase() == "ttm") {
                    chartData.occupancyactual = Utils.evenRound(CurrentHotelsData.OccupancyTTM, 0)
                    chartData.adractual = Utils.evenRound(CurrentHotelsData.ADRTTM, 0)
                    chartData.revparactual = Utils.evenRound(CurrentHotelsData.RevPARTTM, 0)
                }
        }
        if(LYHotelsData.Occupancy  != undefined){
            if (period.toLowerCase() == "current") {
                chartData.occupancylastyear = Utils.evenRound(LYHotelsData.Occupancy, 0)
                chartData.adrlastyear = Utils.evenRound(LYHotelsData.ADR, 0)
                chartData.revparlastyear = Utils.evenRound(LYHotelsData.RevPAR, 0)
            }
            else if (period.toLowerCase() == "mtd") {
                chartData.occupancylastyear = Utils.evenRound(LYHotelsData.OccupancyMTD, 0)
                chartData.adrlastyear = Utils.evenRound(LYHotelsData.ADRMTD, 0)
                chartData.revparlastyear = Utils.evenRound(LYHotelsData.RevPARMTD, 0)
            }
            if (period.toLowerCase() == "ytd") {
                chartData.occupancylastyear = Utils.evenRound(LYHotelsData.OccupancyYTD, 0)
                chartData.adrlastyear = Utils.evenRound(LYHotelsData.ADRYTD, 0)
                chartData.revparlastyear = Utils.evenRound(LYHotelsData.RevPARYTD, 0)
            }
            if (period.toLowerCase() == "ttm") {
                chartData.occupancylastyear = Utils.evenRound(LYHotelsData.OccupancyTTM, 0)
                chartData.adrlastyear = Utils.evenRound(LYHotelsData.ADRTTM, 0)
                chartData.revparlastyear = Utils.evenRound(LYHotelsData.RevPARTTM, 0)
            }
        }
        if(CurrentBudgetForeCastData.BudgetOccupancy  != undefined){
            if (period.toLowerCase() == "current") {
                let budAdr =CurrentBudgetForeCastData.BudgetADR==null?0:CurrentBudgetForeCastData.BudgetADR;
                let budOcc =CurrentBudgetForeCastData.BudgetOccupancy==null?0:CurrentBudgetForeCastData.BudgetOccupancy;
                chartData.occupancybudget = Utils.evenRound(budOcc, 0)
                chartData.adrbudget = Utils.evenRound(budAdr, 0)
                chartData.revparbudget = Utils.evenRound((parseFloat((budAdr*budOcc) / 100)), 0)
                chartData.occupancyforecast = Utils.evenRound(CurrentBudgetForeCastData.ForecastOccupancy==null?0:CurrentBudgetForeCastData.ForecastOccupancy, 0)
                chartData.adrforecast = Utils.evenRound(CurrentBudgetForeCastData.ForecastADR==null?0:CurrentBudgetForeCastData.ForecastADR, 0)
                chartData.revparforecast = Utils.evenRound(parseFloat(((CurrentBudgetForeCastData.ForecastADR==null?0:CurrentBudgetForeCastData.ForecastADR) * (CurrentBudgetForeCastData.ForecastOccupancy==null?0:CurrentBudgetForeCastData.ForecastOccupancy)) / 100), 0)
            }
            else if (period.toLowerCase() == "mtd") {
                let budAdr =CurrentBudgetForeCastData.BudgetADRMTD==null?0:CurrentBudgetForeCastData.BudgetADRMTD;
                let budOcc =CurrentBudgetForeCastData.BudgetOccupancyMTD==null?0:CurrentBudgetForeCastData.BudgetOccupancyMTD
                chartData.occupancybudget = Utils.evenRound(budOcc, 0)
                chartData.adrbudget = Utils.evenRound(budAdr, 0)
                chartData.revparbudget = Utils.evenRound((parseFloat((budAdr*budOcc) / 100)), 0)
                chartData.occupancyforecast = Utils.evenRound(CurrentBudgetForeCastData.ForecastOccupancyMTD==null?0:CurrentBudgetForeCastData.ForecastOccupancyMTD, 0)
                chartData.adrforecast = Utils.evenRound(CurrentBudgetForeCastData.ForecastADRMTD==null?0:CurrentBudgetForeCastData.ForecastADRMTD, 0)
                chartData.revparforecast = Utils.evenRound(parseFloat(((CurrentBudgetForeCastData.ForecastADRMTD==null?0:CurrentBudgetForeCastData.ForecastADRMTD) * (CurrentBudgetForeCastData.ForecastOccupancyMTD==null?0:CurrentBudgetForeCastData.ForecastOccupancyMTD)) / 100), 0)
            }
            if (period.toLowerCase() == "ytd") {
                let budAdr =CurrentBudgetForeCastData.BudgetADRYTD==null?0:CurrentBudgetForeCastData.BudgetADRYTD;
                let budOcc =CurrentBudgetForeCastData.BudgetOccupancyYTD==null?0:CurrentBudgetForeCastData.BudgetOccupancyYTD;
                chartData.occupancybudget = Utils.evenRound(budOcc, 0)
                chartData.adrbudget = Utils.evenRound(budAdr, 0)
                chartData.revparbudget = Utils.evenRound((parseFloat((budAdr*budOcc) / 100)), 0)
                chartData.occupancyforecast = Utils.evenRound(CurrentBudgetForeCastData.ForecastOccupancyYTD==null?0:CurrentBudgetForeCastData.ForecastOccupancyYTD, 0)
                chartData.adrforecast = Utils.evenRound(CurrentBudgetForeCastData.ForecastADRYTD==null?0:CurrentBudgetForeCastData.ForecastADRYTD, 0)
                chartData.revparforecast = Utils.evenRound(parseFloat(((CurrentBudgetForeCastData.ForecastADRYTD==null?0:CurrentBudgetForeCastData.ForecastADRYTD) * (CurrentBudgetForeCastData.ForecastOccupancyYTD==null?0:CurrentBudgetForeCastData.ForecastOccupancyYTD)) / 100), 0)
            }
            if (period.toLowerCase() == "ttm") {
                let budAdr =CurrentBudgetForeCastData.BudgetADRTTM==null?0:CurrentBudgetForeCastData.BudgetADRTTM
                let budOcc =CurrentBudgetForeCastData.BudgetOccupancyTTM==null?0:CurrentBudgetForeCastData.BudgetOccupancyTTM;
                chartData.occupancybudget = Utils.evenRound(budOcc, 0)
                chartData.adrbudget = Utils.evenRound(budAdr, 0)
                chartData.revparbudget = Utils.evenRound((parseFloat((budAdr*budOcc) / 100)), 0)
                chartData.occupancyforecast = Utils.evenRound(CurrentBudgetForeCastData.ForecastOccupancyTTM==null?0:CurrentBudgetForeCastData.ForecastOccupancyTTM, 0)
                chartData.adrforecast = Utils.evenRound(CurrentBudgetForeCastData.ForecastADRTTM==null?0:CurrentBudgetForeCastData.ForecastADRTTM, 0)
                chartData.revparforecast = Utils.evenRound(parseFloat(((CurrentBudgetForeCastData.ForecastADRTTM==null?0:CurrentBudgetForeCastData.BudgetADRTTM) * (CurrentBudgetForeCastData.ForecastOccupancyTTM==null?0:CurrentBudgetForeCastData.ForecastOccupancyTTM)) / 100), 0)
            }
        }
            GaugeChartComparision = dashboardSettings.GaugeChartComparision;

            if (chartData.occupancybudget == 0) {
                OccupancyChart = 0;
            }
            else {
                let ocr = 0;
                if (GaugeChartComparision == 'Last Year')
                    ocr = chartData.occupancylastyear
                else if (GaugeChartComparision == 'Forecast')
                    ocr = chartData.occupancyforecast
                else
                    ocr = chartData.occupancybudget;

                OccupancyChart = Utils.evenRound((Utils.evenRound((chartData.occupancyactual * 100), 0) / Utils.evenRound(ocr, 0)), 0);
            }
            if (chartData.adrbudget == 0) {
                ADRChart = 0;
            }
            else {
                let adr = 0;
                if (GaugeChartComparision == 'Last Year')
                    adr = chartData.adrlastyear
                else if (GaugeChartComparision == 'Forecast')
                    adr = chartData.adrforecast
                else
                    adr = chartData.adrbudget;

                ADRChart = Utils.evenRound((Utils.evenRound((chartData.adractual * 100), 0) / Utils.evenRound(adr, 0)), 0);
            }
            if (chartData.revparbudget == 0) {
                RevPARChart = 0;
            }
            else {
                let revpar = 0;
                if (GaugeChartComparision == 'Last Year')
                    revpar = chartData.revparlastyear
                else if (GaugeChartComparision == 'Forecast')
                    revpar = chartData.revparforecast
                else
                    revpar = chartData.revparbudget;
                RevPARChart = Utils.evenRound((Utils.evenRound((chartData.revparactual * 100), 0) / Utils.evenRound(revpar, 0)), 0);
            }
            chartData.occupancychart = OccupancyChart;
            chartData.adrchart = ADRChart;
            chartData.revparchart = RevPARChart;
            chartData.occupancymax = 100;
            chartData.adrmax = 100;
            chartData.revparmax = 100;

            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getDashboardOccupancyADRvsRevPARChart_GraphQL(userid, hotelid, currentDate, period, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getDashboardOccupancyADRvsRevPARChart(userid, hoteldata.ID, currentDate, period, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }
    //#endregion

    //#region ActualVsBudgetVsLastYr Chart
    static getActualVsBudgetVsLastYrChart(userId, hotelid, currentDate, period, cb) {
        let startdate = new Date();
        let yeasterday = new Date(currentDate);
        let lastYear = Utils.sameDayLastYear(yeasterday);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        lastYear = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);

        let CurrentHotelsData = [];
        let LYHotelsData = [];
        let CurrentBudgetForeCastData = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // get current date Hotel dashboard calculations data
                HoteldashboardcalculationsHelper.GetData(hotelid, startdate, (err, currentHotels_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (currentHotels_result) {
                        CurrentHotelsData = currentHotels_result;
                    }


                    // get LY Hotel dashboard calculations data
                    HoteldashboardcalculationsHelper.GetData(hotelid, lastYear, (err, lyHotel_result) => {
                        if (err) {
                            reject(err);
                        }
                        if (lyHotel_result) {
                            LYHotelsData = lyHotel_result;
                        }

                        // get Hotel budget dashboard calculations data
                        HotelbudgetdashboardcalculationsHelper.GetData(hotelid, startdate, (err, hotelbudget_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (hotelbudget_result) {
                                CurrentBudgetForeCastData = hotelbudget_result;
                            }
                            resolve();
                        });
                    });

                });
            })
        ]).then(resp => {
            let chartData = new ActualVsBudgetVsLastYrData();

            if (period.toLowerCase() == "current") {
                chartData.rractual = parseFloat(CurrentHotelsData.TotalRevenue)
                chartData.fbactual = parseFloat(CurrentHotelsData.FANDBRevenue)
                chartData.oiactual = parseFloat(CurrentHotelsData.OtherRevenue)
            }
            else if (period.toLowerCase() == "mtd") {
                chartData.rractual = parseFloat(CurrentHotelsData.TotalRevenueMTD)
                chartData.fbactual = parseFloat(CurrentHotelsData.FANDBRevenueMTD)
                chartData.oiactual = parseFloat(CurrentHotelsData.OtherRevenueMTD)
            }
            if (period.toLowerCase() == "ytd") {
                chartData.rractual = parseFloat(CurrentHotelsData.TotalRevenueYTD)
                chartData.fbactual = parseFloat(CurrentHotelsData.FANDBRevenueYTD)
                chartData.oiactual = parseFloat(CurrentHotelsData.OtherRevenueYTD)
            }
            if (period.toLowerCase() == "ttm") {
                chartData.rractual = parseFloat(CurrentHotelsData.TotalRevenueTTM)
                chartData.fbactual = parseFloat(CurrentHotelsData.FANDBRevenueTTM)
                chartData.oiactual = parseFloat(CurrentHotelsData.OtherRevenueTTM)
            }
            chartData.toactual = parseFloat(chartData.rractual + chartData.fbactual + chartData.oiactual)

            if (period.toLowerCase() == "current") {
                chartData.rrlastyear = parseFloat(LYHotelsData.TotalRevenue)
                chartData.fblastyear = parseFloat(LYHotelsData.FANDBRevenue)
                chartData.oilastyear = parseFloat(LYHotelsData.OtherRevenue)
            }
            else if (period.toLowerCase() == "mtd") {
                chartData.rrlastyear = parseFloat(LYHotelsData.TotalRevenueMTD)
                chartData.fblastyear = parseFloat(LYHotelsData.FANDBRevenueMTD)
                chartData.oilastyear = parseFloat(LYHotelsData.OtherRevenueMTD)
            }
            if (period.toLowerCase() == "ytd") {
                chartData.rrlastyear = parseFloat(LYHotelsData.TotalRevenueYTD)
                chartData.fblastyear = parseFloat(LYHotelsData.FANDBRevenueYTD)
                chartData.oilastyear = parseFloat(LYHotelsData.OtherRevenueYTD)
            }
            if (period.toLowerCase() == "ttm") {
                chartData.rrlastyear = parseFloat(LYHotelsData.TotalRevenueTTM)
                chartData.fblastyear = parseFloat(LYHotelsData.FANDBRevenueTTM)
                chartData.oilastyear = parseFloat(LYHotelsData.OtherRevenueTTM)
            }
            chartData.tolastyear = parseFloat(chartData.rrlastyear + chartData.fblastyear + chartData.oilastyear)

            if (period.toLowerCase() == "current") {
                chartData.rrbudget = parseFloat(CurrentBudgetForeCastData.BudgetRoomRevenue)
                chartData.fbbudget = parseFloat(CurrentBudgetForeCastData.BudgetFANDBRevenue)
                chartData.oibudget = parseFloat(CurrentBudgetForeCastData.BudgetOtherRevenue)
                chartData.tobudget = parseFloat(CurrentBudgetForeCastData.BudgetTotalRevenue)
            }
            else if (period.toLowerCase() == "mtd") {
                chartData.rrbudget = parseFloat(CurrentBudgetForeCastData.MTDBudget)
                chartData.fbbudget = parseFloat(CurrentBudgetForeCastData.MTDFANDBRevenue)
                chartData.oibudget = parseFloat(CurrentBudgetForeCastData.MTDOtherRevenue)
                chartData.tobudget = parseFloat(CurrentBudgetForeCastData.MTDTotalRevenue)
            }
            if (period.toLowerCase() == "ytd") {
                chartData.rrbudget = parseFloat(CurrentBudgetForeCastData.YTDBudget)
                chartData.fbbudget = parseFloat(CurrentBudgetForeCastData.YTDFANDBRevenue)
                chartData.oibudget = parseFloat(CurrentBudgetForeCastData.YTDOtherRevenue)
                chartData.tobudget = parseFloat(CurrentBudgetForeCastData.YTDTotalRevenue)
            }
            if (period.toLowerCase() == "ttm") {
                chartData.rrbudget = parseFloat(CurrentBudgetForeCastData.TTMBudget)
                chartData.fbbudget = parseFloat(CurrentBudgetForeCastData.TTMFANDBRevenue)
                chartData.oibudget = parseFloat(CurrentBudgetForeCastData.TTMOtherRevenue)
                chartData.tobudget = parseFloat(CurrentBudgetForeCastData.TTMTotalRevenue)
            }
            chartData = chartData.setFormat(chartData);

            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getActualVsBudgetVsLastYrChart_GraphQL(userid, hotelid, currentDate, period, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getActualVsBudgetVsLastYrChart(userid, hoteldata.ID, currentDate, period, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region ADR VS RevPAR Chart
    static getADRVSRevPARChart(hotelid, currentDate, days, cb) {
        let daysMinus = (-1) * days + 1;
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);
        let previousday = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate() + daysMinus, 0, 0, 0);

        startdate = new Date(previousday.getFullYear(), previousday.getMonth(), previousday.getDate(), 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);

        let hoteldashboardcalculationsData = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // get current date Hotel dashboard calculations data
                HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, dashboardCalculation_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (dashboardCalculation_result) {
                        hoteldashboardcalculationsData = dashboardCalculation_result;
                    }
                    resolve();
                });
            })

        ]).then(resp => {
            let lstChartData = [];
            let daysIncrement = 1;

            if (days > 7)
                daysIncrement = 7;

            while (startdate <= enddate) {
                let dt = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate())
                let objAdrVsRevPar = new ADRVSRevPARData();
                objAdrVsRevPar.date = moment(dt).format('YYYY-MM-DD');

                hoteldashboardcalculationsData.forEach(element => {
                    if (new Date(element.Date).setHours(0, 0, 0, 0) >= dt && new Date(element.Date).setHours(0, 0, 0, 0) <= dt) {
                        objAdrVsRevPar.adr = Utils.evenRound(element.ADR, 0);
                        objAdrVsRevPar.revpar = Utils.evenRound(element.RevPAR, 0);
                    }
                })

                lstChartData.push(objAdrVsRevPar);
                startdate = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate() + daysIncrement);
            }

            cb(null, lstChartData);
        }, err => {
            return cb(err);
        })
    }

    static getADRVSRevPARChart_GraphQL(userid, hotelid, currentDate, days, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getADRVSRevPARChart(hoteldata.ID, currentDate, days, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region Revenue Breakdown Chart
    static getRevenueBreakdownChart(userId, hotelid, currentDate, period, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);
        let lastYear = Utils.sameDayLastYear(yeasterday);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);

        let DashboardCalList = [];
        let roomRevenueList = [];
        let HotelSourceTitlesList = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // get current date Hotel dashboard calculations data
                HoteldashboardcalculationsHelper.GetData(hotelid, startdate, (err, DashboardCal_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (DashboardCal_result) {
                        DashboardCalList.push(DashboardCal_result);
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // Get Hotel Revenue Cash Description
                GlcodehotelrevenueSchema.find({
                    [GlcodehotelrevenueSchemaFields.HotelID]: hotelid
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    HotelSourceTitlesList = result;
                    resolve()
                })
            }),
            new Promise((resolve, reject) => {
                // get Hotelrevenue data
                HotelrevenueHelper.GetHotelrevenueForRevenueBreakdown(hotelid, startdate, enddate, (err, roomRevenue_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (roomRevenue_result) {
                        roomRevenueList = roomRevenue_result;
                    }
                    resolve();
                });
            }),

        ]).then(resp => {
            let chartData = [];
            let revenueBreakDow = new RevenueBreakdownData();
            let roomRevenueData = 0;
            let otherData = 0;
            let FANDBData = 0;
            let lstRoomRevenue = [];
            let lstFANDBRevenue = [];
            let lstOtherRevenue = [];
            if (DashboardCalList.length > 0) {

                if (period.toLowerCase() == "current") {
                    roomRevenueData = Utils.evenRound(_.sumBy(DashboardCalList, "TotalRevenue"), 0);
                    FANDBData = Utils.evenRound(_.sumBy(DashboardCalList, "FANDBRevenue"), 0);
                    otherData = Utils.evenRound(_.sumBy(DashboardCalList, "OtherRevenue"), 0);
                }
                else if (period.toLowerCase() == "mtd") {
                    roomRevenueData = Utils.evenRound(_.sumBy(DashboardCalList, "TotalRevenueMTD"), 0);
                    FANDBData = Utils.evenRound(_.sumBy(DashboardCalList, "FANDBRevenueMTD"), 0);
                    otherData = Utils.evenRound(_.sumBy(DashboardCalList, "OtherRevenueMTD"), 0);
                }
                if (period.toLowerCase() == "ytd") {
                    roomRevenueData = Utils.evenRound(_.sumBy(DashboardCalList, "TotalRevenueYTD"), 0);
                    FANDBData = Utils.evenRound(_.sumBy(DashboardCalList, "FANDBRevenueYTD"), 0);
                    otherData = Utils.evenRound(_.sumBy(DashboardCalList, "OtherRevenueYTD"), 0);
                }
                if (period.toLowerCase() == "ttm") {
                    roomRevenueData = Utils.evenRound(_.sumBy(DashboardCalList, "TotalRevenueTTM"), 0);
                    FANDBData = Utils.evenRound(_.sumBy(DashboardCalList, "FANDBRevenueTTM"), 0);
                    otherData = Utils.evenRound(_.sumBy(DashboardCalList, "OtherRevenueTTM"), 0);
                }
            }
            else {

                lstRoomRevenue = roomRevenueList.filter(d => {
                    return (d.Category == "RoomRevenue");
                });

                lstFANDBRevenue = roomRevenueList.filter(d => {
                    return (d.Category == "FANDBRevenue");
                });

                lstOtherRevenue = roomRevenueList.filter(d => {
                    return (d.Category == "OtherRevenue");
                });

                roomRevenueData = Utils.evenRound(_.sumBy(lstRoomRevenue, "Amount"), 0);
                FANDBData = Utils.evenRound(_.sumBy(lstFANDBRevenue, "Amount"), 0);
                otherData = Utils.evenRound(_.sumBy(lstOtherRevenue, "Amount"), 0);
            }

            //------------ RoomRevenue ----------------------------
            let revenueBreakDowList = [];
            let categoryList = [];
            lstRoomRevenue = roomRevenueList.filter(d => {
                return (d.Category == "RoomRevenue");
            });
            if (lstRoomRevenue.length > 0) {
                lstRoomRevenue.forEach((element, index) => {
                    let cnt = categoryList.filter(d => {
                        return (d == element.Description);
                    });
                    if (cnt.length === 0) {

                        let lstrr = roomRevenueList.filter(d => {
                            return (d.Description === element.Description && d.Category == "RoomRevenue");
                        });
                        let lstHotelSourceTitles = HotelSourceTitlesList.filter(d => {
                            return (d.Description == element.Description);
                        });

                        let rrcm = new RevenueBreakdownData();
                        rrcm.data = parseFloat(_.sumBy(lstrr, "Amount"));
                        rrcm.label = lstHotelSourceTitles.DisplayDescription == null ? element.Description : lstHotelSourceTitles.DisplayDescription;
                        revenueBreakDowList.push(rrcm);
                        categoryList.push(element.Description)
                    }
                })
            }

            revenueBreakDow.data = parseFloat(roomRevenueData);
            revenueBreakDow.label = 'Room Sales';
            revenueBreakDow.color = "#0088cc";
            revenueBreakDow.subs = revenueBreakDowList;
            chartData.push(revenueBreakDow);

            //------------ FANDBRevenue ----------------------------
            revenueBreakDowList = [];
            categoryList = [];
            lstFANDBRevenue = roomRevenueList.filter(d => {
                return (d.Category == "FANDBRevenue");
            });
            if (lstFANDBRevenue.length > 0) {
                lstFANDBRevenue.forEach((element, index) => {
                    let cnt = categoryList.filter(d => {
                        return (d == element.Description);
                    });
                    if (cnt.length === 0) {
                        let lstrr = roomRevenueList.filter(d => {
                            return (d.Description === element.Description && d.Category == "FANDBRevenue");
                        });
                        let lstHotelSourceTitles = HotelSourceTitlesList.filter(d => {
                            return (d.Description == element.Description);
                        });

                        let rrcm = new RevenueBreakdownData();
                        rrcm.data = parseFloat(_.sumBy(lstrr, "Amount"));
                        rrcm.label = lstHotelSourceTitles.DisplayDescription == null ? element.Description : lstHotelSourceTitles.DisplayDescription;
                        revenueBreakDowList.push(rrcm);
                        categoryList.push(element.Description)
                    }
                })
            }
            revenueBreakDow = new RevenueBreakdownData();
            revenueBreakDow.data = parseFloat(FANDBData);
            revenueBreakDow.label = 'Food and Beverages Revenue';
            revenueBreakDow.color = "#2baab1";
            revenueBreakDow.subs = revenueBreakDowList;
            chartData.push(revenueBreakDow);

            //------------ OtherRevenue ----------------------------
            revenueBreakDowList = [];
            lstOtherRevenue = roomRevenueList.filter(d => {
                return (d.Category == "OtherRevenue");
            });
            if (lstOtherRevenue.length > 0) {
                lstOtherRevenue.forEach((element, index) => {
                    let cnt = categoryList.filter(d => {
                        return (d == element.Description);
                    });
                    if (cnt.length === 0) {
                        let lstrr = roomRevenueList.filter(d => {
                            return (d.Description === element.Description && d.Category == "OtherRevenue");
                        });

                        let lstHotelSourceTitles = HotelSourceTitlesList.filter(d => {
                            return (d.Description == element.Description);
                        });
                        let rrcm = new RevenueBreakdownData();
                        rrcm.data = parseFloat(_.sumBy(lstrr, "Amount"));
                        rrcm.label = lstHotelSourceTitles.DisplayDescription == null ? element.Description : lstHotelSourceTitles.DisplayDescription;
                        revenueBreakDowList.push(rrcm);
                        categoryList.push(element.Description)
                    }
                })
            }
            revenueBreakDow = new RevenueBreakdownData();
            revenueBreakDow.data = parseFloat(otherData);
            revenueBreakDow.label = 'Other Income';
            revenueBreakDow.color = "#734ba9";
            revenueBreakDow.subs = revenueBreakDowList;
            chartData.push(revenueBreakDow);

            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getRevenueBreakdown_GraphQL(userid, hotelid, currentDate, period, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getRevenueBreakdownChart(userid, hoteldata.ID, currentDate, period, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region Revenue Breakdown Table
    static getRevenueBreakdownTable(userId, hotelid, currentDate, period, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);
        let lastYear = Utils.sameDayLastYear(yeasterday);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
        period = period.toLowerCase();
        if (period == "mtd") {
            startdate = Utils.startofMonth(yeasterday);
        }
        else if (period == "ytd") {
            startdate = Utils.startofYear(yeasterday);
        }
        else if (period == "ttm") {
            startdate = Utils.firstDayOfMonth(yeasterday);
            enddate = Utils.firstDayOfMonth(yeasterday);
            enddate.setDate(startdate.getDate() - 1);
        }
        let roomRevenueList = [];
        let HotelSourceTitlesList = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // Get Hotel Revenue Cash Description
                GlcodehotelrevenueSchema.find({
                    [GlcodehotelrevenueSchemaFields.HotelID]: hotelid
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    HotelSourceTitlesList = result;
                    resolve()
                })
            }),
            new Promise((resolve, reject) => {
                // get Hotelrevenue data
                HotelrevenueHelper.GetHotelrevenueForRevenueBreakdown(hotelid, startdate, enddate, (err, roomRevenue_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (roomRevenue_result) {
                        roomRevenueList = roomRevenue_result;
                    }
                    resolve();
                });
            }),

        ]).then(resp => {
            let chartData = [];
            let lstRoomRevenue = [];
            let lstFANDBRevenue = [];
            let lstOtherRevenue = [];


            //------------ RoomRevenue ----------------------------
            let revenueBreakDowList = [];
            let categoryList = [];
            lstRoomRevenue = roomRevenueList.filter(d => {
                return (d.Category == "RoomRevenue");
            });
            if (lstRoomRevenue.length > 0) {
                lstRoomRevenue.forEach((element, index) => {
                    let cnt = categoryList.filter(d => {
                        return (d == element.Description);
                    });
                    if (cnt.length === 0) {

                        let lstrr = roomRevenueList.filter(d => {
                            return (d.Description === element.Description && d.Category == "RoomRevenue");
                        });
                        let lstHotelSourceTitles = HotelSourceTitlesList.filter(d => {
                            return (d.Description == element.Description);
                        });

                        let amt = parseFloat(_.sumBy(lstrr, "Amount"));
                        let description = lstHotelSourceTitles.DisplayDescription == null ? element.Description : lstHotelSourceTitles.DisplayDescription;
                        if (amt != 0)
                            revenueBreakDowList.push({ amount: amt, description: description });
                        categoryList.push(element.Description)
                    }
                })
            }

            //------------ FANDBRevenue ----------------------------
            categoryList = [];
            lstFANDBRevenue = roomRevenueList.filter(d => {
                return (d.Category == "FANDBRevenue");
            });
            if (lstFANDBRevenue.length > 0) {
                lstFANDBRevenue.forEach((element, index) => {
                    let cnt = categoryList.filter(d => {
                        return (d == element.Description);
                    });
                    if (cnt.length === 0) {
                        let lstrr = roomRevenueList.filter(d => {
                            return (d.Description === element.Description && d.Category == "FANDBRevenue");
                        });
                        let lstHotelSourceTitles = HotelSourceTitlesList.filter(d => {
                            return (d.Description == element.Description);
                        });

                        let amt = parseFloat(_.sumBy(lstrr, "Amount"));
                        let description = lstHotelSourceTitles.DisplayDescription == null ? element.Description : lstHotelSourceTitles.DisplayDescription;
                        if (amt != 0)
                            revenueBreakDowList.push({ amount: amt, description: description });
                        categoryList.push(element.Description)
                    }
                })
            }

            //------------ OtherRevenue ----------------------------
            categoryList = [];
            lstOtherRevenue = roomRevenueList.filter(d => {
                return (d.Category == "OtherRevenue");
            });
            if (lstOtherRevenue.length > 0) {
                lstOtherRevenue.forEach((element, index) => {
                    let cnt = categoryList.filter(d => {
                        return (d == element.Description);
                    });
                    if (cnt.length === 0) {
                        let lstrr = roomRevenueList.filter(d => {
                            return (d.Description === element.Description && d.Category == "OtherRevenue");
                        });

                        let lstHotelSourceTitles = HotelSourceTitlesList.filter(d => {
                            return (d.Description == element.Description);
                        });

                        let amt = parseFloat(_.sumBy(lstrr, "Amount"));
                        let description = lstHotelSourceTitles.DisplayDescription == null ? element.Description : lstHotelSourceTitles.DisplayDescription;
                        if (amt != 0)
                            revenueBreakDowList.push({ amount: amt, description: description });

                        categoryList.push(element.Description)
                    }
                })
            }
            // chartData.push(revenueBreakDowList);

            cb(null, revenueBreakDowList);
        }, err => {
            return cb(err);
        })
    }

    static getRevenueBreakdownTable_GraphQL(userid, hotelid, currentDate, period, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getRevenueBreakdownTable(userid, hoteldata.ID, currentDate, period, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region Rolling Revenue Comparison Chart

    static getRollingRevenueComparison(hotelid, currentDate, days, cb) {
        let daysMinus = (-1) * days + 1;
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);
        let previousday = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate() + daysMinus, 0, 0, 0);

        startdate = new Date(previousday.getFullYear(), previousday.getMonth(), previousday.getDate(), 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        let lstChartData = [];
        let daysIncrement = 1;
        if (days > 7)
            daysIncrement = 7;

        let hoteldashboardcalculationsData = [];
        let CurrentBudgetForeCastData = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // get current date Hotel dashboard calculations data
                HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, dashboardCalculation_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (dashboardCalculation_result) {
                        hoteldashboardcalculationsData = dashboardCalculation_result;
                    }

                    HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, hotelbudget_result) => {
                        if (err) {
                            reject(err);
                        }
                        if (hotelbudget_result) {
                            CurrentBudgetForeCastData = hotelbudget_result;
                        }

                        resolve();
                    });
                })
            })
        ]).then(resp => {

            // If you want an inclusive end date (fully-closed interval)
            for (var m = moment(startdate); m.diff(enddate, 'days') <= 0; m.add(daysIncrement, 'days')) {
                var dt = m.toDate();
                let objRollingData = new RollingRevenueData();
                objRollingData.date = Utils.getFormattedDate(dt, 'DD-MMM-YY');

                if (hoteldashboardcalculationsData.length > 0) {
                    hoteldashboardcalculationsData.forEach(element => {
                        if (new Date(element.Date).setHours(0, 0, 0, 0) >= dt && new Date(element.Date).setHours(0, 0, 0, 0) <= dt) {
                            objRollingData.actual = parseFloat(element.TotalRevenue);
                        }
                    })
                }
                if (CurrentBudgetForeCastData.length > 0) {
                    CurrentBudgetForeCastData.forEach(element => {
                        if (new Date(element.Date).setHours(0, 0, 0, 0) >= dt && new Date(element.Date).setHours(0, 0, 0, 0) <= dt) {
                            objRollingData.budget = Utils.evenRound(element.BudgetRoomRevenue, 0);
                            objRollingData.forecast = Utils.evenRound(element.ForecastRoomRevenue==null?0:element.ForecastRoomRevenue, 0);
                        }
                    })
                }
                objRollingData = objRollingData.setFormat(objRollingData);
                lstChartData.push(objRollingData);
            }
            cb(null, lstChartData);
        }, err => {
            return cb(err);
        })
    }

    static getRollingRevenueComparison_GraphQL(userid, hotelid, currentDate, days, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getRollingRevenueComparison(hoteldata.ID, currentDate, days, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region Membership Stays Chart 
    static getMembershipStaysChart(userId, hotelid, currentDate, period, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);
        let lastYear = Utils.sameDayLastYear(yeasterday);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);

        if (period.toLowerCase() == "mtd") {
            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);

        } else if (period.toLowerCase() == "ytd") {
            startdate = new Date(yeasterday.getFullYear(), 1, 1, 0, 0, 0);
            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);

        }
        else if (period.toLowerCase() == "ttm") {
            var result = Utils.GetTTMDates(yeasterday);
            startdate = result[0];
            enddate = result[1];
        }
        let roomRevenueList = [];

        return Promise.all([
            new Promise((resolve, reject) => {
                // get Hotelrevenue data
                HotelrevenueHelper.GetHotelrevenueForMembership(hotelid, startdate, enddate, (err, roomRevenue_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (roomRevenue_result) {
                        roomRevenueList = roomRevenue_result;
                    }
                    resolve();
                });
            }),

        ]).then(resp => {
            let chartData = [];
            let lstCategory = [];
            let hotelrevenuesData
            var arr = ['Member', 'Gold', 'Club', 'Platinum', 'Spire', 'Blue', 'Silver', 'Diamond', 'Discoverist', 'Explorist', 'Globalist', 'Ambassador', 'Titanium']
            //------------ RoomRevenue ----------------------------

            hotelrevenuesData = _(roomRevenueList)
                .groupBy('Category')
                .map((objs, key) => ({
                    'Category': _.get(_.find(objs, function (o) { return true; }), 'Category') == undefined ? 0 : _.get(_.find(objs, function (o) { return true; }), 'Category'),
                    'NoOfReference': _.sumBy(objs, 'NoOfReference'),
                }))
                .value();

            hotelrevenuesData.forEach(element => {

                if (element.NoOfReference > 0) {
                    let membershipStays = new MembershipStaysData();
                    membershipStays.value = element.NoOfReference;
                    membershipStays.label = element.Category;
                    lstCategory.push(element.Category);

                    if (membershipStays.label == Constants.MembershipLevel.Member)
                        membershipStays.color = '#0088cc';
                    else if (membershipStays.label == Constants.MembershipLevel.Gold)
                        membershipStays.color = '#ECB346';
                    else if (membershipStays.label == Constants.MembershipLevel.Club)
                        membershipStays.color = '#4da74d';
                    else if (membershipStays.label == Constants.MembershipLevel.Platinum)
                        membershipStays.color = '#734ba9';
                    else if (membershipStays.label == Constants.MembershipLevel.Spire)
                        membershipStays.color = '#C73800';
                    else if (membershipStays.label == Constants.MembershipLevel.Blue)
                        membershipStays.color = '#0000FF';
                    else if (membershipStays.label == Constants.MembershipLevel.Silver)
                        membershipStays.color = '#C0C0C0';
                    else if (membershipStays.label == Constants.MembershipLevel.Diamond)
                        membershipStays.color = '#C73800';
                    else if (membershipStays.label == Constants.MembershipLevel.Discoverist)
                        membershipStays.color = '#00b5e2';
                    else if (membershipStays.label == Constants.MembershipLevel.Explorist)
                        membershipStays.color = '#0072ce';
                    else if (membershipStays.label == Constants.MembershipLevel.Globalist)
                        membershipStays.color = '#151f6d';
                    else if (membershipStays.label == Constants.MembershipLevel.Ambassador)
                        membershipStays.color = '#b6bb48';
                    else if (membershipStays.label == Constants.MembershipLevel.Titanium)
                        membershipStays.color = '#6a696f';

                    chartData.push(membershipStays);
                }
            })


            // var array3 = arr.filter(function (obj) { return lstCategory.indexOf(obj) == -1; });
            // array3.forEach(element => {
            //     let membershipStays = new MembershipStaysData();
            //     membershipStays.value = 0;
            //     membershipStays.label = element;
            //     if (membershipStays.label == "Member")
            //         membershipStays.color = '#0088cc';
            //     else if (membershipStays.label == "Gold")
            //         membershipStays.color = '#ECB346';
            //     else if (membershipStays.label == "Club")
            //         membershipStays.color = '#4da74d';
            //     else if (membershipStays.label == "Platinum")
            //         membershipStays.color = '#734ba9';
            //     else if (membershipStays.label == "Spire")
            //         membershipStays.color = '#C73800';
            //     else if (membershipStays.label == "Silver")
            //         membershipStays.color = '#C0C0C0';

            //     chartData.push(membershipStays);
            // })
            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getMembershipStays_GraphQL(userid, hotelid, currentDate, period, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getMembershipStaysChart(userid, hoteldata.ID, currentDate, period, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region Market Segment Current vs. Last Yr Chart
    static getRoomSalesVsLastYrChart(userId, hotelid, currentDate, period, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let startDateLastYear = new Date();
        let endDateLastYear = new Date();
        let yeasterday = new Date(currentDate);

        if (period.toLowerCase() == "current") {
            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
            startDateLastYear = Utils.sameDayLastYear(startdate);
            endDateLastYear = Utils.sameDayLastYear(enddate);
        }
        else if (period.toLowerCase() == "mtd") {
            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
            startDateLastYear = new Date(startdate.getFullYear() - 1, startdate.getMonth(), 1, 0, 0, 0);
            endDateLastYear = new Date(enddate.getFullYear() - 1, enddate.getMonth(), enddate.getDate(), 23, 59, 59);

        } else if (period.toLowerCase() == "ytd") {
            startdate = Utils.firstDayOfYear(yeasterday);
            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
            startDateLastYear = new Date(startdate.getFullYear() - 1, startdate.getMonth(), 1, 0, 0, 0);
            endDateLastYear = new Date(enddate.getFullYear() - 1, enddate.getMonth(), enddate.getDate(), 23, 59, 59);
        }
        else if (period.toLowerCase() == "ttm") {
            var result = Utils.GetTTMDates(yeasterday);
            startdate = result[0];
            enddate = result[1];
            startDateLastYear = new Date(startdate.getFullYear() - 1, startdate.getMonth(), 1, 0, 0, 0);
            endDateLastYear = new Date(enddate.getFullYear() - 1, enddate.getMonth(), enddate.getDate(), 23, 59, 59);

        }

        let roomRevenueLY = [];
        let roomRevenueCurrent = [];
        let HotelSourceTitlesList = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // get Hotelrevenue current year data
                HotelrevenueHelper.GetHotelrevenueByCategory(hotelid, startdate, enddate, Constants.RevenueType.RoomRevenue, (err, roomRevenue_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (roomRevenue_result) {
                        roomRevenueCurrent = roomRevenue_result;
                    }

                    // get Hotelrevenue Last year data
                    HotelrevenueHelper.GetHotelrevenueByCategory(hotelid, startDateLastYear, endDateLastYear, Constants.RevenueType.RoomRevenue, (err, roomRevenuely_result) => {
                        if (err) {
                            reject(err);
                        }
                        if (roomRevenuely_result) {
                            roomRevenueLY = roomRevenuely_result;
                        }

                        // Get Hotel Revenue Cash Description
                        GlcodehotelrevenueSchema.find({
                            [GlcodehotelrevenueSchemaFields.HotelID]: hotelid
                        }).exec(function (err, result) {
                            if (err) { reject(err); }
                            HotelSourceTitlesList = result;
                            resolve()
                        })
                    });
                });
            }),

        ]).then(resp => {
            let chartData = [];

            roomRevenueCurrent = roomRevenueCurrent.filter(d => {
                return (d.Amount > 0);
            });

            if (roomRevenueCurrent.length > 0 || roomRevenueLY.length > 0) {
                roomRevenueCurrent.forEach((element, index) => {
                    let cnt = chartData.filter(d => {
                        return (d.type === element.Description);
                    });

                    if (cnt.length == 0) {
                        let lstActual = roomRevenueCurrent.filter(d => {
                            return (d.Description === element.Description);
                        });
                        let lyActual = roomRevenueLY.filter(d => {
                            return (d.Description === element.Description);
                        });
                        let lstHotelSourceTitles = HotelSourceTitlesList.filter(d => {
                            return (d.Description == element.Description);
                        });

                        let rrcm = new RoomSalesVsLastYrData();
                        rrcm.actual = parseFloat(_.sumBy(lstActual, "Amount")).toFixed(2);
                        rrcm.lastyr = parseFloat(_.sumBy(lyActual, "Amount")).toFixed(2);
                        rrcm.type = lstHotelSourceTitles.DisplayDescription == null ? element.Description : lstHotelSourceTitles.DisplayDescription;
                        chartData.push(rrcm);
                    }
                })
            }

            //Include last year data, if not present in current as well
            roomRevenueLY = roomRevenueLY.filter(d => {
                return (d.Amount > 0);
            });
            if (roomRevenueLY.length > 0) {
                roomRevenueLY.forEach((element, index) => {
                    let cnt = chartData.filter(d => {
                        return (d.type === element.Description);
                    });

                    if (cnt == 0) {
                        let lyActual = roomRevenueLY.filter(d => {
                            return (d.Description === element.Description);
                        });
                        let lstHotelSourceTitles = HotelSourceTitlesList.filter(d => {
                            return (d.Description == element.Description);
                        });

                        let rrcm = new RoomSalesVsLastYrData();
                        rrcm.actual = parseFloat(0);
                        rrcm.lastyr = parseFloat(_.sumBy(lyActual, "Amount")).toFixed(2);
                        rrcm.type = lstHotelSourceTitles.DisplayDescription == null ? element.Description : lstHotelSourceTitles.DisplayDescription;
                        chartData.push(rrcm);
                    }
                })
            }
            chartData = Utils.sort(chartData, 'type')
            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getRoomSalesVsLastYr_GraphQL(userid, hotelid, currentDate, period, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getRoomSalesVsLastYrChart(userid, hoteldata.ID, currentDate, period, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion


    //#region Get Trip Advisor LocationId
    static getTripAdvisorLocationId(hotelid, cb) {

        let Tripadvisor = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // Get Hotel Revenue Cash Description
                TripadvisorhotelmappingSchema.findOne({
                    [TripadvisorhotelmappingSchemaFields.HotelID]: hotelid
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    Tripadvisor = result;
                    resolve()
                })
            }),

        ]).then(resp => {
            let chartData = [];
            let locationId = Tripadvisor.LocationID;
            chartData.push({ 'locationid': locationId })
            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getTripAdvisorLocationId_GraphQL(userid, hotelid, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getTripAdvisorLocationId(hoteldata.ID, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region Get Google PlaceId
    static getGooglePlaceId(hotelid, cb) {

        let GooglePlace = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                GoogleplacehotelmappingSchema.findOne({
                    [GoogleplacehotelmappingSchemaFields.HotelID]: hotelid
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    GooglePlace = result;
                    resolve()
                })
            }),

        ]).then(resp => {
            let chartData = [];
            let locationId = GooglePlace.PlaceID;
            chartData.push({ 'locationid': locationId })
            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getGooglePlaceId_GraphQL(userid, hotelid, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getGooglePlaceId(hoteldata.ID, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion


    //#region Get Facebook Page URL
    static getFacebookPageURL(hotelid, cb) {

        let FacebookPage = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                FbpagehotelmappingSchema.findOne({
                    [FbpagehotelmappingSchemaFields.HotelID]: hotelid
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    FacebookPage = result;
                    resolve()
                })
            }),

        ]).then(resp => {
            let chartData = [];
            let locationId = FacebookPage.FBPageURL;
            let pageurl = '/plugins/page.php';
            let fbresult =[];
            // RESTHelper.GET_FBPageLike(Constants.Urls.FacebookPage,pageurl, (api_err, get_result) => {
            //     if (api_err) {
            //         log.error(api_err);
            //         cb(api_err, null);
            //     }
            //     else {
            //         fbresult = get_result.data;  
            //     }                            
            // });  
            chartData.push({ 'locationid': locationId })
            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getFacebookPageURL_GraphQL(userid, hotelid, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getFacebookPageURL(hoteldata.ID, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region Get Yelp URL
    static getYelpURL(hotelid, cb) {

        let Yelp = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                YelphotelmappingsSchema.findOne({
                    [YelphotelmappingsSchemaFields.HotelID]: hotelid
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    Yelp = result;
                    resolve()
                })
            }),

        ]).then(resp => {
            let chartData = [];
            let locationId = Yelp.YelpID;
            chartData.push({ 'locationid': locationId })
            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getYelpURL_GraphQL(userid, hotelid, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getYelpURL(hoteldata.ID, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    static getHotelCashTableData_GraphQL(userid, hotelid, currentDate, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    CashDetailHelper.getCashTableData(hoteldata.ID, currentDate, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }

    //#region Guest Ledger Widget
    static getGuestLedgerWidget(userId, hotelid, currentDate, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);

        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);

        let GuestLedgerList = [];
        let HotelSourceTitlesList = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // Get Gl code hotel revenue 
                HotelGuestLedgerSchema.find({
                    [HotelGuestLedgerSchemaFields.HotelID]: hotelid,
                    [HotelGuestLedgerSchemaFields.Date]: {
                        $gte: startdate,
                        $lt: enddate
                    }
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    if (result) {
                        GuestLedgerList = result;
                    }

                    // Get Hotel Revenue Cash Description
                    GlcodehotelrevenueSchema.find({
                        [GlcodehotelrevenueSchemaFields.HotelID]: hotelid
                    }).exec(function (err, result) {
                        if (err) { reject(err); }
                        HotelSourceTitlesList = result;
                        resolve()
                    })
                });
            }),

        ]).then(resp => {
            let chartData = [];

            if (GuestLedgerList.length > 0) {
                GuestLedgerList.forEach((element, index) => {

                    let lstHotelSourceTitles = HotelSourceTitlesList.filter(d => {
                        return (d.Description == element.Description);
                    });

                    let guestLedger = new HotelGuestLedgerData();
                    guestLedger.beginingbalance = element.BeginingBalance == null ? 0 : element.BeginingBalance;
                    guestLedger.endingbalance = element.EndingBalance == null ? 0 : element.EndingBalance;
                    guestLedger.debit = element.Debit == null ? 0 : element.Debit;
                    guestLedger.credit = element.Credit == null ? 0 : element.Credit;
                    guestLedger.hotelid = element.HotelID;
                    guestLedger.description = lstHotelSourceTitles.DisplayDescription == null ? element.Description : lstHotelSourceTitles.DisplayDescription;
                    guestLedger = guestLedger.setFormat(guestLedger);
                    chartData.push(guestLedger);
                })
            }

            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getGuestLedgerWidget_GraphQL(userid, hotelid, currentDate, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getGuestLedgerWidget(userid, hoteldata.ID, currentDate, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region Weather Widget
    static getWeatherWidget(city, state, country, currentDate, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);

        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);

        let HotelWeatherList = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // Get Hotel Weather 
                HotelWeatherDataSchema.find({
                    [HotelWeatherDataSchemaFields.City]: city,
                    [HotelWeatherDataSchemaFields.StateISO]: state,
                    [HotelWeatherDataSchemaFields.CountryCode]: country,
                    [HotelWeatherDataSchemaFields.Date]: {
                        $gte: startdate,
                        $lt: enddate
                    }
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    if (result) {
                        HotelWeatherList = result;
                        resolve()
                    }
                });
            }),

        ]).then(resp => {
            let chartData = [];

            if (HotelWeatherList.length > 0) {
                HotelWeatherList.forEach((element, index) => {

                    if (element.Period > 0) {
                        var dt = new Date(element.Date.getFullYear(), element.Date.getMonth(), element.Date.getDate() + element.Period)
                        let weatherdata = new WeatherData();
                        weatherdata.city = element.City;
                        weatherdata.countrycode = element.CountryCode;
                        weatherdata.date = moment(dt).format('ddd MMM DD');
                        weatherdata.fxconditionday = element.FxConditionDay;
                        weatherdata.fxiconday = element.FxIconDay;
                        weatherdata.period = element.Period;
                        weatherdata.poppercentday = element.POPPercentDay;
                        weatherdata.stateiso = element.StateISO;
                        weatherdata.temperaturecmax = element.TemperatureCMax;
                        weatherdata.temperaturecmin = element.TemperatureCMin;
                        weatherdata.temperaturefmax = element.TemperatureFMax;
                        weatherdata.temperaturefmin = element.TemperatureFMin;
                        weatherdata.winddirection = element.WindDirection;
                        weatherdata.windspeedkmh = element.WindSpeedKMH;
                        weatherdata.windspeedmph = element.WindSpeedMPH;

                        var avg = 0;
                        if (element.TemperatureCMin != '' && element.TemperatureCMa != '')
                            avg = parseFloat((parseInt(element.TemperatureCMin) + parseInt(element.TemperatureCMax)) / 2);

                        else if (element.TemperatureCMin != '')
                            avg = parseInt(element.TemperatureCMin);

                        else if (element.TemperatureCMax != '')
                            avg = parseInt(element.TemperatureCMax);

                        weatherdata.temperaturecavg = avg;
                        chartData.push(weatherdata);
                    }
                })

            }
            cb(null, chartData);
        }, err => {
            return cb(err);
        })
    }

    static getWeatherWidget_GraphQL(userid, hotelid, currentDate, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getWeatherWidget(hoteldata.City, hoteldata.StateISO2, hoteldata.CountryISO2, currentDate, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion

    //#region OOO/Comp Rooms Widget Chart
    static getOOOCompTable(userId, hotelid, currentDate, period, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);

        let RoomstatusList = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // get Room status data
                HotelroomstatusdashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, roomstatus_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (roomstatus_result) {
                        RoomstatusList = roomstatus_result;
                    }
                    resolve();
                });
            }),

        ]).then(resp => {
            let retValue = new HotelRoomStatusData();
            if (RoomstatusList.length > 0) {
                if (period == 'current') {
                    retValue.outoforderrooms = RoomstatusList[0].OutOfOrderRooms_NoCalc;
                    retValue.comprooms = RoomstatusList[0].CompRooms;
                }
                else if (period == 'mtd') {
                    retValue.outoforderrooms = RoomstatusList[0].OutOfOrderRoomsMTD_NoCalc;
                    retValue.comprooms = RoomstatusList[0].CompRoomsMTD;
                }
                else if (period == 'ytd') {
                    retValue.outoforderrooms = RoomstatusList[0].OutOfOrderRoomsYTD_NoCalc;
                    retValue.comprooms = RoomstatusList[0].CompRoomsYTD;
                }
                else if (period == 'ttm') {
                    retValue.outoforderrooms = RoomstatusList[0].OutOfOrderRoomsTTM_NoCalc;
                    retValue.comprooms = RoomstatusList[0].CompRoomsTTM;
                }
                retValue.hotelid = hotelid;
            }
            cb(null, retValue);
        }, err => {
            return cb(err);
        })
    }

    static getOOOCompTable_GraphQL(userid, hotelid, currentDate, period, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getOOOCompTable(userid, hoteldata.ID, currentDate, period, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }
    //#endregion


    //#region  Dashboard GSSPriority Chart
    static getGSSPriorityChart(userId, hotelid, currentDate, period, priority, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let lystartdate = new Date();
        let lyenddate = new Date();
        let yeasterday = new Date(currentDate);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);

        if (period.toLowerCase() == "current" || period.toLowerCase() == "mtd") {
            let dt = Utils.firstDayOfMonth(yeasterday)
            startdate = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), 0, 0, 0);
            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
            lystartdate = Utils.addYears(startdate, -1);
            lyenddate = Utils.addYears(enddate, -1);
        }
        else if (period.toLowerCase() == "ytd") {
            let dt = Utils.firstDayOfYear(yeasterday);
            startdate = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), 0, 0, 0);
            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
            lystartdate = Utils.addYears(startdate, -1);
            lyenddate = Utils.addYears(enddate, -1);
        }
        else if (period.toLowerCase() == "ttm") {
            var result = Utils.GetTTMDates(yeasterday);
            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
            enddate = result[1];
            lystartdate = Utils.addYears(startdate, -1);
            lyenddate = Utils.addYears(enddate, -1);
        }
        let lsthotelids = [];
        lsthotelids.push(hotelid);
        let hotelgssData = [];
        let hotelgssData_LY = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                //#GSSDATA
                HotelgssHelper.GetGSSPriorityData(lsthotelids, yeasterday, startdate, enddate, priority, (err, hotelgssdata_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelgssdata_result) {
                        hotelgssData = hotelgssdata_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                //#GSSDATA LY 
                HotelgssHelper.GetGSSPriorityData(lsthotelids, yeasterday, lystartdate, lyenddate, priority, (err, hotelgssdata_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelgssdata_result) {
                        hotelgssData_LY = hotelgssdata_result;
                    }
                    resolve();
                });
            })
        ]).then(resp => {
            let chartData = []
            let objHotelgssdata = new GSSPriorityData();
            if(hotelgssData.length > 0){
                objHotelgssdata.description = hotelgssData[0].description;
            }
            if (period.toLowerCase() == "current" || period.toLowerCase() == "mtd") {
               
                objHotelgssdata.benchmarkgss = _.sumBy(hotelgssData, 'benchmark');
                objHotelgssdata.totalgss = _.sumBy(hotelgssData, 'total');
                objHotelgssdata.actualgss = _.sumBy(hotelgssData, 'actual');
                objHotelgssdata.actualgssly = _.sumBy(hotelgssData_LY, 'actual');
            }
            else if (period.toLowerCase() == "ytd" || period.toLowerCase() == "ttm") {
                objHotelgssdata.benchmarkgss = _.sumBy(hotelgssData, 'benchmark');
                objHotelgssdata.totalgss = _.sumBy(hotelgssData, 'total');
                objHotelgssdata.actualgss = _.sumBy(hotelgssData, 'actual_YTD');
                objHotelgssdata.actualgssly = _.sumBy(hotelgssData_LY, 'actual_YTD');
            }
            if (objHotelgssdata.benchmarkgss > 0)
                objHotelgssdata.chart = Utils.evenRound(((parseFloat(objHotelgssdata.actualgss) * 100) / parseFloat(objHotelgssdata.benchmarkgss)), 2);

            objHotelgssdata = objHotelgssdata.setFormat(objHotelgssdata);
            cb(null, objHotelgssdata);
        }, err => {
            return cb(err);
        })
    }

    static getGSSPriorityChart_GraphQL(userid, hotelid, currentDate, period, priority, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getGSSPriorityChart(userid, hoteldata.ID, currentDate, period, priority, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }
    //#endregion

    //#region  Ota Hotel Widget Data
    static getOtaHotelData(userid, hotelid,organizationId, currentDate, days,cb) {
        let startdate = new Date();
        let yeasterday = new Date(currentDate);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        
        let lsthotelids = [];
        lsthotelids.push(hotelid);
        let otaOrgData = [];
        let otaHotelMappingData = [];
        Promise.all([
            new Promise((resolve, reject) => {               
                // Get Hotel Weather 
                OtainsightapidataorganisationSchema.find({
                [OtainsightapidataorganisationSchemaFields.OrganisationID]: organizationId
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    if (result) {
                        otaOrgData = result;
                       resolve()
                    }
                });               
            }),
            new Promise((resolve, reject) => {               
                // Get Hotel Weather 
                OtainsighthotelmappingSchema.find({
                [OtainsighthotelmappingSchemaFields.HotelID]: hotelid
                }).exec(function (err, result) {
                    if (err) { reject(err); }
                    if (result) {
                        otaHotelMappingData = result;
                       resolve()
                    }
                });               
            })
        ]).then(resp => {
            let chartData = []
            let otaDataList = []
            let otaDemandDataList = []
            if(otaOrgData.length != 0 && otaHotelMappingData.length !=0){
                let shopLength = 30;
                if (days != 0)                
                    shopLength = days;
                let isBar = true;
                let roomType = "standard";
                let ota = "branddotcom";
                let rateUrl = '/v2/rates'
                let demandUrl = '/v2/demand'

                return Promise.all([
                    new Promise((resolve, reject) => {               
                        RESTHelper.GET_OtaRateData(Constants.Urls.OtaHotelRate,rateUrl,otaOrgData[0].OTAInsightToken,otaHotelMappingData[0].OTASubscriptionID,moment(startdate).format('YYYY-MM-DD'),shopLength,isBar,ota, (api_err, get_result) => {
                            if (api_err) {
                                log.error(api_err);
                                cb(api_err, null);
                            }
                            else {
                                otaDataList = get_result.data.rates;  
                                resolve();                      
                            }                            
                        });                
                    }),
                    new Promise((resolve, reject) => {               
                        RESTHelper.GET_OtaDemandData(Constants.Urls.OtaHotelDemands,demandUrl,otaOrgData[0].OTAInsightToken,otaHotelMappingData[0].OTASubscriptionID, (api_err, get_result) => {
                            if (api_err) {
                                log.error(api_err);
                                cb(api_err, null);
                            }
                            else {
                                otaDemandDataList = get_result.data.demands;
                                resolve();
                            }
                        });            
                    })
                ]).then(resp => {
                    let chartdata = [];
                    let unique = [];
                    let datelist = [];
                    for( let i = 0; i < otaDataList.length; i++ ){
                        if( !unique[otaDataList[i].arrivalDate]){
                            datelist.push(otaDataList[i].arrivalDate);
                            unique[otaDataList[i].arrivalDate] = 1;
                        }
                    }

                    datelist.forEach(function (item) {
                        let rateList =  otaDataList.filter(t=>t.arrivalDate == item && t.hotelId != otaHotelMappingData[0].OTAInsightHotelID);
                        let demandList = otaDemandDataList.filter(t=>t.arrivalDate == item);
                        let myHotelData = otaDataList.filter(t=>t.arrivalDate == item && t.hotelId == otaHotelMappingData[0].OTAInsightHotelID);

                        let date = moment(item).format('YYYY-MM-DD');
                        let demand;
                        if (demandList.length != 0)                        
                            demand = demandList[0].demand * 100;                        
                        else                        
                            demand = 0;
                        
                        let hotelrate = myHotelData[0].value;                    
                        let sumrate =   _.sumBy(rateList, 'value');
                        let avg = Utils.average(sumrate, rateList.length);
                        let avgcompsetrates = avg;
                        chartData.push({'date':date,'demand':demand,'hotelrate':hotelrate,'avgcompsetrates':avgcompsetrates});
                    })

                    cb(null, chartData);
                }, err => {
                    return cb(err);
                })
            }
            else{
               return cb(null, chartData);
            }            
        }, err => {
            return cb(err);
        })
    }

    static getOtaHotelData_GraphQL(userid, hotelid, currentdate, days, cb) {        
        return UserHelper.getUserConfigData(userid, (err, userdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getOtaHotelData(userid, hoteldata.ID,hoteldata.OrganizationID, currentdate, days, cb, (err, result) => {                  
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });       
    }
    //#endregion

    //#region Configs
    static GetConfigs_GraphQL(userid, cd) {

        UserHelper.getUserConfigData(userid, (err, result) => {
            if (err) {
                cd(err, null);
            }
            var objPropertyconfigdata = new Propertyconfigdata();
            objPropertyconfigdata.userid = userid;
            if (result) {
                objPropertyconfigdata.rollingrevenuecomparision = result.RollingRevenueComparision;
                objPropertyconfigdata.revenuebreakdowan = result.RevenueBreakdowan;
                objPropertyconfigdata.actvsbudvslastyr = result.ActVsBudVsLastYr;
                objPropertyconfigdata.adrvsrevpar = result.ADRVsRevPAR;
                objPropertyconfigdata.dashboardocc = result.DashboardOcc;
                objPropertyconfigdata.dashboardadr = result.DashboardADR;
                objPropertyconfigdata.dashboardrevpar = result.DashboardRevPAR;
                objPropertyconfigdata.membershipstays = result.MembershipStays;
                objPropertyconfigdata.dashboardmarketcurrentvslastyear = result.DashboardMarketCurrentVsLastYear;
                objPropertyconfigdata.cashwidget = result.CashWidget;
                objPropertyconfigdata.guestledgerwidget = result.GuestLedgerWidget;
                objPropertyconfigdata.payrollactualvsplanwidget = result.PayrollActualvsPlanWidget;
                objPropertyconfigdata.strwidget = result.STRWidget;
                objPropertyconfigdata.tripadvisorratingwidget = result.TripadvisorRatingWidget;
                objPropertyconfigdata.googleplaceratingwidget = result.GooglePlaceRatingWidget;
                objPropertyconfigdata.facebookpagewidget = result.FacebookPageWidget;
                objPropertyconfigdata.yelpreviewwidget = result.YelpReviewWidget;
                objPropertyconfigdata.weatherwidget = result.WeatherWidget;
                objPropertyconfigdata.aragingwidget = result.ARAgingWidgetv
                objPropertyconfigdata.gsspriority = result.GSSPriority;
                objPropertyconfigdata.ooocompwidget = result.OOOCompWidget;
                objPropertyconfigdata.totalprofit = result.TotalProfit;
                objPropertyconfigdata.totalexpensebreakdown = result.TotalExpenseBreakdown;
                objPropertyconfigdata.expensebudgetdepartment = result.ExpenseBudgetDepartment;
                objPropertyconfigdata.expensebudgetcategory = result.ExpenseBudgetCategory;
                objPropertyconfigdata.invoicevscreditcard = result.InvoicevsCreditcard;
                objPropertyconfigdata.expenseformbyglcode = result.ExpenseFormByGLCode;
            }
            cd(null, objPropertyconfigdata);
        });
    }
    static SaveConfigs_GraphQL(userid, rollingrevenuecomparision,
        revenuebreakdowan,
        actvsbudvslastyr,
        adrvsrevpar,
        dashboardocc,
        dashboardadr,
        dashboardrevpar,
        membershipstays,
        dashboardmarketcurrentvslastyear,
        cashwidget,
        guestledgerwidget,
        payrollactualvsplanwidget,
        strwidget,
        tripadvisorratingwidget,
        googleplaceratingwidget,
        facebookpagewidget,
        yelpreviewwidget,
        weatherwidget,
        aragingwidget,
        gsspriority,
        ooocompwidget,
        totalprofit,
        totalexpensebreakdown,
        expensebudgetdepartment,
        expensebudgetcategory,
        invoicevscreditcard,
        expenseformbyglcode, cd) {

        UserHelper.getUserConfigData(userid, (err, result) => {
            if (err) {
                cd(err, null);
            }
            var objPropertyconfigdata = new Propertyconfigdata();
            objPropertyconfigdata.userid = userid;
            objPropertyconfigdata.rollingrevenuecomparision = rollingrevenuecomparision;
            objPropertyconfigdata.revenuebreakdowan = revenuebreakdowan;
            objPropertyconfigdata.actvsbudvslastyr = actvsbudvslastyr;
            objPropertyconfigdata.adrvsrevpar = adrvsrevpar;
            objPropertyconfigdata.dashboardocc = dashboardocc;
            objPropertyconfigdata.dashboardadr = dashboardadr;
            objPropertyconfigdata.dashboardrevpar = dashboardrevpar;
            objPropertyconfigdata.membershipstays = membershipstays;
            objPropertyconfigdata.dashboardmarketcurrentvslastyear = dashboardmarketcurrentvslastyear;
            objPropertyconfigdata.cashwidget = cashwidget;
            objPropertyconfigdata.guestledgerwidget = guestledgerwidget;
            objPropertyconfigdata.payrollactualvsplanwidget = payrollactualvsplanwidget;
            objPropertyconfigdata.strwidget = strwidget;
            objPropertyconfigdata.tripadvisorratingwidget = tripadvisorratingwidget;
            objPropertyconfigdata.googleplaceratingwidget = googleplaceratingwidget;
            objPropertyconfigdata.facebookpagewidget = facebookpagewidget;
            objPropertyconfigdata.yelpreviewwidget = yelpreviewwidget;
            objPropertyconfigdata.weatherwidget = weatherwidget;
            objPropertyconfigdata.aragingwidget = aragingwidget;
            objPropertyconfigdata.gsspriority = gsspriority;
            objPropertyconfigdata.ooocompwidget = ooocompwidget;
            objPropertyconfigdata.totalprofit = totalprofit;
            objPropertyconfigdata.totalexpensebreakdown = totalexpensebreakdown;
            objPropertyconfigdata.expensebudgetdepartment = expensebudgetdepartment;
            objPropertyconfigdata.expensebudgetcategory = expensebudgetcategory;
            objPropertyconfigdata.invoicevscreditcard = invoicevscreditcard;
            objPropertyconfigdata.expenseformbyglcode = expenseformbyglcode;

            UserHelper.saveUserConfigData_Property(objPropertyconfigdata, (err, save_result) => {
                if (err) {
                    cd(err, null);
                }

                //move it to SQL server as well for sync
                if (config.appsettings.sync_to_SQLServer) {

                    //db write to SQL server and sync will handle the data in mangodb
                    var json_postdata = [];
                    json_postdata.userid = userid;
                    json_postdata.RollingRevenueComparision = objPropertyconfigdata.rollingrevenuecomparision;
                    json_postdata.RevenueBreakdowan = objPropertyconfigdata.revenuebreakdowan;
                    json_postdata.ActVsBudVsLastYr = objPropertyconfigdata.actvsbudvslastyr;
                    json_postdata.ADRVsRevPAR = objPropertyconfigdata.adrvsrevpar;
                    json_postdata.DashboardOcc = objPropertyconfigdata.dashboardocc;
                    json_postdata.DashboardADR = objPropertyconfigdata.dashboardadr;
                    json_postdata.DashboardRevPAR = objPropertyconfigdata.dashboardrevpar;
                    json_postdata.MembershipStays = objPropertyconfigdata.membershipstays;
                    json_postdata.DashboardMarketCurrentVsLastYear = objPropertyconfigdata.dashboardmarketcurrentvslastyear;
                    json_postdata.CashWidget = objPropertyconfigdata.cashwidget;
                    json_postdata.GuestLedgerWidget = objPropertyconfigdata.guestledgerwidget;
                    json_postdata.PayrollActualvsPlanWidget = objPropertyconfigdata.payrollactualvsplanwidget;
                    json_postdata.STRWidget = objPropertyconfigdata.strwidget;
                    json_postdata.TripadvisorRatingWidget = objPropertyconfigdata.tripadvisorratingwidget;
                    json_postdata.GooglePlaceRatingWidget = objPropertyconfigdata.googleplaceratingwidget;
                    json_postdata.FacebookPageWidget = objPropertyconfigdata.facebookpagewidget;
                    json_postdata.YelpReviewWidget = objPropertyconfigdata.yelpreviewwidget;
                    json_postdata.WeatherWidget = objPropertyconfigdata.weatherwidget;
                    json_postdata.ARAgingWidget = objPropertyconfigdata.aragingwidget;
                    json_postdata.GSSPriority = objPropertyconfigdata.gsspriority;
                    json_postdata.OOOCompWidget = objPropertyconfigdata.ooocompwidget;
                    json_postdata.TotalProfit = objPropertyconfigdata.totalprofit;
                    json_postdata.TotalExpenseBreakdown = objPropertyconfigdata.totalexpensebreakdown;
                    json_postdata.ExpenseBudgetDepartment = objPropertyconfigdata.expensebudgetdepartment;
                    json_postdata.ExpenseBudgetCategory = objPropertyconfigdata.expensebudgetcategory;
                    json_postdata.InvoicevsCreditcard = objPropertyconfigdata.invoicevscreditcard;
                    json_postdata.ExpenseFormByGLCode = objPropertyconfigdata.expenseformbyglcode;

                    //Config/UpdateProperty in SQL server
                    RESTHelper.POST(Constants.Urls.UpdatePropertyConfig, json_postdata, (api_err, sync_result) => {
                        if (api_err)
                            log.error(api_err);
                        log.debug(sync_result);
                    });
                }


                cd(null, objPropertyconfigdata);
            });
        });
    }
    //#endregion



    static UpdateConfigs_GraphQL(userid, configkey, configvalue, cd) {
        UserHelper.getUserConfigData(userid, (err, result) => {
            if (err) {
                cd(err, null);
            }
            var objPropertyconfigdata_update = new Propertyconfigdata();
            objPropertyconfigdata_update.userid = userid;

            UserHelper.saveUserConfigData_SingleProperty(objPropertyconfigdata_update, configkey, configvalue, (err, save_result) => {
                if (err) {
                    cd(err, null);
                }

                //move it to SQL server as well for sync
                if (config.appsettings.sync_to_SQLServer) {

                    //db write to SQL server and sync will handle the data in mangodb
                    var json_postdata = [];
                    json_postdata.userid = userid;
                    json_postdata.configkey = configkey;
                    json_postdata.configvalue = configvalue;

                    //Config/UpdateProperty in SQL server
                    RESTHelper.POST(Constants.Urls.UpdateSinglePropertyConfig, json_postdata, (api_err, sync_result) => {
                        if (api_err)
                            log.error(api_err);
                        log.debug(sync_result);
                    });
                }

                UserHelper.getUserConfigData(userid, (err, result) => {
                    if (err) {
                        cd(err, null);
                    }
                    var objPropertyconfigdata = new Propertyconfigdata();
                    objPropertyconfigdata.userid = userid;
                    if (result) {
                        objPropertyconfigdata.rollingrevenuecomparision = result.RollingRevenueComparision;
                        objPropertyconfigdata.revenuebreakdowan = result.RevenueBreakdowan;
                        objPropertyconfigdata.actvsbudvslastyr = result.ActVsBudVsLastYr;
                        objPropertyconfigdata.adrvsrevpar = result.ADRVsRevPAR;
                        objPropertyconfigdata.dashboardocc = result.DashboardOcc;
                        objPropertyconfigdata.dashboardadr = result.DashboardADR;
                        objPropertyconfigdata.dashboardrevpar = result.DashboardRevPAR;
                        objPropertyconfigdata.membershipstays = result.MembershipStays;
                        objPropertyconfigdata.dashboardmarketcurrentvslastyear = result.DashboardMarketCurrentVsLastYear;
                        objPropertyconfigdata.cashwidget = result.CashWidget;
                        objPropertyconfigdata.guestledgerwidget = result.GuestLedgerWidget;
                        objPropertyconfigdata.payrollactualvsplanwidget = result.PayrollActualvsPlanWidget;
                        objPropertyconfigdata.strwidget = result.STRWidget;
                        objPropertyconfigdata.tripadvisorratingwidget = result.TripadvisorRatingWidget;
                        objPropertyconfigdata.googleplaceratingwidget = result.GooglePlaceRatingWidget;
                        objPropertyconfigdata.facebookpagewidget = result.FacebookPageWidget;
                        objPropertyconfigdata.yelpreviewwidget = result.YelpReviewWidget;
                        objPropertyconfigdata.weatherwidget = result.WeatherWidget;
                        objPropertyconfigdata.aragingwidget = result.ARAgingWidgetv
                        objPropertyconfigdata.gsspriority = result.GSSPriority;
                        objPropertyconfigdata.ooocompwidget = result.OOOCompWidget;
                        objPropertyconfigdata.totalprofit = result.TotalProfit;
                        objPropertyconfigdata.totalexpensebreakdown = result.TotalExpenseBreakdown;
                        objPropertyconfigdata.expensebudgetdepartment = result.ExpenseBudgetDepartment;
                        objPropertyconfigdata.expensebudgetcategory = result.ExpenseBudgetCategory;
                        objPropertyconfigdata.invoicevscreditcard = result.InvoicevsCreditcard;
                        objPropertyconfigdata.expenseformbyglcode = result.ExpenseFormByGLCode;
                    }
                    cd(null, objPropertyconfigdata);
                });

            });
        });
    }

    //#region Property Dashboard Table
    static getPropertyDashboardTable(userId, hotelid, currentDate, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let yeasterday = new Date(currentDate);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
        let tableRowmappingsData = [];
        let tableColummappingsData = [];
        let TableData = [];

        return Promise.all([
            new Promise((resolve, reject) => {
                CreateowntablemappingsHelper.GetCreateOwnTableMappingList(userId,Constants.DashboardTableName.PropertyRowName, (err, createpropertytablemappings_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (createpropertytablemappings_result[0].kpicolumn) {
                        tableRowmappingsData = createpropertytablemappings_result[0].kpicolumn;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                CreatePropertyDashboardTableMappingHelper.GetPropertyDashboardTableMapping(userId, (err, tablemappings_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (tablemappings_result) {
                        tableColummappingsData = tablemappings_result;
                    }
                    resolve();
                });
            })
        ]).then(resp => {

            if(tableRowmappingsData.length > 0){
                tableRowmappingsData.forEach(async (rowItem, index) => {
                    let rowName = rowItem.CreateOwnTableMasterData.KPIKey;
                    let ColumnValueDate = [];
                    let objRow = new PropertyTableRowData();

                    PropertyHelper.getTableColumndata(rowName, tableColummappingsData, currentDate, hotelid, ColumnValueDate_result  => {
                     
                        objRow.rowname = rowItem.CreateOwnTableMasterData.ColumName;
                        objRow.rowdata = ColumnValueDate_result;
                        TableData.push(objRow);

                        if (tableRowmappingsData.length == TableData.length)
                            return cb(null, TableData);
                    });
                });
            }
            else{
                return cb(null, TableData);
            }
        }, err => {
            return cb(err);
        })
    }

    static getTableColumndata(rowName, tableColummappingsData, currentDate, hotelid, cb) {

        let yeasterday = new Date(currentDate);
        let startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        let enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
        let lastYear = Utils.sameDayLastYear(yeasterday);
        let lastYearMTD = new Date(yeasterday.getFullYear()-1, yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);

        let stLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
        let etLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 23, 59, 59);
        let stLyMtd = new Date(lastYearMTD.getFullYear(), lastYearMTD.getMonth(), lastYearMTD.getDate(), 0, 0, 0);
        let etLyMtd = new Date(lastYearMTD.getFullYear(), lastYearMTD.getMonth(), lastYearMTD.getDate(), 23, 59, 59);
        
        let ColumnValueDate = [];
        let hoteldashboardcalculationsData = [];
        let hotelbudgetdashboardcalculationsData = [];
        let hotelLYcalculationsData = [];
        let hotelLYbudgetData = [];
        let cnt = tableColummappingsData.length;
        // return new Promise((resolve, reject) => {
      
            tableColummappingsData.forEach((colItem, index) => {

                if (colItem.columperiod == 'Current' || colItem.columperiod == 'MTD' || colItem.columperiod == 'YTD' || colItem.columperiod == 'TTM') {
                    startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                    enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
                }
                else if (colItem.columperiod == 'CurrentMonth') {
                    // startdate = Utils.firstDayOfMonth(yeasterday);
                    // enddate = Utils.lastDayOfMonth(yeasterday);
                    startdate = Utils.lastDayOfMonth(yeasterday);
                    enddate = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate(), 23, 59, 59);
                }
                else if (colItem.columperiod == 'QTD') {
                    let now = new Date();
                    let quarter = Math.floor((now.getMonth() / 3));
                    startdate = new Date(now.getFullYear(), quarter * 3, 1);
                    enddate = new Date(startdate.getFullYear(), startdate.getMonth() + 3, 0);

                    stLy = new Date(startdate.getFullYear()-1, startdate.getMonth(), startdate.getDate(), 0, 0, 0);
                    etLy = new Date(stLy.getFullYear(), stLy.getMonth()+ 3, stLy.getDate(), 23, 59, 59);
                }
                else {
                    let month = parseInt(colItem.columperiod.substr(1));
                    if (colItem.columperiod.includes('+')) {
                        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth() + month, yeasterday.getDate(), 23, 59, 59);
                        stLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
                        etLy = new Date(lastYear.getFullYear(), lastYear.getMonth()+ month, lastYear.getDate(), 23, 59, 59);
                    }
                    else {
                        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth() - month, yeasterday.getDate(), 0, 0, 0);
                        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
                        stLy = new Date(lastYear.getFullYear(), lastYear.getMonth() - month, lastYear.getDate(), 0, 0, 0);
                        etLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 23, 59, 59);
                    }
                }

                Promise.all([
                    new Promise((resolve, reject) => {
                        HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, hoteldashboardcalculations_result) => {
                            
                            if (hoteldashboardcalculations_result) {
                                hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                            }
                            resolve();
                        });
                    }),
                    new Promise((resolve, reject) => {
                        HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, hotelbudgetdashboardcalculations_result) => {
                            
                            if (hotelbudgetdashboardcalculations_result) {
                                hotelbudgetdashboardcalculationsData = hotelbudgetdashboardcalculations_result;
                            }
                            resolve();
                        });
                    }),
                    new Promise((resolve, reject) => {
                        if (colItem.columname == 'LastYear' || colItem.columname == 'VarianceToLastYear'){
                            if(colItem.columperiod == 'MTD' || colItem.columperiod == 'YTD' || colItem.columperiod == 'TTM'){
                                HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, stLyMtd, etLyMtd, (err, hotel_result) => {
                                   
                                    if (hotel_result) {
                                        hotelLYcalculationsData = hotel_result;
                                    }
                                    resolve();
                                });
                            }
                            else{
                                HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, stLy, etLy, (err, hoteldashboardcalculations_result) => {
                                    
                                    if (hoteldashboardcalculations_result) {
                                        hotelLYcalculationsData =  hoteldashboardcalculations_result;
                                    }
                                    resolve();
                                });
                            }
                        }else{ resolve();}
                    }),
                    new Promise((resolve, reject) => {
                        if (colItem.columname == 'LastYear' || colItem.columname == 'VarianceToLastYear'){
                        if(colItem.columperiod == 'MTD' || colItem.columperiod == 'YTD' || colItem.columperiod == 'TTM'){
                            HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(hotelid, stLyMtd, etLyMtd, (err, hotelbudgetdashboardcalculations_result) => {
                                
                                if (hotelbudgetdashboardcalculations_result) {
                                    hotelLYbudgetData = hotelbudgetdashboardcalculations_result;
                                }
                                resolve();
                            });
                        }
                        else {
                            HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(hotelid, stLy, etLy, (err, hotelbudgetdashboardcalculations_result) => {
                                
                                if (hotelbudgetdashboardcalculations_result) {
                                    hotelLYbudgetData = hotelbudgetdashboardcalculations_result;
                                }
                                resolve();
                            });
                        }
                    }else{ resolve();}
                    }),
                ]).then(resp => {
                    let rowCatName = '';
                    let rowBudgetCatName = '';
                    let rowForecastCatName = '';
                    let ColumPeriod = '';
                    let sumActual = 0;
                    let sumBudget = 0;
                    let sumForecast = 0;
                    let columnvalue = 0;
                    let smactual = 0;
                    let smbudget = 0;
                    let smforcast = 0;
                    let smactually = 0;
                    let sumActually =0;
                    let objColum = new PropertyTableColumData();
                    if (colItem.columperiod == 'Current' || colItem.columperiod == 'CurrentMonth' ||colItem.columperiod == 'MTD' || colItem.columperiod == 'YTD' || colItem.ColumPeriod == 'TTM') {
                        ColumPeriod = colItem.columperiod == ('Current' || 'CurrentMonth') ? '' : colItem.columperiod;
                        rowCatName = rowName + ColumPeriod;
                        rowBudgetCatName = (colItem.columperiod == ('Current' || 'CurrentMonth') ? 'Budget' : colItem.columperiod) + rowName;
                        rowForecastCatName = (colItem.columperiod == 'Current' ? '' : colItem.columperiod) + 'Forecast' + rowName;
                    }
                    else {
                        rowCatName = rowName;
                    }

                    if (colItem.columname == 'Actual') {
                        smactual = _.sumBy(hoteldashboardcalculationsData, rowCatName);
                        columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                    }
                    else if (colItem.columname == 'Budget') {
                        smbudget = _.sumBy(hotelbudgetdashboardcalculationsData, rowBudgetCatName);
                        columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                    }
                    else if (colItem.columname == 'Forecast') {
                        smforcast = _.sumBy(hotelbudgetdashboardcalculationsData, rowForecastCatName);
                        columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                    }
                    else if (colItem.columname == 'LastYear') {
                        smactually = _.sumBy(hotelLYcalculationsData, rowCatName);
                        columnvalue = parseFloat(smactually == null ? 0 : smactually).toFixed(2);
                    }
                    else if (colItem.columname == 'VarianceToLastYear') {
                        smactual = _.sumBy(hoteldashboardcalculationsData, rowCatName);
                        smactually = _.sumBy(hotelLYcalculationsData, rowCatName);
                        sumActual = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                        sumActually = parseFloat(smactually == null ? 0 : smactually).toFixed(2);
                        columnvalue = (sumActual - sumActually);
                    }
                    else if (colItem.columname == 'VarianceToBudget') {
                        smactual = _.sumBy(hoteldashboardcalculationsData, rowCatName);
                        smbudget = _.sumBy(hotelbudgetdashboardcalculationsData, rowBudgetCatName);
                        sumActual = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                        sumBudget = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                        columnvalue = (sumActual - sumBudget);
                    }
                    else if (colItem.columname == 'VarianceToForecast') {
                        smactual = _.sumBy(hoteldashboardcalculationsData, rowCatName);
                        smforcast = _.sumBy(hotelbudgetdashboardcalculationsData, rowForecastCatName);
                        sumActual = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                        sumForecast = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                        columnvalue = (sumActual - sumForecast);
                    }
                    objColum.columnvalue = columnvalue;
                    objColum.columnname = colItem.columname;
                    objColum.columnperiod = colItem.columperiod;
                    ColumnValueDate.push(objColum);

                    if (cnt == ColumnValueDate.length) {
                        return cb(ColumnValueDate);
                    }
                })
            });
       
        // });     
    }
    static getPropertyDashboardTable_GraphQL(userid, hotelid, currentDate, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    PropertyHelper.getPropertyDashboardTable(userid, hoteldata.ID, currentDate, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }

    static addKPIColumns(userid, columlist) {

        let lstkpilistdatamodel = [];
        var counter = columlist.length;
        return new Promise((resolve, reject) => {
            if (columlist != undefined && columlist.length > 0) {
                var displayordercounter = 1;
                CreatePropertyDashboardTableMappingHelper.GetPropertyDashboardTableMapping(userid, (err, createpropertytablemappings_result) => {
                    if (createpropertytablemappings_result.length>0) {
                        var lastrec = createpropertytablemappings_result[createpropertytablemappings_result.length - 1];
                        displayordercounter = lastrec.displayorder + 1;
                    }
                    columlist.forEach(function (item) {
                        CreatePropertyDashboardTableMappingHelper.addPropertyTableColumns(userid, item.columname, item.columperiod, displayordercounter, (err, addcolum_result) => {
                            if (!err) {
                                lstkpilistdatamodel.push(addcolum_result);
                            }
                            counter = counter - 1;
                            if (counter == 0) {
                                resolve(lstkpilistdatamodel);
                            }
                        });
                        displayordercounter = displayordercounter + 1;
                    });
                });
            }

        });
    }

    static removeTableColumns(userid, columname, columperiod, cb) {
        var kpiListData = [];
        return CreatePropertyDashboardTableMappingHelper.removePropertyTableColumn(userid, columname, columperiod, (err, kpilist_result) => {

            if (kpilist_result) {
                kpiListData = kpilist_result;
                CreatePropertyDashboardTableMappingHelper.GetPropertyDashboardTableMapping(userid, (err, tablecolumn_result) => {
                    if (tablecolumn_result) {
                        //re-order the display order 
                        PropertyHelper.reorderTableColumn(tablecolumn_result, userid, columname, columperiod).then(kpilist_result => {

                            cb(null, kpiListData);
                        });
                    }
                });
            }
            cb(null, kpiListData);
        });
    }
    static removeTableColumns_GraphQL(userid, columname, columperiod, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            if (!userconfigdata) {
                cb(null, null);
            }
            else {
                PropertyHelper.removeTableColumns(userid, columname, columperiod, cb, (err, result) => {
                    if (err) {
                        cb(err, null);
                    }
                    cb(null, result);
                });
            }
        });
    }

    static addKPIColumns_GraphQL(userid, columlist, cb) {
        var kpiListData = [];
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            if (!userconfigdata) {
                cb(null, null);
            }
            else {
                PropertyHelper.addKPIColumns(userid, columlist).then(kpilist_result => {
                    if (kpilist_result) {
                        kpiListData = kpilist_result;
                        cb(null, kpiListData);
                    }
                });
            }
        });
    }

    static getColumnMasterListData(userid, cb) {
        var tableColummappingsData = [];
        return CreatePropertyDashboardTableMappingHelper.GetPropertyDashboardTableMapping(userid, (err, tablemappings_result) => {
            if (err) {
                reject(err);
            }
            if (tablemappings_result) {
                tableColummappingsData = tablemappings_result;
            }
            cb(null, tableColummappingsData);
        });
    }

    static getColumnMasterListData_GraphQL(userid, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            if (!userconfigdata) {
                cb(null, null);
            }
            else {
                PropertyHelper.getColumnMasterListData(userid, cb, (err, result) => {
                    if (err) {
                        cb(err, null);
                    }
                    cb(null, result);
                });
            }
        });
    }

    static reorderTableColumn(columist_temp, userid, columname, columperiod) {

        let lstkpilistdatamodel = [];
        var counter = columist_temp.length;
        return new Promise((resolve, reject) => {
            if (columist_temp != undefined && columist_temp.length > 0) {
                var displayordercounter = 1;
                columist_temp.forEach(function (item) {
                    CreatePropertyDashboardTableMappingHelper.reorderTableColumn(userid, item.columname, item.columperiod, displayordercounter, (err, column_result) => {
                        if (!err) {
                            lstkpilistdatamodel.push(column_result);
                        }
                        counter = counter - 1;
                        if (counter == 0) {
                            resolve(lstkpilistdatamodel);
                        }
                    });
                    displayordercounter = displayordercounter + 1;
                });
            }

        });
    }

    static reorderTableColumns(userid, kpilist, columname, columperiod, cb) {

        //get user information 
        UserHelper.getUserData(userid, (err, userinfo) => {

            if (err) {
                log.error(err);
            }
            if (!userinfo) {
                cb(null, null);
            }
            else {
                var tablename = Constants.DashboardTableName.Portfolio;

                var lstkpidata = [];

                var kpilistjson = [];

                kpilist.forEach((element, index) => {
                    kpilistjson.push({ KPIKey: element, Order: index });
                });



                //get CreateOwnTableMasterID by names first
                PortfolioHelper.getKPIData(kpilistjson, tablename).then(lstkpidata_result => {
                    if (lstkpidata_result) {
                        lstkpidata = lstkpidata_result;
                        lstkpidata = Utils.sort(lstkpidata, "Order");
                    }
                    //re-order the display order 
                    PortfolioHelper.reorderKPIColumn(lstkpidata, userid, tablename).then(kpilist_result => {
                        if (kpilist_result) {
                            kpilist_result = Utils.sort(kpilist_result, "DisplayOrder");
                        }

                        cb(null, kpilist_result);
                    });

                });


            }
        });
    }

    static reorderTableColumns_GraphQL(userid, kpilist, columname, columperiod, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            if (!userconfigdata) {
                cb(null, null);
            }
            else {
                PropertyHelper.reorderTableColumns(userid, kpilist, columname, columperiod, cb, (err, result) => {
                    if (err) {
                        cb(err, null);
                    }

                    cb(null, result);
                });
            }
        });
    }

    static updatetablecolumn_GraphQL(userid, oldcolumname, oldcolumperiod, newcolumname, newcolumperiod, cb) {
        return CreatePropertyDashboardTableMappingHelper.updateTableColumn(userid, oldcolumname, oldcolumperiod, newcolumname, newcolumperiod, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });

    }

    static getTableColumnLookupData_GraphQL(tablename, cb) {
        return CreateowntablemappingsHelper.getColumnMasterListData(tablename, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    //#endregion
    
    //#region Property Chart config

    static getPropertyChartConfigByUserId_GraphQL(userid, cb) {
        return CreatePropertyDashboardTableMappingHelper.getPropertyChartConfigByUserId(userid, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static deletePropertyChartConfig_GraphQL(id, cb) {
        CreatePropertyDashboardTableMappingHelper.deletePropertyChartConfig(id, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static createOrUpdatePropertyChartConfig_GraphQL(id,userid, widgetname, charttype, chartperiod,comparechartdata, cb) {
        CreatePropertyDashboardTableMappingHelper.createOrUpdatePropertyChartConfig(id,userid, widgetname, charttype, chartperiod,comparechartdata, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }

    static getPropertyChartConfigById_GraphQL(id, cb) {
        return CreatePropertyDashboardTableMappingHelper.getPropertyChartConfigById(id, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    //#endregion
    
    //#getallmissingdateslastdays
    static getAllMissingDatesLastDays(hotelid,currentdate,period,roomrevenue,otherrevenue,cd){
        let retValue = new MissingDatesContentModel()
        hotelid = (hotelid==null?"0":hotelid);
        currentdate = (currentdate==null?new Date():currentdate);
        period = (period==null?"7":period);
        let intperiod = parseInt(period);
        let daysMinus = (-1) * intperiod + 1;
        let yeasterday = new Date(Utils.getFormattedDate(currentdate,"YYYY-MM-DD"));
        let previousday = new Date(Utils.addDays(yeasterday,daysMinus));
        let startdate =  new Date(Utils.getFormattedDate(previousday,"YYYY-MM-DD"));
        let enddate = Utils.endofDay(yeasterday);
        let y = new Promise((resolve,reject)=>{
            MissingDatesHelper.getMissingDates(hotelid,startdate,enddate,(err,missingdates)=>{
                if (err) {
                    log.debug("Property Missing Dates for last year not available");
                    cb(err, null);
                }
                resolve(missingdates)
            })
        })

        y.then(missingdates=>{
            
            if(missingdates.length>0){
                let hotel = new Promise((resolve,reject)=>{
                    HotelsHelper.GetLaborHouseKeeping(hotelid,(err,hoteldata)=>{
                        resolve(hoteldata)
                    })
                })
                hotel.then(hoteldata=>{
                    let roomRevenuedata=[]; 
                    let FBOtherdata = [];
                    _.filter(missingdates,(element)=>{
                        if(element.Category==roomrevenue){
                            roomRevenuedata.push(element)
                        }
                    });
                    _.filter(missingdates,(element)=>{
                        if(element.Category==otherrevenue){
                            FBOtherdata.push(element)
                        }
                    });                    
                   

                    let revenuedata = new Promise((resolve,reject)=>{
                        if(roomRevenuedata!=null){
                            
                            PropertyHelper.DatesToStringWithoutLinkNew(roomRevenuedata,hoteldata.ID,(err,linkdata)=>{
                                retValue.RoomRevenue = linkdata;
                                resolve(retValue)
                            })
                        }else{
                            log.debug("Room Revenue category not available");
                            resolve(retValue)
                        }
                    })
                    revenuedata.then(retValue=>{
                       
                        let otherfoodandbeveragesdata = new Promise((resolve,reject)=>{
                            if(hoteldata!=null && hoteldata[0].IsMissingDateOtherRevenueEnabled==true){
                                if(FBOtherdata!=null){
                                    PropertyHelper.DatesToStringWithoutLinkNew(FBOtherdata,hoteldata.ID,(err,linkdata)=>{
                                        retValue.OtherFNBRevenue = linkdata;
                                        resolve(retValue)
                                    })
                                }else{
                                    log.debug("Other/F&B Revenue category not available");
                                    resolve(retValue)
                                }
                            }else{
                                log.debug("hotel data for missing date other revenue not enabled ");
                                resolve(retValue)
                            }

                        })

                        otherfoodandbeveragesdata.then(retValue=>{
                            cd(null,retValue)
                        })

                    })
                })

            }else{
                log.debug("No missing dates available");
                cd(null,retValue) 
            }
            
        })


    }
    static DatesToStringWithoutLinkNew(lstmissingDates,hotelid,cd){
        let retValue = "";
        if(lstmissingDates!=null && lstmissingDates.length>0){
            _.filter(lstmissingDates,(element)=>{
                element['month'] = Utils.getFormattedDate(element.Date,"MMM");
            })
            
            let query = _.map(_.groupBy(lstmissingDates, 'month'), (element, idx) => { return { Month: idx, Date: element} });
            
            _.filter(query,(key)=>{
                retValue = retValue + key.Month + " - ";
                
                _.filter(key.Date,(i)=>{
                    retValue = retValue + Utils.getFormattedDate(i.Date,"DD") + ", ";
                })
            })
            
            cd(null,retValue)
        }else{
            log.debug("category data not available");
            cd(null,retValue)
        }
    }
    static getMissingDatesCash(hotelid,currentdate,period,cd){
        let lstmissingDates = "";
        hotelid = (hotelid==null?"0":hotelid);
        currentdate = (currentdate==null?new Date():currentdate);
        period = (period==null?"current":period);
        let startdate=new Date(Utils.getFormattedDate(new Date(),"YYYY-MM-DD"));
        let enddate = Utils.endofDay(new Date());
        let yeasterday = currentdate;
        if(period.toLowerCase()=="current" || period==null){
            startdate = new Date(Utils.getFormattedDate(yeasterday,"YYYY-MM-DD"));
            enddate = Utils.endofDay(yeasterday);
        }
        
            let y = new Promise((resolve,reject)=>{
                HotelrevenueSchema.find({
                    [HotelrevenueSchemaFields.HotelID]:hotelid,
                    [HotelrevenueSchemaFields.IsDelete]:false,
                    [HotelrevenueSchemaFields.Date]:{
                        $gte:startdate,
                        $lte:enddate
                    },
                    [HotelrevenueSchemaFields.Category]:Constants.RevenueType.Cash}).exec((err,cashdata)=>{
                        if (err) {
                            log.debug("Property Missing Dates cash not available");
                            cb(err, null);
                        }
                        resolve(cashdata)
                    })
                
            })
            y.then(cashdata=>{               
                let missingdates = [];    
                for (let dt = startdate; dt <= enddate; dt = new Date(Utils.addDays(dt,1))) {
                    let data = _.find(cashdata, ['Date', dt]);
                    (data == null ? missingdates.push({'date':dt}) : '');
                }
                _.filter(missingdates,(element)=>{
                    element['month'] = Utils.getFormattedDate(element.date,"MMM");
                })
                let query = _.map(_.groupBy(missingdates, 'month'), (element, idx) => { return { key: idx,data:element} });
                _.filter(query,(element)=>{
                    lstmissingDates = lstmissingDates + element.key + "-";

                    _.filter(element.data,(element)=>{
                        lstmissingDates = lstmissingDates + Utils.getFormattedDate(element.date,"DD") + ",";
                    })
                })
                cd(null,[{"missingdates":lstmissingDates}])
            })
        }
    static getMissingDatesARAging(hotelid,currentdate,period,cd){
        let lstmissingDates = "";
        hotelid = (hotelid==null?"0":hotelid);
        currentdate = (currentdate==null?new Date():currentdate);
        let startdate=new Date(Utils.getFormattedDate(new Date(),"YYYY-MM-DD"));
        let enddate = Utils.endofDay(new Date());
        let yeasterday = currentdate;
        period = period.toLowerCase();
        if (period == "mtd") {
            startdate = new Date(Utils.firstDayOfMonth(yeasterday));                
            enddate = Utils.endofDay(yeasterday);
        }
        else if (period == "ytd") {
            startdate = new Date(Utils.firstDayOfYear(yeasterday))
            enddate = Utils.endofDay(yeasterday);
        }
        else if (period == "ttm") {
            startdate = Utils.firstDayOfMonth(yeasterday);
            startdate = Utils.lastYearDate(startdate);

            enddate = Utils.firstDayOfMonth(yeasterday);
            enddate.setDate(startdate.getDate() - 1);
        }
        else {
            startdate=new Date(Utils.getFormattedDate(yeasterday,"YYYY-MM-DD"));
            enddate = Utils.endofDay(yeasterday);
        }
        let y = new Promise((resolve,reject)=>{
            HotelaragingSchema.find({[HotelaragingSchemaFields.HotelID]:hotelid,
                [HotelaragingSchemaFields.Date]:{$gte:startdate,$lte:enddate}}).exec((err,aragingdata)=>{
                    resolve(aragingdata)
                })
        })
        y.then(aragingdata=>{
            let missingdates = [];    
            for (let dt = startdate; dt <= enddate; dt = new Date(Utils.addDays(dt,1))) {
                let data = _.find(aragingdata, ['Date', dt]);
                (data == null ? missingdates.push({'date':dt}) : '');
            }
            _.filter(missingdates,(element)=>{
                element['month'] = Utils.getFormattedDate(element.date,"MMM");
            })
            let query = _.map(_.groupBy(missingdates, 'month'), (element, idx) => { return { key: idx,data:element} });
            _.filter(query,(element)=>{
                lstmissingDates = lstmissingDates + element.key + "-";

                _.filter(element.data,(element)=>{
                    lstmissingDates = lstmissingDates + Utils.getFormattedDate(element.date,"DD") + ",";
                })
            })
            cd(null,[{"missingdates":lstmissingDates}])
        })

    }
    

}

module.exports = PropertyHelper;