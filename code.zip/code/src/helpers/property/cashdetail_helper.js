const HotelsHelper = require('../hotels_helper');
const HotelsRevenueHelper = require('../hotelrevenue_helper');
const { Categorydescriptionmapping:categorydescriptionmappingSchema , SchemaField: categorydescriptionmappingSchemaFields } = require('../../models/categorydescriptionmapping');
const Cashdetaildata = require('../../property/models/cashdetaildata');
const Cashtabledata =require('../../property/models/cashtabledata');
const Constants = require('../../common/constants');
const Utils = require('../../common/utils');
const moment = require('moment');
const _ = require('lodash');

const UserHelper = require('../user_helper');
var log = require('log4js').getLogger("CashDetailHelper");

class CashDetailHelper {    
    static getCashDetailData(userdata,hotelid,currentDate, period, customEndDate, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let st = new Date();
        let et = new Date();
        let yeasterday  = new Date(currentDate);
        let lastYear = Utils.lastYearDate(yeasterday);
        let hotelsData = [];
        let descriptionList =[];
        let hotelrevenuesData =[];
        if(period.toLowerCase()=="current"){
            startdate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),0 ,0,0);
            enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),23,59,59);

            st = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
            et = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 23, 59, 59);

        }else if (period.toLowerCase()=="mtd")
        {
            // DateTime yeasterday = DateTime.Now.AddDays(-1);
            startdate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),1,0,0,0);
            enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate()+1,23,59,59);

            //DateTime lastYear = DateTime.Now.AddYears(-1).AddDays(-1);
            st = new Date(lastYear.getFullYear(),lastYear.getMonth(),1,0,0,0);
            et = new Date(lastYear.getFullYear(),lastYear.getMonth(),lastYear.getDate(),23,59,59);        

        }else if (period.toLowerCase()=="ytd")
        {
            // DateTime yeasterday = DateTime.Now.AddDays(-1);
            startdate = new Date(yeasterday.getFullYear(),1,1,0,0,0);
            enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate()+1,23,59,59);

            //DateTime lastYear = DateTime.Now.AddYears(-1).AddDays(-1);
            st = new Date(lastYear.getFullYear(),1,1,0,0,0);
            et = new Date(lastYear.getFullYear(),lastYear.getMonth(),lastYear.getDate(),23,59,59);        

        }
        else if (period.toLowerCase()=="ttm")
        {
            var result = Utils.GetTTMDates(yeasterday);
            startdate = result[0];
            enddate =result[1];
            st = Utils.lastYearDate(startdate);
            et = Utils.lastYearDate(enddate);          
        }
        else if(period.toLowerCase()=="custom"){
            let edate  = new Date(customEndDate);
            let lastYearEDate = Utils.lastYearDate(edate);
            startdate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),0 ,0,0);
            enddate = new Date(edate.getFullYear(),edate.getMonth(),edate.getDate(),23,59,59);

            st = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
            et = new Date(lastYearEDate.getFullYear(), lastYearEDate.getMonth(), lastYearEDate.getDate(), 23, 59, 59);

        }
        return Promise.all([
            new Promise((resolve, reject) => {
                // get hotels data
                HotelsHelper.GetData(hotelid, (err, hotels_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotels_result.length >0) {
                        hotelsData = hotels_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get HotelsRevenue data
                HotelsRevenueHelper.GetCashData(hotelid, startdate, enddate, (err, hotelrevenues_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelrevenues_result) {
                        hotelrevenuesData = hotelrevenues_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // Get Hotel Revenue Cash Description
                categorydescriptionmappingSchema.distinct("Description",
                    {[categorydescriptionmappingSchemaFields.HotelID]: hotelid,
                    [categorydescriptionmappingSchemaFields.IsActive]: true,
                    [categorydescriptionmappingSchemaFields.Category]:"Cash"
                    }).exec(function (err, result) {
                        if (err) { reject(err);}
                        descriptionList = result;

                         //for normal cash
                        descriptionList.push("bank deposits");
                        descriptionList.push("GUEST REFUND: GR");
                        resolve()
                })                
            })
        ]).then(resp => {
            let lstCashDetaildata = [];
            let lstCashDetails = [];
            let hotelname = '';
            let organizationId = 0; 
            let organizationName = '';
            let hotelid =0;
            if(hotelsData.length > 0)
            {
                hotelname = hotelsData[0].HotelName;
                organizationId = hotelsData[0].OrganizationId;  
                organizationName = hotelsData[0].CompanyName[0].CompanyName;
                hotelid = hotelsData[0].ID;
            }
          
            while (startdate <= enddate) {
                let dt = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate())
                let objCash  = new Cashdetaildata();
                objCash.dmrasubtype = "Cash";
                objCash.date = moment(dt).format('ll');
                objCash.hotelid = hotelid;
                objCash.hotelname = hotelname;
                objCash.ishotelgroup = false;
                objCash.orgId = organizationId;
                objCash.organisationname = organizationName;
                if(hotelrevenuesData.length > 0)
                {
                let obj = [];
                hotelrevenuesData.forEach(element=>{
                    if(new Date(element.Date).setHours(0, 0, 0, 0)>=dt && new Date(element.Date).setHours(0, 0, 0, 0) <= dt ){
                        obj.push(element);
                    
                    }
                })
                
                if (obj.length > 0) {
                    let todaycash = 0;
                    let cash = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('cash') >=0 
                        || v.Description.toLowerCase().indexOf('check') >=0
                        && v.Description.toLowerCase().indexOf('pos') <=0
                        && v.Description.toLowerCase().indexOf('f&b') <=0
                        && v.Description.toLowerCase().indexOf('refund') <=0
                        && v.Description.toLowerCase().indexOf('touch') <=0)                                 
                        return true; else false;
                    });
                    cash.forEach(function (i) { todaycash += i.Amount })

                    //Also Get Cash Description mapping and add it to total
                    if(descriptionList.length > 0)
                    {
                        descriptionList.forEach(function (i) {
                            let temp = obj.filter(d=>{return d.Description == i})
                            temp.forEach(function (x) { todaycash += x.Amount })
                        })
                    }
                    objCash.cash = todaycash;

                    let todayotherCash =0;
                    let otherCash = obj.filter(d=>{return d.Description == "other bank"});
                    otherCash.forEach(function (x) { todayotherCash += x.Amount });
                    objCash.othercash = todayotherCash;

                    let todayrefundCash =0;
                    let refundcash = obj.filter(d=>{return d.Description == "refund cash"});
                    refundcash.forEach(function (x) { todayrefundCash += x.Amount });
                    objCash.refundcash = todayrefundCash;

                    let todayamex =0;
                    let amex = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('american') >=0 
                        || v.Description.toLowerCase().indexOf('amex') >=0
                        && v.Description.toLowerCase().indexOf('pos') <=0
                        && v.Description.toLowerCase().indexOf('f&b') <=0
                        && v.Description.toLowerCase().indexOf('touch') <=0)                                 
                        return true; else false;
                    });                            
                    amex.forEach(function (x) { todayamex += x.Amount });
                    objCash.amex = todayamex;

                    let todayvisa =0;
                    let visa = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('visa') >=0 
                        && v.Description.toLowerCase().indexOf('pos') <=0
                        && v.Description.toLowerCase().indexOf('f&b') <=0
                        && v.Description.toLowerCase().indexOf('touch') <=0)                                 
                        return true; else false;
                    });                            
                    visa.forEach(function (x) { todayvisa += x.Amount });
                    objCash.visa = todayvisa;

                    let todaymc =0;
                    let mc = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('master') >=0 
                        && v.Description.toLowerCase().indexOf('pos') <=0
                        && v.Description.toLowerCase().indexOf('f&b') <=0
                        && v.Description.toLowerCase().indexOf('visa') <=0)                                 
                        return true; else false;
                    });                            
                    mc.forEach(function (x) { todaymc += x.Amount });
                    objCash.mc = todaymc;

                    let todaydinersCard =0;
                    let dinersCard = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('diners') >=0 
                        && v.Description.toLowerCase().indexOf('pos') <=0
                        && v.Description.toLowerCase().indexOf('f&b') <=0
                        && v.Description.toLowerCase().indexOf('touch') <=0)                                 
                        return true; else false;
                    });                            
                    dinersCard.forEach(function (x) { todaydinersCard += x.Amount });
                    objCash.dinerscard = todaydinersCard;

                    let todaydiscoverCard =0;
                    let discoverCard = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('discover') >=0 
                        && v.Description.toLowerCase().indexOf('pos') <=0
                        && v.Description.toLowerCase().indexOf('f&b') <=0
                        && v.Description.toLowerCase().indexOf('touch') <=0)                                 
                        return true; else false;
                    });                            
                    discoverCard.forEach(function (x) { todaydiscoverCard += x.Amount });
                    objCash.discovercard = todaydiscoverCard

                    let todaydebit =0;
                    let debit = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('debit') >=0 
                        && v.Description.toLowerCase().indexOf('pos') <=0
                        && v.Description.toLowerCase().indexOf('f&b') <=0
                        && v.Description.toLowerCase().indexOf('touch') <=0)                                 
                        return true; else false;
                    });                            
                    debit.forEach(function (x) { todaydebit += x.Amount });
                    objCash.debit = todaydebit

                    let todayeft =0;
                    let eft = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('eft') >=0 
                        && v.Description.toLowerCase().indexOf('pos') <=0
                        && v.Description.toLowerCase().indexOf('f&b') <=0
                        && v.Description.toLowerCase().indexOf('touch') <=0)                                 
                        return true; else false;
                    });                            
                    eft.forEach(function (x) { todayeft += x.Amount });
                    objCash.eft = todayeft

                    let todaycashpos =0;
                    let poscash = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('cash') >=0 
                        && v.Description.toLowerCase().indexOf('pos') >=0
                        || v.Description.toLowerCase().indexOf('f&b') >=0
                        || v.Description.toLowerCase().indexOf('touch') >=0)                                 
                        return true; else false;
                    });                            
                    poscash.forEach(function (x) { todaycashpos += x.Amount });
                    objCash.poscash = todaycashpos

                    let todayposamex =0;
                    let posamex = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('american') >=0 
                        || v.Description.toLowerCase().indexOf('amex') >=0
                        && v.Description.toLowerCase().indexOf('pos') >=0
                        || v.Description.toLowerCase().indexOf('f&b') >=0
                        || v.Description.toLowerCase().indexOf('touch') >=0)                                 
                        return true; else false;
                    });                            
                    posamex.forEach(function (x) { todayposamex += x.Amount });
                    objCash.posamex = todayposamex;

                    let todayposvisa =0;
                    let posvisa = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('visa') >=0 
                        && v.Description.toLowerCase().indexOf('pos') >=0
                        || v.Description.toLowerCase().indexOf('f&b') >=0
                        || v.Description.toLowerCase().indexOf('touch') >=0)                                 
                        return true; else false;
                    });                            
                    posvisa.forEach(function (x) { todayposvisa += x.Amount });
                    objCash.posvisa = todayposvisa;

                    let todayposmc =0;
                    let posmc = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('master') >=0 
                        && v.Description.toLowerCase().indexOf('pos') >=0
                        || v.Description.toLowerCase().indexOf('f&b') >=0
                        || v.Description.toLowerCase().indexOf('touch') >=0)                                 
                        return true; else false;
                    });                            
                    posmc.forEach(function (x) { todayposmc += x.Amount });
                    objCash.posmc = todayposmc;

                    let todayposdinersCard =0;
                    let posdinersCard = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('diners') >=0 
                        && v.Description.toLowerCase().indexOf('pos') >=0
                        || v.Description.toLowerCase().indexOf('f&b') >=0
                        || v.Description.toLowerCase().indexOf('touch') >=0)                                 
                        return true; else false;
                    });                            
                    posdinersCard.forEach(function (x) { todayposdinersCard += x.Amount });
                    objCash.posdinerscard = todayposdinersCard;

                    let todayposdiscoverCard =0;
                    let posdiscoverCard = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('discover') >=0 
                        && v.Description.toLowerCase().indexOf('pos') >=0
                        || v.Description.toLowerCase().indexOf('f&b') >=0
                        || v.Description.toLowerCase().indexOf('touch') >=0)                                 
                        return true; else false;
                    });                            
                    posdiscoverCard.forEach(function (x) { todayposdiscoverCard += x.Amount });
                    objCash.posdiscovercard= todayposdiscoverCard;

                    let todayposdebit =0;
                    let posdebit = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('debit') >=0 
                        && v.Description.toLowerCase().indexOf('pos') >=0
                        || v.Description.toLowerCase().indexOf('f&b') >=0
                        || v.Description.toLowerCase().indexOf('touch') >=0)                                 
                        return true; else false;
                    });                            
                    posdebit.forEach(function (x) { todayposdebit += x.Amount });
                    objCash.posdebit= todayposdebit;

                    let todayposeft =0;
                    let poseft = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('eft') >=0 
                        && v.Description.toLowerCase().indexOf('pos') >=0
                        || v.Description.toLowerCase().indexOf('f&b') >=0
                        || v.Description.toLowerCase().indexOf('touch') >=0)                                 
                        return true; else false;
                    });                            
                    poseft.forEach(function (x) { todayposeft += x.Amount });
                    objCash.poseft= todayposeft;

                    let todayposmanual =0;
                    let posmanual = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('pos') >=0)                                 
                        return true; else false;
                    });                            
                    poseft.forEach(function (x) { todayposmanual += x.Amount });
                    objCash.posmanual= todayposmanual;

                    let todayBankCards =0;
                    let posbankcards = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('pos bank cards') >=0)                                 
                        return true; else false;
                    });                            
                    posbankcards.forEach(function (x) { todayBankCards += x.Amount });
                    objCash.posmanual= todayBankCards;

                    let todaypaidOuts =0;
                    let paidouts = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('paid out') >=0)                                 
                        return true; else false;
                    });                            
                    paidouts.forEach(function (x) { todaypaidOuts += x.Amount });
                    objCash.paidouts= todaypaidOuts;

                    let todaydirectBill =0;
                    let directbill = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('direct bill') >=0)                                 
                        return true; else false;
                    });                            
                    directbill.forEach(function (x) { todaydirectBill += x.Amount });
                    objCash.directbill= todaydirectBill;

                    let todayhiltonadvancepurchase =0;
                    let hiltonadvancepurchase = obj.filter(function(v,i) {
                        if(v.Description.toUpperCase().indexOf('HILTON ADVANCE PURCHASE') >=0)                                 
                        return true; else false;
                    });                            
                    hiltonadvancepurchase.forEach(function (x) { todayhiltonadvancepurchase += x.Amount });
                    objCash.hiltonadvancepurchase= todayhiltonadvancepurchase;

                    let todaywireTransfer =0;
                    let wiretransfer = obj.filter(function(v,i) {
                        if(v.Description.toLowerCase().indexOf('wire transfer') >=0
                        || v.Description.toUpperCase().indexOf('HILTON ADVANCE PURCHASE') >=0)                                 
                        return true; else false;
                    });                            
                    wiretransfer.forEach(function (x) { todaywireTransfer += x.Amount });
                    objCash.wiretransfer= todaywireTransfer;

                    let totalcc = objCash.amex + objCash.visa + objCash.mc +objCash.dinerscard + objCash.discovercard + objCash.debit + objCash.eft
                    objCash.creditcard = totalcc;
                                                
                    }
                }                    
                lstCashDetaildata.push(objCash);
                startdate = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate() + 1) ;// Will increase month if over range
            }  

            if(lstCashDetaildata.length >0){
                let sumcash = 0;
                let sumposcash = 0;
                let sumothercash = 0;
                let sumrefundcash = 0;
                let sumcreditcard = 0;
                let sumamex = 0;
                let sumposamex = 0;
                let sumvisa = 0;
                let sumposvisa = 0;
                let summc = 0;
                let sumposmc = 0;
                let sumdinerscard = 0;
                let sumposdinerscard = 0;
                let sumdiscovercard = 0;
                let sumposdiscovercards = 0;
                let sumposdebit = 0;
                let sumdebit = 0;
                let sumeft = 0;
                let sumposeft = 0;
                let sumposmanual = 0;
                let sumposbankcards = 0;
                let sumpaidouts = 0;
                let sumdirectbill = 0;
                let sumhiltonadvancepurchase = 0;
                let sumwiretransfer = 0;
                
                lstCashDetaildata.forEach((element,index)=>{
                    if (element.cash != 0)                        
                        sumcash = sumcash + parseFloat(element.cash);                        

                    if (element.poscash != 0)                         
                        sumposcash = sumposcash + parseFloat(element.poscash);                        

                    if (element.othercash != 0)                        
                        sumothercash = sumothercash+ parseFloat(element.othercash);
                    
                    if (element.refundcash != 0)                         
                        sumrefundcash = sumrefundcash + parseFloat(element.refundcash);

                    if (element.creditcard != 0)                        
                        sumcreditcard = sumcreditcard + parseFloat(element.creditcard);                        

                    if (element.amex != 0)                         
                        sumamex = sumamex + parseFloat(element.amex);                        

                    if (element.posamex != 0)                        
                        sumposamex = sumposamex+ parseFloat(element.posamex);
                    
                    if (element.visa != 0)                         
                        sumvisa = sumvisa + parseFloat(element.visa);

                    if (element.posvisa != 0)                        
                        sumposvisa = sumposvisa + parseFloat(element.posvisa);                        

                    if (element.mc != 0)                         
                        summc = summc + parseFloat(element.mc);                        

                    if (element.posmc != 0)                        
                        sumposmc = sumposmc+ parseFloat(element.posmc);
                    
                    if (element.dinerscard != 0)                         
                        sumdinerscard = sumdinerscard + parseFloat(element.dinerscard);

                    if (element.posdinerscard != 0)                        
                        sumposdinerscard = sumposdinerscard + parseFloat(element.posdinerscard);                        

                    if (element.discovercard != 0)                         
                        sumdiscovercard = sumdiscovercard + parseFloat(element.discovercard);                        

                    if (element.posdiscovercard != 0)                        
                        sumposdiscovercards = sumposdiscovercards+ parseFloat(element.posdiscovercard);
                    
                    if (element.debit != 0)                         
                        sumdebit = sumdebit + parseFloat(element.debit);

                    if (element.posdebit != 0)                         
                        sumposdebit = sumposdebit + parseFloat(element.posdebit);                        

                    if (element.eft != 0)                        
                        sumeft = sumeft+ parseFloat(element.eft);
                    
                    if (element.poseft != 0)                         
                        sumposeft = sumposeft + parseFloat(element.poseft);

                    if (element.posmanual != 0)                        
                        sumposmanual = sumposmanual + parseFloat(element.posmanual);                        

                    if (element.posbankcards != 0)                         
                        sumposbankcards = sumposbankcards + parseFloat(element.posbankcards);                        

                    if (element.paidouts != 0)                        
                        sumpaidouts = sumpaidouts+ parseFloat(element.paidouts);
                    
                    if (element.directbill != 0)                         
                        sumdirectbill = sumdirectbill + parseFloat(element.directbill);

                    if (element.hiltonadvancepurchase != 0)                         
                        sumhiltonadvancepurchase = sumhiltonadvancepurchase + parseFloat(element.hiltonadvancepurchase);

                    if (element.wiretransfer != 0)                         
                        sumwiretransfer = sumwiretransfer + parseFloat(element.wiretransfer);
                        
                })

                let objTotal = new Cashdetaildata();
                objTotal.cash = sumcash;
                objTotal.poscash = sumposcash;
                objTotal.othercash = sumothercash;
                objTotal.refundcash = sumrefundcash; 
                objTotal.creditcard = sumcreditcard;
                objTotal.amex = sumamex;
                objTotal.posamex = sumposamex;
                objTotal.visa = sumvisa;
                objTotal.posvisa = sumposvisa; 
                objTotal.mc = summc;
                objTotal.posmc = sumposmc;
                objTotal.dinerscard = sumdinerscard;
                objTotal.posdinerscard = sumposdinerscard;
                objTotal.discovercard = sumdiscovercard; 
                objTotal.posdiscovercard = sumposdiscovercards;
                objTotal.debit = sumdebit;
                objTotal.posdebit = sumposdebit;
                objTotal.eft = sumeft;
                objTotal.poseft = sumposeft; 
                objTotal.posmanual = sumposmanual;
                objTotal.posbankcards = sumposbankcards;
                objTotal.paidouts = sumpaidouts;
                objTotal.directbill = sumdirectbill;
                objTotal.hiltonadvancepurchase = sumhiltonadvancepurchase; 
                objTotal.wiretransfer = sumwiretransfer;
                objTotal.dmrasubtype = "Total";
                lstCashDetaildata.push(objTotal);
            }   
            
            lstCashDetaildata.forEach((element,index)=>{
                let obj = new Cashdetaildata();
                obj = element;
                obj = obj.setFormat(obj);
                lstCashDetails.push(obj);
            });
                    
            cb(null, lstCashDetails);
        }, err => {
            return cb(err);
        })  
    }

    static getCashDetailData_GraphQL(userid,hotelid,currentDate, period,customEndDate, cb) {
        return UserHelper.getUserData(userid, (err, userdata) => {
            if (err) {
                cb(err, null);
            }
            CashDetailHelper.getCashDetailData(userdata,hotelid,currentDate, period, customEndDate, cb, (err, result) => {
                if (err) {
                    cb(err, null);
                }
                cb(null, result);
            });
        });
    }

    static getCashTableData(hotelid,currentDate, cb) {
        let startdate = new Date();
        let enddate = new Date();
        let st = new Date();
        let et = new Date();
        let yeasterday  = new Date(currentDate);        
        let currhotelrevenuesData =[];
        let hotelrevenuesData =[];
        
        startdate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),0 ,0,0);
        enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),23,59,59);

        st = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),1,0,0,0);
        et = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),23,59,59);

        return Promise.all([
            new Promise((resolve, reject) => {
                // get HotelsRevenue data
                HotelsRevenueHelper.GetHotelRevenueData(hotelid, startdate, enddate,"Cash", (err, hotelrevenues_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelrevenues_result) {
                        currhotelrevenuesData = hotelrevenues_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get HotelsRevenue data
                HotelsRevenueHelper.GetCashData(hotelid, st, et, (err, hotelrevenues_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelrevenues_result) {
                        hotelrevenuesData = hotelrevenues_result;
                    }
                    resolve();
                });
            }),
        ]).then(resp => {
            
            let lstCashDetails = [];
            currhotelrevenuesData.forEach(element=>{
                let hotelrevenue = hotelrevenuesData.filter(d => {
                    return (d.Description === element._id);
                });
                let MTDAmount = _.sumBy(hotelrevenue, "Amount");
                let Cashtable = new Cashtabledata();
                Cashtable.hotelid = hotelid;
                Cashtable.description=element._id;     
                Cashtable.totalcurrent=element.Amount;
                Cashtable.totalmtd=MTDAmount;
                Cashtable = Cashtable.setFormat(Cashtable);
                lstCashDetails.push(Cashtable);
            })
              
            cb(null, lstCashDetails);
        }, err => {
            return cb(err);
        })  
    }
}

module.exports = CashDetailHelper;