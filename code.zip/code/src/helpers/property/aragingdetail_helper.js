const ARAgainDetailData = require('../../property/models/aragingsdetaildata');
const { Hotelaraging: hotelARAgingSchema, SchemaField: hotelARAgingSchemaFields } = require('../../models/hotelaraging');
const { HotelGuestLedger: hotelGuestLedgerSchema, SchemaField: hotelGuestLedgerSchemaFields } = require('../../models/hotelguestledger');
const HoteldashboardcalculationsHelper = require('./../hoteldashboardcalculations_helper');
const HotelsHelper = require('../hotels_helper');
const Constants = require('../../common/constants');
const Utils = require('../../common/utils');
const moment = require('moment');

const UserHelper = require('../user_helper');
var log = require('log4js').getLogger("ARAgingDetailHelper");

class ARAgingDetailHelper {  
    static getARAgingDetailData(userid,hotelid,hotelgroupid,currentDate, period, cb){        
        return UserHelper.getUserData(userid, (err, userdata) => {
            if (err) {
                log.error(err);
            }
            if (!userdata) {
                cb(null, null);
            }
            else {
                let roleId = userdata.RoleID;
                let orgId = userdata.OrganizationId ==null?userid:userdata.OrganizationId;
                HotelsHelper.GetHotelListByHotelGroup(userid,hotelid,hotelgroupid,roleId,cb ).then(hotelid_result => {
                
                let hotelids = hotelid_result;
                if(hotelid > 0){
                    ARAgingDetailHelper.getARAgingDetailDataByHotelId(hotelid,currentDate, period, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
                else
                {
                    ARAgingDetailHelper.getARAgingDetailDataByGroupId(hotelids,hotelgroupid,currentDate, period,cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
                });
            }
        });
    }

    static getARAgingDetailDataByGroupId(hotelids,hotelgroupid,currentDate, period, cb){        
        let startdate = new Date();
        let enddate = new Date();
        let st = new Date();
        let et = new Date();
        let yeasterday  = new Date(currentDate);
        let lastYear = Utils.lastYearDate(yeasterday);
        if(period.toLowerCase()=="current"){
            startdate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),0 ,0,0);
            enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(), 23, 59, 59);

            st = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
            et = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 23, 59, 59);

        }else if (period.toLowerCase()=="mtd")
        {
            // DateTime yeasterday = DateTime.Now.AddDays(-1);
            startdate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),1,0,0,0);
            enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),23,59,59);

            //DateTime lastYear = DateTime.Now.AddYears(-1).AddDays(-1);
            st = new Date(lastYear.getFullYear(),lastYear.getMonth(),1,0,0,0);
            et = new Date(lastYear.getFullYear(),lastYear.getMonth(),lastYear.getDate(),23,59,59);        

        }else if (period.toLowerCase()=="ytd")
        {
            // DateTime yeasterday = DateTime.Now.AddDays(-1);
            startdate = new Date(yeasterday.getFullYear(),1,1,0,0,0);
            enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),23,59,59);

            //DateTime lastYear = DateTime.Now.AddYears(-1).AddDays(-1);
            st = new Date(lastYear.getFullYear(),1,1,0,0,0);
            et = new Date(lastYear.getFullYear(),lastYear.getMonth(),lastYear.getDate(),23,59,59);        

        }
        else if (period.toLowerCase()=="ttm")
        {
            var result = Utils.GetTTMDates(yeasterday);
            startdate = result[0];
            enddate =result[1];
            st = Utils.lastYearDate(startdate);
            et = Utils.lastYearDate(enddate);          
        }
        let hotelARAgingsData = [];
        let hotelsData = [];
        let hotelGuestLedgerData = [];
        let hotelDepositData = [];
        let hoteldashboardcalculationsData = [];
        let lstARAgingsdataItem = [];
        
        let ids = [];
        hotelids.forEach(element=>{
            ids.push(element.id);
        });
       
        return Promise.all([
            new Promise((resolve, reject) => {
                // get hotels data
                HotelsHelper.GetHotelsByIds(hotelids, (err, hotels_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotels_result) {
                        hotelsData = hotels_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get hotel ARAgings data
                hotelARAgingSchema.find(
                    {[hotelARAgingSchemaFields.HotelID]: {$in:ids},
                    [hotelARAgingSchemaFields.Date]: {
                        $gte: startdate,
                        $lt: enddate
                    }                   
                    }).exec(function (err, result) {
                        if (err) {
                            reject(err);
                        }
                        hotelARAgingsData = result;
                        resolve()
                })                
            }),
            new Promise((resolve, reject) => {
                // get hotel DepositData data
                hotelGuestLedgerSchema.find(
                    {[hotelGuestLedgerSchemaFields.HotelID]: {$in:ids},
                    [hotelGuestLedgerSchemaFields.Description]:{$in:["Advance Deposit","Deposit Ledger", "ADVANCE DEPOSITS"]},
                    [hotelGuestLedgerSchemaFields.Date]: {
                        $gte: startdate,
                        $lt: enddate
                    }                   
                    }).exec(function (err, result) {
                        if (err) {
                            reject(err);
                        }
                        hotelDepositData = result;
                        resolve()
                })                
            }),
            new Promise((resolve, reject) => {
                // get hotel Guest Ledger data
                hotelGuestLedgerSchema.find(
                    {[hotelGuestLedgerSchemaFields.HotelID]: {$in:ids},
                    [hotelGuestLedgerSchemaFields.Description]:{$in:['Guest Ledger', 'House Ledger']},
                    [hotelGuestLedgerSchemaFields.Date]: {
                        $gte: startdate,
                        $lt: enddate
                    }                   
                    }).exec(function (err, result) {
                        if (err) {
                            reject(err);
                        }
                        hotelGuestLedgerData = result;
                        resolve()
                })                
            }),
            new Promise((resolve, reject) => {
                // get Hotel dashboard calculations data
                HoteldashboardcalculationsHelper.GetDataBetweenDateWithHotelIds(ids, startdate, enddate, (err, hoteldashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_result) {
                        hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                    }
                    resolve();
                });
            })

        ]).then(resp => {
            hotelsData.forEach(element=>{
                let hId = element.ID;  
                let hotelname = element.HotelName;
                let organizationId = element.OrganizationID;  
                let organizationName = '';//hotelsData[0].CompanyName[0].CompanyName;

                let objARagaindata = new ARAgainDetailData();
                objARagaindata.dmrasubtype = "ARAging";
                objARagaindata.date = moment(startdate).format('ll');
                objARagaindata.hotelid = hId;
                objARagaindata.hotelname = hotelname;
                objARagaindata.ishotelgroup = false;
                objARagaindata.orgId = organizationId;
                objARagaindata.organisationname = organizationName;
                objARagaindata.description = '---';
                let sumdue_0_30 = 0;
                let sumdue_31_60 = 0;
                let sumdue_61_90 = 0;
                let sumdue_91_120 = 0;
                let sumover_120 = 0;
                let sumunapplied_credits = 0;
                let sumtotal = 0;
                let sumtotalRevenue = 0;
                let sumEndingBalance = 0;
                let sumDeposit = 0;
                let objARAgingsData = hotelARAgingsData.filter(d => {
                    return (d.HotelID === hId);
                });

                let objdashboardcalculations = hoteldashboardcalculationsData.filter(d => {
                    return (d.HotelID === hId);
                });
                let objhotelGuestLedger = hotelGuestLedgerData.filter(d => {
                    return (d.HotelID === hId);
                });
                let objDeposit = hotelDepositData.filter(d => {
                    return (d.HotelID === hId);
                });

                if(objARAgingsData.length > 0 || objdashboardcalculations.length>0 || objhotelGuestLedger.length >0 || objDeposit.length >0)
                {  
                    objARAgingsData.forEach((element,index)=>{

                        let Due_0_30 = parseFloat(element.Due_0_30 == null?0:element.Due_0_30);
                        let Due_31_60 = parseFloat(element.Due_31_60 == null?0:element.Due_31_60);
                        let Due_61_90 = parseFloat(element.Due_61_90 == null?0:element.Due_61_90);
                        let Due_91_120 = parseFloat(element.Due_91_120 == null?0:element.Due_91_120);
                        let Over_120 = parseFloat(element.Over_120 == null?0:element.Over_120);
                        let Unapplied_credits = parseFloat(element.Unapplied_Credits == null?0:element.Unapplied_Credits);
                        let Total = parseFloat(element.Unapplied_Credits == null?0:element.Unapplied_Credits) + parseFloat(element.Due_0_30 == null?0:element.Due_0_30) + parseFloat(element.Due_31_60 == null?0:element.Due_31_60) + parseFloat(element.Due_61_90 == null?0:element.Due_61_90) + parseFloat(element.Due_91_120 == null?0:element.Due_91_120) + parseFloat(element.Over_120 == null?0:element.Over_120);
                
                        if (element.Due_0_30 != 0)                    
                            sumdue_0_30 = sumdue_0_30 + parseFloat(Due_0_30);                    

                        if (element.Due_31_60 != 0)                    
                            sumdue_31_60 = sumdue_31_60 + parseFloat(Due_31_60);
                        
                        if (element.Due_61_90 != 0)                    
                            sumdue_61_90 = sumdue_61_90 + parseFloat(Due_61_90);
                            
                        if (element.Due_91_120 != 0)                    
                            sumdue_91_120 = sumdue_91_120 + parseFloat(Due_91_120);
                    
                        if (element.Over_120 != 0)                    
                            sumover_120 = sumover_120 + parseFloat(Over_120);

                        if (element.Unapplied_credits != 0)                    
                            sumunapplied_credits = sumunapplied_credits + parseFloat(Unapplied_credits);

                        if (element.sumtotal != 0)                    
                            sumtotal = sumtotal + parseFloat(Total);
                    })

                    if (objdashboardcalculations.length >0) {  
                        objdashboardcalculations.forEach((ele,index)=>{
                            let revenu =  parseFloat(ele.TotalRevenue == null?0:ele.TotalRevenue)+ parseFloat(ele.FANDBRevenue == null?0:ele.FANDBRevenue) + parseFloat(ele.OtherRevenue == null?0:ele.OtherRevenue);
                            sumtotalRevenue = sumtotalRevenue + revenu;      
                        });                            
                    }
                    if (objhotelGuestLedger.length >0) {  
                        objhotelGuestLedger.forEach((objLeg,index)=>{
                            let endBal =  parseFloat(objLeg.EndingBalance == null?0:objLeg.EndingBalance);    
                            sumEndingBalance = sumEndingBalance + endBal;      
                        });
                    }
                    if (objDeposit.length >0) {  
                        objDeposit.forEach((objDep,index)=>{
                            let endDep =  parseFloat(objDep.EndingBalance == null?0:objDep.EndingBalance);      
                            sumDeposit = sumDeposit + endDep;      
                        });
                    }

                    let objARagaindata = new ARAgainDetailData();
                    let sumTotalAR = sumEndingBalance + sumDeposit + sumtotal;
                    objARagaindata.dmrasubtype = "ARAging";
                    objARagaindata.date = moment(startdate).format('ll');
                    objARagaindata.hotelid = hId;
                    objARagaindata.hotelname = hotelname;
                    objARagaindata.ishotelgroup = false;
                    objARagaindata.orgId = organizationId;
                    objARagaindata.organisationname = organizationName;
                    objARagaindata.description = '---';
                    objARagaindata.due_0_30 = sumdue_0_30;
                    objARagaindata.due_31_60 = sumdue_31_60;
                    objARagaindata.due_61_90 = sumdue_61_90;
                    objARagaindata.due_91_120 = sumdue_91_120;
                    objARagaindata.over_120 = sumover_120;
                    objARagaindata.unapplied_credits = sumunapplied_credits;
                    objARagaindata.total = sumtotal;
                    objARagaindata.houseledger = sumEndingBalance;
                    objARagaindata.advdeposit = sumDeposit;
                    objARagaindata.totalrevenue = sumtotalRevenue;
                    objARagaindata.totalar = sumTotalAR;
                    objARagaindata.daysInar = (sumTotalAR/(sumtotalRevenue===0?1:sumtotalRevenue));
                    objARagaindata.daysInarhouse = (sumtotal/(sumtotalRevenue===0?1:sumtotalRevenue));
                    
                    lstARAgingsdataItem.push(objARagaindata)

                }
                else{
                    let objARagaindata = new ARAgainDetailData();
                    objARagaindata.dmrasubtype = "ARAging";
                    objARagaindata.date = moment(startdate).format('ll');
                    objARagaindata.hotelid = hId;
                    objARagaindata.hotelname = hotelname;
                    objARagaindata.ishotelgroup = false;
                    objARagaindata.orgId = organizationId;
                    objARagaindata.organisationname = organizationName;
                    objARagaindata.description = '---';
                    objARagaindata.due_0_30 = 'NO DATA';
                    objARagaindata.due_31_60 = 'NO DATA';
                    objARagaindata.due_61_90 = 'NO DATA';
                    objARagaindata.due_91_120 = 'NO DATA';
                    objARagaindata.over_120 = 'NO DATA';
                    objARagaindata.unapplied_credits = 'NO DATA';
                    objARagaindata.total ='NO DATA';
                    objARagaindata.houseledger = '---';
                    objARagaindata.advdeposit = '---';
                    objARagaindata.totalrevenue = '---';
                    objARagaindata.totalar = '---';
                    objARagaindata.daysInar ='---';
                    objARagaindata.daysInarhouse ='---';
                    lstARAgingsdataItem.push(objARagaindata)
                } 
            });

            if(lstARAgingsdataItem.length >0){
                let sumdue_0_30 = 0;
                let sumdue_31_60 = 0;
                let sumdue_61_90 = 0;
                let sumdue_91_120 = 0;
                let sumover_120 = 0;
                let sumunapplied_credits = 0;
                let sumtotal = 0;
                let sumtotalRevenue = 0;
                let sumEndingBalance = 0;
                let sumDeposit = 0;
                let sumTotalar = 0;
                let sumdaysInar = 0;
                let sumdaysInarhouse = 0;
                lstARAgingsdataItem.forEach((element,index)=>{                    
                    if (element.due_0_30 != 'NO DATA')                    
                        sumdue_0_30 = sumdue_0_30 + parseFloat(element.due_0_30);                    
    
                    if (element.due_31_60 != 'NO DATA')                    
                        sumdue_31_60 = sumdue_31_60 + parseFloat(element.due_31_60);
                    
                    if (element.due_61_90 != 'NO DATA')                    
                        sumdue_61_90 = sumdue_61_90 + parseFloat(element.due_61_90);
                        
                    if (element.due_91_120 != 'NO DATA')                    
                        sumdue_91_120 = sumdue_91_120 + parseFloat(element.due_91_120);
                
                    if (element.over_120 != 'NO DATA')                    
                        sumover_120 = sumover_120 + parseFloat(element.over_120);
    
                    if (element.unapplied_credits != 'NO DATA')                    
                        sumunapplied_credits = sumunapplied_credits + parseFloat(element.unapplied_credits);
    
                    if (element.houseledger != '---')                    
                    sumEndingBalance = sumEndingBalance + parseFloat(element.houseledger);

                    if (element.advdeposit != '---')                    
                    sumDeposit = sumDeposit + parseFloat(element.advdeposit);

                    if (element.totalrevenue != '---')                    
                    sumtotalRevenue = sumtotalRevenue + parseFloat(element.totalrevenue);

                    if (element.totalar != '---')                    
                    sumTotalar = sumTotalar + parseFloat(element.totalar);

                    if (element.daysInar != '---')                    
                    sumdaysInar = sumdaysInar + parseFloat(element.daysInar);

                    if (element.daysInarhouse != '---')                    
                    sumdaysInarhouse = sumdaysInarhouse + parseFloat(element.daysInarhouse);
                })
    
                let objARagaindata = new ARAgainDetailData();
                sumtotal = parseFloat(sumunapplied_credits+sumdue_0_30+sumdue_31_60+sumdue_61_90+sumdue_91_120+sumover_120);
                let sumTotalAR = sumEndingBalance + sumDeposit + sumtotal;
                objARagaindata.dmrasubtype = "Total";
                objARagaindata.date = '';
                objARagaindata.hotelid = 0;
                objARagaindata.hotelname = 'zzz';
                objARagaindata.due_0_30 = sumdue_0_30;
                objARagaindata.due_31_60 = sumdue_31_60;
                objARagaindata.due_61_90 = sumdue_61_90;
                objARagaindata.due_91_120 = sumdue_91_120;
                objARagaindata.over_120 = sumover_120;
                objARagaindata.unapplied_credits = sumunapplied_credits;
                objARagaindata.total = sumtotal; 
                objARagaindata.houseledger = sumEndingBalance;
                objARagaindata.advdeposit = sumDeposit;
                objARagaindata.totalrevenue = sumtotalRevenue;
                objARagaindata.totalar = sumTotalAR;
                objARagaindata.daysInar = (sumTotalAR/(sumtotalRevenue===0?1:sumtotalRevenue));
                objARagaindata.daysInarhouse = (sumtotal/(sumtotalRevenue===0?1:sumtotalRevenue));

                lstARAgingsdataItem.push(objARagaindata)
            }

            let lstARAgingsDetails = [];
            lstARAgingsdataItem.forEach((element,index)=>{
                let obj = new ARAgainDetailData();
                obj = element;
                if(obj.due_0_30 !=='NO DATA'){
                    obj = obj.setFormat(obj);
                }
                lstARAgingsDetails.push(obj);
            });
            cb(null, lstARAgingsDetails); 
        }, err => {
            return cb(err);
        })    
    }

    static getARAgingDetailDataByHotelId(hotelid,currentDate, period,cb){        
        let startdate = new Date();
        let enddate = new Date();
        let st = new Date();
        let et = new Date();
        let yeasterday  = new Date(currentDate);
        let lastYear = Utils.lastYearDate(yeasterday);
       
        let hotelrevenuesData =[];
        if(period.toLowerCase()=="current"){
            startdate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),0 ,0,0);
            enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),23,59,59);

            st = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
            et = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate()+1, 23, 59, 59);

        }else if (period.toLowerCase()=="mtd")
        {
            // DateTime yeasterday = DateTime.Now.AddDays(-1);
            startdate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),1,0,0,0);
            enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),23,59,59);

            //DateTime lastYear = DateTime.Now.AddYears(-1).AddDays(-1);
            st = new Date(lastYear.getFullYear(),lastYear.getMonth(),1,0,0,0);
            et = new Date(lastYear.getFullYear(),lastYear.getMonth(),lastYear.getDate(),23,59,59);        

        }else if (period.toLowerCase()=="ytd")
        {
            // DateTime yeasterday = DateTime.Now.AddDays(-1);
            startdate = new Date(yeasterday.getFullYear(),1,1,0,0,0);
            enddate = new Date(yeasterday.getFullYear(),yeasterday.getMonth(),yeasterday.getDate(),23,59,59);

            //DateTime lastYear = DateTime.Now.AddYears(-1).AddDays(-1);
            st = new Date(lastYear.getFullYear(),1,1,0,0,0);
            et = new Date(lastYear.getFullYear(),lastYear.getMonth(),lastYear.getDate(),23,59,59);        

        }
        else if (period.toLowerCase()=="ttm")
        {
            var result = Utils.GetTTMDates(yeasterday);
            startdate = result[0];
            enddate =result[1];
            st = Utils.lastYearDate(startdate);
            et = Utils.lastYearDate(enddate);          
        }

        let hotelARAgingsData = [];
        let hotelsData = [];

        return Promise.all([
            new Promise((resolve, reject) => {
                // get hotels data
                HotelsHelper.GetData(hotelid, (err, hotels_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotels_result) {
                        hotelsData = hotels_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get hotel ARAgings data
                hotelARAgingSchema.find(
                    {[hotelARAgingSchemaFields.HotelID]: hotelid,
                    [hotelARAgingSchemaFields.Date]: {
                        $gte: startdate+1,
                        $lt: enddate
                    }                   
                    }).exec(function (err, result) {
                        if (err) {
                            reject(err);
                        }
                        hotelARAgingsData = result;
                        resolve()
                })                
            })
        ]).then(resp => {
            let lstARAgingsdataItem = [];
            let hotelname = '';
            let organizationId = 0; 
            let organizationName = '';
            if(hotelsData.length > 0)
            {
                hotelname = hotelsData[0].HotelName;
                organizationId = hotelsData[0].OrganizationId;  
                organizationName = hotelsData[0].CompanyName[0].CompanyName;
            }
           
            while (startdate < enddate) {
                let dt = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate())
                
                if(hotelARAgingsData.length > 0)
                {
                    let objAragain = [];
                    hotelARAgingsData.forEach(item=>{
                        if(item.HotelID == hotelid && new Date(item.Date).setHours(0, 0, 0, 0)>=dt && new Date(item.Date).setHours(0, 0, 0, 0) <= dt ){
                            objAragain.push(item);                            
                        }
                    })
                    if(objAragain.length > 0){
                        objAragain = objAragain.sort((a, b) => (a.Description > b.Description) ? 1 : -1)
                        
                        objAragain.forEach(ar=>{
                            let objARagaindata = new ARAgainDetailData();
                            objARagaindata.dmrasubtype = "ARAging";
                            objARagaindata.date = moment(dt).format('ll');
                            objARagaindata.hotelid = hotelid;
                            objARagaindata.hotelname = hotelname;
                            objARagaindata.ishotelgroup = false;
                            objARagaindata.orgId = organizationId;
                            objARagaindata.organisationname = organizationName;
                            objARagaindata.description = ar.Description;
                            objARagaindata.due_0_30 = parseFloat(ar.Due_0_30 == null?0:ar.Due_0_30);
                            objARagaindata.due_31_60 = parseFloat(ar.Due_31_60 == null?0:ar.Due_31_60);
                            objARagaindata.due_61_90 = parseFloat(ar.Due_61_90 == null?0:ar.Due_61_90);
                            objARagaindata.due_91_120 = parseFloat(ar.Due_91_120 == null?0:ar.Due_91_120);
                            objARagaindata.over_120 = parseFloat(ar.Over_120 == null?0:ar.Over_120);
                            objARagaindata.unapplied_credits = parseFloat(ar.Unapplied_Credits == null?0:ar.Unapplied_Credits);
                            objARagaindata.total = parseFloat(ar.Unapplied_Credits == null?0:ar.Unapplied_Credits) + parseFloat(ar.Due_0_30 == null?0:ar.Due_0_30) + parseFloat(ar.Due_31_60 == null?0:ar.Due_31_60) + parseFloat(ar.Due_61_90 == null?0:ar.Due_61_90) + parseFloat(ar.Due_91_120 == null?0:ar.Due_91_120) + parseFloat(ar.Over_120 == null?0:ar.Over_120);
                            objARagaindata.houseledger = '---';
                            objARagaindata.advdeposit = '---';
                            objARagaindata.totalar = '---';
                            objARagaindata.daysInar = '---';
                            objARagaindata.daysInarhouse = '---';
                            if(objARagaindata.total != 0)
                            lstARAgingsdataItem.push(objARagaindata)
                        })
                    }
                    else{
                        let objARagaindata = new ARAgainDetailData();
                        objARagaindata.dmrasubtype = "ARAging";
                        objARagaindata.date = moment(dt).format('ll');
                        objARagaindata.hotelid = hotelid;
                        objARagaindata.hotelname = hotelname;
                        objARagaindata.ishotelgroup = false;
                        objARagaindata.orgId = organizationId;
                        objARagaindata.organisationname = organizationName;
                        objARagaindata.description = '---';
                        objARagaindata.due_0_30 = '0';
                        objARagaindata.due_31_60 = '0';
                        objARagaindata.due_61_90 = '0';
                        objARagaindata.due_91_120 = '0';
                        objARagaindata.over_120 = '0';
                        objARagaindata.unapplied_credits = '0';
                        objARagaindata.total ='0';
                        objARagaindata.houseledger = '---';
                        objARagaindata.advdeposit = '---';
                        objARagaindata.totalar = '---';
                        objARagaindata.daysInar = '---';
                        objARagaindata.daysInarhouse = '---';
                        lstARAgingsdataItem.push(objARagaindata)
                    }
                    
                }
                startdate = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate() + 1) ;// Will increase month if over range
            }          
           
            if(lstARAgingsdataItem.length >0){
                let sumdue_0_30 = 0;
                let sumdue_31_60 = 0;
                let sumdue_61_90 = 0;
                let sumdue_91_120 = 0;
                let sumover_120 = 0;
                let sumunapplied_credits = 0;
                let sumtotal = 0;
                lstARAgingsdataItem.forEach((element,index)=>{                    
                    if (element.due_0_30 != 0)                    
                        sumdue_0_30 = parseFloat(sumdue_0_30) + parseFloat(element.due_0_30);                    

                    if (element.due_31_60 !=0)                    
                        sumdue_31_60 = parseFloat(sumdue_31_60) + parseFloat(element.due_31_60);
                    
                    if (element.due_61_90 != 0)                    
                        sumdue_61_90 = parseFloat(sumdue_61_90) + parseFloat(element.due_61_90);
                        
                    if (element.due_91_120 != 0)                    
                        sumdue_91_120 = parseFloat(sumdue_91_120) + parseFloat(element.due_91_120);
                
                    if (element.over_120 != 0)                    
                        sumover_120 = parseFloat(sumover_120) + parseFloat(element.over_120);

                    if (element.unapplied_credits != 0)                    
                        sumunapplied_credits = parseFloat(sumunapplied_credits) + parseFloat(element.unapplied_credits);

                    if (element.sumtotal != 0)                    
                        sumtotal = parseFloat(sumtotal) + parseFloat(element.total);
                })

                let objARagaindata = new ARAgainDetailData();
                objARagaindata.dmrasubtype = "Total";
                objARagaindata.date = '';
                objARagaindata.hotelid = hotelid;
                objARagaindata.hotelname = 'zzz';
                objARagaindata.due_0_30 = sumdue_0_30;
                objARagaindata.due_31_60 = sumdue_31_60;
                objARagaindata.due_61_90 = sumdue_61_90;
                objARagaindata.due_91_120 = sumdue_91_120;
                objARagaindata.over_120 = sumover_120;
                objARagaindata.unapplied_credits = sumunapplied_credits;
                objARagaindata.total = sumtotal; 
                objARagaindata.houseledger = '0';
                objARagaindata.advdeposit = '0';
                objARagaindata.totalar = '0';
                objARagaindata.daysInar = '0';
                objARagaindata.daysInarhouse = '0';
                lstARAgingsdataItem.push(objARagaindata)
            };           
           
            let lstARAgingsDetails = [];
            lstARAgingsdataItem.forEach((element,index)=>{
                let obj = new ARAgainDetailData();
                obj = element;
                obj = obj.setFormat(obj);
                obj.houseledger = '---';
                obj.advdeposit = '---';
                obj.totalar = '---';
                obj.daysInar = '---';
                obj.daysInarhouse = '---';
                lstARAgingsDetails.push(obj);
            });
            cb(null, lstARAgingsDetails);

        }, err => {
            return cb(err);
        })
    }

    static getARAgingDetailData_GraphQL(userid,hotelid,hotelgroupid,currentDate, period, cb) {
        
        return ARAgingDetailHelper.getARAgingDetailData(userid,hotelid,hotelgroupid,currentDate, period, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }

}

module.exports = ARAgingDetailHelper;