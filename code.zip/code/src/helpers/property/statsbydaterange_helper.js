const HoteldashboardcalculationsHelper = require('./../hoteldashboardcalculations_helper');
const HotelroomstatusdashboardcalculationsHelper = require('./../hotelroomstatusdashboardcalculations_helper');
const Statsbydaterangedata = require('../../property/models/statsbydaterangedata');
const { Hotelroomstatus: hotelroomstatusSchema, SchemaField: hotelroomstatusSchemaFields } = require('../../models/hotelroomstatus');
const { Missingdatesmaster: MissingdatesmasterSchema, SchemaField: MissingdatesmasterSchemaFields } = require('../../models/missingdatesmaster');

const HotelsHelper = require('./../hotels_helper');
const Constants = require('../../common/constants');
const Utils = require('../../common/utils');
const moment = require('moment');

const UserHelper = require('./../user_helper');
var log = require('log4js').getLogger("StatsbyDateRangeHelper");

class StatsbyDateRangeHelper {
    static getStatsbyDateRangeData(hotelid, startdate, enddate, roomrevenuenodata, fnbrevenuenodata, otherrevenenodata, userconfigdata, cb) {
        var stdate = new Date(startdate);
        startdate = new Date(startdate);
        enddate = new Date(enddate);

        let hoteldashboardcalculationsData = [];
        let hotelroomstatusData = [];
        let hotelsData = [];
        let hotelsMissingdate = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                // get hotels data
                HotelsHelper.GetData(hotelid, (err, hotels_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotels_result) {
                        hotelsData = hotels_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations data
                HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, hoteldashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_result) {
                        hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get hotels room status data
                hotelroomstatusSchema.find(
                    {
                        [hotelroomstatusSchemaFields.HotelID]: hotelid,
                        [hotelroomstatusSchemaFields.Date]: {
                            $gte: startdate,
                            $lt: enddate 
                        },
                        [hotelroomstatusSchemaFields.Category]: { $in: ["OutOfOrder", "OOORooms"] }
                    }).exec(function (err, result) {
                        if (err) {
                            reject(err);
                        }
                        hotelroomstatusData = result;
                        resolve()
                    })
            })
            ,
            new Promise((resolve, reject) => {
                MissingdatesmasterSchema.find(
                    {
                        [MissingdatesmasterSchemaFields.HotelID]: hotelid,
                        [MissingdatesmasterSchemaFields.Date]: {
                            $gte: startdate,
                            $lt: enddate 
                        }
                    }).exec(function (err, result) {
                        if (err) {
                            reject(err);
                        }
                        hotelsMissingdate = result;
                        resolve()
                    })
            })
        ]).then(resp => {
            let lstStatsbydateItem = [];
            while (startdate <= enddate) {
                let dt = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate())
                let objStatsbydatedata = new Statsbydaterangedata();
                objStatsbydatedata.date = moment(dt).format('ll');
                if (hotelsData.length > 0) {
                    objStatsbydatedata.hotelid = hotelsData[0].ID;
                    objStatsbydatedata.hotelname = hotelsData[0].HotelName;
                }
                let obj = hoteldashboardcalculationsData.filter(d => {
                    var time = new Date(d.Date);
                    return (time >= dt && time <= dt);
                });

                let objrooms = hotelroomstatusData.filter(d => {
                    var time = new Date(d.Date);
                    return d.HotelID === hotelid && (time >= dt && time <= dt);
                });
                if (obj.length > 0 || objrooms.length > 0) {
                    if (obj.length > 0) {
                        obj = obj[0];
                        objStatsbydatedata.noofroomsold = obj.NoOfRoomSold;
                        objStatsbydatedata.occupancy = obj.Occupancy;
                        objStatsbydatedata.adr = obj.ADR;
                        objStatsbydatedata.revpar = obj.RevPAR;
                        objStatsbydatedata.fandbrevenue = obj.FANDBRevenue;
                        objStatsbydatedata.otherrevenue = obj.OtherRevenue;
                        objStatsbydatedata.totalrevenue = obj.TotalRevenue;
                    }
                    if (objrooms.length > 0) {
                        objrooms = objrooms[0];
                        objStatsbydatedata.ooorooms = objrooms.NoofRooms;
                    }
                    objStatsbydatedata = objStatsbydatedata.setFormat(objStatsbydatedata);

                     //add 0.00 for zero amount values instead of NODATA
                     if (objStatsbydatedata.fandbrevenue == Constants.NoDataValue.NODATA || objStatsbydatedata.otherrevenue == Constants.NoDataValue.NODATA)
                     {
                         if (hotelsMissingdate)
                         {
                             let ismissingactual = hotelsMissingdate.filter(d => {
                                var time = new Date(d.Date);
                                return time == dt && d.Category =="Other/F&B Revenue";
                            })
                             if (ismissingactual.length ==0)
                             {
                                 if (objStatsbydatedata.fandbrevenue == Constants.NoDataValue.NODATA)
                                 {
                                    objStatsbydatedata.fandbrevenue = "0.00";
                                 }
                                 if (objStatsbydatedata.otherrevenue == Constants.NoDataValue.NODATA)
                                 {
                                    objStatsbydatedata.otherrevenue = "0.00";
                                 }
                             }
                         }
                     }

                     //add 0.00 for zero amount values instead of NODATA
                     if (objStatsbydatedata.totalrevenue == Constants.NoDataValue.NODATA)
                     {
                         if (hotelsMissingdate)
                         {
                            let ismissingactual = hotelsMissingdate.filter(d => {
                                var time = new Date(d.Date);
                                return time == dt && d.Category =='Room Revenue';
                            })
                            
                            if (ismissingactual.length ==0)
                             {
                                 if (objstatsbydatedata.totalrevenue == Constants.NoDataValue.NODATA)
                                 {
                                     objstatsbydatedata.totalrevenue = "0.00";
                                 }
                                 if (objstatsbydatedata.occupancy == Constants.NoDataValue.NODATA)
                                 {
                                     objstatsbydatedata.occupancy = "0.00";
                                 }
                                 if (objstatsbydatedata.adr == Constants.NoDataValue.NODATA)
                                 {
                                     objstatsbydatedata.adr = "0.00";
                                 }
                                 if (objstatsbydatedata.revpar == Constants.NoDataValue.NODATA)
                                 {
                                     objstatsbydatedata.revpar = "0.00";
                                 }
                                 if (objstatsbydatedata.noofroomsold == Constants.NoDataValue.NODATA)
                                 {
                                     objstatsbydatedata.noofroomsold = "0";
                                 }
                             }
                         }
                     }
                }
                else {
                    objStatsbydatedata.noofroomsold = Constants.NoDataValue.NODATA;
                    objStatsbydatedata.occupancy = Constants.NoDataValue.NODATA;
                    objStatsbydatedata.adr = Constants.NoDataValue.NODATA;
                    objStatsbydatedata.revpar = Constants.NoDataValue.NODATA;
                    objStatsbydatedata.fandbrevenue = Constants.NoDataValue.NODATA;
                    objStatsbydatedata.otherrevenue = Constants.NoDataValue.NODATA;
                    objStatsbydatedata.totalrevenue = Constants.NoDataValue.NODATA;
                    objStatsbydatedata.ooorooms = 0;
                }
                lstStatsbydateItem.push(objStatsbydatedata);
                startdate = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate() + 1);// Will increase month if over range
            }

            if (roomrevenuenodata == 'true' && fnbrevenuenodata == 'true' && otherrevenenodata == 'true') {
                lstStatsbydateItem = lstStatsbydateItem.filter(t => { return t.totalrevenue === Constants.NoDataValue.NODATA || t.fandbrevenue === Constants.NoDataValue.NODATA || t.otherrevenue === Constants.NoDataValue.NODATA })
            }
            else if (roomrevenuenodata == 'true' && fnbrevenuenodata == 'true' && otherrevenenodata == 'false') {
                lstStatsbydateItem = lstStatsbydateItem.filter(t => { return t.totalrevenue === Constants.NoDataValue.NODATA || t.fandbrevenue === Constants.NoDataValue.NODATA })
            }
            else if (roomrevenuenodata == 'true' && fnbrevenuenodata == 'false' && otherrevenenodata == 'true') {
                lstStatsbydateItem = lstStatsbydateItem.filter(t => { return t.totalrevenue === Constants.NoDataValue.NODATA || t.otherrevenue === Constants.NoDataValue.NODATA })
            }
            else if (roomrevenuenodata == 'true' && fnbrevenuenodata == 'false' && otherrevenenodata == 'false') {
                lstStatsbydateItem = lstStatsbydateItem.filter(t => { return t.totalrevenue === Constants.NoDataValue.NODATA })
            }
            else if (roomrevenuenodata == 'false' && fnbrevenuenodata == 'true' && otherrevenenodata == 'true') {
                lstStatsbydateItem = lstStatsbydateItem.filter(t => { return t.fandbrevenue === Constants.NoDataValue.NODATA || t.otherrevenue === Constants.NoDataValue.NODATA })
            }
            else if (roomrevenuenodata == 'false' && fnbrevenuenodata == 'true' && otherrevenenodata == 'false') {
                lstStatsbydateItem = lstStatsbydateItem.filter(t => { return t.fandbrevenue === Constants.NoDataValue.NODATA })
            }
            else if (roomrevenuenodata == 'false' && fnbrevenuenodata == 'false' && otherrevenenodata == 'true') {
                lstStatsbydateItem = lstStatsbydateItem.filter(t => { return t.otherrevenue === Constants.NoDataValue.NODATA })
            }


            if (lstStatsbydateItem.length > 0) {
                let sumTotalRoomRevenue = 0;
                let sumOtherRevenue = 0;
                let sumFANDBRevenue = 0;
                let sumNoOfRoomSold = 0;
                let sumOutOfOrderRooms = 0;
                let objhoteld = hoteldashboardcalculationsData.filter(d => {
                    var time = new Date(d.Date);
                    return (time >= stdate  && time <= enddate);
                });
                objhoteld.forEach((element, index) => {

                    if (element.TotalRevenue != 0) {
                        sumTotalRoomRevenue = sumTotalRoomRevenue + parseFloat(element.TotalRevenue);
                    }

                    if (element.OtherRevenue != 0) {
                        sumOtherRevenue = sumOtherRevenue + parseFloat(element.OtherRevenue);
                    }

                    if (element.FANDBRevenue != 0) {
                        sumFANDBRevenue = sumFANDBRevenue + parseFloat(element.FANDBRevenue);
                    }
                    if (element.NoOfRoomSold != 0) {
                        sumNoOfRoomSold = sumNoOfRoomSold + parseFloat(element.NoOfRoomSold);
                    }

                })

                hotelroomstatusData.forEach((element, index) => {
                    if (element.NoofRooms != 0) {
                        sumOutOfOrderRooms = sumOutOfOrderRooms + parseFloat(element.NoofRooms);
                    }
                });

                let objTotal = new Statsbydaterangedata();
                objTotal.fandbrevenue = sumFANDBRevenue;
                objTotal.otherrevenue = sumOtherRevenue;
                objTotal.totalrevenue = sumTotalRoomRevenue;
                objTotal.ooorooms = sumOutOfOrderRooms;
                objTotal.noofroomsold = sumNoOfRoomSold;
                objTotal = objTotal.setFormat(objTotal);
                objTotal.date = "-",
                    objTotal.hotelname = "Total",
                    objTotal.occupancy = '-';
                objTotal.adr = '-';
                objTotal.revpar = '-';
                objTotal.fandbrevenue = objTotal.fandbrevenue === Constants.NoDataValue.NODATA ? '0' : objTotal.fandbrevenue;
                objTotal.otherrevenue = objTotal.otherrevenue === Constants.NoDataValue.NODATA ? '0' : objTotal.otherrevenue;
                objTotal.totalrevenue = objTotal.totalrevenue === Constants.NoDataValue.NODATA ? '0' : objTotal.totalrevenue;
                objTotal.ooorooms = objTotal.ooorooms === Constants.NoDataValue.NODATA ? '0' : objTotal.ooorooms;
                objTotal.noofroomsold = objTotal.noofroomsold === Constants.NoDataValue.NODATA ? '0' : objTotal.noofroomsold;
                lstStatsbydateItem.push(objTotal);
            }

            cb(null, lstStatsbydateItem);

        }, err => {
            return cb(err);
        })
    }


    static getStatsbyDateRangeData_GraphQL(userid, hotelid, startdate, enddate, roomrevenuenodata, fnbrevenuenodata, otherrevenenodata, cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    StatsbyDateRangeHelper.getStatsbyDateRangeData(hoteldata.ID, startdate, enddate, roomrevenuenodata, fnbrevenuenodata, otherrevenenodata, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }
}

module.exports = StatsbyDateRangeHelper;