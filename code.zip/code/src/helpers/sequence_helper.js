
const { Autosequence: AutosequenceSchema, SchemaField: AutosequenceSchemaFields } = require('../models/autosequence');

var log = require('log4js').getLogger("sequence_helper");

class SequenceHelper {

    static getValueForNextSequence(tablename, cb) {

        return AutosequenceSchema.findOneAndUpdate({ [AutosequenceSchemaFields.TableName]: tablename }, {
            $inc: {
                [AutosequenceSchemaFields.SequenceValue]: 1
            }
        }, {
            upsert: true,
            new: true
        }).exec((err, result) => {
            if (err)
                return cb(err);

            cb(null, result.sequence_value);
        });
    }


    // return AutosequenceSchema.findOneAndUpdate({ [AutosequenceSchemaFields.TableName]: tablename }, {
    //     [AutosequenceSchemaFields.SequenceValue]   {
    //         $inc: { 
    //             count: 1
    //         }
    //     }
    //     , { [AutosequenceSchemaFields.SequenceValue]: inc }, (err, result) => {
    //         if (err) {
    //             log.error(err);
    //         }
    //         if (!result) {
    //             return cb('Sequence not found');
    //         }

    //     });

}

module.exports = SequenceHelper;
