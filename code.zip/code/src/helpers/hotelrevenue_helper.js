const Constants = require('../common/constants');

const { Hotelrevenue: HotelrevenueSchema, SchemaField: HotelrevenueSchemaFields } = require('../models/hotelrevenue');

var log = require('log4js').getLogger("hotelrevenue_helper");

class HotelrevenueHelper {

    static GetProfitDataSumAmount(hotelid, startdate, enddate, description, cb) {

        log.debug('Call GetProfitDataSumAmount, hotelid:' + hotelid + " startdate:" + startdate + " enddate:" + enddate);

        let category = Constants.RevenueCategory.Profit;
        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        let hotelrevenueAggregate = HotelrevenueSchema.aggregate();

        hotelrevenueAggregate.match({
            [HotelrevenueSchemaFields.HotelID]: hotelid,
            [HotelrevenueSchemaFields.Category]: category,
            [HotelrevenueSchemaFields.Description]: description,
            [HotelrevenueSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })

        hotelrevenueAggregate.group({
            [HotelrevenueSchemaFields._id]: null,
            [HotelrevenueSchemaFields.Amount]: { $sum: `$${HotelrevenueSchemaFields.Amount}` }
        })

        return hotelrevenueAggregate.exec((err, result) => {
            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("GetProfitDataSumAmount result not found");
                return cb(null, 0);
            }
            else {
                return cb(null, result[0].Amount);
            }
        });
    }
    static GetData(hotelid, date, cb){
        log.debug('Call GetDataBetweenDate, hotelid:' + hotelid + "startdate:" + date + "enddate:" + date);

        let start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        let end = new Date(date.getFullYear(), date.getMonth(), date.getDate()+1);
        return HotelrevenueSchema.find(
            {[HotelrevenueSchemaFields.HotelID]: hotelId,
            [HotelrevenueSchemaFields.Category]:"RoomRevenue",
            [HotelrevenueSchemaFields.IsDelete  ]:false,
            [HotelrevenueSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }}
            ).exec((err,result)=>{
                    cb(null,result);
            })        
    }
    static GetPayRollData(hotelId,startdate,enddate,cb){
        return HotelrevenueSchema.find(
            {[HotelrevenueSchemaFields.HotelID]: hotelId,
            [HotelrevenueSchemaFields.Category]:"RoomRevenue",
            [HotelrevenueSchemaFields.IsDelete  ]:false,
            [HotelrevenueSchemaFields.Date]: {
                $gte: startdate,
                $lt: enddate
            }}
            ).exec((err,result)=>{
                    cb(null,result);
            })
    }
    static GetHotelRevenueData(hotelid, startdate, enddate, category, cb) {

        log.debug('Call GetHotelRevenueData, hotelid:' + hotelid + " startdate:" + startdate + " enddate:" + enddate);

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        let hotelrevenueAggregate = HotelrevenueSchema.aggregate();

        hotelrevenueAggregate.match({
            [HotelrevenueSchemaFields.HotelID]: hotelid,
            [HotelrevenueSchemaFields.Category]: category,
            [HotelrevenueSchemaFields.IsDelete]:false,
            [HotelrevenueSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })

        hotelrevenueAggregate.group({
            [HotelrevenueSchemaFields._id]: `$${HotelrevenueSchemaFields.Description}`,
            [HotelrevenueSchemaFields.Amount]: { $sum: `$${HotelrevenueSchemaFields.Amount}` }
        })

        return hotelrevenueAggregate.exec((err, result) => {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetHotelRevenueData result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }
    static GetCashData(hotelid,startdate,enddate, cb) {
        log.debug('Call GetCashData, hotelid:' + hotelid + " startdate:" + startdate );
        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);
       
        return HotelrevenueSchema.find({
            [HotelrevenueSchemaFields.HotelID]: hotelid,
            [HotelrevenueSchemaFields.IsDelete]:false,
            [HotelrevenueSchemaFields.Category]:"Cash",
            [HotelrevenueSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetCashData result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }

    // method used for get DashboardMonthwise in - Portfolio page
    static GetHotelrevenueByHotelIds(hotelids,startdate,enddate, cb) {
        log.debug('Call GetHotelrevenueByHotelIds, startdate:' + startdate );
        let st = new Date(startdate);
        let curdt = new Date(Date.now());
        if(st.getDate() >= curdt.getDate())
        {
            return HotelrevenueSchema.find({
                [HotelrevenueSchemaFields.HotelID]: { $in: hotelids },
                [HotelrevenueSchemaFields.IsDelete]:false,
                [HotelrevenueSchemaFields.Category]:'ForcastRoomRevenue',
                [HotelrevenueSchemaFields.Description]:{$in:["forecast","blocks","group"]},
                [HotelrevenueSchemaFields.Date]: {
                    $gte: startdate,
                    $lt: enddate
                }
            }).exec(function (err, result) {
                if (err) {
                    log.error(err);
                }
                if (!result) {
                    log.debug("GetHotelrevenueByHotelIds result not found");
                    return cb("data not found", null);
                }
                else {
                    return cb(null, result);
                }
            });
        }
        else{
            return HotelrevenueSchema.find({
                [HotelrevenueSchemaFields.HotelID]: { $in: hotelids },
                [HotelrevenueSchemaFields.IsDelete]:false,
                [HotelrevenueSchemaFields.Category]:'RoomRevenue',
                [HotelrevenueSchemaFields.Date]: {
                    $gte: startdate,
                    $lt: enddate
                }
            }).exec(function (err, result) {
                if (err) {
                    log.error(err);
                }
                if (!result) {
                    log.debug("GetHotelrevenueByHotelIds result not found");
                    return cb("data not found", null);
                }
                else {
                    return cb(null, result);
                }
            });
        }
    }

    // method used for get Revenue ForRevenueBreakdown in - Property page
    static GetHotelrevenueForRevenueBreakdown(hotelid,startdate,enddate, cb) {
        log.debug('Call GetHotelrevenueForRevenueBreakdown, startdate:' + startdate );

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        return HotelrevenueSchema.find(
            {[HotelrevenueSchemaFields.HotelID]: hotelid,
            [HotelrevenueSchemaFields.Category]:{$in:["RoomRevenue","FANDBRevenue","OtherRevenue"]},
            [HotelrevenueSchemaFields.IsDelete  ]:false,
            [HotelrevenueSchemaFields.Date ]: {
                $gte: start,
                $lt: end
            }}
            ).exec((err,result)=>{
                    cb(null,result);
            })
    }

    // method used for get Revenue For Membership in - Property page
    static GetHotelrevenueForMembership(hotelid,startdate,enddate, cb) {
        log.debug('Call GetHotelrevenueForMembership, startdate:' + startdate );

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        return HotelrevenueSchema.find(
            {[HotelrevenueSchemaFields.HotelID]: hotelid,
            [HotelrevenueSchemaFields.Category]:{$in:['Member', 'Gold', 'Club', 'Platinum', 'Spire', 'Diamond', 'Blue', 'Silver','Discoverist','Explorist','Globalist','Ambassador','Titanium']},
            [HotelrevenueSchemaFields.IsDelete  ]:false,
            [HotelrevenueSchemaFields.Date ]: {
                $gte: start,
                $lt: end
            }}
            ).exec((err,result)=>{
                    cb(null,result);
            })
    }
    static GetHotelrevenueByCategory(hotelid,startdate,enddate,category, cb) {
        log.debug('Call GetHotelrevenueByCategory, hotelid:' + hotelid + "startdate:" + startdate + "enddate:" + enddate);
        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        return HotelrevenueSchema.find(
            {[HotelrevenueSchemaFields.HotelID]: hotelid,
            [HotelrevenueSchemaFields.Category]:category,
            [HotelrevenueSchemaFields.IsDelete ]:false,
            [HotelrevenueSchemaFields.Date ]: {
                $gte: start,
                $lt: end
            }}
            ).exec((err,result)=>{
                    cb(null,result);
            })
    }
}
module.exports = HotelrevenueHelper;


