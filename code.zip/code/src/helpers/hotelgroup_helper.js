const { Hotelgroup : HotelgroupSchema, SchemaField: HotelgroupSchemaFields } = require('../models/hotelgroup');


const UserHotelGroupXrefHelper = require('../helpers/userhotelgroupxref_helper'); 


//const HotelandHotelGroupPropertiesmodelData = require('../customeview/models/hotelandHotelgrouppropertiesmodeldata');

const dbtable = require('../schema/db_table');

var log = require('log4js').getLogger("hotelgroup_helper");

const _ = require('lodash');
class HotelGroupHelper {
    static getHotelGroupData(hotelgroupId,cd){
        HotelgroupSchema.find({[HotelgroupSchemaFields.ID]:hotelgroupId}).exec(function (err, result) {
            if(err){
                cd(err,null)
            }
            cd(null,result)
        })
    }
    /*static GetHotelGroupsByOrganizationIdStat3(orgId,userId, isadmin,cd) {
        let hgmList = [];
        return new Promise(function(resolve, reject) {
            HotelgroupSchema.find(
                    
                {$and:[
                {[HotelgroupSchemaFields.Org_Id]: orgId},
                {[HotelgroupSchemaFields.IsDelete]:false}
                ]}).exec(function (err, result) {
                if (err) {
                    reject(err);
                }                
                hgmList = result 
                resolve()
            })
        }).then(resp=>{
            let data = []; let uhgx = [];
            _.filter(hgmList, function(val){
                let x = new Promise(function(resolve, reject) {
                   
                    UserHotelGroupXrefHelper.getUserHoteGroupData(val.Id,userId,(err,result)=>{
                        if (err) {
                            reject(err);
                        }                         
                        uhgx.push(result);
                        resolve()


                    })
                })
                data.push(x)
            })
            Promise.all(data).then(resp=>{
                let uhgxArray = [];
                _.filter(uhgx,function(value){
                    uhgxArray.push(value[0])
                })
                if(uhgxArray.length>0|| isadmin){
                    _.filter(hgmList, function(val){
                        let model = new HotelandHotelGroupPropertiesmodelData();
                        model.Id = val.Id;
                        model.OrgId = val.Org_Id;
                        model.Name = val.Group_Name;
                        model.Type = "HotelGroup";
                        hgmList.push(model); 
                    })
                   
                }else{
                    hgmList = new HotelandHotelGroupPropertiesmodelData();
                }
                cd(null,hgmList)
            })
            
        })


    }*/
}
module.exports = HotelGroupHelper;


