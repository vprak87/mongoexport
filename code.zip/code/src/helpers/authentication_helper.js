const Utils = require('../common/utils');
const Constants = require('../common/constants');

const UserHelper = require('./user_helper');
var log = require('log4js').getLogger("AuthenticationHelper");

class AuthenticationHelper {
    static UserLogin_GraphQL(email, password, cb) {

        return UserHelper.login(email, password, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });

    }
}
module.exports = AuthenticationHelper;