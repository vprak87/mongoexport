const { Trustyousurveyreportdata : TrustyousurveyreportdataSchema, SchemaField: TrustyousurveyreportdataSchemaFields } = require('../models/trustyousurveyreportdata');
const { HOTELGMLOGINMAPPING } = require('../schema/db_table');
const dbtable = require('../schema/db_table');
const Trustyousurveyreportdata = require('../trustyousurveyreports/models/trustyousurveyreportdata');
var log = require('log4js').getLogger("trustyousurveyreport_helper");

class TrustYouSurveyReportHelper {
    static GetTrustYouSurveyReportData(hotelid,rptDate,category,cd){
        
        log.debug('Call GetTrustyouSurveyData, hotelid:' + hotelid);

        return TrustyousurveyreportdataSchema.find({
            $and:[
            {[TrustyousurveyreportdataSchemaFields.HotelID]:hotelid},
            {[TrustyousurveyreportdataSchemaFields.Date]:rptDate},
            {[TrustyousurveyreportdataSchemaFields.Category]:category}
            ]}).exec(function(err,result){
            
                if (err) {
                    log.error(err);
                }        
                if (!result) {
                    log.debug("GetTrustyouSurveyData result not found");
                }
               
                var lstData = [];    
                if (result) {        
                result.forEach(function (item) {
                    var obj = new Trustyousurveyreportdata();
                    obj.id=item.ID;
                    obj.organisationid=item.OrganisationID;
                    obj.date=new Date(item.Date),
                    obj.category=item.Category,
                    obj.subcategory=item.SubCategory,
                    obj.description=item.Description,
                    obj.categoryvalue=item.CategoryValue,
                    obj.updatedatetime=item.UpdateDateTime,
                    obj.updatedby=item.UpdatedBy,
                    obj.hotelid=item.HotelID
                    lstData.push(obj)
                });     
            }         
               return cd(null,lstData);                
        }) 
    }
   
    static getTrustYouSurveyReportData_GraphQL(hotelid,rptDate,category, cb) {
        var dtreportdate = new Date(rptDate);

        let startdate = new Date(dtreportdate.getFullYear(), dtreportdate.getMonth(), dtreportdate.getDate());
        
        
        return TrustYouSurveyReportHelper.GetTrustYouSurveyReportData(hotelid,startdate,category, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
}
module.exports = TrustYouSurveyReportHelper;

