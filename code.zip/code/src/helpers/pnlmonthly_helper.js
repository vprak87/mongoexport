const Constants = require('../common/constants');
const Utils = require('../common/utils');
const moment = require('moment');
const _ = require('lodash');

const PlStatementMonthWiseDataModel = require('../pnl/models/plstatementmonthwisedata');
const PLStatementMonthWiseitemDataModel = require('../pnl/models/plstatementmonthwiseitemdata');
const PLStatementRevenueItemDataModel = require('../pnl/models/plstatementrevenueitemdata');
const PLStatementYearWiseDataModel = require('../pnl/models/plstatementyearwisedata');
const PLStatementYearWiseItemDataModel = require('../pnl/models/plstatementyearwiseitemdata');

const { Hotelsourcetitles: HotelsourcetitlesSchema, SchemaField: HotelsourcetitlesSchemaFields } = require('../models/hotelsourcetitles');
const { Hotelrevenue: HotelrevenueSchema, SchemaField: HotelrevenueSchemaFields } = require('../models/hotelrevenue');
const { Hotelexternaldata: HotelexternaldataSchema, SchemaField: HotelexternaldataSchemaFields } = require('../models/hotelexternaldata');
const { Qbdescriptionmapping: QbdescriptionmappingSchema, SchemaField: QbdescriptionmappingSchemaFields } = require('../models/qbdescriptionmapping');
const { Hoteldashboardcalculations: HoteldashboardcalculationsSchema, SchemaField: HoteldashboardcalculationsSchemaFields } = require('../models/hoteldashboardcalculations');
const { Glcodehotelrevenue: GlcodehotelrevenueSchema, SchemaField: GlcodehotelrevenueSchemaFields } = require('../models/glcodehotelrevenue');
const { Glcodemaster: GlcodemasterSchema, SchemaField: GlcodemasterSchemaFields } = require('../models/glcodemaster');
const { Hotelbudget: HotelbudgetSchema, SchemaField: HotelbudgetSchemaFields } = require('../models/hotelbudget');
const { Hotels: HotelsSchema, SchemaField: HotelsSchemaFields } = require('../models/hotels');
const { Department: DepartmentSchema, SchemaField: DepartmentSchemaFields } = require('../models/department');
const { Hotelbudgetexpenseform: HotelbudgetexpenseformSchema, SchemaField: HotelbudgetexpenseformSchemaFields } = require('../models/hotelbudgetexpenseform');
const { Hoteleffectivenesscalculations: HoteleffectivenesscalculationsSchema, SchemaField: HoteleffectivenesscalculationsSchemaFields } = require('../models/hoteleffectivenesscalculations');

const { PnlcustomRaw: PnlcustomizeRawSchema, SchemaField: PnlcustomizeRawSchemaField } = require('../models/pnlcustomizeview');
const { Pnlmonthlycolorder: PnlmonthlycolorderSchema, SchemaField: PnlmonthlycolorderSchemaField } = require('../models/pnlmonthlycolorder');

const HotelsHelper = require('./hotels_helper');
const PnlYearHelper = require('./pnlyear_helper');
const PickUpHelper = require('./pickup_helper');

const UserHelper = require('./user_helper');

var log = require('log4js').getLogger("pnlmonthly_helper");

class PnlMonthHelper {
  static async getMonthPnlData(hotelid, today, userconfigdata, cb) {
    // console.log(userconfigdata, 'userconfigdata');
    let userID = userconfigdata.UserID;
    console.log(userID, 'userID');
    (async() => {
      hotelid = parseInt(hotelid);

      if(today == null || today == "") {
        today = new Date();
      }

      let currentDate = today;
      let yeasterday = new Date(today);
      let model = new PLStatementYearWiseDataModel();
      model.setFormat();

      model.Year = new Date(yeasterday).getFullYear();
      let hotelids = [hotelid];
      let hotel = await PnlYearHelper.getHotelbyId(hotelid);
      model.OrgId = hotel.OrganizationId;

      let totalRevenue = 0;
      let otherRevenue = 0;
      let fnbrevenue = 0;
      let totalProperty = 0;

      let lastYear = Utils.lastYearDate(yeasterday);
      let yeasterday1 = new Date(moment(today).add(1, 'days').format("YYYY-MM-DD"));

      let hdList = await PnlMonthHelper.getHotelDashboardCalculations2(yeasterday.toISOString(), yeasterday1.toISOString(), hotelids);

      if (hdList != null && hdList.length > 0)
      {
          totalRevenue = parseFloat(hdList[0].TotalRevenue);
          otherRevenue = parseFloat(hdList[0].OtherRevenue);
          fnbrevenue = parseFloat(hdList[0].FANDBRevenue);
          totalProperty = totalRevenue + otherRevenue + fnbrevenue;
      }

      // console.log('status')

      let islabordataavailable = await PnlYearHelper.isActiveOrganisation(hotel.OrganizationId);
      let currentPurchaseItem = await PnlYearHelper.getPurchaseItemData(hotel.HotelCode, yeasterday, yeasterday1);

      let currentLabourExpenses = await PnlMonthHelper.getLabourExpenseData2(hotel.ID, yeasterday, yeasterday);
      let objCPORRevenueData = await PnlYearHelper.getPLStatementMonthWiseRevenueData(hotelid, yeasterday, "MTD");
      let currentExternalData = await PnlMonthHelper.getExternalData2(hotel.ID, yeasterday, yeasterday1);
      let currenTaxData = await PnlMonthHelper.getTaxData2(hotel.ID, yeasterday, yeasterday1);

      if (objCPORRevenueData != null && objCPORRevenueData.length > 0 && _.sumBy(objCPORRevenueData, function(o) { return o.NoOfRoomSold; }) == 0)
      {
          objCPORRevenueData[0].NoOfRoomSold = 1;
      }

      // console.log('status2');
      let pArray = [];
      
      // console.log('Start')

      let item = new PLStatementYearWiseItemDataModel();

      model.CategoryList.forEach(async cat => {
        pArray.push(
          new Promise(async (resolve, reject) => { 
          // console.log('Start1')
            let startdate = new Date();
            let enddate = new Date();
            let stLy = new Date();
            let etLy = new Date();

            let period = "Current";
            if (cat == "MTD")
            {
                startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
                enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                period = "MTD";
            }
            else if (cat == "YTD")
            {
                startdate = new Date(yeasterday.getFullYear(), 1, 1, 0, 0, 0);
                enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                period = "YTD";
            }
            else if (cat == "Last Year Actual")
            {
                stLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
                etLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
            }
            else if (cat == "Variance to Last Year")
            {
                stLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
                etLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
            }
            else if (cat == "CPOR")
            {
                startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
                enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
            }
            else if (cat == "GL Code")
            {
                startdate = new Date(yeasterday.getFullYear(), 1, 1, 0, 0, 0);
                enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
            }

            let item = new PLStatementYearWiseItemDataModel();
            item.Period = cat;

            let roomrevenueData = new PLStatementRevenueItemDataModel();
            roomrevenueData.Name = "Room Revenue";
            roomrevenueData.Category = "Revenue";
            roomrevenueData.MonthName = item.Period;
            roomrevenueData.GLCode = "000.00";

            let fnbrevenueData = new PLStatementRevenueItemDataModel();
            fnbrevenueData.Name = "F&B Revenue";
            fnbrevenueData.Category = "Revenue";
            fnbrevenueData.MonthName = item.Period;
            fnbrevenueData.GLCode = "000.00";

            let otherrevenueData = new PLStatementRevenueItemDataModel();
            otherrevenueData.Name = "Other Revenue";
            otherrevenueData.Category = "Revenue";
            otherrevenueData.MonthName = item.Period;
            otherrevenueData.GLCode = "000.00";

            let outlet1otherrevenue = new PLStatementRevenueItemDataModel();
            outlet1otherrevenue.Name = "Outlet 1 - Other";
            outlet1otherrevenue.Category = "Revenue";
            outlet1otherrevenue.MonthName = item.Period;
            outlet1otherrevenue.GLCode = "000.00";

            let outlet2otherrevenue = new PLStatementRevenueItemDataModel();
            outlet2otherrevenue.Name = "Outlet 2 - Other";
            outlet2otherrevenue.Category = "Revenue";
            outlet2otherrevenue.MonthName = item.Period;
            outlet2otherrevenue.GLCode = "000.00";

            let outlet3otherrevenue = new PLStatementRevenueItemDataModel();
            outlet3otherrevenue.Name = "Outlet 3 - Other";
            outlet3otherrevenue.Category = "Revenue";
            outlet3otherrevenue.MonthName = item.Period;
            outlet3otherrevenue.GLCode = "000.00";

            let outlet4otherrevenue = new PLStatementRevenueItemDataModel();
            outlet4otherrevenue.Name = "Outlet 4 - Other";
            outlet4otherrevenue.Category = "Revenue";
            outlet4otherrevenue.MonthName = item.Period;
            outlet4otherrevenue.GLCode = "000.00";

            let outlet1fandbrevenue = new PLStatementRevenueItemDataModel();
            outlet1fandbrevenue.Name = "Outlet 1 - F&B";
            outlet1fandbrevenue.Category = "Revenue";
            outlet1fandbrevenue.MonthName = item.Period;
            outlet1fandbrevenue.GLCode = "000.00";

            let outlet2fandbrevenue = new PLStatementRevenueItemDataModel();
            outlet2fandbrevenue.Name = "Outlet 2 - F&B";
            outlet2fandbrevenue.Category = "Revenue";
            outlet2fandbrevenue.MonthName = item.Period;
            outlet2fandbrevenue.GLCode = "000.00";

            let outlet3fandbrevenue = new PLStatementRevenueItemDataModel();
            outlet3fandbrevenue.Name = "Outlet 3 - F&B";
            outlet3fandbrevenue.Category = "Revenue";
            outlet3fandbrevenue.MonthName = item.Period;
            outlet3fandbrevenue.GLCode = "000.00";

            let outlet4fandbrevenue = new PLStatementRevenueItemDataModel();
            outlet4fandbrevenue.Name = "Outlet 4 - F&B";
            outlet4fandbrevenue.Category = "Revenue";
            outlet4fandbrevenue.MonthName = item.Period;
            outlet4fandbrevenue.GLCode = "000.00";

            let restaurantrevenue = new PLStatementRevenueItemDataModel();
            restaurantrevenue.Name = "Restaurant";
            restaurantrevenue.Category = "Revenue";
            restaurantrevenue.MonthName = item.Period;
            restaurantrevenue.GLCode = "000.00";

            let barrevenue = new PLStatementRevenueItemDataModel();
            barrevenue.Name = "Bar";
            barrevenue.Category = "Revenue";
            barrevenue.MonthName = item.Period;
            barrevenue.GLCode = "000.00";

            let banquetrevenue = new PLStatementRevenueItemDataModel();
            banquetrevenue.Name = "Banquet";
            banquetrevenue.Category = "Revenue";
            banquetrevenue.MonthName = item.Period;
            banquetrevenue.GLCode = "000.00";

            let parkingrevenue = new PLStatementRevenueItemDataModel();
            parkingrevenue.Name = "Parking";
            parkingrevenue.Category = "Revenue";
            parkingrevenue.MonthName = item.Period;
            parkingrevenue.GLCode = "000.00";

            let giftshoprevenue = new PLStatementRevenueItemDataModel();
            giftshoprevenue.Name = "Gift Shop";
            giftshoprevenue.Category = "Revenue";
            giftshoprevenue.MonthName = item.Period;
            giftshoprevenue.GLCode = "000.00";

            let beveragerevenue = new PLStatementRevenueItemDataModel();
            beveragerevenue.Name = "Beverage";
            beveragerevenue.Category = "Revenue";
            beveragerevenue.MonthName = item.Period;
            beveragerevenue.GLCode = "000.00";

            let foodrevenue = new PLStatementRevenueItemDataModel();
            foodrevenue.Name = "Food";
            foodrevenue.Category = "Revenue";
            foodrevenue.MonthName = item.Period;
            foodrevenue.GLCode = "000.00";

            let totalrevenueData = new PLStatementRevenueItemDataModel();
            totalrevenueData.Name = "TOTAL SALES";
            totalrevenueData.Category = "Revenue";
            totalrevenueData.MonthName = item.Period;

            // console.log('Start2')
            // console.log(cat, 'cat')

            if (cat == "MTD" || cat == "YTD")
            {
                let objRevenueData = await PnlYearHelper.getPLStatementMonthWiseRevenueData(hotelid, yeasterday, period);
                // console.log('Start3')
                if (objRevenueData != null && objRevenueData.length > 0)
                {
                    roomrevenueData.Amount = _.sumBy(objRevenueData, function(x) { return x.RoomRevenue});
                    
                    fnbrevenueData.Amount = _.sumBy(objRevenueData, function(x) { return x.FANDBRevenue});
                    // console.log(fnbrevenueData.Amount, 'fnbrevenueData.Amount')
                    otherrevenueData.Amount = _.sumBy(objRevenueData, function(x) { return x.OtherRevenue});
                    // console.log(otherrevenueData.Amount, 'otherrevenueData.Amount')
                    outlet1otherrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.Outet1OtherRevenue});
                    // console.log(outlet1otherrevenue.Amount, 'outlet1otherrevenue.Amount')
                    outlet2otherrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.Outet2OtherRevenue});
                    // console.log(outlet2otherrevenue.Amount, 'outlet2otherrevenue.Amount')
                    outlet3otherrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.Outet3OtherRevenue});
                    // console.log(outlet3otherrevenue.Amount, 'outlet3otherrevenue.Amount')
                    outlet4otherrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.Outet4OtherRevenue});
                    // console.log(outlet4otherrevenue.Amount, 'outlet4otherrevenue.Amount')
                    outlet1fandbrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.Outet1FANDBRevenue});
                    // console.log(outlet1fandbrevenue.Amount, 'outlet1fandbrevenue.Amount')
                    outlet2fandbrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.Outet2FANDBRevenue});
                    // console.log(outlet2fandbrevenue.Amount, 'outlet2fandbrevenue.Amount')
                    outlet3fandbrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.Outet3FANDBRevenue});
                    // console.log(outlet3fandbrevenue.Amount, 'outlet3fandbrevenue.Amount')
                    outlet4fandbrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.Outet4FANDBRevenue});
                    // console.log(outlet4fandbrevenue.Amount, 'outlet4fandbrevenue.Amount')
                    restaurantrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.RestaurantRevenue});
                    barrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.BarRevenue});
                    banquetrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.BanquetRevenue});
                    // console.log(banquetrevenue.Amount, 'banquetrevenue.Amount')
                    parkingrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.ParkingRevenue});
                    // console.log(parkingrevenue.Amount, 'parkingrevenue.Amount')
                    giftshoprevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.GiftShopRevenue});
                    // console.log(giftshoprevenue.Amount, 'giftshoprevenue.Amount')
                    beveragerevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.BeverageRevenue});
                    // console.log(beveragerevenue.Amount, 'beveragerevenue.Amount')
                    foodrevenue.Amount = _.sumBy(objRevenueData, function(x) { return x.FoodRevenue});
                    // console.log(foodrevenue.Amount, 'foodrevenue.Amount')
                    totalrevenueData.Amount = roomrevenueData.Amount + fnbrevenueData.Amount + otherrevenueData.Amount + outlet1otherrevenue.Amount + outlet2otherrevenue.Amount + outlet3otherrevenue.Amount + outlet4otherrevenue.Amount + outlet1fandbrevenue.Amount + outlet2fandbrevenue.Amount + outlet3fandbrevenue.Amount + outlet4fandbrevenue.Amount + restaurantrevenue.Amount + barrevenue.Amount + banquetrevenue.Amount + parkingrevenue.Amount + giftshoprevenue.Amount + beveragerevenue.Amount + foodrevenue.Amount;
                    // console.log(totalrevenueData.Amount, 'totalrevenueData.Amount6')
                }
            } 
            else if(cat == "Variance to Budget") 
            {
              let varianceToBudgetModel = await PnlMonthHelper.getVarianceToBudget(totalRevenue, otherRevenue, fnbrevenue, totalProperty, hotelid, yeasterday);
              // console.log('Start31')
              if (varianceToBudgetModel != null)
              {
                  roomrevenueData.Amount = varianceToBudgetModel.RoomRevenue;
                  fnbrevenueData.Amount = varianceToBudgetModel.FNBRevenue;
                  otherrevenueData.Amount = varianceToBudgetModel.OtherRevenue;
                  totalrevenueData.Amount = (roomrevenueData.Amount + fnbrevenueData.Amount + otherrevenueData.Amount) / 3;
                  // console.log(totalrevenueData.Amount, 'totalrevenueData.Amount5')
              }
            }
            else if (cat == "Last Year Actual")
            {
              let lastYearActualModel = await PnlMonthHelper.getLastYearActualModel(hotelids, lastYear);
              // console.log('Start32')
              if (lastYearActualModel != null)
              {
                  roomrevenueData.Amount = lastYearActualModel.RoomRevenue;
                  fnbrevenueData.Amount = lastYearActualModel.FNBRevenue;
                  otherrevenueData.Amount = lastYearActualModel.OtherRevenue;
                  totalrevenueData.Amount = (roomrevenueData.Amount + fnbrevenueData.Amount + otherrevenueData.Amount);

              }
            } 
            else if (cat == "Variance to Last Year")
            {
                let lastYearActualModel = await PnlMonthHelper.getLastYearActualModel(hotelids, lastYear);
                // console.log('Start33')
                if (lastYearActualModel != null)
                {
                    if (lastYearActualModel.RoomRevenue != 0 && totalRevenue != 0)
                    {
                        roomrevenueData.Amount = ((totalRevenue - lastYearActualModel.RoomRevenue) / lastYearActualModel.RoomRevenue) * 100;
                    }
                    if (lastYearActualModel.FNBRevenue != 0 && fnbrevenue != 0)
                    {
                        fnbrevenueData.Amount = ((fnbrevenue - lastYearActualModel.FNBRevenue) / lastYearActualModel.FNBRevenue) * 100;
                    }
                    if (lastYearActualModel.OtherRevenue != 0 && otherRevenue != 0)
                    {
                        otherrevenueData.Amount = ((otherRevenue - lastYearActualModel.OtherRevenue) / lastYearActualModel.OtherRevenue) * 100;
                    }
                    if ((roomrevenueData.Amount + fnbrevenueData.Amount + otherrevenueData.Amount) != 0)
                    {
                        totalrevenueData.Amount = (roomrevenueData.Amount + fnbrevenueData.Amount + otherrevenueData.Amount) / 3;
                    }
                    // console.log(totalrevenueData.Amount, 'totalrevenueData.Amount3')
                }
            }
            else if (cat == "Last Year Budget")
            {
                let lastYearBudgetModel = await PnlMonthHelper.getLastYearToBudget(hotelid, lastYear);
                // console.log('Start34')
                if (lastYearBudgetModel != null)
                {
                    roomrevenueData.Amount = lastYearBudgetModel.RoomRevenue;
                    fnbrevenueData.Amount = lastYearBudgetModel.FNBRevenue;
                    otherrevenueData.Amount = lastYearBudgetModel.OtherRevenue;
                    totalrevenueData.Amount = (roomrevenueData.Amount + fnbrevenueData.Amount + otherrevenueData.Amount);
                    // console.log(totalrevenueData.Amount, 'totalrevenueData.Amount1')
                }
            }
            else if (cat == "CPOR")
            {
                if (objCPORRevenueData != null && objCPORRevenueData.length > 0)
                {
                    roomrevenueData.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.RoomRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    
                    fnbrevenueData.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.FANDBRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    otherrevenueData.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.OtherRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    outlet1otherrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.Outet1OtherRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    outlet2otherrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.Outet2OtherRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    outlet3otherrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.Outet3OtherRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    outlet4otherrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.Outet4OtherRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    outlet1fandbrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.Outet1FANDBRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    outlet2fandbrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.Outet2FANDBRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    outlet3fandbrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.Outet3FANDBRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    outlet4fandbrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.Outet4FANDBRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    restaurantrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.RestaurantRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    barrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.BarRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    banquetrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.BanquetRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    parkingrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.ParkingRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    giftshoprevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.GiftShopRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    beveragerevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.BeverageRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    foodrevenue.Amount = _.sumBy(objCPORRevenueData, function (x){ return x.FoodRevenue}) / _.sumBy(objCPORRevenueData, function (x){ return x.NoOfRoomSold});
                    totalrevenueData.Amount = roomrevenueData.Amount + fnbrevenueData.Amount + otherrevenueData.Amount + outlet1otherrevenue.Amount + outlet2otherrevenue.Amount + outlet3otherrevenue.Amount + outlet4otherrevenue.Amount + outlet1fandbrevenue.Amount + outlet2fandbrevenue.Amount + outlet3fandbrevenue.Amount + outlet4fandbrevenue.Amount + restaurantrevenue.Amount + barrevenue.Amount + banquetrevenue.Amount + parkingrevenue.Amount + giftshoprevenue.Amount + beveragerevenue.Amount + foodrevenue.Amount;
                    // console.log(totalrevenueData.Amount, 'totalrevenueData.Amount2')
                }
            }
            else if (cat == "GL Code")
            {
              // console.log('///////////////////////////////////')
                if (objCPORRevenueData != null && objCPORRevenueData.length > 0)
                {
                    // console.log('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///')
                    roomrevenueData.GLCode = await PnlMonthHelper.getGLCode2(roomrevenueData.Name, hotelid);
                    // console.log('Start35')
                    fnbrevenueData.GLCode = await PnlYearHelper.getGLCode(fnbrevenueData.Name, hotelid);
                    otherrevenueData.GLCode = await PnlYearHelper.getGLCode(otherrevenueData.Name, hotelid);
                    outlet1otherrevenue.GLCode = await PnlYearHelper.getGLCode(outlet1otherrevenue.Name, hotelid);
                    outlet2otherrevenue.GLCode = await PnlYearHelper.getGLCode(outlet2otherrevenue.Name, hotelid);
                    outlet3otherrevenue.GLCode = await PnlYearHelper.getGLCode(outlet3otherrevenue.Name, hotelid);
                    outlet4otherrevenue.GLCode = await PnlYearHelper.getGLCode(outlet4otherrevenue.Name, hotelid);
                    outlet1fandbrevenue.GLCode = await PnlYearHelper.getGLCode(outlet1fandbrevenue.Name, hotelid);
                    outlet2fandbrevenue.GLCode = await PnlYearHelper.getGLCode(outlet2fandbrevenue.Name, hotelid);
                    outlet3fandbrevenue.GLCode = await PnlYearHelper.getGLCode(outlet3fandbrevenue.Name, hotelid);
                    outlet4fandbrevenue.GLCode = await PnlYearHelper.getGLCode(outlet4fandbrevenue.Name, hotelid);
                    restaurantrevenue.GLCode = await PnlYearHelper.getGLCode(restaurantrevenue.Name, hotelid);
                    barrevenue.GLCode = await PnlYearHelper.getGLCode(barrevenue.Name, hotelid);
                    banquetrevenue.GLCode = await PnlYearHelper.getGLCode(banquetrevenue.Name, hotelid);
                    parkingrevenue.GLCode = await PnlYearHelper.getGLCode(parkingrevenue.Name, hotelid);
                    giftshoprevenue.GLCode = await PnlYearHelper.getGLCode(giftshoprevenue.Name, hotelid);
                    beveragerevenue.GLCode = await PnlYearHelper.getGLCode(beveragerevenue.Name, hotelid);
                    foodrevenue.GLCode = await PnlYearHelper.getGLCode(foodrevenue.Name, hotelid);

                    totalrevenueData.GLCode = await PnlYearHelper.getGLCode(totalrevenueData.GLCode, hotelid);
                    // console.log('finished')
                }
            }
            item.RevenueList.push(roomrevenueData);
            item.RevenueList.push(fnbrevenueData);
            item.RevenueList.push(otherrevenueData);
            item.RevenueList.push(totalrevenueData);

            let TotalefDataAmount = 0;
            let eflist = [];
            if (cat == "MTD" || cat == "YTD")
            {
                eflist = await PnlYearHelper.getPurchaseItemData(hotel.HotelCode, startdate, enddate);
            }
            else if (cat == "Last Year Actual")
            {
                eflist = await PnlYearHelper.getPurchaseItemData(hotel.HotelCode, stLy, etLy);
            }
            else if (cat == "Variance to Last Year")
            {
                let eflistly = await PnlYearHelper.getPurchaseItemData(hotel.HotelCode, stLy, etLy);

                currentPurchaseItem.forEach(currentitem => {
                  let itemvly = {
                    RefNumber: '',
                    Description: '',
                    DMRASubType: '',
                    UnitPrice: '',
                    GLCode: '',
                    CreatedBy: '',
                    puCreatedOn: '',
                    ModifiedBy: '',
                    puModifiedOn: '',
                    HotelCode: '',
                    AccountNumber: '',
                    DepartmentId: '',
                    Quantity: '',
                    DepartmentName: '',
                    PurchaseOrderId: '',
                    ExpenseFormLink: '',
                    puPoDate: ''
                  };

                  itemvly.AccountNumber = currentitem.AccountNumber;
                  let lyUnitPrice = 0;
                  lyUnitPrice = _.sumBy(_.filter(eflistly, function (x) { return x.AccountNumber == currentitem.AccountNumber}) , function (o){ return o.UnitPrice});
                  if (lyUnitPrice != 0 && currentitem.UnitPrice != 0)
                  {
                      itemvly.UnitPrice = ((currentitem.UnitPrice - lyUnitPrice) / lyUnitPrice) * 100;
                  }
                  eflist.push(itemvly);
                });
            }
            else if (cat == "Variance to Budget")
            {
              currentPurchaseItem.forEach(currentitem => {
                let itemvly = {
                  RefNumber: '',
                  Description: '',
                  DMRASubType: '',
                  UnitPrice: '',
                  GLCode: '',
                  CreatedBy: '',
                  puCreatedOn: '',
                  ModifiedBy: '',
                  puModifiedOn: '',
                  HotelCode: '',
                  AccountNumber: '',
                  DepartmentId: '',
                  Quantity: '',
                  DepartmentName: '',
                  PurchaseOrderId: '',
                  ExpenseFormLink: '',
                  puPoDate: ''
                };

                itemvly.AccountNumber = currentitem.AccountNumber;
                lyBudget = 0;
                itemvly.UnitPrice = lyBudget;
                eflist.push(itemvly);
              });
            }
            else if (cat == "CPOR" || cat == "GL Code")
            {
              let eflistcpor = await await PnlYearHelper.getPurchaseItemData(hotel.HotelCode, startdate, yeasterday);
              eflistcpor.forEach(currentitem => {
                let itemvly = {
                  RefNumber: '',
                  Description: '',
                  DMRASubType: '',
                  UnitPrice: '',
                  GLCode: '',
                  CreatedBy: '',
                  puCreatedOn: '',
                  ModifiedBy: '',
                  puModifiedOn: '',
                  HotelCode: '',
                  AccountNumber: '',
                  DepartmentId: '',
                  Quantity: '',
                  DepartmentName: '',
                  PurchaseOrderId: '',
                  ExpenseFormLink: '',
                  puPoDate: ''
                };
                itemvly.AccountNumber = currentitem.AccountNumber;
                itemvly.UnitPrice = currentitem.UnitPrice / _.sumBy(objCPORRevenueData, function(x) { return x.NoOfRoomSold });
                itemvly.GLCode = currentitem.GLCode;
                eflist.push(itemvly);
              });
            }

            if (eflist != null && eflist.length > 0)
            {
              // eflist = FilterInactiveDesc(eflist, "Expense");
              eflist =await PnlYearHelper.filterInactiveDesc(eflist, "Expense");
              eflist = GroupByGLCode(eflist);

              eflist.forEach(async ef => {
                efData = new PLStatementRevenueItemDataModel();
                efData.Name = ef.AccountNumber;
                efData.Category = "Expense";
                efData.MonthName = item.Period;
                efData.Amount = parseFloat(ef.UnitPrice);
                efData.GLCode = await PnlYearHelper.getGLCodePL(efData.Name, hotelid);
                item.ExpenseList.push(efData);
                model.ExpenseList.push(efData);
              });
            }

            let externalDataList = [];
            if (cat == "MTD" || cat == "YTD" || cat == "GL Code")
            {
                externalDataList = await PnlMonthHelper.getExternalData2(hotel.ID, startdate, enddate);
            }
            else if (cat == "Last Year Actual")
            {
                externalDataList = await PnlMonthHelper.getExternalData2(hotel.ID, stLy, etLy);
            }
            else if (cat == "Variance to Last Year")
            {
                let eflistly = await PnlMonthHelper.getExternalData2(hotel.ID, stLy, etLy);

                currentExternalData.forEach(async currentitem => {
                  itemvly = { 
                    ID: '',
                    HotelID: '',
                    Date: '',
                    Category: '',
                    Description: '',
                    Amount: '',
                    UpdatedBy: '',
                    UpdatedDateTime: '',
                    IsDelete: false
                  }

                  itemvly.Description = currentitem.Description;
                  let lyUnitPrice = 0;
                  lyUnitPrice = _.sumBy(_.filter(eflistly, function(o) { return o.Description == currentitem.Description }) , function (x) {return x.Amount});
                  if (lyUnitPrice != 0 && lyUnitPrice != null && currentitem.Amount != 0)
                  {
                      itemvly.Amount = ((currentitem.Amount - lyUnitPrice) / lyUnitPrice) * 100;
                  }
                  externalDataList.push(itemvly);
                });
            }
            else if (cat == "CPOR")
            {
              let eflistcpor = await PnlMonthHelper.getExternalData2(hotel.ID, startdate, enddate);
              eflistcpor.forEach(async currentitem => {
                let itemvly = {
                  ID: '',
                  HotelID: '',
                  Date: '',
                  Category: '',
                  Description: '',
                  Amount: '',
                  UpdatedBy: '',
                  UpdatedDateTime: '',
                  IsDelete: false
                }

                itemvly.Description = currentitem.Description;
                itemvly.Amount = currentitem.Amount / objCPORRevenueData.Sum(x => x.NoOfRoomSold);
                externalDataList.push(itemvly);
              });
            }
            if (externalDataList != null && externalDataList.length > 0)
            {
                externalDataList = groupByDescription(externalDataList);
                externalDataList.forEach(async ef => {
                  efData = new PLStatementRevenueItemDataModel();
                  efData.Name = await PnlYearHelper.getGLCodePLV2(ef.Description, hotelid);
                  efData.Category = "Expense";
                  efData.MonthName = item.Period;
                  efData.Amount = parseFloat(ef.Amount);
                  efData.GLCode = await PnlYearHelper.getGLCodePL(efData.Name, hotelid);
                  item.ExpenseList.push(efData);
                  model.ExpenseList.push(efData);
                });
            }

            let efTotal = (item.ExpenseList != null && item.ExpenseList.length > 0) ? _.sumBy(item.ExpenseList, function(x) { return x.Amount }) : 0;
            let TotalefData = new PLStatementRevenueItemDataModel();
            TotalefData.Name = "TOTAL EXPENSES";
            TotalefData.Category = "Expense";
            TotalefData.MonthName = item.Period;
            TotalefData.Amount = efTotal;
            TotalefDataAmount = TotalefData.Amount;
            item.ExpenseList.push(TotalefData);
            model.ExpenseList.push(TotalefData);

            item.ExpenseList = _(item.ExpenseList)
            .groupBy('Name', 'MonthName', 'GLCode')
            .map((objs, key) => ({
                'Category': _.get(_.find(objs, function(o) { return true; }), 'Category') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'Category'),
                'Amount': _.sumBy(objs, 'Amount'),
                'Name': key,
                'MonthName': _.get(_.find(objs, function(o) { return true; }), 'MonthName') == undefined ? "" : _.get(_.find(objs, function(o) { return true; }), 'MonthName'),
                'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode') == undefined ? "" : _.get(_.find(objs, function(o) { return true; }), 'GLCode'),
                }))
            .value();

            let TotallbefDataAmount = 0;
            if (islabordataavailable)
            {
                model.LaborDataType = "(Hotel Effectiveness)";
            }
            else
            {
                model.LaborDataType = "";
            }

            let LabourDataList = [];
            if (cat == "MTD" || cat == "YTD" || cat == "GL Code")
            {
                LabourDataList = await PnlMonthHelper.getLabourExpenseData2(hotel.ID, startdate, enddate);
            }
            else if (cat == "Last Year Actual")
            {
                LabourDataList = await PnlMonthHelper.getLabourExpenseData2(hotel.ID, stLy, etLy);
            }
            else if (cat == "Variance to Last Year")
            {
              let eflistly = await PnlMonthHelper.getLabourExpenseData2(hotel.ID, stLy, etLy);
              currentLabourExpenses.forEach(async currentitem => {
                itemvly = {
                  ID: '',
                  HotelID: '',
                  Date: '',
                  Department: '',
                  Wages: '',
                  PlanWages: '',
                  Hours: '',
                  PlanHours: '',
                  UpdatedBy: '',
                  UpdatedDateTime: '',
                  ToDate: '',
                  FromDate: '',
                  Category: ''
                }

                itemvly.Department = currentitem.Department;
                let lyUnitPrice = 0;
                lyUnitPrice = _.sumBy(_.filter(eflistly, function(o) { return o.Department == currentitem.Department }) , function (x) {return x.Wages});
                if (lyUnitPrice != 0 && lyUnitPrice != null && currentitem.Wages != 0 && currentitem.Wages != null)
                {
                  itemvly.Wages = ((currentitem.Wages - lyUnitPrice) / lyUnitPrice) * 100;
                }
                LabourDataList.push(itemvly);
              });
            }
            else if (cat == "CPOR")
            {
              let eflistcpor = await PnlMonthHelper.getLabourExpenseData2(hotel.ID, startdate, enddate);
              eflistcpor.forEach(async currentitem => {
                let itemcpor = {
                  ID: '',
                  HotelID: '',
                  Date: '',
                  Department: '',
                  Wages: '',
                  PlanWages: '',
                  Hours: '',
                  PlanHours: '',
                  UpdatedBy: '',
                  UpdatedDateTime: '',
                  ToDate: '',
                  FromDate: '',
                  Category: ''
                }

                itemcpor.Department = currentitem.Department;
                if (objCPORRevenueData.length > 0) {
                  itemcpor.Wages = currentitem.Wages / _.sumBy(objCPORRevenueData, function(x){ return x.NoOfRoomSold });
                }
                LabourDataList.push(itemcpor);
              });
            }
            else if (cat == "Variance to Budget")
            {
              let lstexpenseDepartment = await PnlMonthHelper.getExpenseDepartmentBudget(hotel.ID, "current", yeasterday);

              currentLabourExpenses.forEach(async currentitem => {
                let itemvly = {
                  ID: '',
                  HotelID: '',
                  Date: '',
                  Department: '',
                  Wages: '',
                  PlanWages: '',
                  Hours: '',
                  PlanHours: '',
                  UpdatedBy: '',
                  UpdatedDateTime: '',
                  ToDate: '',
                  FromDate: '',
                  Category: ''
                }
                itemvly.Department = currentitem.Department;
                let budget = _.sumBy(_.filter(lstexpenseDepartment, function(x){return x.DepartmentName.ToLower() == itemvly.Department.ToLower() }), function(o) { return o.Budget; });
              
                if (budget != 0 && itemvly.Wages != 0)
                {
                    itemvly.Wages = ((itemvly.Wages - parseFloat(budget)) / parseFloat(budget)) * 100;
                }
                LabourDataList.push(itemvly);
              });
            }

            if (LabourDataList != null && LabourDataList.length > 0)
            {
              LabourDataList = await PnlYearHelper.filterInactiveDescLB(LabourDataList, "LaborExpense");
              LabourDataList.forEach(async lb => {
                let efData = new PLStatementRevenueItemDataModel();
                efData.Name = lb.Department;
                efData.Category = "Labour Expense";
                efData.MonthName = item.Period;
                efData.Amount = parseFloat(lb.Wages);
                efData.GLCode = await PnlYearHelper.getGLCodePL(efData.Name, hotelid);
                item.LabourExpenseList.push(efData);
                model.LabourExpenseList.push(efData);
              });
              let lbefTotal = (item.LabourExpenseList != null && item.LabourExpenseList.length > 0) ? _.sumBy(item.LabourExpenseList, function(x) {return x.Amount }) : 0;
              
              let TotallbefData = new PLStatementRevenueItemDataModel();
              TotallbefData.Name = "TOTAL LABOR EXPENSES";
              TotallbefData.Category = "Labour Expense";
              TotallbefData.MonthName = item.Period;
              TotallbefData.Amount = lbefTotal;
              TotallbefDataAmount = TotallbefData.Amount;
              item.LabourExpenseList.push(TotallbefData);
              model.LabourExpenseList.push(TotallbefData);

              item.LabourExpenseList = _(item.LabourExpenseList)
              .groupBy('Name', 'MonthName', 'GLCode')
              .map((objs, key) => ({
                  'Category': _.get(_.find(objs, function(o) { return true; }), 'Category') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'Category'),
                  'Amount': _.sumBy(objs, 'Amount'),
                  'Name': key,
                  'MonthName': _.get(_.find(objs, function(o) { return true; }), 'MonthName') == undefined ? "" : _.get(_.find(objs, function(o) { return true; }), 'MonthName'),
                  'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode') == undefined ? "" : _.get(_.find(objs, function(o) { return true; }), 'GLCode'),
                  }))
              .value();
            }

            let TotaltaxDataAmount = 0;
            let taxList = [];
            if (cat == "MTD" || cat == "YTD" || cat == "GL Code")
            {
                taxList = await PnlMonthHelper.getTaxData2(hotelid, startdate, enddate);
            }
            else if (cat == "Last Year Actual")
            {
                taxList = await PnlMonthHelper.getTaxData2(hotelid, stLy, etLy);
            }
            else if (cat == "Variance to Last Year")
            {
              let eflistly = await PnlMonthHelper.getTaxData2(hotel.ID, stLy, etLy);

              currenTaxData.forEach(async currentitem => {
                let itemvly = {
                  ID: '',
                  HotelID: '',
                  Date: '',
                  Category: '',
                  Description: '',
                  NoOfReference: '',
                  Amount: '',
                  NumberofAvailableRooms: '',
                  UpdatedBy: '',
                  UpdatedDateTime: '',
                  IsDelete: '',
                  ReportedDateTime: '',
                  TransientRoomsSold: '',
                  TransientRoomRevenue: '',
                  GroupRoomsSold: '',
                  GroupRoomRevenue: '',
                  GroupBlock: '',
                  AmountMTD: '',
                  AmountYTD: '',
                  PMSCode: '',
                  PMSType: '',
                  ReportName: '',
                  AccountingID: '',
                  Hotel: '',
                }

                itemvly.Description = currentitem.Description;
                let lyUnitPrice = 0;
                lyUnitPrice = _.sumBy(_.filter(eflistly, function(o) { return o.Description == currentitem.Description }) , function (x) {return x.Amount});
                if (lyUnitPrice != 0 && lyUnitPrice != null && currentitem.Amount != 0)
                {
                    itemvly.Amount = ((currentitem.Amount - lyUnitPrice) / lyUnitPrice) * 100;
                }
                taxList.push(itemvly);
              });
            }
            else if (cat == "CPOR")
            {
              let eflistcpor = await PnlMonthHelper.getTaxData2(hotelid, startdate, enddate);
              eflistcpor.forEach(currentitem => {
                let itemcpor = {
                  ID: '',
                  HotelID: '',
                  Date: '',
                  Category: '',
                  Description: '',
                  NoOfReference: '',
                  Amount: '',
                  NumberofAvailableRooms: '',
                  UpdatedBy: '',
                  UpdatedDateTime: '',
                  IsDelete: '',
                  ReportedDateTime: '',
                  TransientRoomsSold: '',
                  TransientRoomRevenue: '',
                  GroupRoomsSold: '',
                  GroupRoomRevenue: '',
                  GroupBlock: '',
                  AmountMTD: '',
                  AmountYTD: '',
                  PMSCode: '',
                  PMSType: '',
                  ReportName: '',
                  AccountingID: '',
                  Hotel: '',
                }
                itemcpor.Description = currentitem.Description;
                itemcpor.Amount = currentitem.Amount / _.sumBy(objCPORRevenueData, function(x) { x.NoOfRoomSold });
                taxList.push(itemcpor);
              });
            }

            if (taxList != null && taxList.length > 0)
            {
              taxList.forEach(async tax => {
                taxData = new PLStatementRevenueItemDataModel();
                taxData.Name = tax.Description;
                taxData.Category = "Tax";
                taxData.MonthName = item.Period;
                taxData.Amount = parseFloat(tax.Amount);
                taxData.GLCode = await PnlYearHelper.getGLCode(taxData.Name, hotelid);
                item.TaxList.push(taxData);
                model.TaxList.push(taxData);
              });

              //Total Tax
              let TotaltaxData = new PLStatementRevenueItemDataModel();
              TotaltaxData.Name = "TOTAL TAX";
              TotaltaxData.Category = "Tax";
              TotaltaxData.MonthName = item.Period;
              TotaltaxData.Amount = (item.TaxList != null && item.TaxList.length > 0) ? _.sumBy(item.TaxList, function(x) { x.Amount }) : 0;
              TotaltaxDataAmount = TotaltaxData.Amount;
              item.TaxList.push(TotaltaxData);
              model.TaxList.push(TotaltaxData);
            }

            let netbeforeTax = new PLStatementRevenueItemDataModel();
            netbeforeTax.Category = "netbeforeTax";
            netbeforeTax.MonthName = item.Period;
            // console.log(totalrevenueData.Amount, 'totalrevenueData.Amount');
            netbeforeTax.Amount = totalrevenueData.Amount - TotalefDataAmount - TotallbefDataAmount;
            netbeforeTax.Name = "Net Profit before Tax";
            model.NetBeforeTaxList.push(netbeforeTax);

            let netprofit = new PLStatementRevenueItemDataModel();
            netprofit.Category = "netprofit";
            netprofit.MonthName = item.Period;
            // console.log(netbeforeTax.Amount, 'netbeforeTax.Amount');
            netprofit.Amount = netbeforeTax.Amount;
            if (model.OrgId != 238)
            {
                netprofit.Amount = netbeforeTax.Amount - TotaltaxDataAmount;
            }
            netprofit.Name = "Net Profit";
            model.NetProfitList.push(netprofit);

            let netprofitmargin = new PLStatementRevenueItemDataModel();
            netprofitmargin.Category = "netprofitmargin";
            netprofitmargin.MonthName = item.Period;
            netprofitmargin.Amount = 0;
            if (netbeforeTax.Amount != 0 && totalrevenueData.Amount != 0)
            {
                netprofitmargin.Amount = (netbeforeTax.Amount / totalrevenueData.Amount) * 100;
            }
            netprofitmargin.Name = "Gross Profit Margin";
            model.NetProfitMarginList.push(netprofitmargin);

            model.Items.push(item);
            resolve();
            // console.log('end')
          })
        )
      });// end of for loop ------------------------------------------------------------------>
    
      Promise.all(pArray).then(resp => {
        
        Promise.all([

        ])

        if (model.ExpenseList != null && model.ExpenseList.length > 0)
        {
          model.ExpenseList = _(item.ExpenseList)
          .groupBy('Name')
          .map((objs, Key) => ({
            'Name': Key,
            'Amount': _.sumBy(objs, 'Amount'),
            'MonthName': _.last(objs, 'MonthName'),
            'Category': _.last(objs, 'Category')
          })) 
          .value();

          model.ExpenseList =_.orderBy(model.ExpenseList , ['Name'], ['asc']);

          let TOTALEXPENSESitem = _.find(model.ExpenseList, function(x) { return x.Name == "TOTAL EXPENSES" });
          let oldIndex = model.ExpenseList.findIndex(x => x.Name == "TOTAL EXPENSES" );
          model.ExpenseList.splice(oldIndex, 1);
          model.ExpenseList.push(TOTALEXPENSESitem);
        }

        if (model.TaxList != null && model.TaxList.length > 0)
        {
          model.TaxList = _(item.TaxList)
            .groupBy('Name')
            .map((objs, Key) => ({
              'Name': Key,
              'Amount': _.sumBy(objs, 'Amount'),
              'MonthName': _.last(objs, 'MonthName'),
              'Category': _.last(objs, 'Category')
            })) 
            .value();

          model.TaxList =_.orderBy(model.TaxList , ['Name'], ['asc']);

          let TOTALTAXitem = _.find(model.TaxList, function(x) { return x.Name == "TOTAL TAX"});
          let TOTALTAXoldIndex = model.TaxList.findIndex(x => x.Name == "TOTAL TAX");
          model.TaxList.splice(TOTALTAXoldIndex, 1);
          model.TaxList.push(TOTALTAXitem);
        }

        if (model.LabourExpenseList != null && model.LabourExpenseList.length > 0)
        {
          model.LabourExpenseList = _(item.LabourExpenseList)
            .groupBy('Name')
            .map((objs, Key) => ({
              'Name': Key,
              'Amount': _.sumBy(objs, 'Amount'),
              'MonthName': _.last(objs, 'MonthName'),
              'Category': _.last(objs, 'Category')
            })) 
            .value();

          model.LabourExpenseList =_.orderBy(model.LabourExpenseList , ['Name'], ['asc']);

          let TOTALEXPENSESitem = _.find(model.LabourExpenseList, function(x) { return x.Name == "TOTAL LABOR EXPENSES" });
          let oldIndex = model.LabourExpenseList.findIndex(x => x.Name =="TOTAL LABOR EXPENSES" );
          model.LabourExpenseList.splice(oldIndex, 1);
          model.LabourExpenseList.push(TOTALEXPENSESitem);
        }

        model.rawOrder = {};
        model.colOrder = {};

        PnlcustomizeRawSchema.findOne({[PnlcustomizeRawSchemaField.Hotel_ID]: hotelid, [PnlcustomizeRawSchemaField.Pnl_view]: 'Monthly'},
        (err, res) => {
          if(err) {
            log.error(err)
            reject(err)
          }
          model.rawOrder = res;

          console.log(hotelid, userconfigdata.UserID);
          PnlmonthlycolorderSchema.findOne({[PnlmonthlycolorderSchemaField.Hotel_ID]: hotelid, [PnlmonthlycolorderSchemaField.User_ID]: userID},
          // PnlmonthlycolorderSchema.findOne({[PnlmonthlycolorderSchemaField.Hotel_ID]: 123, [PnlmonthlycolorderSchemaField.User_ID]: 2},
            (err2, res2) => {
              if(err2) {
                log.error(err2)
                reject(err2)
              }
              model.colOrder = res2;

              return cb(null, model);
            })
        })


        // console.log('wait')
        // return cb(null, model);
      })
    })();
  }


  static async getHotelDashboardCalculations2(currentDate, prevDate, hotelid) {
    return new Promise((resolve, reject) => {
      HoteldashboardcalculationsSchema.find({[HoteldashboardcalculationsSchemaFields.HotelID]: { "$in": hotelid }, [HoteldashboardcalculationsSchemaFields.Date]: { "$gte": currentDate, "$lt": prevDate} },
      (err, calculationData) => {
        if (err) {
          log.error(err)
          reject(err)
        }
        resolve(calculationData);
      });
    });
  }

  static async getLabourExpenseData2(hotelId, startDate, endDate) {
    return new Promise((resolve, reject) => {
      let hotelEffectivenessMappingModelList = [];
      startDate = new Date(moment(startDate).format("YYYY-MM-DD")).toISOString();
      endDate = new Date(moment(endDate).format("YYYY-MM-DD")).toISOString();
      HoteleffectivenesscalculationsSchema.find({ $or: [{ [HoteleffectivenesscalculationsSchemaFields.ReportName]: "Adams_Keegan_Payroll_Report" }, { [HoteleffectivenesscalculationsSchemaFields.ReportName]: "Labor Allocation Report" }, { [HoteleffectivenesscalculationsSchemaFields.ReportName]: "Manual Entry" } ], [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId, [HoteleffectivenesscalculationsSchemaFields.Date]: { "$gte": startDate, "$lt": endDate }},
      (err, res) => {
        if(err) {
            log.error(err)
            reject(err)
        }
        let results = res;
        let groupdataList = _(results)
          .groupBy('Department')
          .map((objs, key) => ({
              'Department': key,
              'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
              'HotelID': _.get(_.find(objs, function(o) { return true; }), 'HotelID'),
              'Date': _.get(_.find(objs, function(o) { return true; }), 'Date'),
              'Category': _.get(_.find(objs, function(o) { return true; }), 'Category'),
              'ID': _.get(_.find(objs, function(o) { return true; }), 'ID'),
              'UpdatedBy': _.get(_.find(objs, function(o) { return true; }), 'UpdatedBy'),
              'UpdatedDateTime': _.get(_.find(objs, function(o) { return true; }), 'UpdatedDateTime'),
              'FromDate': _.get(_.find(objs, function(o) { return true; }), 'FromDate'),
              'ToDate': _.get(_.find(objs, function(o) { return true; }), 'ToDate'),
              'Wages': _.sumBy(objs, 'Wages'),
              'Hours': _.sumBy(objs, 'Hours')}))
          .value();

          groupdataList.forEach(async element => {
            PnlYearHelper.hotelEffectivemodelConverter(element , (err, res) =>{
              if(err) {
                log.error(err)
                reject(err);
              }
              hotelEffectivenessMappingModelList.push(res);
            })
          });
        resolve(hotelEffectivenessMappingModelList);
      })
    })
  }

  static async getExternalData2(hotelId, startDate, endDate) {
    return new Promise((resolve, reject) => {
      startDate = new Date(startDate).toISOString();
      endDate = new Date(endDate).toISOString();

      let finalData = [];
      let hotelExternalDataList = [];
      Promise.all([
        new Promise((resolve, reject) => {
          HotelexternaldataSchema.find({[HotelexternaldataSchemaFields.HotelID]: hotelId, [HotelexternaldataSchemaFields.Category]: "Expense", [HotelexternaldataSchemaFields.IsDelete]: false, [HotelexternaldataSchemaFields.Date]: { "$gte": startDate, "$lt": endDate}},
          (err, resp) => {
            // console.log(hotelExternalDataList, 'hotelExternalDataList');
            if(err) {
                log.error(err)
                reject(err);
            }
            hotelExternalDataList = resp;
            resolve();
          })
        })
      ]).then(res=> {
        let prArr = [];
        if(hotelExternalDataList.length > 0) {
          hotelExternalDataList.forEach(element => {
            prArr.push(
              new Promise((resolve, reject) => {
                QbdescriptionmappingSchema.find({[QbdescriptionmappingSchemaFields.HotelID]: hotelId, [QbdescriptionmappingSchemaFields.IsActive]: false, [QbdescriptionmappingSchemaFields.Description]: element.Description},
                  (err, result) => {
                    // console.log(result, 'result');
                    if(err) {
                        log.error(err)
                        reject(err);
                    }
                    if (result.length == 0) {
                      finalData.push(element);
                    }
                    resolve();
                });
              })
            )
          })
        } else {
          prArr = [];
        }
        Promise.all(prArr).then(res => {
          // console.log(finalData, 'finalData');
          resolve(finalData);
        });
      })
    })
  }

  static async getTaxData2(hotelId, startDate, endDate) {
    return new Promise((resolve, reject) => {
      startDate = new Date(startDate).toISOString();
      endDate = new Date(endDate).toISOString();
  
      let strTax = "Tax";
      let output = [];
  
      HotelrevenueSchema.find({[HotelrevenueSchemaFields.HotelID]: hotelId, [HotelrevenueSchemaFields.Category]: strTax, [HotelrevenueSchemaFields.Date]: { "$gte": startDate, "$lt": endDate } },
        (err, result) => {
          if(err) {
              log.error(err)
              cb(err, null);
          }
          if (result.length > 0) {
            output =
            _(result)
              .groupBy('Description')
              .map((objs, key) => ({
                  'Description': key,
                  'Amount':  _.sumBy(objs, 'Amount'),
                  'Date': _.last(objs, 'Date'),
                  'Category': _.last(objs, 'Category'),
                  'HotelID': _.last(objs, 'HotelID'),
                  }))
              .value();
          }
          resolve(output);
      })
    });
  }

  static async getVarianceToBudget(totalRevenue, otherRevenue, fYesterday, totalProperty, hotelId, yeasterday) {
    return new Promise((resolve, reject) => {

      let sdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
      let edate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), moment(moment(yeasterday).format('YYYY-MM')).daysInMonth()+1, 0, 0, 0);
      let model = {
        RoomRevenue: 0,
        TotalRevenue: 0,
        FNBRevenue: 0,
        OtherRevenue: 0
      };

      let hotelbudgetlist = [];
      let hsHotelBudget = [];

      let prArr = [];
      for (var dt = moment(sdate); dt.isBefore(edate); dt.add(1, 'days')) {
        let hotelbudgetList = [];
        prArr.push(
          HotelbudgetSchema.find({[HotelbudgetSchemaFields.HotelID]: hotelId, [HotelbudgetSchemaFields.DateTo]: { "$gte": dt}, [HotelbudgetSchemaFields.DateFrom]: {"$lte": dt }},
          (err, res) => {
            if(err) {
                log.error(err)
                reject(err)
            }
            hotelbudgetList = res;
            if(hotelbudgetList.length != 0) {
              hotelbudgetList.forEach(hb => {
                hotelbudgetlist.push(hb);
              });
            }
          })
        )
      }
      Promise.all(prArr).then(resp =>{

        hotelbudgetlist = _.uniqBy(hotelbudgetlist, function (e) {
          return e.DateFrom && e.DateTo;
        });

        let budgetlist1 = [];
        let forcastlist = [];

        let avgbudgetroomrevenue = 0;
        let avgbudgetfnbrevenue = 0;
        let avgbudgettotalrevenue = 0;
        let avgbudgetotherrevenue = 0;

        for (var dt = moment(sdate); dt.isBefore(edate); dt.add(1, 'days')) {
          let hpList = _.filter(hotelbudgetlist, function (x) { return moment(x.DateFrom) <= moment(dt) && moment(x.DateTo) >= moment(dt) });

          hpList.forEach(hp => {
            if (hp != null)
            {
                let todate = new Date(hp.DateTo);
                let fromdate = new Date(hp.DateFrom);
                let TDays = moment.duration(fromdate.diff(todate)).asDays();
                console.log(TDays)
                // let TDays = Math.ceil(Convert.ToDouble((todate - fromdate).TotalDays))
                avgbudgetroomrevenue = avgbudgetroomrevenue + Convert.ToDouble(hp.RoomRevenueBudget / TDays);
                avgbudgetfnbrevenue = avgbudgetfnbrevenue + parseFloat(hp.FoodAndBeveragesBudget / TDays);
                avgbudgettotalrevenue = avgbudgettotalrevenue + parseFloat(hp.TotalHotelBudget / TDays);
                avgbudgetotherrevenue = avgbudgetotherrevenue + parseFloat(hp.OtherIncomeBudget / TDays);
            }
          });
        }

        // let totalDays = parseInt(getDaysDiff(sdate, edate) + 1);
        let totalDays = parseInt(moment(edate).diff(moment(sdate), 'days') + 1);
        // console.log(sdate, 'sdate');
        // console.log(edate, 'edate');
        // console.log(totalDays);
        if (avgbudgetroomrevenue != 0)
        {
            let currentBRoomRevenue = parseFloat(avgbudgetroomrevenue / totalDays);
            model.RoomRevenue = ((totalRevenue - currentBRoomRevenue) / currentBRoomRevenue) * 100;
        }

        if (avgbudgettotalrevenue != 0)
        {
            let currentBTotalRevenue = parseFloat(avgbudgettotalrevenue / totalDays);
            model.TotalRevenue = ((totalProperty - currentBTotalRevenue) / currentBTotalRevenue) * 100;
        }

        if (avgbudgetfnbrevenue != 0)
        {
            let currentBfnbRevenue = parseFloat(avgbudgetfnbrevenue / totalDays);
            model.FNBRevenue = ((fYesterday - currentBfnbRevenue) / currentBfnbRevenue) * 100;
        }
        if (avgbudgetotherrevenue != 0)
        {
            let currentBOtherRevenue = parseFloat(avgbudgetotherrevenue / totalDays);
            model.OtherRevenue = ((otherRevenue - currentBOtherRevenue) / currentBOtherRevenue) * 100;
        }

        resolve(model);

      })
    });
  }

  static async getLastYearActualModel(hotelId, lastYear) {
    return new Promise((resolve, reject) => {
      let model = {
        RoomRevenue: 0.0,
        TotalRevenue: 0.0,
        FNBRevenue: 0.0,
        OtherRevenue: 0.0
      }

      let stLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate(), 0, 0, 0);
      let etLy = new Date(lastYear.getFullYear(), lastYear.getMonth(), lastYear.getDate() + 1, 0, 0, 0);
      let avgActual1 = 0;

      let roomRevenueListLy = [];

      let hdListLy = [];
      return Promise.all([
        new Promise((resolve, reject) => {
          PickUpHelper.getHotelDashboardCalculations(etLy, etLy, hotelId, (err, res) => {
            if(err) {
              reject(err);
            }
            hdListLy = res;
            resolve();
          })
        })
      ]).then(resp => {
        let pArr = [];
        if(hdListLy.length == 0) {
          pArr.push(
            new Promise((resolve, reject) => {
              HotelrevenueSchema.find({[HotelrevenueSchemaFields.HotelID]: { "$in": hotelId }, [HotelrevenueSchemaFields.Category]: "RoomRevenue", [HotelrevenueSchemaFields.IsDelete]: false, [HotelrevenueSchemaFields.Date]: { "$gte": stLy, "$lt": etLy} },
              (err, results) => {
                if(err) {
                  reject(err);
                }
                roomRevenueListLy = results;
                let actualList1 = [];

                roomRevenueListLy.forEach(rr => {
                  let actual = parseFloat(rr.Amount);
                  actualList1.push(actual);
                  avgActual1 = avgActual1 + actual;
                });

                if (avgActual1 != 0)
                {
                    let totalDays = parseInt((etLy - stLy).TotalDays);
                    model.RoomRevenue = (avgActual1 * totalDays);
                }
                resolve();
              })
            })
          )
        } else {
          pArr.push(
            new Promise((resolve, reject) => {
              model.RoomRevenue = _.sumBy(hdListLy, function(x) { x.TotalRevenue});
              resolve();
            })
          )
        }
        Promise.all(pArr).then(resp =>{
          resolve(model);
        })
      });
    });
  }

  static async getLastYearToBudget(hotelId, lastYear) {
    return new Promise((resolve, reject) => {
      let model = {
        RoomRevenue: 0.0,
        TotalRevenue: 0.0,
        FNBRevenue: 0.0,
        OtherRevenue: 0.0
      }

      let sdate = new Date(lastYear.getFullYear(), lastYear.getMonth(), 1, 0, 0, 0);
      let edate = new Date(lastYear.getFullYear(), lastYear.getMonth(), moment(moment(lastYear).format('YYYY-MM')).daysInMonth(), 0, 0, 0);

      let hotelbudgetlist = [];
      let hsHotelBudget = [];
      let prr = [];
      for (var dt = moment(sdate); dt.isBefore(edate); dt.add(1, 'days')) {
        let hotelbudgetList = [];
        prr.push(
          HotelbudgetSchema.find({ [HotelbudgetSchemaFields.HotelID]: hotelId, [HotelbudgetSchemaFields.DateTo]: { "$gte": new Date(dt)}, [HotelbudgetSchemaFields.DateFrom]: {"$lt": new Date(dt) } },
          (err, resultset) => {
            if(err) {
              log.error(err);
            }
            hotelbudgetList = resultset;
            if (hotelbudgetList.length != 0)
            {
              hotelbudgetList.forEach(hb => {
                hotelbudgetlist.push(hb);
              });
            }
          })
        )
      }
      Promise.all(prr).then(resp => {
        hotelbudgetlist = _.uniqBy(hotelbudgetlist, function (e) {
          return e.DateFrom && e.DateTo;
        });

        let budgetlist1 = [];
        let forcastlist = [];
        let avgbudgetroomrevenue = 0;
        let avgbudgetfnbrevenue = 0;
        let avgbudgettotalrevenue = 0;
        let avgbudgetotherrevenue = 0;

        for (var dt = moment(sdate); dt.isBefore(edate); dt.add(1, 'days')) {
          let hpList = _.filter(hotelbudgetlist, function(o) { return o.HotelID == hotelId && new Date(o.DateFrom) <= new Date(dt) && new Date(o.DateTo) >= new Date(dt); });
          hpList.forEach(hp => {
            let todate = moment(hp.DateTo).format("YYYY-MM-DD");
            let fromdate = moment(hp.DateFrom).format("YYYY-MM-DD");
            let TDays = moment(todate).diff(moment(fromdate), 'days');
            avgbudgetroomrevenue = avgbudgetroomrevenue + parseFloat(hp.RoomRevenueBudget / TDays);
            avgbudgetfnbrevenue = avgbudgetfnbrevenue + parseFloat(hp.FoodAndBeveragesBudget / TDays);
            avgbudgettotalrevenue = avgbudgettotalrevenue + parseFloat(hp.TotalHotelBudget / TDays);
            avgbudgetotherrevenue = avgbudgetotherrevenue + parseFloat(hp.OtherIncomeBudget / TDays);
          });
        }

        let totalDays = moment(edate).diff(moment(sdate), 'days');
        if (avgbudgetroomrevenue != 0)
        {
            let currentBRoomRevenue = parseFloat(avgbudgetroomrevenue / totalDays);
            model.RoomRevenue = currentBRoomRevenue;
        }

        if (avgbudgettotalrevenue != 0)
        {
            let currentBTotalRevenue = parseFloat(avgbudgettotalrevenue / totalDays);
            model.TotalRevenue = currentBTotalRevenue;
        }

        if (avgbudgetfnbrevenue != 0)
        {
            let currentBfnbRevenue = parseFloat(avgbudgetfnbrevenue / totalDays);
            model.FNBRevenue = currentBfnbRevenue;
        }
        if (avgbudgetotherrevenue != 0)
        {
            let currentBOtherRevenue = parseFloat(avgbudgetotherrevenue / totalDays);
            model.OtherRevenue = currentBOtherRevenue;
        }
        resolve(model);
      })
    })
  }


static async getExpenseDepartmentBudget(hotelId, period, yeasterday) {
  return new Promise((resolve, reject) => {

    let retList = [];
    let startdate = new Date();
    let enddate = new Date();

    if (period.toLowerCase() == "current" || period == null)
    {
        //DateTime yeasterday = DateTime.Now.AddDays(-1);
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate, 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate + 1, 0, 0, 0);
    }
    else if (period.toLowerCase() == "mtd")
    {
        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate + 1, 0, 0, 0);
    }
    else if (period.toLowerCase() == "ytd")
    {
        startdate = new Date(yeasterday.getFullYear(), 1, 1, 0, 0, 0);
        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate + 1, 0, 0, 0);
    }
    else if (period.toLowerCase() == "ttm")
    {
        let arr = Utils.GetTTMDates(yeasterday);
        startdate = arr[0];
        enddate = arr[1];
    }

    let  items = [];
    let orgid = 0;
    let hid = 0;

    let hotelList = [];
    return Promise.all([
      new Promise((resolve, reject) => {
        HotelsSchema.find({ [HotelsSchemaFields.ID]: hotelId }, (err, resultset) => {
          if(err) {
            log.error(err);
            reject(err);
          }
          hotelList = resultset;
          resolve();
        });
      })
    ]).then(resp =>{
      // for (DateTime dt = startdate.Date; dt.Date <= enddate.Date; dt = dt.AddDays(1))
      let hpList = [];
      let prArr = [];
      let hotelbudgetlist = [];
      for (var dt = moment(startdate); dt.isBefore(enddate); dt.add(1, 'days')) {
        prArr.push(
          new Promise((resolve, reject) => {
            HotelbudgetexpenseformSchema.find({ [HotelbudgetexpenseformSchemaFields.HotelID]: hotelId, [HotelbudgetexpenseformSchemaFields.IsDelete]: false, [HotelbudgetexpenseformSchemaFields.IsGLCodeBudget]: true, [HotelbudgetexpenseformSchemaFields.DateFrom]: { "$gte": new Date(dt) }, [HotelbudgetexpenseformSchemaFields.DateTo]: {"$lte": new Date(dt) } }, 
            (err, resultset) => {
              if(err) {
                log.error(err);
                reject(err);
              }
              hpList = resultset;

              if (hpList.length > 0)
              {
                hpList.forEach(hp => {
                  hotelbudgetlist.push(hp);
                });
              }
            })
          })
        )
      }
      Promise.all(prArr).then(resp => {
        hotelbudgetlist = _.uniqBy(hotelbudgetlist, function (e) {
          return e.DateFrom && e.DateTo;
        });
        
        let groupCodes = _(hotelbudgetlist)
        .groupBy('GLCode')
        .map((objs, Key) => ({
            'GLCode': Key,
            'HotelID': _.get(_.find(objs, function(o) { return true; }), 'HotelID') == undefined ? '' : _.get(_.find(objs, function(o) { return true; }), 'HotelID'),
            'DepartmentID': _.get(_.find(objs, function(o) { return true; }), 'DepartmentID') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'DepartmentID'),
            'TotalHotelBudget': _.sumBy(objs, 'TotalHotelBudget')
            }))
        .value();

        let newhotelbudgetlist = [];

        groupCodes.forEach(async grpcode => {
          let avgbudget = 0;

          for (var dt = moment(startdate); dt.isBefore(enddate); dt.add(1, 'days')) {
            let hpList = _.filter(hotelbudgetlist, function(x) { return x.HotelID == hotelId && x.GLCode == grpcode.GLCode && x.DateFrom <= new Date(dt) && x.DateTo >= new Date(dt) });

            hpList.forEach(async hp => {
              if (hp == null)
              {
                  avgbudget = avgbudget + 0;
              }
              else
              {
                let todate = moment(hp.DateTo);
                let fromdate = moment(hp.DateFrom);
                // let TDays = Math.Floor(Convert.ToDouble((todate - fromdate).TotalDays)) + 1;
                let TDays = moment.duration(fromdate.diff(todate)).asDays();
                avgbudget = avgbudget + parseFloat(hp.TotalHotelBudget / TDays);
              }
            });
          }

          let data = {
            ID: '',
            HotelID: '',
            HotelName: '',
            DepartmentID: '',
            DateFrom: '',
            DateTo: '',
            IsGLCodeBudget: '',
            GLCode: '',
            otalHotelBudget: '',
            UpdatedBy: '',
            UpdatedDateTime: '',
            IsDelete: '',
            HotelBudgetHours: ''
          }
          data.GLCode = grpcode.GLCode;
          data.HotelID = grpcode.HotelID;
          data.DepartmentID = grpcode.DepartmentID;
          data.TotalHotelBudget = avgbudget;
          newhotelbudgetlist.push(data);
        });

        hotelbudgetlist = _(newhotelbudgetlist)
        .groupBy('DepartmentID')
        .map((objs, key) => ({
            'DepartmentID': key,
            'HotelID': _.get(_.find(objs, function(o) { return true; }), 'HotelID') == undefined ? '' : _.get(_.find(objs, function(o) { return true; }), 'HotelID'),
            'TotalHotelBudget': _.sumBy(objs, 'TotalHotelBudget')
            }))
        .value();

        if (hotelList.Count > 0)
        {
          orgid = _.get(_.find(hotelList, function(o) { return true; }), 'OrganizationID') == undefined ? '' : _.get(_.find(hotelList, function(o) { return true; }), 'OrganizationID');
          hid = _.get(_.find(hotelList, function(o) { return true; }), 'ID') == undefined ? '' : _.get(_.find(hotelList, function(o) { return true; }), 'ID');
        }

        let depList = [];
        DepartmentSchema.find({ [DepartmentSchemaFields.OrganizationID]: orgid, [DepartmentSchemaFields.IsActive]: true },
          (err, resultset) => {
            if(err) {
              log(err);
              reject(err);
            }
            depList = resultset;
            depList = _.orderBy(depList, ['Name'], ['asc']);

            depList.forEach(async dep => {
              let chartitem = {
                DepartmentId: '',
                DepartmentName: '',
                Actual: '',
                Budget: ''
              }
              chartitem.DepartmentName = dep.Name;
              chartitem.DepartmentId = dep.Id;
              let budget = 0;

              let depbudget = _.find(depList, function(o) { return o.DepartmentID == chartitem.DepartmentId; });
              if (depbudget != null)
              {
                  budget = parseFloat(hotelbudgetlist.TotalHotelBudget);
              }
              chartitem.Budget = budget;
              retList.push(chartitem);
            });

            resolve(retList);
        });
      })
    })
  });
}

static async getGLCode2(DisplayDescription, hotelid) {
  return new Promise((resolve, reject) => {
    let GLCodeData = "000.00";
    hotelid = parseInt(hotelid);
    GlcodehotelrevenueSchema.findOne({[GlcodehotelrevenueSchemaFields.DisplayDescription]: DisplayDescription, [GlcodehotelrevenueSchemaFields.HotelID]: hotelid },
    (err, result) => {
      if(err) {
          log.error(err)
          reject(err)
      }
      if(result != null) {
        GLCodeData = result.GLCode;
      }

      resolve(GLCodeData);
    });
  });
}


  static getMonthPnlData_GraphQL(hotelid, currentdate, userID, cb) {
    //get myp hotelid from cmp_id
    return HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
      if (err) {
        cb(err, null);
      }
      if (!hoteldata) {
        cb(Constants.HotelNotFound, null);
      }
      else {
        UserHelper.getUserConfigData(userID, (err, userconfigdata) => {
          if (err) {
              return next(err);
          }
          PnlMonthHelper.getMonthPnlData(hoteldata.ID, currentdate, userconfigdata, cb, (err, result) => {
            if (err) {
              cb(err, null);
            }
            cb(null, result);
          });
        });
      }
    });
  }

  static editOrSavepnlcolOrder(userId, hotelId, data, cb) {
    if(data != null) {
      PnlmonthlycolorderSchema.findOne({[PnlmonthlycolorderSchemaField.Hotel_ID]: hotelId, [PnlmonthlycolorderSchemaField.User_ID]: userId},
      (err, res) => {
        if(err) {
          log.error(err)
          reject(err)
        }
        if(res == null) {
          let colOrderData = {
              [PnlmonthlycolorderSchemaField.User_ID]: userId,
              [PnlmonthlycolorderSchemaField.Hotel_ID]: hotelId,
              [PnlmonthlycolorderSchemaField.Created_at]: new Date(),
              [PnlmonthlycolorderSchemaField.Data]: data,
            };

          let Pnlcolorder = new PnlmonthlycolorderSchema(colOrderData);
          Pnlcolorder.save((err, result) => {
            if (err)
                return cb(err, null);
            else {
                return cb(null, result);
            }
          });
        } else {
          PnlmonthlycolorderSchema.findOneAndUpdate(
            {
                [PnlmonthlycolorderSchemaField.Hotel_ID]: hotelId,
                [PnlmonthlycolorderSchemaField.User_ID]: userId,
            },
            {
                [PnlmonthlycolorderSchemaField.Created_at]: new Date(),
                [PnlmonthlycolorderSchemaField.Data]: data
            },
            {
                new: true
            }
        ).exec((err, result) => {
            if(err) {
              return cb(err);
            }
            return cb(null, result);
        })
        }
      })
    } else {
      return cb('Data Required !');
    }
  }

  static editOrSavepnlMonthlyColOrder_GraphQL(userId, hotelid, view, groups, colorder, cb) {
      //get myp hotelid from cmp_id
    return HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
      if (err) {
        cb(err, null);
      }
      if (!hoteldata) {
        cb(Constants.HotelNotFound, null);
      } else {
        PnlYearHelper.editOrSavepnlRawOrder2(userId, hoteldata.ID, view, groups, cb, (err, result, next) => {
          if (err) {
            cb(err, null);
            console.log(err);
          } else{
          PnlMonthHelper.editOrSavepnlcolOrder(userId, hoteldata.ID, colorder, cb, (err2, result2)=> {
            if (err2) {
              cb(err2, null);
              console.log(err);
            }
            cb(null, result2);
          })
        }
        });
      }
    })
  }

}

module.exports = PnlMonthHelper;


function groupByGLCode(items) {

  let grouopedItems = _(items)
    .groupBy('AccountNumber')
    .map((objs, key) => ({
        'AccountNumber': key,
        'UnitPrice': _.sumBy(objs, 'UnitPrice') }))
    .value();

  return grouopedItems;
}

function groupByDescription(items) {

  let grouopedItems = _(items)
    .groupBy('Description')
    .map((objs, key) => ({
        'Description': key,
        'Amount': _.sumBy(objs, 'Amount') }))
    .value();

  return grouopedItems;
}