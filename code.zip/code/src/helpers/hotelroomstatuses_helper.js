const { Hotelroomstatus: HotelroomstatusSchema, SchemaField: HotelroomstatusSchemaFields } = require('../models/hotelroomstatus');
const { Operaoutoforderbyreasonreport: OperaoutoforderbyreasonreportSchema, SchemaField: OperaoutoforderbyreasonreportSchemaFields } = require('../models/operaoutoforderbyreasonreport');

const dbtable = require('../schema/db_table');
const HttpMessages = require('../common/constants')
var log = require('log4js').getLogger("hotelroomstatuses_helper");

class HotelroomstatusesHelper {

    static GetOutOfOrderRooms(hotelId,startdate,endDate,cd) {
        
        let outoforderRooms = 0;
        let outofOrderCategory = HttpMessages.RevenueType.OutOfOrder;
        
        HotelroomstatusSchema.find({$and:[
        {[HotelroomstatusSchemaFields.HotelID]: hotelId[0]},
        {[HotelroomstatusSchemaFields.Category]: outofOrderCategory},
        {[HotelroomstatusSchemaFields.Date]: { $gte: startdate}},
        {[HotelroomstatusSchemaFields.Date]: { $lte: endDate}},
        {[HotelroomstatusSchemaFields.NoofRooms]: { $gt: 0}},
        { $or:[
            {[HotelroomstatusSchemaFields.IsDeleted]:false},
            {[HotelroomstatusSchemaFields.IsDeleted]:null}, 
        ]}

    ]},[HotelroomstatusSchemaFields.NoofRooms]).exec(function (err, result) {
            
            if (result.length==0){
                cd(null,outoforderRooms);
            }else{
                result.forEach(element=>{
                    outoforderRooms = outoforderRooms + element.NoofRooms 
                })
                            

                cd(null,outoforderRooms);
            }
        })

    }    

    static GetHotelroomstatus(hotelId,startdate,endDate,cd) {
        
        let outoforderRooms = 0;
        let outofOrderCategory = HttpMessages.RevenueType.OutOfOrder;
        
        HotelroomstatusSchema.find({$and:[
        {[HotelroomstatusSchemaFields.HotelID]: {$in:hotelId}},
        {[HotelroomstatusSchemaFields.Category]: outofOrderCategory},
        {[HotelroomstatusSchemaFields.Date]: { $gte: startdate}},
        {[HotelroomstatusSchemaFields.Date]: { $lte: endDate}},
        {[HotelroomstatusSchemaFields.NoofRooms]: { $gt: 0}},
        { $or:[
            {[HotelroomstatusSchemaFields.IsDeleted]:false},
            {[HotelroomstatusSchemaFields.IsDeleted]:null}, 
        ]}

        ]}).exec(function (err, result) {
            
        if (err) {
            reject(err);
        }
        cd(null,result);
    })
}

static GetOutoforderbyreason(hotelid,datefrom,dateto,cd) {
    //let start = new Date(datefrom.getFullYear(), datefrom.getMonth(), datefrom.getDate());
   // let end = new Date(dateto.getFullYear(), dateto.getMonth(), dateto.getDate() + 1);
   log.debug('Call hotelid' + hotelid);
   log.debug('Call datefrom' + datefrom);
   log.debug('Call dateto' + dateto);
   let start = new Date(datefrom.getFullYear(), datefrom.getMonth(), datefrom.getDate());
   let end = new Date(dateto.getFullYear(), dateto.getMonth(), dateto.getDate());

    let outoforderRooms = 0;
    //let outofOrderCategory = HttpMessages.RevenueType.OutOfOrder;
    //console.log(start);
    //console.log(end);

    (OperaoutoforderbyreasonreportSchema).find({$and:[
    {[OperaoutoforderbyreasonreportSchemaFields.HotelID]: {$in:hotelid}},
    {[OperaoutoforderbyreasonreportSchemaFields.NoOfRooms]: { $gt: 0}},
    {[OperaoutoforderbyreasonreportSchemaFields.DateFrom]: { $lte: start}},
    { $and:[
    { $or:[
               {[OperaoutoforderbyreasonreportSchemaFields.DateTo]: { $gte: end}},
        {[OperaoutoforderbyreasonreportSchemaFields.DateTo]: { $gte: start}}
  
      ]}
    ]}
]}).exec(function (err, result) {
        //console.log("count:" +result.length);
    if (err) {
        reject(err);
    }


     
    cd(null,result);
})
}

static getOutoforderbyreasonReportData_GraphQL(hotelid,datefrom,dateto, cb) {
    datefrom = new Date(datefrom);
    dateto = new Date(dateto);
    //console.log(datefrom);
    //console.log(dateto);
    return HotelroomstatusesHelper.GetOutoforderbyreason(hotelid,datefrom,dateto, cb, (err, result) => {
        if (err) {
            cb(err, null);
        }
       
        cb(null, result);
    });
}

}
module.exports = HotelroomstatusesHelper;

