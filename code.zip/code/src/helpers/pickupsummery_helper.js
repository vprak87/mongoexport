const Constants = require('../common/constants');
const Utils = require('../common/utils');
const moment = require('moment');
const _ = require('lodash');

const Pickupdashboarddata = require('../pickup/models/pickupdashboarddata');
const Pickupdata = require('../pickup/models/pickupdata');
const Pickupreportdata = require('../pickup/models/pickupreportdata');
const Summeryreportdata = require('../pickup/models/summeryreportdata');
const Hoteldata = require('../hotels/models/hoteldata');

const { Hotelrevenue: HotelrevenueSchema, SchemaField: HotelrevenueSchemaFields } = require('../models/hotelrevenue');
const { Pickupreport: PickupreportSchema, SchemaField: PickupSchemaFields } = require('../models/pickupreport');
const { Hotelbudget: HotelbudgetSchema, SchemaField: HotelbudgetSchemaFields } = require('../models/hotelbudget');
const { Hoteldashboardcalculations: HoteldashboardcalculationsSchema, SchemaField: HoteldashboardcalculationsSchemaFields } = require('../models/hoteldashboardcalculations');
const { Hotelbudgetdashboardcalculations: HotelbudgetdashboardcalculationsSchema, SchemaField: HotelbudgetdashboardcalculationsSchemaFields } = require('../models/hotelbudgetdashboardcalculations');

const UserHelper = require('./user_helper');
const HotelsHelper = require('./hotels_helper');
const PickupHelper = require('./pickup_helper');
const MonthlypickupHelper = require('./monthlypickup_helper');
var log = require('log4js').getLogger("pickup_helper");

class PickupsSummeryHelper {

  static getMissingPickupDates_GraphQL(userid, hotelid, days, today, cd) {
    UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
      if (err) {
        return next(err);
      }
      PickupsSummeryHelper.getMissingPickupDates(hotelid, days, today, userconfigdata, (err, result) => {
        cd(null, result)
      })
    })
  }


  static getMissingPickupDates(hotelId, days, today, userconfigdata, cd) {

    let lstmissingDates = [];
    let retValue = '';
    
    hotelId = (hotelId == null ? "0" : hotelId);

    days = (days == null ? "7" : days);

    today = (today == null ? Utils.getFormattedDate(new Date(), "YYYY-MM-DD") : today);
   
    let currentDate = today;

    let enddate = today;

    let startdate = new Date(Utils.addDays(currentDate, -7));

    enddate = Utils.endofDay(enddate);
   
    let y = new Promise((resolve, reject) => {
      PickupHelper.getMissingDates(hotelId, startdate, enddate, (err, pickupdata) => {
        resolve(pickupdata)
      })
    })

    y.then(pickupdata => {

      for (let dt = startdate;dt <= enddate; dt = new Date(Utils.addDate(dt, 1))) {
      let enddt = Utils.endofDay(dt);
      let data = pickupdata.filter(i => i.ReportedDateTime >= dt && i.ReportedDateTime <= enddt );

      if (data != null && data.length > 0) {          
         
          let data1 = pickupdata.filter(i => i.ReportedDateTime >= dt && i.ReportedDateTime <= enddt );

          let totalRevenue = _.sumBy(data1, 'TotalRevenue');


          if (totalRevenue == null || totalRevenue == 0) {
            lstmissingDates.push({ "date": Utils.getFormattedDate(dt, "DD"), "month": Utils.getFormattedDate(dt, "MMM") })
          }

        } else {
          lstmissingDates.push({ "date": Utils.getFormattedDate(dt, "DD"), "month": Utils.getFormattedDate(dt, "MMM") })
        }
      }

      let query = _.map(_.groupBy(lstmissingDates, 'month'), (element, idx) => { return { key: idx,data:element} });
      
      _.filter(query,(element)=>{
        retValue = retValue + element.key + "-";

        _.filter(element.data,(element)=>{
          retValue = retValue + element.date + ",";
        })
      })

      cd(null, [{ missingdates: retValue }]);

    })
  }
  static getSummeryPickupData(hotelId, date, userconfigdata, cb) {
    // console.log('called');

    // current month section
    let mSummeryReportDataModelList = [];
    let mSummeryReportDataModel = {};

    let dt = new Date();
    if (!date) {
      dt = new Date();
    }
    else {
      dt = new Date(date);
    }

    let currentDate = new Date();
    let TransientRoomRevenue = 0;
    let GroupRoomRevenue = 0;
    let revenueOnBook = 0;
    let TotalRevenueYesterday = 0;

    let currentYear = dt.getFullYear();
    let totalNoOfDays = Utils.daysInMonth(dt);
    let currentMonth = moment(dt).format("MMMM");
    let currentMonthFirstdate = new Date(dt.getFullYear(), dt.getMonth(), 1, 23, 59, 59);
    let currentMonthLastdate = new Date(dt.getFullYear(), dt.getMonth(), totalNoOfDays, 23, 59, 59);
    let currentselecteddate = new Date(dt);

    let PickupReportDataModelList = [];
    let HotelRevenueData = [];

    return Promise.all([
      new Promise((resolve, reject) => {
        MonthlypickupHelper.getMonthlyPickupData(hotelId, "", dt, "", (err, res) => {
          if (err) {
            reject(err);
          }
          PickupReportDataModelList = res;
          resolve();
        });
      })
    ]).then(resp => {

      let sum = 0;
      PickupReportDataModelList.forEach(element => {
        sum = parseFloat(element.ReveneActual) + sum;
      });
      revenueOnBook = sum;

      let data = []
      var hotelRoomBudgetData = [];
      return Promise.all([
        new Promise((resolve, reject) => {
          PickupsSummeryHelper.getHotelRevenueDataForSummeryReport(hotelId, currentMonthFirstdate, currentMonthLastdate, (err, result) => {
            if (err) {
              reject(err)
            }
            if (result) {
              HotelRevenueData = result;
            }
            resolve();
          });
        }),
        // new Promise((resolve, reject) => {
        //   MonthlypickupHelper.getHotelRevenuesForPickup(currentMonthFirstdate, currentMonthLastdate, parseInt(hotelId), (err, hoteldata) => {
        //     if(err) {
        //       reject(err)
        //     }
        //     if(hoteldata) {
        //       data = hoteldata;
        //     }
        //     resolve();
        //   });
        // }),
        new Promise((resolve, reject) => {
          PickupsSummeryHelper.getHotelBudgetDashboardCalculationsByHotelID(hotelId, currentMonthFirstdate, currentMonthLastdate, (err, results) => {
            if (err) {
              reject(err)
            }
            if (results) {
              hotelRoomBudgetData = results;
            }
            resolve();
          });
        })
      ]).then(resp => {

        let sum2 = 0;
        PickupReportDataModelList.forEach(element => {
          sum2 = parseFloat(element.pickupToday) + sum2;
        });
        mSummeryReportDataModel.PickUpRoomNight = parseFloat(sum2).toFixed(2);

        let sum3 = 0;
        PickupReportDataModelList.forEach(element => {
          sum3 = parseFloat(element.pickupRevenue) + sum3;
        });
        mSummeryReportDataModel.PickUpRevenue = parseFloat(sum3).toFixed(2);

        if (mSummeryReportDataModel.PickUpRoomNight != 0 && mSummeryReportDataModel.PickUpRevenue != 0) {
          mSummeryReportDataModel.PickUpADR = (mSummeryReportDataModel.PickUpRevenue / mSummeryReportDataModel.PickUpRoomNight).toFixed(2);
        }

        if (mSummeryReportDataModel.PickUpADR == null || isNaN(mSummeryReportDataModel.PickUpADR)) {
          mSummeryReportDataModel.PickUpADR = 0;
        }

        var data = [];
        PickupReportDataModelList.forEach(element => {
          if (moment(element.Date).format('YYYY-MM-DD') >= moment(currentMonthFirstdate).format('YYYY-MM-DD') && moment(element.Date).format('YYYY-MM-DD') <= moment(currentMonthLastdate).format('YYYY-MM-DD')) {
            data.push(element);
          }
        });

        var data_MTD = [];
        data.forEach(element => {
          if (moment(element.Date).format('YYYY-MM-DD') >= moment(currentMonthFirstdate).format('YYYY-MM-DD') && moment(element.Date).format('YYYY-MM-DD') <= moment(currentselecteddate).format('YYYY-MM-DD')) {
            data_MTD.push(element);
          }
        });

        let sum4 = 0;
        data_MTD.forEach(element => {
          sum4 += element.RoomsActual == null ? 0 : parseFloat(element.RoomsActual);
        });
        let sumOfRoombook = sum4;

        var hotelRoomBudgetData_MTD = [];

        hotelRoomBudgetData.forEach(element => {
          if (moment(element.Date).format('YYYY-MM-DD') >= moment(currentselecteddate).format('YYYY-MM-DD') && moment(element.Date).format('YYYY-MM-DD') <= moment(currentselecteddate).format('YYYY-MM-DD')) {
            hotelRoomBudgetData_MTD.push(element);
          }
        });

        let sum5 = 0;
        hotelRoomBudgetData_MTD.forEach(element => {
          sum5 += element.MTDBudgetRooms == null ? 0 : parseInt(element.MTDBudgetRooms);
        });
        let sumOfRoomBudget = sum5;
        mSummeryReportDataModel.MTDBudgetRoomNight = sumOfRoombook - sumOfRoomBudget;

        let sum6 = 0;
        data_MTD.forEach(element => {
          sum6 += element.ReveneActual == null ? 0 : parseFloat(element.ReveneActual);
        });
        let sumOfRevenueActual = sum6;

        let sum7 = 0;
        hotelRoomBudgetData_MTD.forEach(element => {
          sum7 += element.MTDBudget == null ? 0 : parseFloat(element.MTDBudget);
        });
        let sumOfRevenueBudget = sum7;
        mSummeryReportDataModel.MTDBudgetRevenue = (sumOfRevenueActual - sumOfRevenueBudget).toFixed(2);

        let sum8 = 0;
        hotelRoomBudgetData.forEach(element => {
          if (moment(element.Date).format('YYYY-MM-DD') >= moment(currentMonthFirstdate).format('YYYY-MM-DD') && moment(element.Date).format('YYYY-MM-DD') <= moment(currentselecteddate).format('YYYY-MM-DD')) {
            sum8 += element.ForecastRoomSold == null ? 0 : parseInt(element.ForecastRoomSold);
          }
        });
        let sumOfRoomForcast = sum8;
        mSummeryReportDataModel.MTDForcastRoomNight = sumOfRoombook - sumOfRoomForcast;

        let sum9 = 0;
        hotelRoomBudgetData_MTD.forEach(element => {
          sum9 += element.MTDForecastRoomRevenue == null ? 0 : parseFloat(element.MTDForecastRoomRevenue);
        });
        let sumOfRevenueForcast = sum9;
        mSummeryReportDataModel.MTDForcastRevenue = (sumOfRevenueActual - sumOfRevenueForcast).toFixed(2);


        var hotelRoomBudgetData_OTB = [];


        let sum4_OTB = 0;
        data.forEach(element => {
          sum4_OTB += element.RoomsActual == null ? 0 : parseFloat(element.RoomsActual);
        });
        let sumOfRoombook_OTB = sum4_OTB;

        hotelRoomBudgetData.forEach(element => {
          if (moment(element.Date).format('YYYY-MM-DD') >= moment(currentMonthLastdate).format('YYYY-MM-DD') && moment(element.Date).format('YYYY-MM-DD') <= moment(currentMonthLastdate).format('YYYY-MM-DD')) {
            hotelRoomBudgetData_OTB.push(element);
          }
        });

        let sum5_OTB = 0;
        hotelRoomBudgetData_OTB.forEach(element => {
          sum5_OTB += element.MTDBudgetRooms == null ? 0 : parseInt(element.MTDBudgetRooms);
        });
        let sumOfRoomBudget_OTB = sum5_OTB;


        let sum6_OTB = 0;
        data.forEach(element => {
          sum6_OTB += element.ReveneActual == null ? 0 : parseFloat(element.ReveneActual);
        });
        let sumOfRevenueActual_OTB = sum6_OTB;

        let sum7_OTB = 0;
        hotelRoomBudgetData_OTB.forEach(element => {
          sum7_OTB += element.MTDBudget == null ? 0 : parseFloat(element.MTDBudget);
        });
        let sumOfRevenueBudget_OTB = sum7_OTB;


        let sum8_OTB = 0;
        hotelRoomBudgetData.forEach(element => {
          if (moment(element.Date).format('YYYY-MM-DD') >= moment(currentMonthFirstdate).format('YYYY-MM-DD')
            && moment(element.Date).format('YYYY-MM-DD') <= moment(currentMonthLastdate).format('YYYY-MM-DD')) {
            sum8_OTB += element.ForecastRoomSold == null ? 0 : parseInt(element.ForecastRoomSold);
          }
        });

        let sumOfRoomForcast_OTB = sum8_OTB;


        let sum9_OTB = 0;
        hotelRoomBudgetData_OTB.forEach(element => {
          sum9_OTB += element.MTDForecastRoomRevenue == null ? 0 : parseFloat(element.MTDForecastRoomRevenue);
        });
        let sumOfRevenueForcast_OTB = sum9_OTB;

        mSummeryReportDataModel.OTBBudgetRoomNight = sumOfRoombook_OTB - sumOfRoomBudget_OTB;
        mSummeryReportDataModel.OTBBudgetRevenue = (sumOfRevenueActual_OTB - sumOfRevenueBudget_OTB).toFixed(2);
        mSummeryReportDataModel.OTBForcastRoomNight = sumOfRoombook_OTB - sumOfRoomForcast_OTB;
        mSummeryReportDataModel.OTBForcastRevenue = (sumOfRevenueActual_OTB - sumOfRevenueForcast_OTB).toFixed(2);

        mSummeryReportDataModel.MonthYear = currentMonth + "-" + currentYear;
        mSummeryReportDataModelList.push(mSummeryReportDataModel);

        // next month section
        mSummeryReportDataModel = {};
        let nextDatetime = new Date(moment(dt).add(1, 'M'));
        // let MonthYear = moment(nextDatetime).format("MMMM - YYYY");
        let nextMonth = moment(nextDatetime).format("MMMM");
        let nextmonthNumber = moment(nextDatetime).format("MM");
        totalNoOfDays = Utils.daysInMonth(nextDatetime);
        let NextMonthFirstdate = new Date(nextDatetime.getFullYear(), nextDatetime.getMonth(), 1, 23, 59, 59);
        let NextMonthLastdate = new Date(nextDatetime.getFullYear(), nextDatetime.getMonth(), totalNoOfDays, 23, 59, 59);

        let currentselecteddate_NextMonth = new Date(nextDatetime);

        return Promise.all([
          new Promise((resolve, reject) => {
            PickupsSummeryHelper.getPickupReportData_v2(hotelId, dt.toISOString(), NextMonthFirstdate, NextMonthLastdate, (err, res) => {
              if (err) {
                reject(err);
              }
              PickupReportDataModelList = res;
              resolve();
            });
          })
        ]).then(resp => {
          return Promise.all([
            new Promise((resolve, reject) => {
              PickupsSummeryHelper.getHotelRevenueDataForSummeryReport(hotelId, NextMonthFirstdate, NextMonthLastdate, (err, result) => {
                if (err) {
                  reject(err)
                }
                if (result) {
                  HotelRevenueData = result;
                }
                resolve();
              });
            }),
            // new Promise((resolve, reject) => {
            //   MonthlypickupHelper.getHotelRevenuesForPickup(NextMonthFirstdate, NextMonthLastdate, parseInt(hotelId), (err, hoteldata) => {
            //     if (err) {
            //       reject(err)
            //     }
            //     if (hoteldata) {
            //       data = hoteldata;
            //     }
            //     resolve();
            //   });
            // }),
            new Promise((resolve, reject) => {
              PickupsSummeryHelper.getHotelBudgetDashboardCalculationsByHotelID(hotelId, NextMonthFirstdate, NextMonthLastdate, (err, results) => {
                if (err) {
                  reject(err)
                }
                if (results) {
                  hotelRoomBudgetData = results;
                }
                resolve();
              });
            })
          ]).then(resp => {

            let MonthYear = moment(nextDatetime).format("MMMM - YYYY");

            let sum10 = 0;
            PickupReportDataModelList.forEach(element => {
              sum10 = element.pickupToday + sum10;
            });
            mSummeryReportDataModel.PickUpRoomNight = parseFloat(sum10).toFixed(2);

            let sum11 = 0;
            PickupReportDataModelList.forEach(element => {
              sum11 = element.pickupRevenue + sum11;
            });
            mSummeryReportDataModel.PickUpRevenue = parseFloat(sum11).toFixed(2);;

            if (mSummeryReportDataModel.PickUpRoomNight != 0 && mSummeryReportDataModel.PickUpRevenue != 0) {
              mSummeryReportDataModel.PickUpADR = (mSummeryReportDataModel.PickUpRevenue / mSummeryReportDataModel.PickUpRoomNight).toFixed(2);
            }

            if (mSummeryReportDataModel.PickUpADR == null || isNaN(mSummeryReportDataModel.PickUpADR)) {
              mSummeryReportDataModel.PickUpADR = 0;
            }

            var data = [];
            PickupReportDataModelList.forEach(element => {
              if (moment(element.Date).format('YYYY-MM-DD') >= moment(NextMonthFirstdate).format('YYYY-MM-DD') && moment(element.Date).format('YYYY-MM-DD') <= moment(NextMonthLastdate).format('YYYY-MM-DD')) {
                data.push(element);
              }
            });

            var data_MTD = [];
            data.forEach(element => {
              if (moment(element.Date).format('YYYY-MM-DD') >= moment(NextMonthFirstdate).format('YYYY-MM-DD') && moment(element.Date).format('YYYY-MM-DD') <= moment(currentselecteddate_NextMonth).format('YYYY-MM-DD')) {
                data_MTD.push(element);
              }
            });

            let sum12 = 0;
            data_MTD.forEach(element => {
              sum12 += element.RoomsActual == null ? 0 : parseFloat(element.RoomsActual);
            });
            let sumOfRoombook = sum12;

            var hotelRoomBudgetData_MTD = [];

            hotelRoomBudgetData.forEach(element => {
              if (moment(element.Date).format('YYYY-MM-DD') >= moment(currentselecteddate_NextMonth).format('YYYY-MM-DD') && moment(element.Date).format('YYYY-MM-DD') <= moment(currentselecteddate_NextMonth).format('YYYY-MM-DD')) {
                hotelRoomBudgetData_MTD.push(element);
              }
            });

            let sum13 = 0;
            hotelRoomBudgetData_MTD.forEach(element => {
              sum13 += element.MTDBudgetRooms == null ? 0 : parseInt(element.MTDBudgetRooms);
            });
            let sumOfRoomBudget = sum13;
            mSummeryReportDataModel.MTDBudgetRoomNight = sumOfRoombook - sumOfRoomBudget;

            let sum14 = 0;
            data_MTD.forEach(element => {
              sum14 += element.ReveneActual == null ? 0 : parseFloat(element.ReveneActual);
            });
            let sumOfRevenueActual = sum14;

            let sum15 = 0;
            hotelRoomBudgetData_MTD.forEach(element => {
              sum15 += element.MTDBudget == null ? 0 : parseFloat(element.MTDBudget);
            });

            let sumOfRevenueBudget = sum15;
            mSummeryReportDataModel.MTDBudgetRevenue = (sumOfRevenueActual - sumOfRevenueBudget).toFixed(2);


            let sum16 = 0;
            hotelRoomBudgetData.forEach(element => {
              if (moment(element.Date).format('YYYY-MM-DD') >= moment(NextMonthFirstdate).format('YYYY-MM-DD')
                && moment(element.Date).format('YYYY-MM-DD') <= moment(currentselecteddate_NextMonth).format('YYYY-MM-DD')) {
                sum16 = element.ForecastRoomSold + sum16;
              }
            });
            let sumOfRoomForcast = sum16;
            mSummeryReportDataModel.MTDForcastRoomNight = sumOfRoombook - sumOfRoomForcast;

            let sum17 = 0;
            hotelRoomBudgetData_MTD.forEach(element => {
              sum17 += element.MTDForecastRoomRevenue == null ? 0 : parseFloat(element.MTDForecastRoomRevenue);
            });

            let sumOfRevenueForcast = sum17;
            mSummeryReportDataModel.MTDForcastRevenue = (sumOfRevenueActual - sumOfRevenueForcast).toFixed(2);




            var hotelRoomBudgetData_OTB = [];


            let sum4_OTB = 0;
            data.forEach(element => {
              sum4_OTB += element.RoomsActual == null ? 0 : parseFloat(element.RoomsActual);
            });
            let sumOfRoombook_OTB = sum4_OTB;

            hotelRoomBudgetData.forEach(element => {
              if (moment(element.Date).format('YYYY-MM-DD') >= moment(NextMonthLastdate).format('YYYY-MM-DD') && moment(element.Date).format('YYYY-MM-DD') <= moment(NextMonthLastdate).format('YYYY-MM-DD')) {
                hotelRoomBudgetData_OTB.push(element);
              }
            });

            let sum5_OTB = 0;
            hotelRoomBudgetData_OTB.forEach(element => {
              sum5_OTB += element.MTDBudgetRooms == null ? 0 : parseInt(element.MTDBudgetRooms);
            });
            let sumOfRoomBudget_OTB = sum5_OTB;


            let sum6_OTB = 0;
            data.forEach(element => {
              sum6_OTB += element.ReveneActual == null ? 0 : parseFloat(element.ReveneActual);
            });
            let sumOfRevenueActual_OTB = sum6_OTB;

            let sum7_OTB = 0;
            hotelRoomBudgetData_OTB.forEach(element => {
              sum7_OTB += element.MTDBudget == null ? 0 : parseFloat(element.MTDBudget);
            });
            let sumOfRevenueBudget_OTB = sum7_OTB;


            let sum8_OTB = 0;
            hotelRoomBudgetData.forEach(element => {
              if (moment(element.Date).format('YYYY-MM-DD') >= moment(NextMonthFirstdate).format('YYYY-MM-DD')
                && moment(element.Date).format('YYYY-MM-DD') <= moment(NextMonthLastdate).format('YYYY-MM-DD')) {
                sum8_OTB += element.ForecastRoomSold == null ? 0 : parseInt(element.ForecastRoomSold);
              }
            });

            let sumOfRoomForcast_OTB = sum8_OTB;


            let sum9_OTB = 0;
            hotelRoomBudgetData_OTB.forEach(element => {
              sum9_OTB += element.MTDForecastRoomRevenue == null ? 0 : parseFloat(element.MTDForecastRoomRevenue);
            });
            let sumOfRevenueForcast_OTB = sum9_OTB;

            mSummeryReportDataModel.OTBBudgetRoomNight = sumOfRoombook_OTB - sumOfRoomBudget_OTB;
            mSummeryReportDataModel.OTBBudgetRevenue = (sumOfRevenueActual_OTB - sumOfRevenueBudget_OTB).toFixed(2);
            mSummeryReportDataModel.OTBForcastRoomNight = sumOfRoombook_OTB - sumOfRoomForcast_OTB;
            mSummeryReportDataModel.OTBForcastRevenue = (sumOfRevenueActual_OTB - sumOfRevenueForcast_OTB).toFixed(2);


            mSummeryReportDataModel.MonthYear = MonthYear;
            mSummeryReportDataModelList.push(mSummeryReportDataModel);


            // next 2month section
            mSummeryReportDataModel = {};
            let next2Datetime = new Date(moment(dt).add(2, 'M'));
            // console.log(next2Datetime, 'next2Datetime')
            MonthYear = moment(next2Datetime).format("MMMM - YYYY");
            // let MonthYear = moment(next2Datetime).format("MMMM - YYYY");
            // console.log(MonthYear, 'MonthYear')
            let next2Month = moment(next2Datetime).format("MMMM");
            let next2monthNumber = moment(next2Datetime).format("MM");
            // totalNoOfDays = DateTime.DaysInMonth(next2Datetime.Year, next2monthNumber);
            totalNoOfDays = Utils.daysInMonth(next2Datetime);
            let Next2MonthFirstdate = new Date(next2Datetime.getFullYear(), next2Datetime.getMonth(), 1, 23, 59, 59);
            let Next2MonthLastdate = new Date(next2Datetime.getFullYear(), next2Datetime.getMonth(), totalNoOfDays, 23, 59, 59);
            let currentselecteddate_Next2Month = new Date(next2Datetime);

            return Promise.all([
              new Promise((resolve, reject) => {
                // hotelId, Convert.ToString(dt), Next2MonthFirstdate, Next2MonthLastdate
                PickupsSummeryHelper.getPickupReportData_v2(hotelId, dt.toISOString(), Next2MonthFirstdate, Next2MonthLastdate, (err, res) => {
                  if (err) {
                    reject(err);
                  }
                  PickupReportDataModelList = res;
                  resolve();
                });
              })
            ]).then(resp => {

              return Promise.all([
                new Promise((resolve, reject) => {
                  PickupsSummeryHelper.getHotelRevenueDataForSummeryReport(hotelId, Next2MonthFirstdate, Next2MonthLastdate, (err, result) => {
                    if (err) {
                      reject(err)
                    }
                    if (result) {
                      HotelRevenueData = result;
                    }
                    resolve();
                  });
                }),
                new Promise((resolve, reject) => {
                  MonthlypickupHelper.getHotelRevenuesForPickup(Next2MonthFirstdate, Next2MonthLastdate, parseInt(hotelId), (err, hoteldata) => {
                    if (err) {
                      reject(err)
                    }
                    if (hoteldata) {
                      data = hoteldata;
                    }
                    resolve();
                  });
                }),
                new Promise((resolve, reject) => {
                  PickupsSummeryHelper.getHotelBudgetDashboardCalculationsByHotelID(hotelId, Next2MonthFirstdate, Next2MonthLastdate, (err, results) => { // need to pass starting date and end date -------------------------------------------------->
                    if (err) {
                      reject(err)
                    }
                    if (results) {
                      hotelRoomBudgetData = results;
                    }
                    resolve();
                  });
                })
              ]).then(resp => {



                let sum18 = 0;
                PickupReportDataModelList.forEach(element => {
                  sum18 = element.pickupToday + sum18;
                });
                mSummeryReportDataModel.PickUpRoomNight = parseInt(sum18).toFixed(2);

                let sum19 = 0;
                PickupReportDataModelList.forEach(element => {
                  sum19 = element.pickupRevenue + sum19;
                });
                mSummeryReportDataModel.PickUpRevenue = parseFloat(sum19).toFixed(2);

                if (mSummeryReportDataModel.PickUpRoomNight != 0 && mSummeryReportDataModel.PickUpRevenue != 0) {
                  mSummeryReportDataModel.PickUpADR = (mSummeryReportDataModel.PickUpRevenue / mSummeryReportDataModel.PickUpRoomNight).toFixed(2);
                }

                if (mSummeryReportDataModel.PickUpADR == null || isNaN(mSummeryReportDataModel.PickUpADR)) {
                  mSummeryReportDataModel.PickUpADR = 0;
                }

                var data = [];
                PickupReportDataModelList.forEach(element => {
                  if (moment(element.Date).format('YYYY-MM-DD') >= moment(Next2MonthFirstdate).format('YYYY-MM-DD')
                    && moment(element.Date).format('YYYY-MM-DD') <= moment(Next2MonthLastdate).format('YYYY-MM-DD')) {
                    data.push(element);
                  }
                });

                var data_MTD = [];
                data.forEach(element => {
                  if (moment(element.Date).format('YYYY-MM-DD') >= moment(Next2MonthFirstdate).format('YYYY-MM-DD')
                    && moment(element.Date).format('YYYY-MM-DD') <= moment(currentselecteddate_Next2Month).format('YYYY-MM-DD')) {
                    data_MTD.push(element);
                  }
                });

                let sum20 = 0;
                data_MTD.forEach(element => {
                  sum20 += element.RoomsActual == null ? 0 : parseFloat(element.RoomsActual);

                });
                let sumOfRoombook = sum20;


                var hotelRoomBudgetData_MTD = [];

                hotelRoomBudgetData.forEach(element => {
                  if (moment(element.Date).format('YYYY-MM-DD') >= moment(currentselecteddate_Next2Month).format('YYYY-MM-DD')
                    && moment(element.Date).format('YYYY-MM-DD') <= moment(currentselecteddate_Next2Month).format('YYYY-MM-DD')) {
                    hotelRoomBudgetData_MTD.push(element);
                  }
                });

                let sum21 = 0;
                hotelRoomBudgetData_MTD.forEach(element => {
                  sum21 += element.MTDBudgetRooms == null ? 0 : parseInt(element.MTDBudgetRooms);
                });
                let sumOfRoomBudget = sum21;
                mSummeryReportDataModel.MTDBudgetRoomNight = sumOfRoombook - sumOfRoomBudget;

                let sum22 = 0;
                data_MTD.forEach(element => {
                  sum22 += element.ReveneActual == null ? 0 : parseFloat(element.ReveneActual);
                });
                let sumOfRevenueActual = sum22;

                let sum24 = 0;
                hotelRoomBudgetData_MTD.forEach(element => {
                  sum24 += element.MTDBudget == null ? 0 : parseFloat(element.MTDBudget);
                });
                let sumOfRevenueBudget = sum24;
                mSummeryReportDataModel.MTDBudgetRevenue = (sumOfRevenueActual - sumOfRevenueBudget).toFixed(2);

                let sum25 = 0;

                hotelRoomBudgetData.forEach(element => {
                  if (moment(element.Date).format('YYYY-MM-DD') >= moment(Next2MonthFirstdate).format('YYYY-MM-DD')
                    && moment(element.Date).format('YYYY-MM-DD') <= moment(currentselecteddate_Next2Month).format('YYYY-MM-DD')) {
                    sum25 += element.ForecastRoomSold == null ? 0 : parseInt(element.ForecastRoomSold);
                  }
                });


                let sumOfRoomForcast = sum25;
                mSummeryReportDataModel.MTDForcastRoomNight = sumOfRoombook - sumOfRoomForcast;

                let sum26 = 0;
                hotelRoomBudgetData_MTD.forEach(element => {
                  sum26 += element.MTDForecastRoomRevenue == null ? 0 : parseFloat(element.MTDForecastRoomRevenue);
                });

                let sumOfRevenueForcast = sum26;
                mSummeryReportDataModel.MTDForcastRevenue = (sumOfRevenueActual - sumOfRevenueForcast).toFixed(2);

                var hotelRoomBudgetData_OTB = [];


                let sum4_OTB = 0;
                data.forEach(element => {
                  sum4_OTB += element.RoomsActual == null ? 0 : parseFloat(element.RoomsActual);
                });
                let sumOfRoombook_OTB = sum4_OTB;

                hotelRoomBudgetData.forEach(element => {
                  if (moment(element.Date).format('YYYY-MM-DD') >= moment(Next2MonthLastdate).format('YYYY-MM-DD')
                    && moment(element.Date).format('YYYY-MM-DD') <= moment(Next2MonthLastdate).format('YYYY-MM-DD')) {
                    hotelRoomBudgetData_OTB.push(element);
                  }
                });

                let sum5_OTB = 0;
                hotelRoomBudgetData_OTB.forEach(element => {
                  sum5_OTB += element.MTDBudgetRooms == null ? 0 : parseInt(element.MTDBudgetRooms);
                });
                let sumOfRoomBudget_OTB = sum5_OTB;


                let sum6_OTB = 0;
                data.forEach(element => {
                  sum6_OTB += element.ReveneActual == null ? 0 : parseFloat(element.ReveneActual);
                });
                let sumOfRevenueActual_OTB = sum6_OTB;

                let sum7_OTB = 0;
                hotelRoomBudgetData_OTB.forEach(element => {
                  sum7_OTB += element.MTDBudget == null ? 0 : parseFloat(element.MTDBudget);
                });
                let sumOfRevenueBudget_OTB = sum7_OTB;


                let sum8_OTB = 0;
                hotelRoomBudgetData.forEach(element => {
                  if (moment(element.Date).format('YYYY-MM-DD') >= moment(Next2MonthFirstdate).format('YYYY-MM-DD')
                    && moment(element.Date).format('YYYY-MM-DD') <= moment(Next2MonthLastdate).format('YYYY-MM-DD')) {
                    sum8_OTB += element.ForecastRoomSold == null ? 0 : parseInt(element.ForecastRoomSold);
                  }
                });

                let sumOfRoomForcast_OTB = sum8_OTB;


                let sum9_OTB = 0;
                hotelRoomBudgetData_OTB.forEach(element => {
                  sum9_OTB += element.MTDForecastRoomRevenue == null ? 0 : parseFloat(element.MTDForecastRoomRevenue);
                });
                let sumOfRevenueForcast_OTB = sum9_OTB;

                mSummeryReportDataModel.OTBBudgetRoomNight = sumOfRoombook_OTB - sumOfRoomBudget_OTB;
                mSummeryReportDataModel.OTBBudgetRevenue = (sumOfRevenueActual_OTB - sumOfRevenueBudget_OTB).toFixed(2);
                mSummeryReportDataModel.OTBForcastRoomNight = sumOfRoombook_OTB - sumOfRoomForcast_OTB;
                mSummeryReportDataModel.OTBForcastRevenue = (sumOfRevenueActual_OTB - sumOfRevenueForcast_OTB).toFixed(2);


                mSummeryReportDataModel.MonthYear = MonthYear;
                mSummeryReportDataModelList.push(mSummeryReportDataModel);

                // console.log('ended')
                return cb(null, mSummeryReportDataModelList);
              })
            })
          })
        })
      })
    })
  }

  static getHotelRevenueDataForSummeryReport(hotelId, startDate, endDate, cb) {

    let mhotelRevenueList = [];

    for (var m = moment(startDate); m.isBefore(endDate); m.add(1, 'days')) {
      let hotelID = parseInt(hotelId);
      startDate = new Date(startDate).toISOString();
      endDate = new Date(endDate).toISOString();

      let reportedDateTimePreviousRpt = new Date(moment().subtract(1, 'days').format('YYYY-MM-DD')).toISOString();

      HotelrevenueSchema.findOne({ [HotelrevenueSchemaFields.HotelID]: hotelID, [HotelrevenueSchemaFields.Category]: "ForcastRoomRevenue", [HotelrevenueSchemaFields.ReportedDateTime]: reportedDateTimePreviousRpt, [HotelrevenueSchemaFields.Date]: { "$gte": new Date(moment(m).format('YYYY-MM-DD')).toISOString(), "$lte": new Date(moment(m).add(1, 'days').format('YYYY-MM-DD')).toISOString() } },
        (err, result) => {
          if (err) {
            log.error(err)
            cb(err, null);
          }
          // console.log(result)
          if (result != null) {
            mhotelRevenueList.push(result);
          }
        });
    }
    return cb(null, mhotelRevenueList);
  }


  static getHotelBudgetDashboardCalculationsByHotelID(hotelId, fdate, ldate, cb) {

    let hotelDashboardCalculationList = [];

    HotelbudgetdashboardcalculationsSchema.find({ [HotelbudgetdashboardcalculationsSchemaFields.HotelID]: hotelId, [HotelbudgetdashboardcalculationsSchemaFields.Date]: { "$gte": fdate, "$lte": ldate } },
      (err, result) => {
        if (err) {
          log.error(err)
          cb(err, null);
        }
        hotelDashboardCalculationList = result;
        return cb(null, hotelDashboardCalculationList);
      });
  }

  static getPickupReportData(hotelId, Currentdate, startdate, enddate, cb) {

    let mPickupReportDataModel = [];

    let HotelId = parseInt(hotelId);
    let pickuprpt1Amount = 0;
    let pickuprpt1RoomSold = 0;
    let transientDelta1 = 0;

    startdate = new Date(startdate);
    enddate = new Date(enddate);

    let dt = new Date();
    if (!Currentdate) {
      dt = new Date();
    }
    else {
      dt = new Date(Currentdate);
    }

    let mtdpickupList = [];

    let currentDate = dt;
    let PickupReportDataModelList = [];

    let pickupReportsList = [];

    return Promise.all([
      new Promise((resolve, reject) => {

        MonthlypickupHelper.getPickReportTableDataForPickup(HotelId, currentDate, currentDate, enddate, (err, res) => {
          if (err) {
            reject(err);
          }
          pickupReportsList = res;
          resolve();
        });
      }),
      // new Promise((resolve, reject) => {
      //   MonthlyPickupsHelper.getPickReportDeltaForMTD_v2(HotelId, currentDate, startdate, enddate, (err, hrevData) => {
      //     if (err) {
      //       reject(err);
      //     }
      //     if (hrevData) {
      //       mtdpickupList = hrevData;
      //       // console.log('4')
      //     }
      //     resolve();
      //   });
      // }),

    ]).then(resp => {
      let p = [];
      let p2 = [];
      for (var date = moment(startdate); date.isBefore(enddate); date.add(1, 'days')) {
        p.push(
          new Promise(resolve => {
            let data = _.find(pickupReportsList, function (x) {
              return new Date(moment(x.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString();
            });

            if (data != null) {
              let totalroomssold = data.NoOfRoomSold ? data.NoOfRoomSold : 0;
              let totalrevenue = data.TotalRevenue ? data.TotalRevenue : 0;
              let transientRoomSold = data.TransientRoomsSold ? data.TransientRoomsSold : 0;

              // dal.GetPickUpDelta(hotelIDs, date, currentDate, 1, totalrevenue, totalroomssold, transientRoomSold, out pickuprpt1Amount, out pickuprpt1RoomSold, out transientDelta1);
              p2.push(
                new Promise(resolve => {
                  PickupHelper.getPickUpDelta(HotelId, date, currentDate, 1, totalrevenue, totalroomssold, transientRoomSold, (err, result) => {
                    if (err) {
                      reject(err);
                    }
                    if (result) {
                      pickuprpt1Amount = result.rptamount;
                      pickuprpt1RoomSold = result.rptroomsold;
                      transientDelta1 = result.transientDelta;
                    }
                    resolve();
                  });
                })
              )
              // let result = await MonthlypickupHelper.getPickUpDelta2(HotelId, date, currentDate, 1, totalrevenue, totalroomssold, transientRoomSold);
              // if (result) {
              //   pickuprpt1Amount = result.rptamount;
              //   pickuprpt1RoomSold = result.rptroomsold;
              //   transientDelta1 = result.transientDelta;
              // }
            }




            Promise.all(p2).then(res => {

              mPickupReportDataModel.Day = moment(date).format('ddd');
              mPickupReportDataModel.Date = moment(date).format("YYYY-MM-DD");

              mPickupReportDataModel.pickupToday = parseFloat(pickuprpt1RoomSold);
              mPickupReportDataModel.pickupRevenue = pickuprpt1Amount;
              PickupReportDataModelList.push(mPickupReportDataModel);
              resolve();
            })
          })
        )
      }
      Promise.all(p).then(res => {
        return cb(null, PickupReportDataModelList);

      });
    });
  }

  static getPickupReportData_v2(hotelId, Currentdate, startdate, enddate, cb) {


    let HotelId = parseInt(hotelId);
    let pickuprpt1Amount = 0;
    let pickuprpt1RoomSold = 0;
    let transientDelta1 = 0;

    startdate = new Date(startdate);
    enddate = new Date(enddate);

    let dt = new Date();
    if (!Currentdate) {
      dt = new Date();
    }
    else {
      dt = new Date(Currentdate);
    }


    let currentDate = dt;
    let PickupReportDataModelList = [];

    let pickupReportsList = [];
    let HotelRevenueFCData = [];

    return Promise.all([
      new Promise((resolve, reject) => {

        MonthlypickupHelper.getPickReportTableDataForPickup(HotelId, currentDate, currentDate, enddate, (err, res) => {
          if (err) {
            reject(err);
          }
          pickupReportsList = res;
          resolve();
        });
      }),
      new Promise((resolve, reject) => {
        MonthlypickupHelper.getHotelRevenuesForPickupReport(currentDate, currentDate, enddate, HotelId, (err, hrevFCData) => {
          if (err) {
            reject(err);
          }
          if (hrevFCData) {
            HotelRevenueFCData = hrevFCData;
            // console.log('5')
          }
          resolve();
        });
      }),


    ]).then(async resp => {

      let enddate_plus_1 = new Date(enddate);
      enddate_plus_1 = new Date(Utils.addDays(enddate_plus_1, 1));

      for (var date = moment(startdate); date.isBefore(enddate_plus_1); date.add(1, 'days')) {


        let data = _.find(pickupReportsList, function (x) {
          return new Date(moment(x.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString();
        });

        if (data != null) {

          let totalroomssold = data.NoOfRoomSold ? data.NoOfRoomSold : 0;
          let totalrevenue = data.TotalRevenue ? data.TotalRevenue : 0;
          let transientRoomSold = data.TransientRoomsSold ? data.TransientRoomsSold : 0;

          // dal.GetPickUpDelta(hotelIDs, date, currentDate, 1, totalrevenue, totalroomssold, transientRoomSold, out pickuprpt1Amount, out pickuprpt1RoomSold, out transientDelta1);


          let valset = await new Promise((resolve, reject) => PickupHelper.getPickUpDelta(HotelId, date, currentDate, 1, totalrevenue, totalroomssold, transientRoomSold, (err, result) => {
            if (err) {
              reject(err);
            }
            resolve(result);
          })
          )
          if (valset) {
            pickuprpt1Amount = valset.rptamount;
            pickuprpt1RoomSold = valset.rptroomsold;
            transientDelta1 = valset.transientDelta;
          }

          let mPickupReportDataModel = [];

          if (HotelRevenueFCData != null) {
            let sum = 0;
            let sum_ReveneActual = 0;
            HotelRevenueFCData.forEach(element => {
              if (new Date(moment(element.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString()) {
                sum = element.NoOfRoomSold + sum;
                sum_ReveneActual = element.TotalRevenue + sum_ReveneActual;
              }
            });
            mPickupReportDataModel.RoomsActual = sum;
            mPickupReportDataModel.ReveneActual = sum_ReveneActual;
          } else {
            mPickupReportDataModel.RoomsActual = 0;
            mPickupReportDataModel.ReveneActual = 0;
          }


          mPickupReportDataModel.Day = moment(date).format('ddd');
          mPickupReportDataModel.Date = moment(date).format("YYYY-MM-DD");

          mPickupReportDataModel.pickupToday = parseFloat(pickuprpt1RoomSold);
          mPickupReportDataModel.pickupRevenue = pickuprpt1Amount;
          PickupReportDataModelList.push(mPickupReportDataModel);

        }
      }
      return cb(null, PickupReportDataModelList);


    }, err => {
      return cb(err);
    });

  }

  static getSummeryPickupData_GraphQL(hotelId, date, cb) {
    //get myp hotelid from cmp_id
    return HotelsHelper.getHotelDataByCMPID(hotelId, (err, hoteldata) => {
      if (err) {
        cb(err, null);
      }
      if (!hoteldata) {
        cb(Constants.HotelNotFound, null);
      }
      else {
        PickupsSummeryHelper.getSummeryPickupData(hoteldata.ID, date, cb, (err, result) => {
          // console.log(result, 'called')
          if (err) {
            cb(err, null);
          }
          cb(null, result);
        });
      }
    });

  }


}

module.exports = PickupsSummeryHelper;