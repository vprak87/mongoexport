const Utils = require('../common/utils');
const moment = require('moment');
const _ = require('lodash');

const { Starreport: StarreportSchema, SchemaField: StarreportSchemaFields } = require('../models/starreport');

const Starreportchartdatamodel = require('../strreport/models/starreportchartdatamodel');
const Starreportbudgetdatamodel = require('../strreport/models/starreportbudgetdatamodel');

const { Starmonthreport: StarmonthreportSchema, SchemaField: StarmonthreportSchemaFields } = require('../models/starmonthreport');
const { Stroccweekreport: StroccweekreportSchema, SchemaField: StroccweekreportSchemaFields } = require('../models/stroccweekreport');
const { Stroccmonthreport: StroccmonthreportSchema, SchemaField: StroccmonthreportSchemaFields } = require('../models/stroccmonthreport');

const { Stradrweekreport: StradrweekreportSchema, SchemaField: StradrweekreportSchemaFields } = require('../models/stradrweekreport');
const { Stradrmonthreport: StradrmonthreportSchema, SchemaField: StradrmonthreportSchemaFields } = require('../models/stradrmonthreport');

const { Strrevparweekreport: StrrevparweekreportSchema, SchemaField: StrrevparweekreportSchemaFields } = require('../models/strrevparweekreport');
const { Strrevparmonthreport: StrrevparmonthreportSchema, SchemaField: StrrevparmonthreportSchemaFields } = require('../models/strrevparmonthreport');

const { Hotelbudget: HotelbudgetSchema, SchemaField: HotelbudgetSchemaFields } = require('../models/hotelbudget');

var log = require('log4js').getLogger("starreport_helper");

class StarreportHelper {

    static GetMonthData(hotelid, reportdate, cb) {

        log.debug('Call GetMonthData, hotelid:' + hotelid + "reportdate:" + reportdate);

        let start = Utils.firstDayOfMonth(reportdate);
        let enddate = Utils.lastDayOfMonth(reportdate);
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);


        return StarmonthreportSchema.find({
            [StarmonthreportSchemaFields.HotelID]: hotelid,
            [StarmonthreportSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {

                //check weekly data TODO

                log.debug("GetMonthData result not found");
            }
            return cb(null, result);
        });
    }


    static getWeekData(hotelid, startdate, enddate, cb) {

        log.debug('Call getWeekData, hotelid:' + hotelid + " startdate:" + startdate + " enddate:" + enddate);

        let starreportAggregate = StarreportSchema.aggregate();

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        let totalDays = Utils.dateDiffInDays(startdate, enddate);


        starreportAggregate.match({
            [StarreportSchemaFields.HotelID]: hotelid,
            [StarreportSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })



        starreportAggregate.exec((err, result) => {

            let objStarreportchartdatamodel = new Starreportchartdatamodel();
            objStarreportchartdatamodel.Date = Utils.getFormattedDate(start, 'DD-MMM-YY');
            objStarreportchartdatamodel.StartDate = startdate;
            objStarreportchartdatamodel.EndDate = enddate;
            objStarreportchartdatamodel.DateForChart = start;
            objStarreportchartdatamodel.HotelId = hotelid;
            objStarreportchartdatamodel.WeekNumber = Utils.getWeekNumber(start);

            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("getWeekData result not found");

                //check month table
                let starmonthreportAggregate = StarmonthreportSchema.aggregate();

                starmonthreportAggregate.match({
                    [StarmonthreportSchemaFields.HotelID]: hotelid,
                    [StarmonthreportSchemaFields.Date]: {
                        $gte: start,
                        $lt: end
                    }
                })
                starmonthreportAggregate.exec((err, result2) => {

                    if (err) {
                        log.error(err);
                    }
                    if (!result2 || result2.length == 0) {
                        log.debug("getWeekData  month table result not found");
                    }
                    else {

                        const occChgIndex = _.meanBy(result2, (p) => p.OccChgIndex);
                        const occChgMyPropertyAvg = _.meanBy(result2, (p) => p.OccChgMyProperty);
                        const occIndexAvg = _.meanBy(result2, (p) => p.OccIndex);
                        const occMyPropertyAvg = _.meanBy(result2, (p) => p.OccMyProperty);

                        const adrChgIndexAvg = _.meanBy(result2, (p) => p.AdrChgIndex);
                        const adrChgMyPropertyAvg = _.meanBy(result2, (p) => p.AdrChgMyProperty);
                        const adrIndexAvg = _.meanBy(result2, (p) => p.AdrIndex);
                        const adrMyPropertyAvg = _.meanBy(result2, (p) => p.AdrMyProperty);


                        const revParChgIndexAvg = _.meanBy(result2, (p) => p.RevParChgIndex);
                        const revParChgMyPropertyAvg = _.meanBy(result2, (p) => p.RevParChgMyProperty);
                        const revParIndexAvg = _.meanBy(result2, (p) => p.RevParIndex);
                        const revParMyPropertyAvg = _.meanBy(result2, (p) => p.RevParMyProperty);

                        objStarreportchartdatamodel.OccChgIndex = totalDays == 1 ? result2[0].OccChgIndex : occChgIndex;
                        objStarreportchartdatamodel.OccChgMyProperty = totalDays == 1 ? result2[0].OccChgMyProperty : occChgMyPropertyAvg;
                        objStarreportchartdatamodel.OccChgRank = 'NA';
                        objStarreportchartdatamodel.OccIndex = totalDays == 1 ? result2[0].OccIndex : occIndexAvg;
                        objStarreportchartdatamodel.OccMyProperty = totalDays == 1 ? result2[0].OccMyProperty : occMyPropertyAvg;
                        objStarreportchartdatamodel.OccRank = 'NA';

                        objStarreportchartdatamodel.AdrChgIndex = totalDays == 1 ? result2[0].AdrChgIndex : adrChgIndexAvg;
                        objStarreportchartdatamodel.AdrChgMyProperty = totalDays == 1 ? result2[0].AdrChgMyProperty : adrChgMyPropertyAvg;
                        objStarreportchartdatamodel.AdrChgRank = 'NA';
                        objStarreportchartdatamodel.AdrIndex = totalDays == 1 ? result2[0].AdrIndex : adrIndexAvg;
                        objStarreportchartdatamodel.AdrMyProperty = totalDays == 1 ? result2[0].AdrMyProperty : adrMyPropertyAvg;
                        objStarreportchartdatamodel.AdrRank = 'NA';

                        objStarreportchartdatamodel.RevParChgIndex = totalDays == 1 ? result2[0].RevParChgIndex : revParChgIndexAvg;
                        objStarreportchartdatamodel.RevParChgMyProperty = totalDays == 1 ? result2[0].RevParChgMyProperty : revParChgMyPropertyAvg;
                        objStarreportchartdatamodel.RevParChgRank = 'NA';
                        objStarreportchartdatamodel.RevParIndex = totalDays == 1 ? result2[0].RevParIndex : revParIndexAvg;
                        objStarreportchartdatamodel.RevParMyProperty = totalDays == 1 ? result2[0].RevParMyProperty : revParMyPropertyAvg;
                        objStarreportchartdatamodel.RevParRank = 'NA';

                    }

                    return cb(null, objStarreportchartdatamodel);
                });

            }
            else {

                //get data from StrOccWeekReports, StrAdrWeekReports, StrRevParWeekReports
                let occWeekId = 0;
                let adrWeekId = 0;
                let revparWeekId = 0;
                occWeekId = result[0].OccId;
                adrWeekId = result[0].AdrId;
                revparWeekId = result[0].RevParId;
                let occreport = null;
                let adrreport = null;
                let revparreport = null;


                return Promise.all([
                    new Promise((resolve, reject) => {
                        // get StrOccWeekReports data
                        StroccweekreportSchema.findOne({ [StroccweekreportSchemaFields.ID]: occWeekId }, (err, occreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (occreport_result) {
                                occreport = occreport_result;
                            }
                            resolve();
                        });
                    }),
                    new Promise((resolve, reject) => {
                        // get StrAdrWeekReports data
                        StradrweekreportSchema.findOne({ [StradrweekreportSchemaFields.ID]: adrWeekId }, (err, adrreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (adrreport_result) {
                                adrreport = adrreport_result;
                            }
                            resolve();
                        });
                    }),
                    new Promise((resolve, reject) => {
                        // get StrRevParWeekReports data
                        StrrevparweekreportSchema.findOne({ [StrrevparweekreportSchemaFields.ID]: revparWeekId }, (err, revparreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (revparreport_result) {
                                revparreport = revparreport_result;
                            }
                            resolve();
                        });
                    })
                ]).then(resp => {

                    objStarreportchartdatamodel.OccChgIndex = totalDays == 1 ? result[0].OccChgIndex : ((occreport) ? occreport.OccIndexChgCurrentWeek : 0);
                    objStarreportchartdatamodel.OccChgMyProperty = totalDays == 1 ? result[0].OccChgMyProperty : ((occreport) ? occreport.OccChgMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.OccChgRank = totalDays == 1 ? result[0].OccChgRank : ((occreport) ? occreport.OccRankChgCurrentWeek : 'NA');
                    objStarreportchartdatamodel.OccIndex = totalDays == 1 ? result[0].OccIndex : ((occreport) ? occreport.OccIndexCurrentWeek : 0);
                    objStarreportchartdatamodel.OccMyProperty = totalDays == 1 ? result[0].OccMyProperty : ((occreport) ? occreport.OccMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.OccRank = totalDays == 1 ? result[0].OccRank : ((occreport) ? occreport.OccRankCurrentWeek : 'NA');

                    objStarreportchartdatamodel.AdrChgIndex = totalDays == 1 ? result[0].AdrChgIndex : ((adrreport) ? adrreport.AdrIndexChgCurrentWeek : 0);
                    objStarreportchartdatamodel.AdrChgMyProperty = totalDays == 1 ? result[0].AdrChgMyProperty : ((adrreport) ? adrreport.AdrChgMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.AdrChgRank = totalDays == 1 ? result[0].AdrchgRank : ((adrreport) ? adrreport.AdrRankChgCurrentWeek : 'NA');
                    objStarreportchartdatamodel.AdrIndex = totalDays == 1 ? result[0].AdrIndex : ((adrreport) ? adrreport.AdrIndexCurrentWeek : 0);
                    objStarreportchartdatamodel.AdrMyProperty = totalDays == 1 ? result[0].AdrMyProperty : ((adrreport) ? adrreport.AdrMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.AdrRank = totalDays == 1 ? result[0].AdrRank : ((adrreport) ? adrreport.AdrRankCurrentWeek : 'NA');

                    objStarreportchartdatamodel.RevParChgIndex = totalDays == 1 ? result[0].RevParChgIndex : ((revparreport) ? revparreport.RevParIndexChgCurrentWeek : 0);
                    objStarreportchartdatamodel.RevParChgMyProperty = totalDays == 1 ? result[0].RevParChgMyProperty : ((revparreport) ? revparreport.RevParChgMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.RevParChgRank = totalDays == 1 ? result[0].RevParChgRank : ((revparreport) ? revparreport.RevParRankChgCurrentWeek : 'NA');
                    objStarreportchartdatamodel.RevParIndex = totalDays == 1 ? result[0].RevParIndex : ((revparreport) ? revparreport.RevParIndexCurrentWeek : 0);
                    objStarreportchartdatamodel.RevParMyProperty = totalDays == 1 ? result[0].RevParMyProperty : ((revparreport) ? revparreport.RevParMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.RevParRank = totalDays == 1 ? result[0].RevParRank : ((revparreport) ? revparreport.RevParRankCurrentWeek : 'NA');

                    return cb(null, objStarreportchartdatamodel);

                }, err => {
                    return cb(err, null);
                })
            }
        });


    }



    static getLYSamePeriodData(hotelid, currentdate, startdate, enddate, cb) {

        log.debug('Call getLYSamePeriodData, hotelid:' + hotelid + " startdate:" + startdate + " enddate:" + enddate);

        let starreportAggregate = StarreportSchema.aggregate();

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        let totalDays = Utils.dateDiffInDays(startdate, enddate);


        starreportAggregate.match({
            [StarreportSchemaFields.HotelID]: hotelid,
            [StarreportSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })



        starreportAggregate.exec((err, result) => {

            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("getLYSamePeriodData result not found");

                //#region check StarMonthReports table if not found
                let starmonthreportAggregate = StarmonthreportSchema.aggregate();

                starmonthreportAggregate.match({
                    [StarmonthreportSchemaFields.HotelID]: hotelid,
                    [StarmonthreportSchemaFields.Date]: {
                        $gte: start,
                        $lt: end
                    }
                })

                starmonthreportAggregate.exec((err2, result2) => {
                    if (err2) {
                        log.error(err2);
                    }
                    if (!result2 || result2.length == 0) {
                        log.debug("getLYSamePeriodData StarMonthReports result not found");
                        let objStarreportchartdatamodel = new Starreportchartdatamodel();
                        objStarreportchartdatamodel.Date = currentdate;
                        objStarreportchartdatamodel.DateLY = Utils.getFormattedDate(start, 'DD-MMM-YY');
                        objStarreportchartdatamodel.DateForChartLY = start;
                        objStarreportchartdatamodel.HotelId = hotelid;
                        objStarreportchartdatamodel.OccChgIndex = "NA";
                        objStarreportchartdatamodel.OccIndex = "NA";
                        objStarreportchartdatamodel.OccMyProperty = "NA";
                        objStarreportchartdatamodel.OccChgMyProperty = "NA";
                        objStarreportchartdatamodel.AdrMyProperty = "NA";
                        objStarreportchartdatamodel.AdrChgMyProperty = "NA";
                        objStarreportchartdatamodel.AdrIndex = "NA";
                        objStarreportchartdatamodel.AdrChgIndex = "NA";
                        objStarreportchartdatamodel.RevParMyProperty = "NA";
                        objStarreportchartdatamodel.RevParChgMyProperty = "NA";
                        objStarreportchartdatamodel.RevParIndex = "NA";
                        objStarreportchartdatamodel.RevParChgIndex = "NA";
                        return cb(null, objStarreportchartdatamodel);
                    }
                    else {

                        //#region get data from StrOccMonthReports, StrAdrMonthReports, StrRevParMonthReports
                        let occWeekId = 0;
                        let adrWeekId = 0;
                        let revparWeekId = 0;
                        occWeekId = result2[0].OccId;
                        adrWeekId = result2[0].AdrId;
                        revparWeekId = result2[0].RevParId;
                        let occreport = null;
                        let adrreport = null;
                        let revparreport = null;


                        return Promise.all([
                            new Promise((resolve, reject) => {
                                // get StrOccMonthReports data
                                StroccmonthreportSchema.findOne({ [StroccmonthreportSchemaFields.ID]: occWeekId }, (err, occreport_result) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    if (occreport_result) {
                                        occreport = occreport_result;
                                    }
                                    resolve();
                                });
                            }),
                            new Promise((resolve, reject) => {
                                // get StrAdrMonthReports data
                                StradrmonthreportSchema.findOne({ [StradrmonthreportSchemaFields.ID]: adrWeekId }, (err, adrreport_result) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    if (adrreport_result) {
                                        adrreport = adrreport_result;
                                    }
                                    resolve();
                                });
                            }),
                            new Promise((resolve, reject) => {
                                // get StrRevParMonthReports data
                                StrrevparmonthreportSchema.findOne({ [StrrevparmonthreportSchemaFields.ID]: revparWeekId }, (err, revparreport_result) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    if (revparreport_result) {
                                        revparreport = revparreport_result;
                                    }
                                    resolve();
                                });
                            })
                        ]).then(resp => {

                            const occChgIndex = _.meanBy(result2, (p) => p.OccChgIndex);
                            const occChgMyPropertyAvg = _.meanBy(result2, (p) => p.OccChgMyProperty);
                            const occIndexAvg = _.meanBy(result2, (p) => p.OccIndex);
                            const occMyPropertyAvg = _.meanBy(result2, (p) => p.OccMyProperty);
    
                            const adrChgIndexAvg = _.meanBy(result2, (p) => p.AdrChgIndex);
                            const adrChgMyPropertyAvg = _.meanBy(result2, (p) => p.AdrChgMyProperty);
                            const adrIndexAvg = _.meanBy(result2, (p) => p.AdrIndex);
                            const adrMyPropertyAvg = _.meanBy(result2, (p) => p.AdrMyProperty);
    
    
                            const revParChgIndexAvg = _.meanBy(result2, (p) => p.RevParChgIndex);
                            const revParChgMyPropertyAvg = _.meanBy(result2, (p) => p.RevParChgMyProperty);
                            const revParIndexAvg = _.meanBy(result2, (p) => p.RevParIndex);
                            const revParMyPropertyAvg = _.meanBy(result2, (p) => p.RevParMyProperty);

                            let objStarreportchartdatamodel = new Starreportchartdatamodel();
                            objStarreportchartdatamodel.Date = currentdate;
                            objStarreportchartdatamodel.DateLY = Utils.getFormattedDate(start, 'DD-MMM-YY');
                            objStarreportchartdatamodel.DateForChartLY = start;
                            objStarreportchartdatamodel.HotelId = hotelid;
                            
                            objStarreportchartdatamodel.OccChgIndex = totalDays == 1 ? result2[0].OccChgIndex : (occChgIndex);
                            objStarreportchartdatamodel.OccChgMyProperty = totalDays == 1 ? result[0].OccChgMyProperty : (occChgMyPropertyAvg);
                            objStarreportchartdatamodel.OccIndex = totalDays == 1 ? result[0].OccIndex : (occIndexAvg);
                            objStarreportchartdatamodel.OccChgRank = 'NA';
                            objStarreportchartdatamodel.OccMyProperty = totalDays == 1 ? result[0].OccMyProperty : (occMyPropertyAvg);
                            objStarreportchartdatamodel.OccRank = 'NA';

                            objStarreportchartdatamodel.AdrChgIndex = totalDays == 1 ? result[0].AdrChgIndex : (adrChgIndexAvg);
                            objStarreportchartdatamodel.AdrChgMyProperty = totalDays == 1 ? result[0].AdrChgMyProperty : (adrChgMyPropertyAvg);
                            objStarreportchartdatamodel.AdrChgRank = 'NA';
                            objStarreportchartdatamodel.AdrIndex = totalDays == 1 ? result[0].AdrIndex : (adrIndexAvg);
                            objStarreportchartdatamodel.AdrMyProperty = totalDays == 1 ? result[0].AdrMyProperty : (adrMyPropertyAvg);
                            objStarreportchartdatamodel.AdrRank = 'NA';

                            objStarreportchartdatamodel.RevParChgIndex = totalDays == 1 ? result[0].RevParChgIndex : (revParChgIndexAvg);
                            objStarreportchartdatamodel.RevParChgMyProperty = totalDays == 1 ? result[0].RevParChgMyProperty : (revParChgMyPropertyAvg);
                            objStarreportchartdatamodel.RevParChgRank = 'NA';
                            objStarreportchartdatamodel.RevParIndex = totalDays == 1 ? result[0].RevParIndex : (revParIndexAvg);
                            objStarreportchartdatamodel.RevParMyProperty = totalDays == 1 ? result[0].RevParMyProperty : (revParMyPropertyAvg);
                            objStarreportchartdatamodel.RevParRank = 'NA';

                            objStarreportchartdatamodel.Date = currentdate;
                            objStarreportchartdatamodel.DateLY = Utils.getFormattedDate(start, 'DD-MMM-YY');
                            objStarreportchartdatamodel.DateForChartLY = start;
                            objStarreportchartdatamodel.HotelId = hotelid;
                            return cb(null, objStarreportchartdatamodel);

                        }, err => {
                            return cb(err, null);
                        })
                        //#endregion

                    }
                });
                ////#endregion

            }
            else {

                //#region get data from StrOccWeekReports, StrAdrWeekReports, StrRevParWeekReports
                let occWeekId = 0;
                let adrWeekId = 0;
                let revparWeekId = 0;
                occWeekId = result[0].OccId;
                adrWeekId = result[0].AdrId;
                revparWeekId = result[0].RevParId;
                let occreport = null;
                let adrreport = null;
                let revparreport = null;


                return Promise.all([
                    new Promise((resolve, reject) => {
                        // get StrOccWeekReports data
                        StroccweekreportSchema.findOne({ [StroccweekreportSchemaFields.ID]: occWeekId }, (err, occreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (occreport_result) {
                                occreport = occreport_result;
                            }
                            resolve();
                        });
                    }),
                    new Promise((resolve, reject) => {
                        // get StrAdrWeekReports data
                        StradrweekreportSchema.findOne({ [StradrweekreportSchemaFields.ID]: adrWeekId }, (err, adrreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (adrreport_result) {
                                adrreport = adrreport_result;
                            }
                            resolve();
                        });
                    }),
                    new Promise((resolve, reject) => {
                        // get StrRevParWeekReports data
                        StrrevparweekreportSchema.findOne({ [StrrevparweekreportSchemaFields.ID]: revparWeekId }, (err, revparreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (revparreport_result) {
                                revparreport = revparreport_result;
                            }
                            resolve();
                        });
                    })
                ]).then(resp => {
                    let objStarreportchartdatamodel = new Starreportchartdatamodel();
                    objStarreportchartdatamodel.OccChgIndex = totalDays == 1 ? result[0].OccChgIndex : ((occreport) ? occreport.OccIndexChgCurrentWeek : 0);
                    objStarreportchartdatamodel.OccChgMyProperty = totalDays == 1 ? result[0].OccChgMyProperty : ((occreport) ? occreport.OccChgMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.OccChgRank = totalDays == 1 ? result[0].OccChgRank : ((occreport) ? occreport.OccRankChgCurrentWeek : 'NA');
                    objStarreportchartdatamodel.OccIndex = totalDays == 1 ? result[0].OccIndex : ((occreport) ? occreport.OccIndexCurrentWeek : 0);
                    objStarreportchartdatamodel.OccMyProperty = totalDays == 1 ? result[0].OccMyProperty : ((occreport) ? occreport.OccMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.OccRank = totalDays == 1 ? result[0].OccRank : ((occreport) ? occreport.OccRankCurrentWeek : 'NA');

                    objStarreportchartdatamodel.AdrChgIndex = totalDays == 1 ? result[0].AdrChgIndex : ((adrreport) ? adrreport.AdrIndexChgCurrentWeek : 0);
                    objStarreportchartdatamodel.AdrChgMyProperty = totalDays == 1 ? result[0].AdrChgMyProperty : ((adrreport) ? adrreport.AdrChgMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.AdrChgRank = totalDays == 1 ? result[0].AdrchgRank : ((adrreport) ? adrreport.AdrRankChgCurrentWeek : 'NA');
                    objStarreportchartdatamodel.AdrIndex = totalDays == 1 ? result[0].AdrIndex : ((adrreport) ? adrreport.AdrIndexCurrentWeek : 0);
                    objStarreportchartdatamodel.AdrMyProperty = totalDays == 1 ? result[0].AdrMyProperty : ((adrreport) ? adrreport.AdrMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.AdrRank = totalDays == 1 ? result[0].AdrRank : ((adrreport) ? adrreport.AdrRankCurrentWeek : 'NA');

                    objStarreportchartdatamodel.RevParChgIndex = totalDays == 1 ? result[0].RevParChgIndex : ((revparreport) ? revparreport.RevParIndexChgCurrentWeek : 0);
                    objStarreportchartdatamodel.RevParChgMyProperty = totalDays == 1 ? result[0].RevParChgMyProperty : ((revparreport) ? revparreport.RevParChgMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.RevParChgRank = totalDays == 1 ? result[0].RevParChgRank : ((revparreport) ? revparreport.RevParRankChgCurrentWeek : 'NA');
                    objStarreportchartdatamodel.RevParIndex = totalDays == 1 ? result[0].RevParIndex : ((revparreport) ? revparreport.RevParIndexCurrentWeek : 0);
                    objStarreportchartdatamodel.RevParMyProperty = totalDays == 1 ? result[0].RevParMyProperty : ((revparreport) ? revparreport.RevParMyPropCurrentWeek : 0);
                    objStarreportchartdatamodel.RevParRank = totalDays == 1 ? result[0].RevParRank : ((revparreport) ? revparreport.RevParRankCurrentWeek : 'NA');

                    objStarreportchartdatamodel.Date = currentdate;
                    objStarreportchartdatamodel.DateLY = Utils.getFormattedDate(start, 'DD-MMM-YY');
                    objStarreportchartdatamodel.DateForChartLY = start;
                    objStarreportchartdatamodel.HotelId = hotelid;
                    return cb(null, objStarreportchartdatamodel);

                }, err => {
                    return cb(err, null);
                })
                //#endregion
            }
        });


    }


    static getSTRRunning28DaysData(hotelid, currentdate, startdate, enddate, cb) {

        log.debug('Call getSTRRunning28DaysData, hotelid:' + hotelid + " startdate:" + startdate + " enddate:" + enddate);

        let starreportAggregate = StarreportSchema.aggregate();

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        let totalDays = Utils.dateDiffInDays(startdate, enddate);


        starreportAggregate.match({
            [StarreportSchemaFields.HotelID]: hotelid,
            [StarreportSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })


        let objStarreportchartdatamodel = new Starreportchartdatamodel();
        starreportAggregate.exec((err, result) => {

            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("getSTRRunning28DaysData result not found");

                //#region check StarMonthReports table if not found
                let starmonthreportAggregate = StarmonthreportSchema.aggregate();

                starmonthreportAggregate.match({
                    [StarmonthreportSchemaFields.HotelID]: hotelid,
                    [StarmonthreportSchemaFields.Date]: {
                        $gte: start,
                        $lt: end
                    }
                })

                starmonthreportAggregate.exec((err2, result2) => {
                    if (err2) {
                        log.error(err2);
                    }
                    
                    if (!result2 || result2.length == 0) {
                        log.debug("getLYSamePeriodData StarMonthReports result not found");
                      
                        objStarreportchartdatamodel.Date = Utils.getFormattedDate(currentdate, 'DD-MMM-YY');
                        objStarreportchartdatamodel.DateForChart = Utils.getFormattedDate(currentdate, 'DD-MMM-YY');
                        objStarreportchartdatamodel.DateLY = Utils.getFormattedDate(start, 'DD-MMM-YY');
                        objStarreportchartdatamodel.DateForChartLY = start;
                        objStarreportchartdatamodel.HotelId = hotelid;
                        objStarreportchartdatamodel.WeekNumber = Utils.getWeekNumber(start);

                        return cb(null, objStarreportchartdatamodel);
                    }
                    else {

                        //#region get data from StrOccMonthReports, StrAdrMonthReports, StrRevParMonthReports
                        let occWeekId = 0;
                        let adrWeekId = 0;
                        let revparWeekId = 0;
                        occWeekId = result2[0].OccId;
                        adrWeekId = result2[0].AdrId;
                        revparWeekId = result2[0].RevParId;
                        let occreport = null;
                        let adrreport = null;
                        let revparreport = null;


                        return Promise.all([
                            new Promise((resolve, reject) => {
                                // get StrOccMonthReports data
                                StroccmonthreportSchema.findOne({ [StroccmonthreportSchemaFields.ID]: occWeekId }, (err, occreport_result) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    if (occreport_result) {
                                        occreport = occreport_result;
                                    }
                                    resolve();
                                });
                            }),
                            new Promise((resolve, reject) => {
                                // get StrAdrMonthReports data
                                StradrmonthreportSchema.findOne({ [StradrmonthreportSchemaFields.ID]: adrWeekId }, (err, adrreport_result) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    if (adrreport_result) {
                                        adrreport = adrreport_result;
                                    }
                                    resolve();
                                });
                            }),
                            new Promise((resolve, reject) => {
                                // get StrRevParMonthReports data
                                StrrevparmonthreportSchema.findOne({ [StrrevparmonthreportSchemaFields.ID]: revparWeekId }, (err, revparreport_result) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    if (revparreport_result) {
                                        revparreport = revparreport_result;
                                    }
                                    resolve();
                                });
                            })
                        ]).then(resp => {

                            objStarreportchartdatamodel.OccChgIndex = totalDays == 1 ? result2[0].OccChgIndex : ((occreport) ? occreport.OccIndexChgRun28 : 0);
                            objStarreportchartdatamodel.OccChgMyProperty = totalDays == 1 ? result2[0].OccChgMyProperty : ((occreport) ? occreport.OccChgMyPropRun28 : 0);
                            objStarreportchartdatamodel.OccChgRank = 'NA';
                            objStarreportchartdatamodel.OccIndex = totalDays == 1 ? result2[0].OccIndex : ((occreport) ? occreport.OccIndexRun28 : 0);
                            objStarreportchartdatamodel.OccMyProperty = totalDays == 1 ? result2[0].OccMyProperty : ((occreport) ? occreport.OccMyPropRun28 : 0);
                            objStarreportchartdatamodel.OccRank = 'NA';

                            objStarreportchartdatamodel.AdrChgIndex = totalDays == 1 ? result2[0].AdrChgIndex : ((adrreport) ? adrreport.AdrIndexChgRun28 : 0);
                            objStarreportchartdatamodel.AdrChgMyProperty = totalDays == 1 ? result2[0].AdrChgMyProperty : ((adrreport) ? adrreport.AdrChgMyPropRun28 : 0);
                            objStarreportchartdatamodel.AdrChgRank = 'NA';
                            objStarreportchartdatamodel.AdrIndex = totalDays == 1 ? result2[0].AdrIndex : ((adrreport) ? adrreport.AdrIndexRun28 : 0);
                            objStarreportchartdatamodel.AdrMyProperty = totalDays == 1 ? result2[0].AdrMyProperty : ((adrreport) ? adrreport.AdrMyPropRun28 : 0);
                            objStarreportchartdatamodel.AdrRank = 'NA';

                            objStarreportchartdatamodel.RevParChgIndex = totalDays == 1 ? result2[0].RevParChgIndex : ((revparreport) ? revparreport.RevParIndexChgRun28 : 0);
                            objStarreportchartdatamodel.RevParChgMyProperty = totalDays == 1 ? result2[0].RevParChgMyProperty : ((revparreport) ? revparreport.RevParChgMyPropRun28 : 0);
                            objStarreportchartdatamodel.RevParChgRank = 'NA';
                            objStarreportchartdatamodel.RevParIndex = totalDays == 1 ? result2[0].RevParIndex : ((revparreport) ? revparreport.RevParIndexRun28 : 0);
                            objStarreportchartdatamodel.RevParMyProperty = totalDays == 1 ? result2[0].RevParMyProperty : ((revparreport) ? revparreport.RevParMyPropRun28 : 0);
                            objStarreportchartdatamodel.RevParRank = 'NA';

                            objStarreportchartdatamodel.Date = Utils.getFormattedDate(currentdate, 'DD-MMM-YY');
                            objStarreportchartdatamodel.DateForChart = Utils.getFormattedDate(currentdate, 'DD-MMM-YY');
                            objStarreportchartdatamodel.DateLY = Utils.getFormattedDate(start, 'DD-MMM-YY');
                            objStarreportchartdatamodel.DateForChartLY = start;
                            objStarreportchartdatamodel.HotelId = hotelid;
                            objStarreportchartdatamodel.WeekNumber = Utils.getWeekNumber(start);
                            return cb(null, objStarreportchartdatamodel);


                        }, err => {
                            return cb(err, null);
                        })
                        //#endregion

                    }
                });
                ////#endregion
            }
            else {

                //get data from StrOccWeekReports, StrAdrWeekReports, StrRevParWeekReports
                let occWeekId = 0;
                let adrWeekId = 0;
                let revparWeekId = 0;
                occWeekId = result[0].OccId;
                adrWeekId = result[0].AdrId;
                revparWeekId = result[0].RevParId;
                let occreport = null;
                let adrreport = null;
                let revparreport = null;


                return Promise.all([
                    new Promise((resolve, reject) => {
                        // get StrOccWeekReports data
                        StroccweekreportSchema.findOne({ [StroccweekreportSchemaFields.ID]: occWeekId }, (err, occreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (occreport_result) {
                                occreport = occreport_result;
                            }
                            resolve();
                        });
                    }),
                    new Promise((resolve, reject) => {
                        // get StrAdrWeekReports data
                        StradrweekreportSchema.findOne({ [StradrweekreportSchemaFields.ID]: adrWeekId }, (err, adrreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (adrreport_result) {
                                adrreport = adrreport_result;
                            }
                            resolve();
                        });
                    }),
                    new Promise((resolve, reject) => {
                        // get StrRevParWeekReports data
                        StrrevparweekreportSchema.findOne({ [StrrevparweekreportSchemaFields.ID]: revparWeekId }, (err, revparreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (revparreport_result) {
                                revparreport = revparreport_result;
                            }
                            resolve();
                        });
                    })
                ]).then(resp => {

                    objStarreportchartdatamodel.OccChgIndex = totalDays == 1 ? result[0].OccChgIndex : ((occreport) ? occreport.OccIndexChgRun28 : 0);
                    objStarreportchartdatamodel.OccChgMyProperty = totalDays == 1 ? result[0].OccChgMyProperty : ((occreport) ? occreport.OccChgMyPropRun28 : 0);
                    objStarreportchartdatamodel.OccChgRank = totalDays == 1 ? result[0].OccChgRank : ((occreport) ? occreport.OccRankChgRun28 : 'NA');
                    objStarreportchartdatamodel.OccIndex = totalDays == 1 ? result[0].OccIndex : ((occreport) ? occreport.OccIndexRun28 : 0);
                    objStarreportchartdatamodel.OccMyProperty = totalDays == 1 ? result[0].OccMyProperty : ((occreport) ? occreport.OccMyPropRun28 : 0);
                    objStarreportchartdatamodel.OccRank = totalDays == 1 ? result[0].OccRank : ((occreport) ? occreport.OccRankRun28 : 'NA');

                    objStarreportchartdatamodel.AdrChgIndex = totalDays == 1 ? result[0].AdrChgIndex : ((adrreport) ? adrreport.AdrIndexChgRun28 : 0);
                    objStarreportchartdatamodel.AdrChgMyProperty = totalDays == 1 ? result[0].AdrChgMyProperty : ((adrreport) ? adrreport.AdrChgMyPropRun28 : 0);
                    objStarreportchartdatamodel.AdrChgRank = totalDays == 1 ? result[0].AdrchgRank : ((adrreport) ? adrreport.AdrRankChgRun28 : 'NA');
                    objStarreportchartdatamodel.AdrIndex = totalDays == 1 ? result[0].AdrIndex : ((adrreport) ? adrreport.AdrIndexRun28 : 0);
                    objStarreportchartdatamodel.AdrMyProperty = totalDays == 1 ? result[0].AdrMyProperty : ((adrreport) ? adrreport.AdrMyPropRun28 : 0);
                    objStarreportchartdatamodel.AdrRank = totalDays == 1 ? result[0].AdrRank : ((adrreport) ? adrreport.AdrRankRun28 : 'NA');

                    objStarreportchartdatamodel.RevParChgIndex = totalDays == 1 ? result[0].RevParChgIndex : ((revparreport) ? revparreport.RevParIndexChgRun28 : 0);
                    objStarreportchartdatamodel.RevParChgMyProperty = totalDays == 1 ? result[0].RevParChgMyProperty : ((revparreport) ? revparreport.RevParChgMyPropRun28 : 0);
                    objStarreportchartdatamodel.RevParChgRank = totalDays == 1 ? result[0].RevParChgRank : ((revparreport) ? revparreport.RevParRankChgRun28 : 'NA');
                    objStarreportchartdatamodel.RevParIndex = totalDays == 1 ? result[0].RevParIndex : ((revparreport) ? revparreport.RevParIndexRun28 : 0);
                    objStarreportchartdatamodel.RevParMyProperty = totalDays == 1 ? result[0].RevParMyProperty : ((revparreport) ? revparreport.RevParMyPropRun28 : 0);
                    objStarreportchartdatamodel.RevParRank = totalDays == 1 ? result[0].RevParRank : ((revparreport) ? revparreport.RevParRankRun28 : 'NA');

                    objStarreportchartdatamodel.Date = Utils.getFormattedDate(currentdate, 'DD-MMM-YY');
                    objStarreportchartdatamodel.DateForChart = Utils.getFormattedDate(currentdate, 'DD-MMM-YY');
                    objStarreportchartdatamodel.DateLY = Utils.getFormattedDate(start, 'DD-MMM-YY');
                    objStarreportchartdatamodel.DateForChartLY = start;
                    objStarreportchartdatamodel.HotelId = hotelid;
                    objStarreportchartdatamodel.WeekNumber = Utils.getWeekNumber(start);
                    return cb(null, objStarreportchartdatamodel);

                }, err => {
                    return cb(err, null);
                })
            }
        });


    }
    static getMonthWiseDataForMonthView(hotelid, startdate, enddate, cb) {

        log.debug('Call getMonthWiseDataForMonthView, hotelid:' + hotelid + " startdate:" + startdate + " enddate:" + enddate);

        let starreportAggregate = StarmonthreportSchema.aggregate();

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        var currMonthName = Utils.getFormattedDate(start, 'MMM');
        var currYear = Utils.getFormattedDate(start, 'YYYY');

        starreportAggregate.match({
            [StarmonthreportSchemaFields.HotelID]: hotelid,
            [StarmonthreportSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })


        starreportAggregate.group({
            [StarmonthreportSchemaFields._id]: null,
            [StarmonthreportSchemaFields.OccChgMyProperty]: { $avg: `$${StarmonthreportSchemaFields.OccChgMyProperty}` },
            [StarmonthreportSchemaFields.OccMyProperty]: { $avg: `$${StarmonthreportSchemaFields.OccMyProperty}` },
            [StarmonthreportSchemaFields.OccChgIndex]: { $avg: `$${StarmonthreportSchemaFields.OccChgIndex}` },
            [StarmonthreportSchemaFields.OccIndex]: { $avg: `$${StarmonthreportSchemaFields.OccIndex}` },
            [StarmonthreportSchemaFields.AdrChgMyProperty]: { $avg: `$${StarmonthreportSchemaFields.AdrChgMyProperty}` },
            [StarmonthreportSchemaFields.AdrMyProperty]: { $avg: `$${StarmonthreportSchemaFields.AdrMyProperty}` },
            [StarmonthreportSchemaFields.AdrChgIndex]: { $avg: `$${StarmonthreportSchemaFields.AdrChgIndex}` },
            [StarmonthreportSchemaFields.AdrIndex]: { $avg: `$${StarmonthreportSchemaFields.AdrIndex}` },
            [StarmonthreportSchemaFields.RevParChgMyProperty]: { $avg: `$${StarmonthreportSchemaFields.RevParChgMyProperty}` },
            [StarmonthreportSchemaFields.RevParMyProperty]: { $avg: `$${StarmonthreportSchemaFields.RevParMyProperty}` },
            [StarmonthreportSchemaFields.RevParChgIndex]: { $avg: `$${StarmonthreportSchemaFields.RevParChgIndex}` },
            [StarmonthreportSchemaFields.RevParIndex]: { $avg: `$${StarmonthreportSchemaFields.RevParIndex}` }
        })



        return starreportAggregate.exec((err, result) => {
            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("getMonthWiseDataForMonthView result not found");
                result = [];
                result.MonthName = currMonthName;
                result.Year = currYear;
                return cb(null, result);
            }
            else {
                result[0].MonthName = currMonthName;
                result[0].Year = currYear;
                return cb(null, result[0]);
            }
        });


    }

    static getMonthWiseData(hotelid, startdate, enddate, cb) {

        log.debug('Call getMonthWiseData, hotelid:' + hotelid + " startdate:" + startdate + " enddate:" + enddate);

        let starreportAggregate = StarreportSchema.aggregate();

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        var currMonthName = Utils.getFormattedDate(start, 'MMM');
        var currYear = Utils.getFormattedDate(start, 'YYYY');

        starreportAggregate.match({
            [StarreportSchemaFields.HotelID]: hotelid,
            [StarreportSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })


        starreportAggregate.group({
            [StarreportSchemaFields._id]: null,
            [StarreportSchemaFields.OccChgMyProperty]: { $avg: `$${StarreportSchemaFields.OccChgMyProperty}` },
            [StarreportSchemaFields.OccMyProperty]: { $avg: `$${StarreportSchemaFields.OccMyProperty}` },
            [StarreportSchemaFields.OccChgIndex]: { $avg: `$${StarreportSchemaFields.OccChgIndex}` },
            [StarreportSchemaFields.OccIndex]: { $avg: `$${StarreportSchemaFields.OccIndex}` },
            [StarreportSchemaFields.AdrChgMyProperty]: { $avg: `$${StarreportSchemaFields.AdrChgMyProperty}` },
            [StarreportSchemaFields.AdrMyProperty]: { $avg: `$${StarreportSchemaFields.AdrMyProperty}` },
            [StarreportSchemaFields.AdrChgIndex]: { $avg: `$${StarreportSchemaFields.AdrChgIndex}` },
            [StarreportSchemaFields.AdrIndex]: { $avg: `$${StarreportSchemaFields.AdrIndex}` },
            [StarreportSchemaFields.RevParChgMyProperty]: { $avg: `$${StarreportSchemaFields.RevParChgMyProperty}` },
            [StarreportSchemaFields.RevParMyProperty]: { $avg: `$${StarreportSchemaFields.RevParMyProperty}` },
            [StarreportSchemaFields.RevParChgIndex]: { $avg: `$${StarreportSchemaFields.RevParChgIndex}` },
            [StarreportSchemaFields.RevParIndex]: { $avg: `$${StarreportSchemaFields.RevParIndex}` },
            [StarreportSchemaFields.OccRank]: {
                $avg: { $toInt: { $substr: [{ $ifNull: [{ $cond: [{ $eq: [`$${StarreportSchemaFields.OccRank}`, ""] }, null, `$${StarreportSchemaFields.OccRank}`] }, "0"] }, 0, 1] } }
            },
            [StarreportSchemaFields.AdrRank]: {
                $avg: { $toInt: { $substr: [{ $ifNull: [{ $cond: [{ $eq: [`$${StarreportSchemaFields.AdrRank}`, ""] }, null, `$${StarreportSchemaFields.AdrRank}`] }, "0"] }, 0, 1] } }
            },
            [StarreportSchemaFields.RevParRank]: {
                $avg: { $toInt: { $substr: [{ $ifNull: [{ $cond: [{ $eq: [`$${StarreportSchemaFields.RevParRank}`, ""] }, null, `$${StarreportSchemaFields.RevParRank}`] }, "0"] }, 0, 1] } }
            }
        })



        return starreportAggregate.exec((err, result) => {
            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("getMonthWiseData result not found");
                result = [];
                result.MonthName = currMonthName;
                result.Year = currYear;
                return cb(null, result);
            }
            else {
                result[0].MonthName = currMonthName;
                result[0].Year = currYear;
                return cb(null, result[0]);
            }
        });


    }

    static getBudgetData(hotelid, start, end, cb) {

        return new Promise((resolve, reject) => {

            let MPIBudget = 0;
            let ARIBudget = 0;
            let RGIBudget = 0;

            var counter = Utils.dateDiffInDays(start, end);

            // If you want an inclusive end date (fully-closed interval)
            for (var m = moment(start); m.diff(end, 'days') <= 0; m.add(1, 'days')) {

                var dt = m.toDate();

                HotelbudgetSchema.findOne({
                    [HotelbudgetSchemaFields.HotelID]: hotelid,
                    [HotelbudgetSchemaFields.DateFrom]: {
                        $gte: dt
                    },
                    [HotelbudgetSchemaFields.DateTo]: {
                        $lte: dt
                    }
                }).exec(function (err, hotelbudget_result) {
                    if (err) {
                        log.error(err);
                    }
                    if (hotelbudget_result) {

                        let totalDays = Utils.dateDiffInDays(hotelbudget_result.DateFrom, hotelbudget_result.DateTo);
                        if (hotelbudget_result.StrMPIBgt) {
                            MPIBudget += hotelbudget_result.StrMPIBgt / totalDays;
                        }
                        if (hotelbudget_result.StrARIBgt) {
                            ARIBudget += hotelbudget_result.StrARIBgt / totalDays;
                        }
                        if (hotelbudget_result.StrRGIBgt) {
                            RGIBudget += hotelbudget_result.StrRGIBgt / totalDays;
                        }
                    }
                    counter = counter - 1;
                    if (counter == 0) {

                        var objstarreportbudgetdatamodel = new Starreportbudgetdatamodel();
                        objstarreportbudgetdatamodel.MPIBudget = MPIBudget;
                        objstarreportbudgetdatamodel.ARIBudget = ARIBudget;
                        objstarreportbudgetdatamodel.RGIBudget = RGIBudget;
                        resolve(objstarreportbudgetdatamodel);
                    }
                });



            }
        });


    }
    static getSTRBudgetData(hotelid, currentdate, startdate, enddate, cb) {

        log.debug('Call getSTRBudgetData, hotelid:' + hotelid + " startdate:" + startdate + " enddate:" + enddate);


        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate());

        StarreportHelper.getBudgetData(hotelid, start, end, cb).then(starreportbudgetdatamodel_result => {

            let objStarreportchartdatamodel = new Starreportchartdatamodel();
            objStarreportchartdatamodel.Date = Utils.getFormattedDate(currentdate, 'DD-MMM-YY');
            objStarreportchartdatamodel.DateForChart = Utils.getFormattedDate(currentdate, 'DD-MMM-YY');
            objStarreportchartdatamodel.DateLY = Utils.getFormattedDate(start, 'DD-MMM-YY');
            objStarreportchartdatamodel.DateForChartLY = start;
            objStarreportchartdatamodel.HotelId = hotelid;
            if (starreportbudgetdatamodel_result) {
                objStarreportchartdatamodel.MPIBudget = starreportbudgetdatamodel_result.MPIBudget;
                objStarreportchartdatamodel.ARIBudget = starreportbudgetdatamodel_result.ARIBudget;
                objStarreportchartdatamodel.RGIBudget = starreportbudgetdatamodel_result.RGIBudget;
            }

            return cb(null, objStarreportchartdatamodel);

        });

    }

    static getSTRPortfolioData(hotelid, startdate, enddate, frommonthtable, cb) {

        log.debug('Call getSTRPortfolioData, hotelid:' + hotelid + " startdate:" + startdate + " enddate:" + enddate);

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        if (frommonthtable) {
            let starreportAggregate = StarmonthreportSchema.aggregate();

            starreportAggregate.match({
                [StarmonthreportSchemaFields.HotelID]: hotelid,
                [StarmonthreportSchemaFields.Date]: {
                    $gte: start,
                    $lt: end
                }
            })


            starreportAggregate.group({
                [StarmonthreportSchemaFields._id]: `$${StarmonthreportSchemaFields.HotelID}`,
                [StarmonthreportSchemaFields.OccMyProperty]: { $avg: `$${StarmonthreportSchemaFields.OccMyProperty}` },
                [StarmonthreportSchemaFields.OccCompSet]: { $avg: `$${StarmonthreportSchemaFields.OccCompSet}` },
                [StarmonthreportSchemaFields.OccChgMyProperty]: { $avg: `$${StarmonthreportSchemaFields.OccChgMyProperty}` },
                [StarmonthreportSchemaFields.OccChgCompSet]: { $avg: `$${StarmonthreportSchemaFields.OccChgCompSet}` },
                [StarmonthreportSchemaFields.AdrMyProperty]: { $avg: `$${StarmonthreportSchemaFields.AdrMyProperty}` },
                [StarmonthreportSchemaFields.AdrCompSet]: { $avg: `$${StarmonthreportSchemaFields.AdrCompSet}` },
                [StarmonthreportSchemaFields.AdrChgMyProperty]: { $avg: `$${StarmonthreportSchemaFields.AdrChgMyProperty}` },
                [StarmonthreportSchemaFields.AdrChgCompSet]: { $avg: `$${StarmonthreportSchemaFields.AdrChgCompSet}` },
                [StarmonthreportSchemaFields.RevParMyProperty]: { $avg: `$${StarmonthreportSchemaFields.RevParMyProperty}` },
                [StarmonthreportSchemaFields.RevParCompSet]: { $avg: `$${StarmonthreportSchemaFields.RevParCompSet}` },
                [StarmonthreportSchemaFields.RevParChgMyProperty]: { $avg: `$${StarmonthreportSchemaFields.RevParChgMyProperty}` },
                [StarmonthreportSchemaFields.RevParChgCompSet]: { $avg: `$${StarmonthreportSchemaFields.RevParChgCompSet}` }

            })


            return starreportAggregate.exec((err, result) => {
                if (err) {
                    log.error(err);
                }
                if (!result || result.length == 0) {
                    log.debug("getSTRPortfolioData result not found");
                    return cb(null, null);
                }
                return cb(null, result[0]);
            });
        }
        else {
            let starreportAggregate = StarreportSchema.aggregate();

            starreportAggregate.match({
                [StarreportSchemaFields.HotelID]: hotelid,
                [StarreportSchemaFields.Date]: {
                    $gte: start,
                    $lt: end
                }
            })


            starreportAggregate.group({
                [StarreportSchemaFields._id]: `$${StarreportSchemaFields.HotelID}`,
                [StarreportSchemaFields.OccMyProperty]: { $avg: `$${StarreportSchemaFields.OccMyProperty}` },
                [StarreportSchemaFields.OccCompSet]: { $avg: `$${StarreportSchemaFields.OccCompSet}` },
                [StarreportSchemaFields.OccChgMyProperty]: { $avg: `$${StarreportSchemaFields.OccChgMyProperty}` },
                [StarreportSchemaFields.OccChgCompSet]: { $avg: `$${StarreportSchemaFields.OccChgCompSet}` },
                [StarreportSchemaFields.AdrMyProperty]: { $avg: `$${StarreportSchemaFields.AdrMyProperty}` },
                [StarreportSchemaFields.AdrCompSet]: { $avg: `$${StarreportSchemaFields.AdrCompSet}` },
                [StarreportSchemaFields.AdrChgMyProperty]: { $avg: `$${StarreportSchemaFields.AdrChgMyProperty}` },
                [StarreportSchemaFields.AdrChgCompSet]: { $avg: `$${StarreportSchemaFields.AdrChgCompSet}` },
                [StarreportSchemaFields.RevParMyProperty]: { $avg: `$${StarreportSchemaFields.RevParMyProperty}` },
                [StarreportSchemaFields.RevParCompSet]: { $avg: `$${StarreportSchemaFields.RevParCompSet}` },
                [StarreportSchemaFields.RevParChgMyProperty]: { $avg: `$${StarreportSchemaFields.RevParChgMyProperty}` },
                [StarreportSchemaFields.RevParChgCompSet]: { $avg: `$${StarreportSchemaFields.RevParChgCompSet}` }

            })


            return starreportAggregate.exec((err, result) => {
                if (err) {
                    log.error(err);
                }
                if (!result || result.length == 0) {
                    log.debug("getSTRPortfolioData result not found");
                    return cb(null, null);
                }
                return cb(null, result[0]);
            });
        }




    }


    static GetLatestPortfolioData(lsthotelids, startdate, enddate, frommonthtable, cb) {

        log.debug('Call GetLatestPortfolioData startdate:' + startdate + " enddate:" + enddate);

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        if (frommonthtable) {
            let starreportAggregate = StarmonthreportSchema.aggregate();

            starreportAggregate.match({
                [StarmonthreportSchemaFields.HotelID]: {
                    $in: lsthotelids
                },
                [StarmonthreportSchemaFields.Date]: {
                    $gte: start,
                    $lt: end
                }
            })


            starreportAggregate.group({
                [StarmonthreportSchemaFields._id]: `$${StarmonthreportSchemaFields.HotelID}`,
                [StarmonthreportSchemaFields.OccIndex]: { $avg: `$${StarmonthreportSchemaFields.OccIndex}` },
                [StarmonthreportSchemaFields.AdrIndex]: { $avg: `$${StarmonthreportSchemaFields.AdrIndex}` },
                [StarmonthreportSchemaFields.RevParIndex]: { $avg: `$${StarmonthreportSchemaFields.RevParIndex}` }
            })


            return starreportAggregate.exec((err, result) => {
                if (err) {
                    log.error(err);
                }
                if (!result || result.length == 0) {
                    log.debug("GetLatestPortfolioData result not found");
                    return cb(null, null);
                }
                return cb(null, result);
            });
        }
        else {
            let starreportAggregate = StarreportSchema.aggregate();

            starreportAggregate.match({
                [StarreportSchemaFields.HotelID]: {
                    $in: lsthotelids
                },
                [StarreportSchemaFields.Date]: {
                    $gte: start,
                    $lt: end
                }
            })


            starreportAggregate.group({
                [StarreportSchemaFields._id]: `$${StarreportSchemaFields.HotelID}`,
                [StarreportSchemaFields.OccIndex]: { $avg: `$${StarreportSchemaFields.OccIndex}` },
                [StarreportSchemaFields.AdrIndex]: { $avg: `$${StarreportSchemaFields.AdrIndex}` },
                [StarreportSchemaFields.RevParIndex]: { $avg: `$${StarreportSchemaFields.RevParIndex}` },
                [StarreportSchemaFields.OccRank]: { $max: `$${StarreportSchemaFields.OccRank}` },
                [StarreportSchemaFields.AdrRank]: { $max: `$${StarreportSchemaFields.AdrRank}` },
                [StarreportSchemaFields.RevParRank]: { $max: `$${StarreportSchemaFields.RevParRank}` }
            })


            return starreportAggregate.exec((err, result) => {
                if (err) {
                    log.error(err);
                }
                if (!result || result.length == 0) {
                    log.debug("GetLatestPortfolioData result not found");
                    return cb(null, null);
                }
                return cb(null, result);
            });
        }




    }



}
module.exports = StarreportHelper;

