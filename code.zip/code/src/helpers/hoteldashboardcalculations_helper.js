const { Hoteldashboardcalculations: HoteldashboardcalculationsSchema, SchemaField: HoteldashboardcalculationsSchemaFields } = require('../models/hoteldashboardcalculations');

var log = require('log4js').getLogger("hoteldashboardcalculations_helper");
const _ = require('lodash');
class HoteldashboardcalculationsHelper {

    static GetData(hotelid, reportdate, cb) {

        log.debug('Call GetData, hotelid:' + hotelid + "reportdate:" + reportdate);

        let start = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate());
        let end = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate() + 1);

        // let startutc = new Date(start.toISOString());
        // let endutc = new Date(end.toISOString());
        // console.log("start" + start);
        // console.log("end" + end);
        // console.log("startutc" + startutc);
        // console.log("endutc" + endutc);

        return HoteldashboardcalculationsSchema.findOne({
            [HoteldashboardcalculationsSchemaFields.HotelID]: hotelid,
            [HoteldashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetData result not found");
            }
            return cb(null, result);
        });
    }


    static GetLatestMTDData(hotelid, reportdate, startdate_mtd, cb) {

        log.debug('Call GetLatestMTDData, hotelid:' + hotelid + "reportdate:" + reportdate + "startdate_mtd:" + startdate_mtd);

        let start = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate());
        let end = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate() + 1);

        return HoteldashboardcalculationsSchema.findOne({
            [HoteldashboardcalculationsSchemaFields.HotelID]: hotelid,
            [HoteldashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {

                log.debug("GetLatestMTDData result not found, checking for latest MTD data");

                let start_mtd = new Date(startdate_mtd.getFullYear(), startdate_mtd.getMonth(), startdate_mtd.getDate());

                //check for latest MTD data
                return HoteldashboardcalculationsSchema.find({
                    [HoteldashboardcalculationsSchemaFields.HotelID]: hotelid,
                    [HoteldashboardcalculationsSchemaFields.Date]: {
                        $gte: start_mtd,
                        $lt: end
                    }
                }).sort({ [HoteldashboardcalculationsSchemaFields.Date]: -1 }).limit(1).exec(function (err, result2) {
                    if (err) {
                        log.error(err);
                    }
                    if (!result2) {
                        //check for latest MTD data
                        log.debug("GetLatestMTDData result not found");
                        return cb("data not found", null);

                    }
                    return cb(null, result2[0]);
                });

            }
            else {
                return cb(null, result);
            }
        });
    }


    static GetLatestPortfolioData(lsthotelids, reportdate, cb) {

        log.debug("Call GetLatestPortfolioData, reportdate:" + reportdate);

        let start = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate());
        let end = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate() + 1);

        return HoteldashboardcalculationsSchema.find({

            [HoteldashboardcalculationsSchemaFields.HotelID]: {
                $in: lsthotelids
            },
            [HoteldashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetLatestPortfolioData result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }


    static GetLatestPortfolioDataByRange(lsthotelids, reportdate, enddate, cb) {

        log.debug("Call GetLatestPortfolioDataByRange, reportdate:" + reportdate);

        let start = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        return HoteldashboardcalculationsSchema.find({

            [HoteldashboardcalculationsSchemaFields.HotelID]: {
                $in: lsthotelids
            },
            [HoteldashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetLatestPortfolioDataByRange result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }


    static GetDataBetweenDate(hotelid, startdate, enddate, cb) {

        log.debug('Call GetDataBetweenDate, hotelid:' + hotelid + "startdate:" + startdate + "enddate:" + enddate);

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        return HoteldashboardcalculationsSchema.find({
            [HoteldashboardcalculationsSchemaFields.HotelID]: hotelid,
            [HoteldashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {

                log.debug("GetDataBetweenDate result not found");
                return cb("data not found", null);

            }
            else {
                return cb(null, result);
            }
        });
    }

    static GetDataBetweenDateWithHotelIds(hotelids, startdate, enddate, cb) {

        log.debug('Call GetDataBetweenDate,' + startdate + "enddate:" + enddate);

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        return HoteldashboardcalculationsSchema.find({
            [HoteldashboardcalculationsSchemaFields.HotelID]: { $in: hotelids },
            [HoteldashboardcalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {

                log.debug("GetDataBetweenDate result not found");
                return cb("data not found", null);

            }
            else {
                return cb(null, result);
            }
        });
    }
    static GetPayrollData(hotelId, startdate, enddate, cb) {

        HoteldashboardcalculationsSchema.find({
            [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId,
            [HoteldashboardcalculationsSchemaFields.Date]: { $gte: startdate, $lte: enddate }
        }
        ).exec((err, result) => {

            cb(null, result);
        })
    }
    static GetPayrollHouseKeepingData(hotelId, date, cb) {
        HoteldashboardcalculationsSchema.find(
            {
                [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId,
                [HoteldashboardcalculationsSchemaFields.Date]: { $gte: date, $lte: date }
            },
            [HoteldashboardcalculationsSchemaFields.NoOfRoomSold]).exec((err, result) => {
                cb(null, result);
            })
    }

    static GetPayrollHouseKeepingDataSweekDate(hotelId, sweekdate, date, cb) {
        HoteldashboardcalculationsSchema.find(
            {
                [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId,
                [HoteldashboardcalculationsSchemaFields.Date]: { $gte: sweekdate, $lte: date }
            }
        ).exec((err, result) => {

            cb(null, result);
        })
    }

    static GetHotelofRoom1(hotelId, date, cb) {

        HoteldashboardcalculationsSchema.find(
            {
                [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId,
                [HoteldashboardcalculationsSchemaFields.Date]: { $eq: date }
            }
            , [HoteldashboardcalculationsSchemaFields.NoOfRoomSold]).exec((err, result) => {

                cb(null, result);
            })
    }
    static NoOfRoomSoldMTD(hotelId, date, cb) {
        HoteldashboardcalculationsSchema.find({
            $and: [
                { [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId },
                { [HoteldashboardcalculationsSchemaFields.Date]: { $eq: date } }
            ]
        }, [HoteldashboardcalculationsSchemaFields.NoOfRoomSoldMTD]).exec((err, result) => {

            cb(null, result);
        })
    }
    static NoOfRoomSoldYTD(hotelId, date, cb) {
        HoteldashboardcalculationsSchema.find({
            $and: [
                { [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId },
                { [HoteldashboardcalculationsSchemaFields.Date]: { $eq: date } }
            ]
        }, [HoteldashboardcalculationsSchemaFields.NoOfRoomSoldYTD]).exec((err, result) => {
            cb(null, result);

        })
    }
    static ActVsBudVsLsYrChartData(date, cb) {
        HoteldashboardcalculationsSchema.aggregate(
            [{ $match: { [HoteldashboardcalculationsSchemaFields.Date]: new Date(date) } }]
        ).exec((err, result) => {
            cb(null, result);
        })
    }

    static ActVsBudVsLsYrChartDataForOccupancy(date, cb) {
        HoteldashboardcalculationsSchema.find({
            $and: [
                { [HoteldashboardcalculationsSchemaFields.Date]: { $gte: new Date(date) } },
                { [HoteldashboardcalculationsSchemaFields.Date]: { $lte: new Date(date) } }
            ]
        }).exec((err, result) => {
            cb(null, result);
        })

    }

    static GetMissingDatesRevenue(hotelId, startdate, enddate, cd) {
        let missingdates = [];
        let daysIncrement = 1;
        startdate = new Date(startdate);
        enddate = new Date(enddate);
        HoteldashboardcalculationsSchema.find({
            [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId,
            [HoteldashboardcalculationsSchemaFields.Date]: { $gte: startdate, $lte: enddate }
        }).exec((err, result) => {

            for (let dt = startdate; dt <= enddate; dt = new Date(startdate.setDate(startdate.getDate() + daysIncrement))) {
                let data = _.find(result, ['Date', dt]);
                (data == null ? missingdates.push(dt) : '');
            }

            cd(null, missingdates)
        })
    }

}
module.exports = HoteldashboardcalculationsHelper;

