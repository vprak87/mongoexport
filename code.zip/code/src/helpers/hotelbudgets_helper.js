const { Hotelbudget: HotelbudgetSchema, SchemaField: HotelbudgetSchemaFields } = require('../models/hotelbudget');

var log = require('log4js').getLogger("hotelbudget_helper");

class HotelbudgetHelper {
    static GetPayrollActualvsPlanTableData(hotelId, date,  cb) {
        HotelbudgetSchema.find(
            {[HotelbudgetSchemaFields.HotelID]: hotelId,
             [HotelbudgetSchemaFields.DateFrom]: { $lte: date },
             [HotelbudgetSchemaFields.DateTo]: { $gte: date }},
             [HotelbudgetSchemaFields.TotalNumberofBudgetedRoomsSold]).exec((err,result)=>{
                cb(null,result);
        })
    }
    
    static GetPayrollActualvsPlanTableDataSweekDate(hotelId, sweekdate,date,  cb) {
        HotelbudgetSchema.find(
            {[HotelbudgetSchemaFields.HotelID]: hotelId,
             [HotelbudgetSchemaFields.DateFrom]: { $lte: date },
             [HotelbudgetSchemaFields.DateTo]: { $gte: sweekdate }}
            ,[HotelbudgetSchemaFields.TotalNumberofBudgetedRoomsSold]).exec((err,result)=>{
                cb(null,result);
        })
    }
    static GetData(hotelid, date, cb) {

        log.debug('Call GetDataBetweenDate, hotelid:' + hotelid + "startdate:" + date + "enddate:" + date);

        let start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        let end = new Date(date.getFullYear(), date.getMonth(), date.getDate()+1);
        
        return HotelbudgetSchema.find(
            {
            [HotelbudgetSchemaFields.HotelID]: hotelid,
            [HotelbudgetSchemaFields.DateFrom]: { $gte: start },
            [HotelbudgetSchemaFields.DateTo]: { $lte: end }
            }).exec(function (err, result) {
            
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetDataBetweenDate result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }     
    static GetDataBetweenDate(hotelid, startdate, enddate, cb) {

        log.debug('Call GetDataBetweenDate, hotelid:' + hotelid + "startdate:" + startdate + "enddate:" + enddate);

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate()+1);
        
        return HotelbudgetSchema.find(
            {
            [HotelbudgetSchemaFields.HotelID]: hotelid,
            [HotelbudgetSchemaFields.DateFrom]: { $gte: start },
            [HotelbudgetSchemaFields.DateTo]: { $lte: end }
            }).exec(function (err, result) {
            
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetDataBetweenDate result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }    
}

module.exports = HotelbudgetHelper;