const Constants = require('../common/constants');
const Utils = require('../common/utils');
const UserHelper = require('./user_helper');
const dbtable = require('../schema/db_table');
const { Systempermision: SystempermisionSchema, SchemaField: SystempermisionSchemaFields } = require('../models/systempermision');
const { Userbasedpermission: UserbasedpermissionSchema, SchemaField: UserbasedpermissionSchemaFields } = require('../models/userbasedpermission');

var log = require('log4js').getLogger("PermissionHelper");

class PermissionHelper {

    static  GetPageAccessByUserId(userid,cb) {

        let userbasedpermissionAggregate = UserbasedpermissionSchema.aggregate();

        userbasedpermissionAggregate.match({
            [UserbasedpermissionSchemaFields.UserId]: userid
        })

        //user org detail
        userbasedpermissionAggregate.lookup({
            from: dbtable.SYSTEMPERMISION,
            let: { permId: `$${UserbasedpermissionSchemaFields.PermissionId}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$permId", `$${SystempermisionSchemaFields.PermissionId}`] },
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [SystempermisionSchemaFields.ControllerName]: 1,
                        [SystempermisionSchemaFields.Action]: 1
                    }
                }
            ],
            as: "UserPermission"
        })


        return userbasedpermissionAggregate.exec((err, result) => {
            let lstPermission=[];
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetPageAccessByUserId result not found");
            }
            
            result.forEach((element, index) => {
                if(element.UserPermission.length >0)
                lstPermission.push({ controllername: element.UserPermission[0].ControllerName,action: element.UserPermission[0].Action });
            });
            lstPermission = Utils.sort(lstPermission, "controllername");
            return cb(null, lstPermission);
        });

    }

    static getPageAccessByUserId_GraphQL(userid,cb) {
        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            if (!userconfigdata) {
                cb(null, null);
            }
            else {
                PermissionHelper.GetPageAccessByUserId(userid,cb, (err, result) => {
                    if (err) {
                        cb(err, null);
                    }
                    cb(null, result);
                });
            }
        });
    }

}
module.exports = PermissionHelper;