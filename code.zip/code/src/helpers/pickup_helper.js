const Constants = require('../common/constants');
const Utils = require('../common/utils');
const moment = require('moment');
const _ = require('lodash');

const Pickupdashboarddata = require('../pickup/models/pickupdashboarddata');
const Pickupdata = require('../pickup/models/pickupdata');
const Pickupreportdata = require('../pickup/models/pickupreportdata');
const Summeryreportdata = require('../pickup/models/summeryreportdata');

const { Pickupreport: PickupreportSchema, SchemaField: PickupreportSchemaFields } = require('../models/pickupreport');
const { Hotelbudget: HotelbudgetSchema, SchemaField: HotelbudgetSchemaFields } = require('../models/hotelbudget');
const { Hoteldashboardcalculations: HoteldashboardcalculationsSchema, SchemaField: HoteldashboardcalculationsSchemaFields } = require('../models/hoteldashboardcalculations');

const UserHelper = require('./user_helper');
const HotelsHelper = require('../helpers/hotels_helper');
var log = require('log4js').getLogger("pickup_helper");

class PickupsHelper {

  static getMissingDates(hotelid, startdate, enddate, cd) {
    PickupreportSchema.find({ [PickupreportSchemaFields.HotelID]: hotelid, [PickupreportSchemaFields.ReportedDateTime]: { "$gte": startdate, "$lte": enddate } },
      (err, res) => {

        if (err) {
          log.error(err)
          cd(err, null);

        }
        if (!res) {
          return cb("User pickup data not found ", null);
        }

        cd(null, res)
      });
  }

  static getPickupData(hotelid, today, days, startDate, userconfigdata, cb) {
    if (Utils.isNullOrEmpty(hotelid)) {
      hotelid = "0";
    }

    if (Utils.isNullOrEmpty(days)) {
      days = "7";
    }


    var dttodaydate = new Date(today);
    var dtstartdate = new Date(startDate);
    dtstartdate = Utils.addDays(dtstartdate, 1);

    if (Utils.isNullOrEmpty(today)) {
      today = moment(new Date()).format("MM/DD/YYYY");
    }

    if (Utils.isNullOrEmpty(startDate)) {
      startDate = moment(new Date(startDate)).format("MM/DD/YYYY");
    }
    let lstpickup = [];

    startDate = moment(startDate).format("YYYY-MM-DD");
    today = moment(today).format("YYYY-MM-DD");


    let currentDate = new Date(today);
    let currentDateforPickup = new Date(today);
    currentDateforPickup = new Date(Utils.addDays(currentDateforPickup, 1));

    let startdate = new Date(startDate);
    let enddate = Utils.addDays(currentDate, days);
    enddate = new Date(enddate);





    startdate = startdate.toISOString();
    currentDate = currentDate.toISOString();
    currentDateforPickup = currentDateforPickup.toISOString();
    enddate = enddate.toISOString();

    hotelid = parseInt(hotelid);

    let result = [];
    Promise.all([
      new Promise((resolve, reject) => {
        PickupreportSchema.find({ [PickupreportSchemaFields.HotelID]: hotelid, [PickupreportSchemaFields.ReportedDateTime]: currentDate, [PickupreportSchemaFields.Date]: { "$gte": currentDateforPickup, "$lte": enddate } },
          (err, res) => {
            // console.log(res)
            if (err) {
              log.error(err)
              cb(err, null);
              reject(err);
            }
            if (!res) {
              return cb("User Hotel xref data not found ", null);
            }
            // console.log(res, 'resset');
            result = res;
            resolve()
          });
      })
    ]).then(resp => {

      let pmArr = [];
      for (var m = moment(currentDateforPickup); m.isBefore(enddate); m.add(1, 'days')) {
        // console.log(m.toISOString());
        pmArr.push(
          new Promise((resolve, reject) => {
            PickupsHelper.createLstArray(result, m, currentDate, hotelid, (err, res) => {
              if (err) {
                reject(err);
              }
              lstpickup.push(res);
              resolve();
            })
          })
        )
      }

      Promise.all(pmArr).then(res => {
        // new section 
        if (startdate != '' && startdate != null) {

          // if (currentDate != startdate) {

          let prevDate = moment(startdate).subtract(1, 'days');

          let dtstartdateminus_1 = new Date(Utils.addDays(dtstartdate, -1));

          let roomrevenueList = [];

          Promise.all([
            new Promise((resolve, reject) => {
              PickupsHelper.getHotelDashboardCalculationsv2(dttodaydate, dtstartdateminus_1, hotelid, (err, dashboardData) => {
                if (err) {
                  log.error(err)
                  cb(err, null);
                }
                roomrevenueList = dashboardData;
                resolve();
              });
            })
          ]).then(resp => {
            let pmArr2 = [];
            for (var m = moment(startdate); m.isBefore(currentDateforPickup); m.add(1, 'days')) {
              pmArr2.push(
                new Promise((resolve, reject) => {
                  PickupsHelper.createLstArrayRev(roomrevenueList, m, currentDate, hotelid, (err, res) => {
                    if (err) {
                      reject(err);
                    }
                    lstpickup.push(res);
                    resolve();
                  })
                })
              )
            }

            Promise.all(pmArr2).then(res => {
              // console.log('ended2');

              let pickupDashboardData = lstpickup;
              pickupDashboardData = Utils.sort(pickupDashboardData, "DailyActivityDate");
              let pickupDashboardModel = {};
              let curDate = new Date(today);
              pickupDashboardModel.PickupDataModelList = pickupDashboardData;
              pickupDashboardModel.CurrentDate = Utils.getFormattedDate(curDate, 'DD-MM-YYYY');
              pickupDashboardModel.DailyActivityDateDelta1 = Utils.getFormattedDate(moment(currentDate).subtract(1, 'days'), 'DD-MM-YYYY');
              pickupDashboardModel.DailyActivityDateDelta3 = Utils.getFormattedDate(moment(currentDate).subtract(3, 'days'), 'DD-MM-YYYY');
              pickupDashboardModel.DailyActivityDateDelta7 = Utils.getFormattedDate(moment(currentDate).subtract(7, 'days'), 'DD-MM-YYYY');
              pickupDashboardModel.DailyActivityDateDeltaSDLY = Utils.getFormattedDate(Utils.sameDayLastYear(currentDate), 'DD-MM-YYYY');

              return cb(null, pickupDashboardModel);

            })
          })
          // } else {
          //   // console.log('else part')
          //   let pickupDashboardData = lstpickup;
          //   pickupDashboardData = Utils.sort(pickupDashboardData, "DailyActivityDate");

          //   let pickupDashboardModel = {};
          //   let curDate = new Date(today);
          //   pickupDashboardModel.PickupDataModelList = pickupDashboardData;
          //   pickupDashboardModel.CurrentDate = Utils.getFormattedDate(curDate, 'DD-MM-YYYY');
          //   pickupDashboardModel.DailyActivityDateDelta1 = Utils.getFormattedDate(moment(currentDate).subtract(1, 'days'), 'DD-MM-YYYY');
          //   pickupDashboardModel.DailyActivityDateDelta3 = Utils.getFormattedDate(moment(currentDate).subtract(3, 'days'), 'DD-MM-YYYY');
          //   pickupDashboardModel.DailyActivityDateDelta7 = Utils.getFormattedDate(moment(currentDate).subtract(7, 'days'), 'DD-MM-YYYY');
          //   pickupDashboardModel.DailyActivityDateDeltaSDLY = Utils.getFormattedDate(Utils.sameDayLastYear(currentDate), 'DD-MM-YYYY');

          //   return cb(null, pickupDashboardModel);
          // }
        }
      })
    })
  }

  static createLstArray(resultset, date, currentDate, hotelid, cb) {
    // console.log(resultset, 'arr');

    let sdly = Utils.sameDayLastYear(currentDate);
    var dtcurrentDate = new Date(currentDate);
    var dtDate = new Date(date);
    if (dtDate > dtcurrentDate) {
      var days = Utils.dateDiffInDays(dtcurrentDate, dtDate);
      sdly = new Date(Utils.addDays(sdly, days - 1));
    }
    let pickupItem = new Pickupdata();
    pickupItem.Date = Utils.getFormattedDate(date, 'DD-MM-YYYY')
    pickupItem.DailyActivityDate = Utils.getFormattedDate(date, 'DD-MM-YYYY')
    let occupancy = 0;
    let totalroomssold = 0;
    let totalrevenue = 0;
    let totalroomsAvailable = 0;
    let pickuprpt1Amount = 0;
    let pickuprpt1RoomSold = 0;
    let pickuprpt3Amount = 0;
    let pickuprpt3RoomSold = 0;
    let pickuprpt7Amount = 0;
    let pickuprpt7RoomSold = 0;
    let pickuprptSDLYAmount = 0;
    let pickuprptSDLYRoomSold = 0;
    let transientRoomSold = 0;
    let transientDelta1 = 0;
    let transientDelta3 = 0;
    let transientDelta7 = 0;
    let transientDeltaSDLY = 0;
    let groupRoomSold = 0;
    let groupBlock = 0;

    let data = _.find(resultset, function (x) {
      return x.Date.toISOString() == date.toISOString();
    });

    let prmsArr = [];

    if (resultset.length > 0) {
      prmsArr.push(
        new Promise((resolve, reject) => {
          if (data != undefined) {
            occupancy = data.Occupancy ? data.Occupancy : 0;
            totalroomssold = data.NoOfRoomSold ? data.NoOfRoomSold : 0;
            totalrevenue = data.TotalRevenue ? data.TotalRevenue : 0;
            totalroomsAvailable = data.NumberofAvailableRooms ? data.NumberofAvailableRooms : 0;
            totalroomsAvailable = totalroomsAvailable - totalroomssold;
            transientRoomSold = data.TransientRoomsSold ? data.TransientRoomsSold : 0;
            groupRoomSold = data.GroupRoomsSold ? data.GroupRoomsSold : 0;
            groupBlock = data.GroupBlock ? data.GroupBlock : 0;


            Promise.all([
              new Promise((resolve, reject) => {
                PickupsHelper.getPickUpDelta(hotelid, date, currentDate, 1, totalrevenue, totalroomssold, transientRoomSold, (err, res) => {
                  if (err) {
                    reject(err);
                  }
                  // console.log('called 1');
                  if (res) {
                    pickuprpt1Amount = res.rptamount;
                    pickuprpt1RoomSold = res.rptroomsold;
                    transientDelta1 = res.transientDelta;
                    resolve();
                  }
                  resolve()
                });
              }),
              new Promise((resolve, reject) => {
                PickupsHelper.getPickUpDelta(hotelid, date, currentDate, 3, totalrevenue, totalroomssold, transientRoomSold, (err, res) => {
                  if (err) {
                    reject(err);
                  }
                  // console.log('called 2');
                  if (res) {
                    pickuprpt3Amount = res.rptamount;
                    pickuprpt3RoomSold = res.rptroomsold;
                    transientDelta3 = res.transientDelta;
                    resolve();
                  }
                  resolve();

                });
              }),
              new Promise((resolve, reject) => {
                PickupsHelper.getPickUpDelta(hotelid, date, currentDate, 7, totalrevenue, totalroomssold, transientRoomSold, (err, res) => {
                  if (err) {
                    reject(err);
                  }
                  // console.log('called 3');
                  if (res) {
                    pickuprpt7Amount = res.rptamount;
                    pickuprpt7RoomSold = res.rptroomsold;
                    transientDelta7 = res.transientDelta;
                    resolve();
                  }
                  resolve();

                });
              }),
              new Promise((resolve, reject) => {
                PickupsHelper.getPickUpDeltaSDLY(hotelid, date, currentDate, sdly, totalrevenue, totalroomssold, transientRoomSold, (err, res) => {
                  if (err) {
                    reject(err);
                  }
                  // console.log('called 4');
                  if (res) {
                    pickuprptSDLYAmount = res.rptamount;
                    pickuprptSDLYRoomSold = res.rptroomsold;
                    transientDeltaSDLY = res.transientDelta;
                    resolve();
                  }
                  resolve();
                });
              })
            ]).then(resp => {
              resolve();
            })
          } else { // end of "undefined" 
            // console.log('triggered else')
            resolve();
          }
        }) // end of promise
      ) // end of promise push

    } //end of "result.length > 0"
    else {
      prmsArr.push(
        new Promise((resolve, reject) => {
          pickuprpt1Amount = Constants.PickupReport.NA;
          pickuprpt1RoomSold = Constants.PickupReport.NA;
          transientDelta1 = Constants.PickupReport.NA;
          pickuprpt7Amount = Constants.PickupReport.NA;
          pickuprpt7RoomSold = Constants.PickupReport.NA;
          transientDelta7 = Constants.PickupReport.NA;
          pickuprpt3Amount = Constants.PickupReport.NA;
          pickuprpt3RoomSold = Constants.PickupReport.NA;
          transientDelta3 = Constants.PickupReport.NA;
          pickuprptSDLYAmount = Constants.PickupReport.NA;
          pickuprptSDLYRoomSold = Constants.PickupReport.NA;
          transientDeltaSDLY = Constants.PickupReport.NA;
          resolve();
        })
      )
    }

    Promise.all(prmsArr).then(res => {

      pickupItem.Occupancy = occupancy.toFixed(2);
      pickupItem.TotalRevenue = totalrevenue.toFixed(2);
      pickupItem.NoOfRoomSold = totalroomssold.toString();
      pickupItem.NoOfRoomAvailable = totalroomsAvailable.toString();
      pickupItem.Pickup1Amount = pickuprpt1Amount.toFixed(2);
      pickupItem.Pickup1RoomSold = pickuprpt1RoomSold;
      pickupItem.Pickup3Amount = pickuprpt3Amount.toFixed(2);
      pickupItem.Pickup3RoomSold = pickuprpt3RoomSold;
      pickupItem.Pickup7Amount = pickuprpt7Amount.toFixed(2);
      pickupItem.Pickup7RoomSold = pickuprpt7RoomSold;
      pickupItem.PickupSDLYAmount = pickuprptSDLYAmount.toFixed(2);
      pickupItem.PickupSDLYRoomSold = pickuprptSDLYRoomSold;

      Promise.all([
        new Promise((resolve, reject) => {
          PickupsHelper.getDeltaForcast(hotelid, currentDate, totalrevenue, (err, res) => {
            if (err) {
              reject(err);
            }
            pickupItem.DeltaForcast = res;
            resolve();
          });
        })
      ])

      pickupItem.TransientRoomSold = transientRoomSold;
      pickupItem.TransientDelta1 = transientDelta1;
      pickupItem.TransientDelta3 = transientDelta3;
      pickupItem.TransientDelta7 = transientDelta7;
      pickupItem.TransientDeltaSDLY = transientDeltaSDLY;
      pickupItem.GroupNotPickedUp = groupBlock;
      pickupItem.GroupBlock = groupRoomSold;
      pickupItem.TodayDate = Utils.getFormattedDate(new Date(), 'DD-MM-YYYY');

      return cb(null, pickupItem);
    }).catch(err => {
      console.log(err)
    })
  }

  static createLstArrayRev(roomrevenueList, date, currentDate, hotelid, cb) {
    let occupancy = 0;
    let totalroomssold = 0;
    let totalrevenue = 0;
    let totalroomsAvailable = 0;
    let pickuprpt1Amount = 0;
    let pickuprpt1RoomSold = 0;
    let pickuprpt3Amount = 0;
    let pickuprpt3RoomSold = 0;
    let pickuprpt7Amount = 0;
    let pickuprpt7RoomSold = 0;
    let pickuprptSDLYAmount = 0;
    let pickuprptSDLYRoomSold = 0;
    let transientRoomSold = 0;
    let transientDelta1 = 0;
    let transientDelta3 = 0;
    let transientDelta7 = 0;
    let transientDeltaSDLY = 0;
    let groupRoomSold = 0;

    let groupBlock = 0;
    let pickupItem = new Pickupdata();
    // pickupItem.Date =  m.format('YYYY-MM-DD');
    pickupItem.Date = Utils.getFormattedDate(date, 'DD-MM-YYYY');
    pickupItem.DailyActivityDate = Utils.getFormattedDate(date, 'DD-MM-YYYY');
    // pickupItem.DailyActivityDate = m.format("dd MMM yyyy");
    pickupItem.TodayDate = Utils.getFormattedDate(new Date(), 'DD-MM-YYYY');

    pickuprpt1Amount = Constants.PickupReport.NA;
    pickuprpt1RoomSold = Constants.PickupReport.NA;
    transientDelta1 = Constants.PickupReport.NA;
    pickuprpt7Amount = Constants.PickupReport.NA;
    pickuprpt7RoomSold = Constants.PickupReport.NA;
    transientDelta7 = Constants.PickupReport.NA;
    pickuprpt3Amount = Constants.PickupReport.NA;
    pickuprpt3RoomSold = Constants.PickupReport.NA;
    transientDelta3 = Constants.PickupReport.NA;
    pickuprptSDLYAmount = Constants.PickupReport.NA;
    pickuprptSDLYRoomSold = Constants.PickupReport.NA;
    transientDeltaSDLY = Constants.PickupReport.NA;

    if (roomrevenueList != null) {
      let data = _.find(roomrevenueList, function (x) {
        return x.Date.toISOString() == date.toISOString();
      });

      if (data != null) {
        occupancy = data.Occupancy ? data.Occupancy : 0;
        totalroomssold = data.NoOfRoomSold ? data.NoOfRoomSold : 0;
        totalrevenue = data.TotalRevenue ? data.TotalRevenue : 0;
        totalroomsAvailable = data.AvailableRooms ? data.AvailableRooms : 0;
        totalroomsAvailable = totalroomsAvailable - totalroomssold;
      }
    }


    //get delta's for business date as well
    if (date.toISOString() == currentDate) {


      var currentDate_minus1 = new Date(currentDate);
      var _currentDate = new Date(currentDate);
      currentDate_minus1 = new Date(Utils.addDays(currentDate_minus1, -1));
      currentDate_minus1 = currentDate_minus1.toISOString();
      let sdly = Utils.sameDayLastYear(currentDate);

      Promise.all([
        new Promise((resolve, reject) => {
          PickupsHelper.getPickUpDelta(hotelid, _currentDate, _currentDate, 1, totalrevenue, totalroomssold, transientRoomSold, (err, res) => {
            if (err) {
              reject(err);
            }
            // console.log('called 1');
            if (res) {
              pickuprpt1Amount = res.rptamount;
              pickuprpt1RoomSold = res.rptroomsold;
              transientDelta1 = res.transientDelta;
              resolve();
            }
            resolve()
          });
        }),
        new Promise((resolve, reject) => {
          PickupsHelper.getPickUpDelta(hotelid, _currentDate, _currentDate, 3, totalrevenue, totalroomssold, transientRoomSold, (err, res) => {
            if (err) {
              reject(err);
            }
            // console.log('called 2');
            if (res) {
              pickuprpt3Amount = res.rptamount;
              pickuprpt3RoomSold = res.rptroomsold;
              transientDelta3 = res.transientDelta;
              resolve();
            }
            resolve();

          });
        }),
        new Promise((resolve, reject) => {
          PickupsHelper.getPickUpDelta(hotelid, _currentDate, _currentDate, 7, totalrevenue, totalroomssold, transientRoomSold, (err, res) => {
            if (err) {
              reject(err);
            }
            // console.log('called 3');
            if (res) {
              pickuprpt7Amount = res.rptamount;
              pickuprpt7RoomSold = res.rptroomsold;
              transientDelta7 = res.transientDelta;
              resolve();
            }
            resolve();

          });
        }),
        new Promise((resolve, reject) => {
          PickupsHelper.getPickUpDeltaSDLY(hotelid, _currentDate, _currentDate, sdly, totalrevenue, totalroomssold, transientRoomSold, (err, res) => {
            if (err) {
              reject(err);
            }
            // console.log('called 4');
            if (res) {
              pickuprptSDLYAmount = res.rptamount;
              pickuprptSDLYRoomSold = res.rptroomsold;
              transientDeltaSDLY = res.transientDelta;
              resolve();
            }
            resolve();
          });
        })
      ]).then(resp => {




        Promise.all([
          new Promise((resolve, reject) => {
            PickupsHelper.getDeltaForcast(hotelid, currentDate, totalrevenue, (err, res) => {
              if (err) {
                log.error(err)
                reject(err)
              }
              pickupItem.DeltaForcast = res;
              resolve();
            });
          })
        ]).then(res => {


          transientDelta1 = transientDelta1 != 0 ? transientDelta1 : Constants.PickupReport.NA;
          transientDelta7 = transientDelta7 != 0 ? transientDelta7 : Constants.PickupReport.NA;
          transientDelta3 = transientDelta3 != 0 ? transientDelta3 : Constants.PickupReport.NA;
          pickuprptSDLYAmount = pickuprptSDLYAmount != 0 ? pickuprptSDLYAmount : Constants.PickupReport.NA;
          pickuprptSDLYRoomSold = pickuprptSDLYRoomSold != 0 ? pickuprptSDLYRoomSold : Constants.PickupReport.NA;
          transientDeltaSDLY = transientDeltaSDLY != 0 ? transientDeltaSDLY : Constants.PickupReport.NA;

          pickupItem.Occupancy = occupancy.toFixed(2);
          pickupItem.TotalRevenue = totalrevenue.toFixed(2);
          pickupItem.NoOfRoomSold = totalroomssold.toString();
          pickupItem.NoOfRoomAvailable = totalroomsAvailable.toString();
          pickupItem.Pickup1Amount = pickuprpt1Amount.toFixed(2);
          pickupItem.Pickup1RoomSold = pickuprpt1RoomSold;
          pickupItem.Pickup3Amount = pickuprpt3Amount.toFixed(2);
          pickupItem.Pickup3RoomSold = pickuprpt3RoomSold;
          pickupItem.Pickup7Amount = pickuprpt7Amount.toFixed(2);
          pickupItem.Pickup7RoomSold = pickuprpt7RoomSold;
          pickupItem.PickupSDLYAmount = pickuprptSDLYAmount.toFixed(2);
          pickupItem.PickupSDLYRoomSold = pickuprptSDLYRoomSold;

          pickupItem.TransientRoomSold = transientRoomSold;
          pickupItem.TransientDelta1 = transientDelta1;
          pickupItem.TransientDelta3 = transientDelta3;
          pickupItem.TransientDelta7 = transientDelta7;
          pickupItem.TransientDeltaSDLY = transientDeltaSDLY;
          pickupItem.GroupNotPickedUp = groupBlock;
          pickupItem.GroupBlock = groupRoomSold;

          return cb(null, pickupItem);
        }).catch(err => {
          console.log(err)
        })
      });

    }
    else {

      Promise.all([
        new Promise((resolve, reject) => {
          PickupsHelper.getDeltaForcast(hotelid, currentDate, totalrevenue, (err, res) => {
            if (err) {
              log.error(err)
              reject(err)
            }
            pickupItem.DeltaForcast = res;
            resolve();
          });
        })
      ]).then(res => {


        pickupItem.Occupancy = occupancy.toFixed(2);
        pickupItem.TotalRevenue = totalrevenue.toFixed(2);
        pickupItem.NoOfRoomSold = totalroomssold.toString();
        pickupItem.NoOfRoomAvailable = totalroomsAvailable.toString();
        pickupItem.Pickup1Amount = pickuprpt1Amount.toFixed(2);
        pickupItem.Pickup1RoomSold = pickuprpt1RoomSold;
        pickupItem.Pickup3Amount = pickuprpt3Amount.toFixed(2);
        pickupItem.Pickup3RoomSold = pickuprpt3RoomSold;
        pickupItem.Pickup7Amount = pickuprpt7Amount.toFixed(2);
        pickupItem.Pickup7RoomSold = pickuprpt7RoomSold;
        pickupItem.PickupSDLYAmount = pickuprptSDLYAmount.toFixed(2);
        pickupItem.PickupSDLYRoomSold = pickuprptSDLYRoomSold;

        pickupItem.TransientRoomSold = transientRoomSold;
        pickupItem.TransientDelta1 = transientDelta1;
        pickupItem.TransientDelta3 = transientDelta3;
        pickupItem.TransientDelta7 = transientDelta7;
        pickupItem.TransientDeltaSDLY = transientDeltaSDLY;
        pickupItem.GroupNotPickedUp = groupBlock;
        pickupItem.GroupBlock = groupRoomSold;

        return cb(null, pickupItem);
      }).catch(err => {
        console.log(err)
      })
    }



  }


  static getPickUpDelta(hotelId, startdate, reportedDateTime, rptValue, pickupAmount, pickupRoomSold, transientRoomSold, cb) {

    startdate = moment(startdate).format("YYYY-MM-DD");
    startdate = new Date(startdate).toISOString();

    let pickupAmountPreviousRpt = 0;
    let pickupRoomSoldPreviousRpt = 0;
    let transientRoomSoldPreviousRpt = 0;
    let data = {
      rptamount: Constants.PickupReport.NA,
      rptroomsold: Constants.PickupReport.NA,
      transientDelta: Constants.PickupReport.NA
    }

    let reportedDateTimePreviousRpt = '';

    if (rptValue > 0) {
      reportedDateTimePreviousRpt = moment(reportedDateTime).subtract(rptValue, 'days').format("YYYY-MM-DD");
    } else if (rptValue < 0) {
      reportedDateTimePreviousRpt = moment(reportedDateTime).add(rptValue, 'days').format("YYYY-MM-DD");
    } else {
      reportedDateTimePreviousRpt = reportedDateTime;
    }

    reportedDateTimePreviousRpt = moment(new Date(reportedDateTimePreviousRpt)).toISOString();

    // need to implement decending ordering here
    PickupreportSchema.find({ [PickupreportSchemaFields.HotelID]: hotelId, [PickupreportSchemaFields.ReportedDateTime]: reportedDateTimePreviousRpt, [PickupreportSchemaFields.Date]: { "$gte": startdate, "$lte": startdate } },
      (err, result) => {
        if (err) {
          log.error(err)
          cb(err, null);
        }
        if (result.length > 0) {
          result = result[0];
        }
        // console.log(result, 'result.TotalRevenue');
        pickupAmountPreviousRpt = result.TotalRevenue != undefined ? result.TotalRevenue : 0;
        pickupRoomSoldPreviousRpt = result.NoOfRoomSold != undefined ? result.NoOfRoomSold : 0;
        transientRoomSoldPreviousRpt = result.TransientRoomsSold != undefined ? result.TransientRoomsSold : 0;

        data.rptamount = pickupAmount - pickupAmountPreviousRpt;
        data.rptroomsold = pickupRoomSold - pickupRoomSoldPreviousRpt;
        data.transientDelta = transientRoomSold - transientRoomSoldPreviousRpt;

        return cb(null, data);
      });
  }

  static getPickUpDeltaSDLY(hotelId, startdate, reportedDateTime, sdlyDate, pickupAmount, pickupRoomSold, transientRoomSold, cb) {
    startdate = moment(sdlyDate).format("YYYY-MM-DD");
    startdate = new Date(sdlyDate).toISOString();

    let pickupAmountPreviousRpt = 0;
    let pickupRoomSoldPreviousRpt = 0;
    let transientRoomSoldPreviousRpt = 0;
    let data = {
      rptamount: Constants.PickupReport.NA,
      rptroomsold: Constants.PickupReport.NA,
      transientDelta: Constants.PickupReport.NA
    }

    HoteldashboardcalculationsSchema.find({ [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId, [HoteldashboardcalculationsSchemaFields.Date]: { "$gte": startdate, "$lte": startdate } },
      (err, result) => {
        if (err) {
          log.error(err)
          console.log(err)
          cb(err, null);
        }
        if (result.length > 0) {
          result = result[0];
        } else {
          result = {};
        }

        pickupAmountPreviousRpt = result.TotalRevenue != undefined ? result.TotalRevenue : 0; // where it crashes
        pickupRoomSoldPreviousRpt = result.NoOfRoomSold != undefined ? result.NoOfRoomSold : 0;
        data.rptamount = pickupAmount - pickupAmountPreviousRpt;
        data.rptroomsold = pickupRoomSold - pickupRoomSoldPreviousRpt;
        data.transientDelta = transientRoomSold - transientRoomSoldPreviousRpt;

        return cb(null, data);
      });
  }


  static getDeltaForcast(hotelId, currentDate, totalRevenue, cb) {

    let deltaforcast = 0;
    let RoomRevenueForcast = 0;
    let hotelbudgetlist = [];

    HotelbudgetSchema.find({ [HotelbudgetSchemaFields.HotelID]: hotelId, [HotelbudgetSchemaFields.DateFrom]: currentDate, [HotelbudgetSchemaFields.DateTo]: currentDate },
      (err, result) => {
        if (err) {
          console.log(err);
          log.error(err);
          cb(err, null);
        }
        if (!result) {
          return cb("Hotel budget data not found ", null);
        }

        if (result.length > 0) {
          let rForecasAVGtMTD = 0;

          result.forEach(element => {

            let todate = DateTime.Parse(element.DateTo.ToString());
            let fromdate = DateTime.Parse(element.DateFrom.ToString());
            let TDays = Math.Floor(Convert.ToDouble((todate - fromdate).TotalDays)) + 1;
            let RForcast = (element.RoomRevenueForcast / TDays);
            rForecasAVGtMTD = rForecasAVGtMTD + RForcast;

          });
          RoomRevenueForcast = rForecasAVGtMTD;
          deltaforcast = RoomRevenueForcast - totalRevenue;
        }
      });
    if (deltaforcast == 0) {
      deltaforcast = totalRevenue;
    }
    return cb(null, deltaforcast);
  }

  static getHotelDashboardCalculationsv2(currentDate, prevDate, hotelid, cb) {

    let start = new Date(prevDate.getFullYear(), prevDate.getMonth(), prevDate.getDate());
    let end = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 1);

    HoteldashboardcalculationsSchema.find({
      [HoteldashboardcalculationsSchemaFields.HotelID]: hotelid,
      [HoteldashboardcalculationsSchemaFields.Date]: {
        $gte: start,
        $lt: end
      }
    },
      (err, calculationData) => {

        if (err) {
          log.error(err)
          console.log(err)
          cb(err, null);
        }
        if (!calculationData) {
          return cb("dashboard calculations data not found ", null);
        }
        return cb(null, calculationData);
      });
  }



  static getHotelDashboardCalculations(currentDate, prevDate, hotelid, cb) {

    HoteldashboardcalculationsSchema.find({ [HoteldashboardcalculationsSchemaFields.HotelID]: hotelid, [HoteldashboardcalculationsSchemaFields.Date]: { "$gte": currentDate, "$lte": prevDate } },
      (err, calculationData) => {

        if (err) {
          log.error(err)
          console.log(err)
          cb(err, null);
        }
        if (!calculationData) {
          return cb("dashboard calculations data not found ", null);
        }
        return cb(null, calculationData);
      });
  }

  static getPickupData_GraphQL(hotelid, today, days, startDate, cb) {

    //get myp hotelid from cmp_id
    return HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
      if (err) {
        cb(err, null);
      }
      if (!hoteldata) {
        cb(Constants.HotelNotFound, null);
      }
      else {
        PickupsHelper.getPickupData(hoteldata.ID, today, days, startDate, cb, (err, result) => {
          if (err) {
            cb(err, null);
          }
          cb(null, result);
        });
      }
    });

  }

}

module.exports = PickupsHelper;

