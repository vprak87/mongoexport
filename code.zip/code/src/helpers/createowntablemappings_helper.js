
const { Createowntablemapping: CreateowntablemappingSchema, SchemaField: CreateowntablemappingSchemaFields } = require('../models/createowntablemapping');
const { Createowntablemappingmaster: CreateowntablemappingmasterSchema, SchemaField: CreateowntablemappingmasterSchemaFields } = require('../models/createowntablemappingmaster');
const dbtable = require('../schema/db_table');
const SequenceHelper = require('./sequence_helper');
const RESTHelper = require('./rest_helper');
const Constants = require('../common/constants');
const config = require('../../appsettings.js');
const KPIData = require('../customkpi/models/kpidata')

var log = require('log4js').getLogger("createowntablemappings_helper");
class CreateowntablemappingsHelper {

    static GetTagList(tablename, cd) {
        CreateowntablemappingmasterSchema.find({ [CreateowntablemappingmasterSchemaFields.TableName]: tablename }).sort({ [CreateowntablemappingmasterSchemaFields.DisplayOrder]: 1 }).exec((err, result) => {
            cd(null, result)
        })


    }
    static GetCreateOwnTableMappingList(userid, tablename, cb) {

        log.debug('Call GetCreateOwnTableMappingList, userid:' + userid + 'tablename: ' + tablename);

        let createowntablemappingAggregate = CreateowntablemappingSchema.aggregate();

        createowntablemappingAggregate.match({
            [CreateowntablemappingSchemaFields.UserID]: userid,
            [CreateowntablemappingSchemaFields.CreateOwnTableMasterID]: {
                $gt: 0
            }
        })
        createowntablemappingAggregate.sort({
            [CreateowntablemappingSchemaFields.DisplayOrder]: 1
        });

        createowntablemappingAggregate.lookup({
            from: dbtable.CREATEOWNTABLEMAPPINGMASTER,
            let: { cId: `$${CreateowntablemappingSchemaFields.CreateOwnTableMasterID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: {
                            $and: [
                                { $eq: ["$$cId", `$${CreateowntablemappingmasterSchemaFields.ID}`] }
                                //    { $eq: [tablename, `$${CreateowntablemappingmasterSchemaFields.TableName}`] }
                            ]
                        }
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        [CreateowntablemappingmasterSchemaFields.TableName]: 1,
                        [CreateowntablemappingmasterSchemaFields.ColumName]: 1,
                        [CreateowntablemappingmasterSchemaFields.KPIKey]: 1,
                        [CreateowntablemappingmasterSchemaFields.IsCustom]: 1,
                        [CreateowntablemappingmasterSchemaFields.KPIFormula]: 1,


                    }
                }
            ],
            as: "CreateOwnTableMasterData"
        })

        createowntablemappingAggregate.unwind({
            path: "$CreateOwnTableMasterData",
            preserveNullAndEmptyArrays: true
        });


        createowntablemappingAggregate.group({
            _id: null,
            kpicolumns: {
                $push: {
                    _id: "$_id",
                    CreateOwnTableMasterID: "$CreateOwnTableMasterID",
                    UserID: "$UserID",
                    DisplayOrder: "$DisplayOrder",
                    CreateOwnTableMasterData: "$CreateOwnTableMasterData"
                }
            }

        })

        createowntablemappingAggregate.project({
            kpicolumn: {
                $filter: {
                    input: "$kpicolumns",
                    as: "kpicolumn",
                    cond: {
                        $and: [
                            { $eq: ["$$kpicolumn.CreateOwnTableMasterData.TableName", tablename] }
                        ]
                    }
                }
            }
        })

        return createowntablemappingAggregate.exec((err, result) => {
            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("GetCreateOwnTableMappingList result not found");
                return cb(null, null);
            }
            else {
                return cb(null, result);
            }
        });


    }


    static getKPIMasterListData(orgid, tablename, cb) {

        log.debug('Call getKPIMasterListData, orgid:' + orgid + 'tablename:' + tablename);

        return CreateowntablemappingmasterSchema.find({
            $and: [
                { [CreateowntablemappingmasterSchemaFields.TableName]: tablename },
                {
                    $or:
                        [{ [CreateowntablemappingmasterSchemaFields.OrganizationId]: orgid },
                        { [CreateowntablemappingmasterSchemaFields.OrganizationId]: 2 },
                        { [CreateowntablemappingmasterSchemaFields.OrganizationId]: null }
                        ]
                }
            ]
        }
        ).sort(CreateowntablemappingmasterSchemaFields.ColumName).exec(function (err, result) {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("getKPIMasterListData result not found");
            }


            return cb(null, result);

        })


    }

    static reorderKPIColumn(userid, kpiid, tablename, displayordercounter, cb) {

        log.debug('Call reorderKPIColumn, userid:' + userid + 'kpiid:' + kpiid + 'tablename:' + tablename + 'displayordercounter' + displayordercounter);
        var today = new Date();
        CreateowntablemappingSchema.findOneAndUpdate(
            {
                [CreateowntablemappingSchemaFields.CreateOwnTableMasterID]: kpiid,
            },
            {
                [CreateowntablemappingSchemaFields.DisplayOrder]: displayordercounter,
                [CreateowntablemappingSchemaFields.UpdateDateTime]: today
            },
            {
                new: true
            }
        ).exec((err, result) => {
            cb(null, result);
        })

    }

    static addKPIColumns(userid, kpikey, tablename, displayordercounter, cb) {

        log.debug('Call addKPIColumns, userid:' + userid + 'kpikey:' + kpikey + 'tablename:' + tablename);
        var today = new Date();

        //GetTableMappingMasterId
        CreateowntablemappingmasterSchema.findOne({
            $and: [
                { [CreateowntablemappingmasterSchemaFields.TableName]: tablename },
                { [CreateowntablemappingmasterSchemaFields.KPIKey]: kpikey }

            ]
        }
        ).exec(function (err, kpikey_result) {
            if (err) {
                log.error(err);
                return cb(err, null);
            }
            if (kpikey_result) {

                //get addkpiid from sql server for mapping correct pk id
                var json_postdata = [];
                json_postdata.userid = userid;
                json_postdata.createowntablemasterid = kpikey_result.ID;
                RESTHelper.POST(Constants.Urls.GetKPIColumn, json_postdata, (api_err, api_result) => {
                    if (api_err) {
                        log.error(api_err);
                        return cb(new Error(Constants.internalErrorMsg), null);
                    }

                    //#region write it to mongodb with id returned by SQL
                    let id = parseInt(api_result.data.longid);

                    // SequenceHelper.getValueForNextSequence(dbtable.CREATEOWNTABLEMAPPING, (err, seq_result) => {
                    //     if (seq_result) {
                    //         let id = parseInt(seq_result);

                    var createowntablemappings = {
                        [CreateowntablemappingSchemaFields.ID]: id,
                        [CreateowntablemappingSchemaFields.DisplayOrder]: displayordercounter,
                        [CreateowntablemappingSchemaFields.CreateOwnTableMasterID]: kpikey_result.ID,
                        [CreateowntablemappingSchemaFields.UserID]: userid,
                        [CreateowntablemappingSchemaFields.UpdateDateTime]: today,
                        [CreateowntablemappingSchemaFields.UpdatedBy]: userid
                    };

                    let createowntablemappingsSchema = new CreateowntablemappingSchema(createowntablemappings);
                    createowntablemappingsSchema.save((err, createowntablemappings_result) => {
                        if (err)
                            return cb(err, null);
                        else {

                            return cb(null, createowntablemappings_result);
                        }
                    })

                });
            }
            else {
                return cb(null, null);
            }
        })

    }

    static removeKPIColumn(userid, kpikey, tablename, cb) {

        log.debug('Call removeKPIColumn, userid:' + userid + 'kpikey:' + kpikey + 'tablename:' + tablename);

        //GetTableMappingMasterId
        CreateowntablemappingmasterSchema.findOne({
            $and: [
                { [CreateowntablemappingmasterSchemaFields.TableName]: tablename },
                { [CreateowntablemappingmasterSchemaFields.KPIKey]: kpikey }

            ]
        }
        ).exec(function (err, kpikey_result) {
            if (err) {
                log.error(err);
                return cb(err, null);
            }
            if (kpikey_result) {

                //remove it from createowntablemappings
                CreateowntablemappingSchema.deleteOne({ [CreateowntablemappingSchemaFields.CreateOwnTableMasterID]: kpikey_result.ID }, (err, result) => {
                    if (err) {
                        log.error(err);
                    }

                    cb(null, result);
                })

            }
            else {
                return cb(null, null);
            }
        })


    }

    static getKPIData(kpikey, tablename, index_order, cb) {
        log.debug('Call getKPIData, kpikey:' + kpikey + 'tablename: ' + tablename);

        return CreateowntablemappingmasterSchema.findOne({
            $and: [
                { [CreateowntablemappingmasterSchemaFields.KPIKey]: kpikey },
                { [CreateowntablemappingmasterSchemaFields.TableName]: tablename },
            ]
        }
        ).exec(function (err, result) {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("getKPIData result not found");
            }
            else {
                result.order = index_order;
            }
            return cb(null, result);
        })

    }


    static updatekpicolumn_graphQL(userid, oldkpikey, newkpikey, tablename, cb) {
        log.debug('Call updatekpicolumn_graphQL, userid:' + userid + 'oldkpikey: ' + oldkpikey + "newkpikey:" + newkpikey + "tablename" + tablename);
        var today = new Date();

        //GetTableMappingMasterId
        CreateowntablemappingmasterSchema.findOne({
            $and: [
                { [CreateowntablemappingmasterSchemaFields.TableName]: tablename },
                { [CreateowntablemappingmasterSchemaFields.KPIKey]: oldkpikey }
            ]
        }
        ).exec(function (err, oldkpikey_result) {
            if (err) {
                log.error(err);
                return cb(err, null);
            }
            if (oldkpikey_result) {

                //replace it with newkpikey id
                CreateowntablemappingmasterSchema.findOne({
                    $and: [
                        { [CreateowntablemappingmasterSchemaFields.TableName]: tablename },
                        { [CreateowntablemappingmasterSchemaFields.KPIKey]: newkpikey }
                    ]
                }
                ).exec(function (err, newkpikey_result) {
                    if (err) {
                        log.error(err);
                        return cb(err, null);
                    }
                    if (newkpikey_result) {

                        CreateowntablemappingSchema.findOneAndUpdate(
                            {
                                [CreateowntablemappingSchemaFields.CreateOwnTableMasterID]: oldkpikey_result.ID,
                                [CreateowntablemappingSchemaFields.UserID]: userid,
                            },
                            {
                                [CreateowntablemappingSchemaFields.CreateOwnTableMasterID]: newkpikey_result.ID,
                                [CreateowntablemappingSchemaFields.UpdateDateTime]: today,
                                [CreateowntablemappingSchemaFields.UpdatedBy]: userid
                            },
                            {
                                new: true
                            }
                        ).exec((err, result) => {


                            //move it to SQL server as well for sync
                            if (config.appsettings.sync_to_SQLServer) {

                                //db write to SQL server and sync will handle the data in mangodb
                                var json_postdata = [];
                                json_postdata.userid = userid;
                                json_postdata.tablename = tablename;
                                json_postdata.oldkpikey = oldkpikey;
                                json_postdata.newkpikey = newkpikey;

                                //KPI/Update in SQL server
                                RESTHelper.POST(Constants.Urls.UpdateKPIColumn, json_postdata, (api_err, sync_result) => {
                                    if (api_err)
                                        log.error(api_err);
                                    log.debug(sync_result);
                                });
                            }

                            cb(null, result);
                        })

                    }
                    else {
                        return cb(null, null);
                    }
                })


            }
            else {
                return cb(null, null);
            }
        })



    }

    static getColumnMasterListData(tablename, cb) {

        log.debug('Call getColumnMasterListData tablename:' + tablename);

        return CreateowntablemappingmasterSchema.find({
            $and: [
                { [CreateowntablemappingmasterSchemaFields.TableName]: tablename }
            ]
        }
        ).sort(CreateowntablemappingmasterSchemaFields.ColumName).exec(function (err, result) {

            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("getColumnMasterListData result not found");
            }
            let kpiListData = [];
            result.forEach((element, index) => {
                var kpiData = new KPIData();
                kpiData.id = element.ID,
                    kpiData.tablename = element.TableName,
                    kpiData.columname = element.ColumName,
                    kpiData.displayorder = element.DisplayOrder,
                    kpiData.kpikey = element.KPIKey,
                    kpiData.parentkey = element.ParentKey,
                    kpiData.hassubkey = element.HasSubKey,
                    kpiData.kpiformula = element.KPIFormula,
                    kpiData.unit = element.Unit,
                    kpiData.organizationid = element.OrganizationId,
                    kpiData.iscustom = element.IsCustom
                kpiListData.push(kpiData);
            });

            return cb(null, kpiListData);

        })


    }

}
module.exports = CreateowntablemappingsHelper;
