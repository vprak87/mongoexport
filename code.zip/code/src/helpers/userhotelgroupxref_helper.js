const { Userhotelgroupxref: UserhotelgroupxrefSchema, SchemaField: UserhotelgroupxrefSchemaFields } = require('../models/userhotelgroupxref');
const dbtable = require('../schema/db_table');

var log = require('log4js').getLogger("userhotelgroupxref_helper");

class UserHotelGroupXrefHelper {
    static getUserHoteGroupData(hotelgroupid,userid,  cd) {
    UserhotelgroupxrefSchema.find(
                    
        {$and:[
        {[UserhotelgroupxrefSchemaFields.HotelGroupId]: hotelgroupid},
        {[UserhotelgroupxrefSchemaFields.UserId]:userid}
        ]}).exec(function (err, result) {
            if(err){
                cd(err,null)
                log.debug('User Hotel Group not exsisit !')
            }
            cd(null,result)
        })
    }

}
module.exports = UserHotelGroupXrefHelper;
