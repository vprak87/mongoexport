const { Hotelcomment: HotelcommentSchema, SchemaField: HotelcommentSchemaFields } = require('../models/hotelcomment');

const { Hotels: HotelsSchema, SchemaField: HotelsSchemaFields } = require('../models/hotels');

const { User: UserSchema, SchemaField: UserSchemaFields } = require('../models/user');

const Hotelcommentview = require('../comment/models/Hotelcommentview');

const Createowntablemappingmasterview = require('../comment/models/Createowntablemappingmasterview');

const Constants = require('../common/constants');

const Utils = require('../common/utils');

let log = require('log4js').getLogger("comments_helper");

const _ = require('lodash');

const dbtable = require('../schema/db_table');

const UserHelper = require('./user_helper');

const HttpMsg = require('../common/constants');

const HotelsHelper = require('./hotels_helper');
const CreateowntablemappingsHelper = require('./createowntablemappings_helper');

let USERID = 0;
let FIRSTNAME = '';
class CommentsHelper {
    static getHotelCommentData_GraphQL(userid, hotelid, currentdate, period, startDate, strtags, cd) {
        if(userid==null){
            log.debug('Comments to be shown only to superadmin and admin users')
            cd(null,null);
        }
        UserHelper.getUserData(userid, (err, userconfigdata) => {
            if (err) {
                cd(err,null)
            }
            
        let flag = (userconfigdata!=null?true:false);
        if(flag){
            
                if (userconfigdata.RoleID > 2) {
                    log.debug('Comments to be shown only to superadmin and admin users')
                    cd(null,null);
                }else{
                            
                        
                CommentsHelper.getHotelComment(hotelid, currentdate, userconfigdata, period, startDate, strtags, (err, result) => {
                    let allcomments = [];
                    _.filter(result, (key) => {
    
                        _.filter(key, (i) => {
                            allcomments.push(i)
                        })
    
                    })
    
                    cd(null, allcomments)
                })
            }
        
    }else{
        cd(null,null);
    }
                  



    })
    }
    static getHotelComment(hotelid, currentdate, userconfigdata, period, startDate, strtags, cd) {
        let hotelidList = hotelid.split(',');
        let commentresult = [];
        if(userconfigdata!=null){
            _.filter([userconfigdata], (element) => {
                USERID = element.ID;
                FIRSTNAME = element.FirstName;
            })
        }

        let x = [];

        _.filter(hotelidList, (element) => {
            let y = new Promise((resolve, reject) => {
                CommentsHelper.getHotelCommentCal(element, currentdate, period, startDate, strtags, (err, result) => {

                    if (result != null && result.length > 0) {
                        commentresult.push(result)
                    } else {
                        commentresult.push(result)
                    }


                    resolve();
                })
            })
            x.push(y);
        })
        Promise.all(x).then(resp => {

            cd(null, commentresult)
        })
    }

    static getHotelCommentCal(hotelid, currentdate, period, strstartDate, strtags, cd) {

        let startdate = new Date(Utils.getFormattedDate(new Date(), "YYYY-MM-DD"));
        let enddate = new Date(Utils.getFormattedDate(new Date(), "YYYY-MM-DD"));
        let yeasterday = new Date(currentdate);
        period = period.toLowerCase();
        if (period == "mtd") {
            startdate = Utils.startofMonth(yeasterday);
            enddate = Utils.endofDay(yeasterday);
        }
        else if (period == "ytd") {
            startdate = Utils.startofYear(yeasterday);
            enddate = Utils.endofDay(yeasterday);
        }
        else if (period == "ttm") {
            startdate = Utils.firstDayOfMonth(yeasterday);
            startdate = Utils.lastYearDate(startdate);



            enddate = Utils.firstDayOfMonth(yeasterday);
            enddate.setDate(startdate.getDate() - 1);



        }
        else if (period == "current" || typeof (period) == 'undefined' || period === null) {
            startdate = new Date(Utils.getFormattedDate(yeasterday, "YYYY-MM-DD"));
            enddate = Utils.endofDay(yeasterday);
        }
        else if (period == "custom" && (typeof (strstartDate) != 'undefined' || strstartDate != null)) {
            let startDate = new Date(Utils.getFormattedDate(strstartDate, "YYYY-MM-DD"));
            startdate = new Date(Utils.getFormattedDate(startDate, "YYYY-MM-DD"));
            enddate = Utils.endofDay(yeasterday);
        }

        let x = [];
        if (strtags != null) {
            /*
            
                [HotelcommentSchemaFields.Date]: {
                    $gte: startdate,
                    $lt: enddate
                },
            */
            
            HotelcommentSchema.find({
                //[HotelcommentSchemaFields.UserID]: USERID,
                [HotelcommentSchemaFields.Date]: {
                    $gte: startdate,
                    $lte: enddate
                },
                [HotelcommentSchemaFields.HotelID]: hotelid,
                [HotelcommentSchemaFields.ParentID]: null,
                [HotelcommentSchemaFields.Tags]: strtags
            }).exec((err, result) => {
                _.filter(result, (key) => {
                    let hotelCommentList = new Hotelcommentview();
                    hotelCommentList.ID = key.ID;
                    hotelCommentList.HotelID = key.HotelID;
                    hotelCommentList.Tags = key.Tags.replace(",", "/");
                    hotelCommentList.Date = key.Date;
                    hotelCommentList.Description = key.Description;
                    hotelCommentList.FirstName = FIRSTNAME;
                    hotelCommentList.UpdateDateTime = key.UpdateDateTime;
                    x.push(hotelCommentList)

                })



                let replieArray = [];
                _.filter(x, (element) => {
                    element.DisplayDate = Utils.getFormattedDate(element.Date, "DD-MMM-YYYY");


                    replieArray.push(element.ID);
                })
                if (replieArray != null && replieArray.length > 0) {
                    let hotelcommentAggregate = HotelcommentSchema.aggregate();
                    hotelcommentAggregate.lookup({
                        from: dbtable.USER,
                        let: { userId: `$${HotelcommentSchemaFields.UserID}` },
                        pipeline: [
                            { $in: [replieArray[0], `$${HotelcommentSchemaFields.ParentID}`] },
                            { "$sort": { [HotelcommentSchemaFields.UpdateDateTime]: -1 } },
                            {
                                $match:
                                {
                                    $expr: { $eq: ["$$userId", `$${UserSchemaFields.ID}`] }
                                }

                            },
                            {
                                $project: {
                                    "_id": 1,
                                    [UserSchemaFields.UserName]: 1,
                                    [UserSchemaFields.FirstName]: 1,
                                    [UserSchemaFields.LastName]: 1
                                }
                            }
                        ],
                        as: "user"
                    }).lookup({
                        from: dbtable.HOTELS,
                        let: { hotelId: `$${HotelcommentSchemaFields.HotelID}` },
                        pipeline: [
                            {
                                $match:
                                {
                                    $expr: { $eq: ["$$hotelId", `$${HotelsSchemaFields.ID}`] }
                                }

                            },
                            {
                                $project: {
                                    "_id": 1,
                                    [HotelsSchemaFields.HotelName]: 1
                                }
                            }
                        ],
                        as: "hotel"
                    })

                    hotelcommentAggregate.exec((err, result) => {
                        let replies = [];
                        _.filter(result, function (element) {
                            let hotelCommentList = new Hotelcommentview();
                            hotelCommentList.ID = element.ID;
                            hotelCommentList.HotelID = element.HotelID;
                            hotelCommentList.Tags = element.Tags;
                            hotelCommentList.Date = element.Date;
                            hotelCommentList.Description = element.Description;
                            hotelCommentList.UserName = element.user[0].Username;
                            hotelCommentList.FirstName = element.user[0].FirstName;
                            hotelCommentList.LastName = element.user[0].LastName;
                            hotelCommentList.HotelName = element.hotel[0].HotelName;
                            replies.push(hotelCommentList)
                        })


                        let existingreply = [];
                        _.filter(replies, function (element) {
                            existingreply.push({ "text": element.FirstName + " " + element.Description })
                        })
                        _.filter(x, (element) => {
                            element.ExistingReply = existingreply;
                        })

                        let finalResult = _.orderBy(x, ['UpdateDateTime'], ['asc'])
                        cd(null, finalResult)

                    })
                } else {
                    let finalResult = _.orderBy(x, ['UpdateDateTime'], ['asc'])
                    cd(null, finalResult)
                }

            })

        } else {

            HotelcommentSchema.find({
                //[HotelcommentSchemaFields.UserID]: USERID,
                [HotelcommentSchemaFields.Date]: {
                    $gte: startdate,
                    $lte: enddate
                },
                [HotelcommentSchemaFields.HotelID]: hotelid,
                [HotelcommentSchemaFields.ParentID]: null
            }).exec((err, result) => {
                _.filter(result, (key) => {
                    let hotelCommentList = new Hotelcommentview();
                    hotelCommentList.ID = key.ID;
                    hotelCommentList.HotelID = key.HotelID;
                    hotelCommentList.Tags = key.Tags.replace(",", "/");
                    hotelCommentList.Date = key.Date;
                    hotelCommentList.Description = key.Description;
                    hotelCommentList.FirstName = FIRSTNAME;
                    hotelCommentList.UpdateDateTime = key.UpdateDateTime;
                    x.push(hotelCommentList)
                })
                let replieArray = [];
                _.filter(x, (element) => {
                    element.DisplayDate = Utils.getFormattedDate(element.Date, "DD-MMM-YYYY");


                    replieArray.push(element.ID);
                })
                if (replieArray != null && replieArray.length > 0) {
                    let hotelcommentAggregate = HotelcommentSchema.aggregate();
                    hotelcommentAggregate.lookup({
                        from: dbtable.USER,
                        let: { userId: `$${HotelcommentSchemaFields.UserID}` },
                        pipeline: [
                            { $in: [replieArray[0], `$${HotelcommentSchemaFields.ParentID}`] },
                            { "$sort": { [HotelcommentSchemaFields.UpdateDateTime]: -1 } },
                            {
                                $match:
                                {
                                    $expr: { $eq: ["$$userId", `$${UserSchemaFields.ID}`] }




                                }

                            },
                            {
                                $project: {
                                    "_id": 1,
                                    [UserSchemaFields.UserName]: 1,
                                    [UserSchemaFields.FirstName]: 1,
                                    [UserSchemaFields.LastName]: 1
                                }
                            }
                        ],
                        as: "user"
                    }).lookup({
                        from: dbtable.HOTELS,
                        let: { hotelId: `$${HotelcommentSchemaFields.HotelID}` },
                        pipeline: [
                            {
                                $match:
                                {
                                    $expr: { $eq: ["$$hotelId", `$${HotelsSchemaFields.ID}`] }
                                }

                            },
                            {
                                $project: {
                                    "_id": 1,
                                    [HotelsSchemaFields.HotelName]: 1
                                }
                            }
                        ],
                        as: "hotel"
                    })

                    hotelcommentAggregate.exec((err, result) => {
                        let replies = [];
                        _.filter(result, function (element) {
                            let hotelCommentList = new Hotelcommentview();
                            hotelCommentList.ID = element.ID;
                            hotelCommentList.HotelID = element.HotelID;
                            hotelCommentList.Tags = element.Tags;
                            hotelCommentList.Date = element.Date;
                            hotelCommentList.Description = element.Description;
                            hotelCommentList.UserName = element.user[0].Username;
                            hotelCommentList.FirstName = element.user[0].FirstName;
                            hotelCommentList.LastName = element.user[0].LastName;
                            hotelCommentList.HotelName = element.hotel[0].HotelName;
                            replies.push(hotelCommentList)
                        })


                        let existingreply = [];
                        _.filter(replies, function (element) {
                            existingreply.push({ "text": element.FirstName + " " + element.Description })
                        })
                        _.filter(x, (element) => {
                            element.ExistingReply = existingreply;
                        })

                        let finalResult = _.orderBy(x, ['UpdateDateTime'], ['asc'])
                        cd(null, finalResult)

                    })
                } else {
                    let finalResult = _.orderBy(x, ['UpdateDateTime'], ['asc'])
                    cd(null, finalResult)
                }

            })
        }





    }
    static getCommentDetailData_GraphQL(userid, tags, hotelId, currentDate, cd) {
        UserHelper.getUserData(userid, (err, userconfigdata) => {
            if (err) {
                cd(err,null);
            }

            CommentsHelper.getshowchartdata(tags, hotelId, currentDate, userconfigdata, (err, result) => {
                cd(null, result)
            })
           


        })
    }
    static getshowchartdata(tags, hotelId, currentDate, configdata, cd) {
        CommentsHelper.populateshowchatviewmodelcommon(tags, hotelId, currentDate, configdata, (err, result) => {

            // let model = new Hotelcommentchatviewmodel();
            // model.HotelComments = result;
            // model.IDTags = 
            let ChartData = [];

            _.filter(result, (element) => {
                if (element.ParentID == null || element.ParentID == 0) {
                    if (element.UserID == [configdata][0].ID) {
                        let item = { "Description": "", "FirstName": "", "LastName": "" };
                        item.Description = element.Description;
                        ChartData.push(item)
                    }
                    else {
                        let item = { "Description": "", "FirstName": "", "LastName": "" };
                        item.Description = element.Description;
                        item.FirstName = element.FirstName;
                        item.LastName = element.LastName;
                        ChartData.push(item)
                    }
                    if (element.ChildComments == null || element.ChildComments.length > 0) {
                        
                        _.filter(element.ChildComments, (key) => {

                            if (key.UserID == [configdata][0].ID) {
                                let itemchild = { "Description": "", "FirstName": "", "LastName": "" };
                                itemchild.Description = key.Description;
                                ChartData.push(itemchild)
                            } 
                            // else {
                            //     let itemchild = { "Description": "", "FirstName": "", "LastName": "" };
                            //     itemchild.Description = element.Description;
                            //     itemchild.FirstName = element.FirstName;
                            //     itemchild.LastName = element.LastName;
                            //     if(element.Description !== ''){
                            //         ChartData.push(itemchild)
                            //     }
                            // }

                        })
                    }
                }

            })
            cd(null, ChartData)
        })
    }

    static populateshowchatviewmodelcommon(tags, hotelId, currentDate, configdata, cd) {
        
        let retValue;
        let x = "Consolidated Report";
        return new Promise((resolve, reject) => {
            CreateowntablemappingsHelper.GetTagList(x, (err, tagdata) => {

                if (err) {
                    reject(err);
                }
                resolve(tagdata)

            })
        }).then(tagdata => {
            let flag = false;
            let filteredlist = [];
            if (tagdata != null && tagdata.length > 0) {
                switch (tags) {
                    case "adr":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("ADR")) {
                                let owntablemapping = new Createowntablemappingmasterview();
                                owntablemapping.ID = key.ID;
                                owntablemapping.TableName = key.TableName;
                                owntablemapping.ColumName = key.ColumName;
                                owntablemapping.DisplayOrder = key.DisplayOrder;
                                owntablemapping.KPIKey = key.KPIKey;
                                owntablemapping.ParentKey = key.ParentKey;
                                owntablemapping.HasSubKey = key.HasSubKey;
                                filteredlist.push(owntablemapping)
                            }
                        })
                        break;
                    case "occ":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("Occ")) {
                                let owntablemapping = new Createowntablemappingmasterview();
                                owntablemapping.ID = key.ID;
                                owntablemapping.TableName = key.TableName;
                                owntablemapping.ColumName = key.ColumName;
                                owntablemapping.DisplayOrder = key.DisplayOrder;
                                owntablemapping.KPIKey = key.KPIKey;
                                owntablemapping.ParentKey = key.ParentKey;
                                owntablemapping.HasSubKey = key.HasSubKey;
                                filteredlist.push(owntablemapping)
                            }
                        })
                        break;
                    case "revpar":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("RevPAR")) {
                                let owntablemapping = new Createowntablemappingmasterview();
                                owntablemapping.ID = key.ID;
                                owntablemapping.TableName = key.TableName;
                                owntablemapping.ColumName = key.ColumName;
                                owntablemapping.DisplayOrder = key.DisplayOrder;
                                owntablemapping.KPIKey = key.KPIKey;
                                owntablemapping.ParentKey = key.ParentKey;
                                owntablemapping.HasSubKey = key.HasSubKey;
                                filteredlist.push(owntablemapping)
                            }
                        })
                        break;
                    case "ooocomp":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("OOO Rooms")) {
                                let owntablemapping = new Createowntablemappingmasterview();
                                owntablemapping.ID = key.ID;
                                owntablemapping.TableName = key.TableName;
                                owntablemapping.ColumName = key.ColumName;
                                owntablemapping.DisplayOrder = key.DisplayOrder;
                                owntablemapping.KPIKey = key.KPIKey;
                                owntablemapping.ParentKey = key.ParentKey;
                                owntablemapping.HasSubKey = key.HasSubKey;
                                filteredlist.push(owntablemapping)
                            }
                            if (key.ColumName.includes("Comp Rooms")) {
                                let owntablemapping = new Createowntablemappingmasterview();
                                owntablemapping.ID = key.ID;
                                owntablemapping.TableName = key.TableName;
                                owntablemapping.ColumName = key.ColumName;
                                owntablemapping.DisplayOrder = key.DisplayOrder;
                                owntablemapping.KPIKey = key.KPIKey;
                                owntablemapping.ParentKey = key.ParentKey;
                                owntablemapping.HasSubKey = key.HasSubKey;
                                filteredlist.push(owntablemapping)
                            }
                        })
                        break;
                    case "revenuebreakdown":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("Room") &&
                                key.ColumName.includes("OOO") == false &&
                                key.ColumName.includes("Plan") == false &&
                                key.ColumName.includes("Budget") == false &&
                                key.ColumName.includes("Comp") == false) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }


                            }

                            if (key.ColumName.includes("Other Income")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }

                            if (key.ColumName.includes("F&B")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("Outet")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("Food")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("beverage")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("GiftShop")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("parking")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("banquet")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("bar")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("restaurant")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            let Adjustments = new Createowntablemappingmasterview();
                            Adjustments.ColumName = "Adjustments";
                            filteredlist.push(Adjustments)


                        })
                        break;
                    case "rollingrevenue":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("Room") &&
                                key.ColumName.includes("OOO") == false &&
                                key.ColumName.includes("Sold") == false &&
                                key.ColumName.includes("LY") == false &&
                                key.ColumName.includes("Comp") == false) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }


                            }
                            if (key.ColumName.includes("MTD Budget")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("BOB")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("This Month")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                        })
                        break;
                    case "ActVsBudVsLastYr":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("Room") &&
                                key.ColumName.includes("OOO") == false &&
                                key.ColumName.includes("Sold") == false &&
                                key.ColumName.includes("Forecast") == false &&
                                key.ColumName.includes("Comp") == false) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }


                            }
                            if (key.ColumName.includes("MTD Budget")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("BOB")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("This Month")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                        })
                        break;
                    case "ADRVSRevPAR":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("ADR")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                            if (key.ColumName.includes("RevPAR")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                        })
                        break;
                    case "MarketCurrentVsLastYear":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("Room") &&
                                key.ColumName.includes("OOO") == false &&
                                key.ColumName.includes("Plan") == false &&
                                key.ColumName.includes("Budget") == false &&
                                key.ColumName.includes("Comp") == false) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }


                            }
                        })
                        break;
                    case "STR":
                        _.filter(tagdata, (key) => {
                            if (key.ColumName.includes("STR -")) {
                                if (key != null) {
                                    let owntablemapping = new Createowntablemappingmasterview();
                                    owntablemapping.ID = key.ID;
                                    owntablemapping.TableName = key.TableName;
                                    owntablemapping.ColumName = key.ColumName;
                                    owntablemapping.DisplayOrder = key.DisplayOrder;
                                    owntablemapping.KPIKey = key.KPIKey;
                                    owntablemapping.ParentKey = key.ParentKey;
                                    owntablemapping.HasSubKey = key.HasSubKey;
                                    filteredlist.push(owntablemapping)
                                }
                            }
                        })
                        break;
                    case "ARAging":
                        let ARAging = new Createowntablemappingmasterview();
                        ARAging.ColumName = "ARAging";
                        filteredlist.push(ARAging)
                        break;
                    case "CashData":
                        let CashData = new Createowntablemappingmasterview();
                        CashData.ColumName = "CashData";
                        filteredlist.push(CashData)
                        break;

                }

            }

            let actualtags = '';
            if (filteredlist != null && filteredlist.length) {
                let retValue = [];
                _.filter(filteredlist, (key) => {
                    retValue.push(key.ColumName)
                })

                actualtags = retValue.join(",");
            }



            let orgId;
            let userId;
            let yesterday = currentDate != null ? new Date(Utils.getFormattedDate(currentDate, 'YYYY-MM-DD')) : Utils.getFormattedDate(new Date(), 'YYYY-MM-DD');



            _.filter([configdata], (key) => {
                orgId = key.OrganizationId;
                userId = key.ID;
            })

            CommentsHelper.GetCommentsByUserId(orgId, userId, hotelId, yesterday, actualtags, (err, result) => {
                
                cd(null, result)
            })

        })

    }

    static GetCommentsByUserId(orgId, userId, hotelid, currentdate, tags, cd) {

        let lsttags;

        if (tags != null) {
            lsttags = tags.split(',');
        } else {
            lsttags = tags;
        }
        
        let filteredhotelCommentList = [];
        let hotelcommentAggregate = HotelcommentSchema.aggregate();
        hotelcommentAggregate.match({ [HotelcommentSchemaFields.HotelID]: hotelid })
        hotelcommentAggregate.lookup({
            from: dbtable.USER,
            let: { userId: `$${HotelcommentSchemaFields.UserID}` },
            pipeline: [

                {
                    $match:
                    {
                        $expr: { $eq: ["$$userId", `$${UserSchemaFields.ID}`] }
                    }

                },
                {
                    $project: {
                        "_id": 1,
                        [UserSchemaFields.UserName]: 1,
                        [UserSchemaFields.FirstName]: 1,
                        [UserSchemaFields.LastName]: 1
                    }
                }
            ],
            as: "user"
        }).lookup({
            from: dbtable.HOTELS,
            let: { hotelId: `$${HotelcommentSchemaFields.HotelID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: { $eq: ["$$hotelId", `$${HotelsSchemaFields.ID}`] }
                    }

                },
                {
                    $project: {
                        "_id": 1,
                        [HotelsSchemaFields.HotelName]: 1
                    }
                }
            ],
            as: "hotel"
        })

        hotelcommentAggregate.exec((err, result) => {
            let replies = [];
            if (result != null && result.length > 0) {

                _.filter(result, function (element) {
                   
                    
                    let hotelCommentList = new Hotelcommentview();
                    hotelCommentList.ID = element.ID;
                    hotelCommentList.HotelID = element.HotelID;
                    hotelCommentList.Tags = element.Tags;
                    hotelCommentList.Date = element.Date;
                    hotelCommentList.Description = element.Description;

                    if(element.user){
                        _.filter(element.user,(key)=>{
                            hotelCommentList.UserName = key.UserName;
                            hotelCommentList.FirstName = key.FirstName;
                            hotelCommentList.LastName = key.LastName;                            
                        })
                    }else{
                        hotelCommentList.UserName = "";
                        hotelCommentList.FirstName = "";
                        hotelCommentList.LastName = "";
                    }

                    if(element.hotel){
                        _.filter(element.hotel,(key)=>{
                            hotelCommentList.HotelName =key.HotelName;
                        })
                    }else{
                        hotelCommentList.HotelName = "";
                    }
                    hotelCommentList.UpdateDateTime = element.UpdateDateTime;
                    hotelCommentList.ParentID = element.ParentID != null ? element.ParentID : 0;
                    hotelCommentList.UserID = element.UserID != null ? element.UserID : 0;
                    replies.push(hotelCommentList)
                })


                if (replies != null && replies.length > 0) {
                    replies = _.map(_.groupBy(replies, 'ParentID'), (element, idx) => { return { ParentID: idx,data:element} });
                }

                let start = new Date(Utils.getFormattedDate(currentdate,"YYYY-MM-DD"));
                let end = Utils.endofDay(start);
               
                _.filter(replies, (key) => {


                    if (key.ParentID == 0) {

                        _.filter(key.data, (element) => {

                            let date = new Date(Utils.getFormattedDate(element.Date,"YYYY-MM-DD"));

                            let flag = false;

                            let  tagdata = element.Tags.split(',');
                             
                             _.filter(tagdata,(i)=>{
                                 flag = (lsttags.indexOf(i.toString()) > -1)
                             })
                            
                            if (date >= start && date <= end && flag) {
                                    element.DisplayDate = Utils.getFormattedDate(element.Date, "DD-MMM-YYYY");
                                    filteredhotelCommentList.push(element);
                            }
                        })

                        

                    } else {


                        let parentItem = [];

                        _.filter(filteredhotelCommentList, (val) => {
                            if (val.ID == key.ParentID) {
                                parentItem.push(val);
                            }
                        })




                        if (parentItem != null && parentItem.length > 0) {

                            if (parentItem.ChildComments == null) {
                                parentItem.ChildComments = new Hotelcommentview();
                            }
                            _.filter(parentItem, (element) => {
                                _.filter(element.ChildComments, (i) => {

                                    _.filter(key.data, (child) => {
                                        i.ID = child.ID;
                                        i.HotelID = child.HotelID;
                                        i.Date = child.Date;
                                        i.UserID = child.UserID;
                                        i.Tags = child.Tags;
                                        i.Description = child.Description;
                                        i.UpdateDateTime = child.UpdateDateTime;
                                        i.UpdatedBy = child.UpdatedBy;
                                        i.ParentID = child.ParentID;
                                        i.DisplayDate = child.DisplayDate;
                                        i.UserName = child.UserName;
                                        i.FirstName = child.FirstName;
                                        i.LastName = child.LastName;
                                        i.HotelName = child.HotelName;
                                    })

                                })

                            })

                        }

                    }


                })                
                cd(null, filteredhotelCommentList)
            } else {
                cd(null, filteredhotelCommentList)
            }
        })


    }

    static GetCommentsByUserTagsId(userid, currentdate, cb) {

        log.debug('Call GetCommentsByUserTagsId, userid:' + userid + 'currentdate: ' + currentdate);
        let hotelcommentAggregate = HotelcommentSchema.aggregate();
        let start = new Date(currentdate.getFullYear(), currentdate.getMonth(), currentdate.getDate());
        let end = new Date(currentdate.getFullYear(), currentdate.getMonth(), currentdate.getDate() + 1);

        hotelcommentAggregate.match({
            [HotelcommentSchemaFields.UserTags]: { $ne: null },
            [HotelcommentSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })

        hotelcommentAggregate.lookup({
            from: dbtable.HOTELS,
            let: { hotelId: `$${HotelcommentSchemaFields.HotelID}` },
            pipeline: [
                {
                    $match:
                    {
                        $expr: { $eq: ["$$hotelId", `$${HotelsSchemaFields.ID}`] }
                    }

                },
                {
                    $project: {
                        "_id": 1,
                        [HotelsSchemaFields.HotelName]: 1
                    }
                }
            ],
            as: "hotel"
        })


        return hotelcommentAggregate.exec((err, result) => {
            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("GetCommentsByUserTagsId result not found");
                return cb(null, null);
            }
            else {

                let fresult = result.filter(d => {
                    return (d.UserTags.split(",")
                        .map(function (el) {
                            return el.replace(/^\s+/, "")
                        }).indexOf(userid.toString()) != -1);
                });

                return cb(null, fresult);
            }
        });



    }

}

module.exports = CommentsHelper;
