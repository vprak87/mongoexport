const { Hotelgmloginmapping: HotelgmloginmappingSchema, SchemaField: HotelgmloginmappingSchemaFields } = require('../models/hotelgmloginmapping');
const Utils = require('../common/utils');
var log = require('log4js').getLogger("hotelgmloginmapping_helper");

class HotelgmloginmappingsHelper {

    static GetGMLoginData(lsthotelids, cb) {

        log.debug("Call GetGMLoginData");
        let start = Date.now();
        start = Utils.addDate(start, -1);

        return HotelgmloginmappingSchema.find({

            [HotelgmloginmappingSchemaFields.HotelID]: {
                $in: lsthotelids
            },
            [HotelgmloginmappingSchemaFields.LastGMLoginDateTime]: {
                $gte: start
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetGMLoginData result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }
    static GetLastGMLoginDateTimeData(lsthotelids, cb) {

        log.debug("Call GetLastGMLoginDateTimeData");
        let hotelgmloginmappingAggregate = HotelgmloginmappingSchema.aggregate();
        hotelgmloginmappingAggregate.match({
            [HotelgmloginmappingSchemaFields.HotelID]: {
                $in: lsthotelids
            }
        })

        hotelgmloginmappingAggregate.group({
            [HotelgmloginmappingSchemaFields._id]: `$${HotelgmloginmappingSchemaFields.HotelID}`,
            [HotelgmloginmappingSchemaFields.LastGMLoginDateTime]: { $max: `$${HotelgmloginmappingSchemaFields.LastGMLoginDateTime}` },
        })


        return hotelgmloginmappingAggregate.exec((err, result) => {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetLastGMLoginDateTimeData result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        });
    }
    static GetData(hotelid, date, cb){
        log.debug('Call GetDataBetweenDate, hotelid:' + hotelid + "startdate:" + date + "enddate:" + date);

        let start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        let end = new Date(date.getFullYear(), date.getMonth(), date.getDate()+1);
        return HotelgmloginmappingSchema.find({

            [HotelgmloginmappingSchemaFields.HotelID]:id,
            [HotelgmloginmappingSchemaFields.LastGMLoginDateTime]: {
                $gte: start,$lte: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetLastGMLoginDateTimeData result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        })    

    }
    static GetDataBetweenDate(id,start,end, cb) {
        HotelgmloginmappingSchema.find({

            [HotelgmloginmappingSchemaFields.HotelID]:id,
            [HotelgmloginmappingSchemaFields.LastGMLoginDateTime]: {
                $gte: start,$lte: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("GetLastGMLoginDateTimeData result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        })
    }



}
module.exports = HotelgmloginmappingsHelper;