const _ = require('lodash');
const Utils = require('../common/utils');

const { Missingdatesmaster: MissingdatesmasterSchema, SchemaField: MissingdatesmasterSchemaFields } = require('../models/missingdatesmaster');

var log = require('log4js').getLogger("missingdates_helper");

class MissingDatesHelper {

    static getMissingDates(hotelids, startDate, endDate, cb) {

        startDate = new Date(Utils.getFormattedDate(startDate, "YYYY-MM-DD"));
        endDate = new Date(Utils.getFormattedDate(endDate, "YYYY-MM-DD"));

        return MissingdatesmasterSchema.find({
            [MissingdatesmasterSchemaFields.HotelID]: { $in: hotelids },
            [MissingdatesmasterSchemaFields.Date]: {
                $gte: startDate,
                $lte: endDate
            }
        }, (err, revenuedata) => {
            if (err) {
                log.error(err);
            }
            cb(null, revenuedata);
        })

    }

}
module.exports = MissingDatesHelper;
