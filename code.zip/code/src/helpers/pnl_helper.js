const HoteldashboardcalculationsHelper = require('./hoteldashboardcalculations_helper');
const HotelbudgetdashboardcalculationsHelper = require('./hotelbudgetdashboardcalculations_helper');
const CreatePropertyDashboardTableMappingHelper = require('./createpropertydashboardtablemapping_helper');
const CreateowntablemappingsHelper = require('./createowntablemappings_helper');
const PnlTableColumData = require('../viewModel/pnltablecolumdata');
const PnlTableRowData = require('../viewModel/pnltablerowdata');
const Constants = require('../common/constants');
const Utils = require('../common/utils');
const _ = require('lodash');
const UserHelper = require('./user_helper');
const HotelsHelper = require('./hotels_helper');
const mdoglcodemaster = require('./mdoglcodemaster_helper');
const { CreatePnlTableMapping: CreatePnlTableMappingSchema, SchemaField: CreatePnlTableMappingSchemaFields } = require('../models/createpnltablemappings');
const { Hotelexpensedashboardcalculations: HotelexpensedashboardcalculationsSchema, SchemaField: HotelexpensedashboardcalculationsSchemaFields } = require('../models/hotelexpensedashboardcalculations');
const { Hotelbudgetexpenseform: HotelbudgetexpenseformSchema, SchemaField: HotelbudgetexpenseformSchemaFields } = require('../models/hotelbudgetexpenseform');
const { Hoteleffectivenesscalculations: HoteleffectivenesscalculationsSchema, SchemaField: HoteleffectivenesscalculationsSchemaFields } = require('../models/hoteleffectivenesscalculations');
const { Glcodemaster: GlcodemasterSchema, SchemaField: GlcodemasterSchemaFields } = require('../models/glcodemaster');

const PnlTableData = require('../viewModel/pnltabledata');
const SequenceHelper = require('./sequence_helper');
const dbtable = require('../schema/db_table');
const moment = require('moment');
const { constant } = require('lodash');
const { ParentId } = require('../schema/fields/mdoglcodemasterSchema');
var log = require('log4js').getLogger("PNLHelper");
const MDOGLCodeMasterData = require('../viewModel/mdoglcodemasterdata'); 
const HMGGLCodeMasterData = require('../viewModel/hmgglcodemasterdata'); 
const MDOGLCodeHMGMappingData = require('../viewModel/mdoglcodehmgmappingdata'); 
const MDOGLCodeMappingData = require('../viewModel/mdoglcodemappingtable')
const { MDOGLCodeMaster: MDOGLCodeMasterSchema, SchemaField: MDOGLCodeMasterSchemaFields } = require('../models/mdoglcodemaster');
const { HMGGLCodeMaster: HMGGLCodeMasterSchema, SchemaField: HMGGLCodeMasterSchemaFields } = require('../models/hmgglcodemaster');
const { MDOGLCodeHMGMapping: MDOGLCodeHMGMappingSchema, SchemaField: MDOGLCodeHMGMappingSchemaFields } = require('../models/mdoglcodehmgmapping');


class PNLHelper {
    //#region Table Column API
    
    static getPNLTable_GraphQL(userid, hotelid, currentDate, cb) {
        //get myp hotelid from cmp_id
        return HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
            if (err) {
                cb(err, null);
            }
            if (!hoteldata) {
                cb(Constants.HotelNotFound, null);
            }
            else {
                PNLHelper.getPNLTable(userid, hoteldata.ID,hoteldata.OrganizationID,currentDate, cb, (err, result) => {
                    if (err) {
                        cb(err, null);
                    }
                    cb(null, result);
                });
            }
        });
    
    }

    static getPnlTableMapping_GraphQL(userid,pnltype, cb) {
        PNLHelper.getPnlTableMapping(userid,pnltype, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }

    static updatetablecolumn_GraphQL(userid, oldcolumname, oldcolumperiod, newcolumname, newcolumperiod,pnltype, cb) {
        return PNLHelper.updateTableColumn(userid, oldcolumname, oldcolumperiod, newcolumname, newcolumperiod,pnltype, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });

    }

    static getTableColumnLookupData_GraphQL(tablename, cb) {
        return CreateowntablemappingsHelper.getColumnMasterListData(tablename, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }    
    
	static getPnlTableMapping(userId,pnltype,cb){
          
        return CreatePnlTableMappingSchema.find({
            [CreatePnlTableMappingSchemaFields.UserID]: userId,
            [CreatePnlTableMappingSchemaFields.PNLType]: pnltype

        }).sort({ [CreatePnlTableMappingSchemaFields.DiplayOrder]: -1 }).exec(function (err, result2) {
            if (err) {
                log.error(err);
            }
            
            var lstPnlTable=[];
            if(result2.length > 0){
                result2.forEach((element, index) => {
                    var PnlTable = new PnlTableData();
                    PnlTable.id = element.ID,
                    PnlTable.columname = element.ColumName,
                    PnlTable.columperiod = element.ColumPeriod,
                    PnlTable.displayorder = element.DisplayOrder,
                    PnlTable.userid = element.UserID,
                    PnlTable.pnltype = element.PNLType
                    lstPnlTable.push(PnlTable);
                });
                return cb(null, lstPnlTable);
            }
            else{
                var columns = [];
                var lstColumns = [];
                if(pnltype == Constants.PNLType.PNLYearly){
                    columns.push({ columname: "ACTUALS",columperiod:"Current" });
                }
                else{
                    columns.push({ columname: "BUDGET",columperiod:"Current" });
                    columns.push({ columname: "ACTUALS",columperiod:"Current" });
                    columns.push({ columname: "FORECAST",columperiod:"Current" });
                }
                var disInd = 0;

                columns.forEach(function (item) {
                    log.debug('Call add PNL Columns, userid:' + userId + 'columname:' + item.columname + 'columperiod:' + item.columperiod);
                
                    //InsertCreateOwnTableMapping
                    SequenceHelper.getValueForNextSequence(dbtable.CREATEPNLTABLEMAPPINGS, (err, seq_result) => {
                        if (seq_result) {
                            let id = parseInt(seq_result);
                            disInd++; 
                            var createPnlTablemappings = {
                                [CreatePnlTableMappingSchemaFields.ID]: id,
                                [CreatePnlTableMappingSchemaFields.DisplayOrder]: disInd,
                                [CreatePnlTableMappingSchemaFields.ColumName]: item.columname,
                                [CreatePnlTableMappingSchemaFields.ColumPeriod]: item.columperiod,
                                [CreatePnlTableMappingSchemaFields.UserID]: userId,
                                [CreatePnlTableMappingSchemaFields.PNLType]: pnltype
                            };

                            let createpnltablemappingsSchema = new CreatePnlTableMappingSchema(createPnlTablemappings);
                            createpnltablemappingsSchema.save((err, createpnltablemapping_result) => {
                                if (err)
                                    return cb(err, null);
                                else {

                                    var PnlTable = new PnlTableData();
                                    PnlTable.id = createpnltablemapping_result.ID,
                                    PnlTable.columname = createpnltablemapping_result.ColumName,
                                    PnlTable.columperiod = createpnltablemapping_result.ColumPeriod,
                                    PnlTable.displayorder = createpnltablemapping_result.DisplayOrder,
                                    PnlTable.userid = createpnltablemapping_result.UserID,
                                    PnlTable.pnltype = createpnltablemapping_result.PNLType

                                    lstColumns.push(PnlTable)
                                }
                            })
                        }
                    });                   
                })   
                return cb(null, lstColumns);             
            }     
        });       
    }

    static updateTableColumn(userid, oldcolumname, oldcolumperiod,newcolumname, newcolumperiod,pnltype, cb) {
        log.debug('Call updateTableColumn, userid:' + userid + 'oldcolumname: ' + oldcolumname + "oldcolumperiod:" + oldcolumperiod + "newcolumname" + newcolumname);
        
        //CreatePnlTableMappingSchema
        CreatePnlTableMappingSchema.findOneAndUpdate(
            {
                [CreatePnlTableMappingSchemaFields.ColumName]: oldcolumname ,
                [CreatePnlTableMappingSchemaFields.ColumPeriod]: oldcolumperiod,
                [CreatePnlTableMappingSchemaFields.UserID]: userid ,
                [CreatePnlTableMappingSchemaFields.PNLType]: pnltype 

            },
            {
                [CreatePnlTableMappingSchemaFields.ColumName]: newcolumname ,
                [CreatePnlTableMappingSchemaFields.ColumPeriod]: newcolumperiod,
            },
            {
                new: true
            }
        ).exec((err, result) => {           
            if (err) {
                log.error(err);
            }
            var lstPnlTable=[];
            if(result){
                var PnlTable = new PnlTableData();
                PnlTable.id = result.ID,
                PnlTable.columname = result.ColumName,
                PnlTable.columperiod = result.ColumPeriod,
                PnlTable.displayorder = result.DisplayOrder,
                PnlTable.userid = result.UserID,
                PnlTable.pnltype = result.PNLType

                lstPnlTable.push(PnlTable);
            }
            return cb(null, PnlTable);
        })
    }
    //#endregion

    //#region PNL Monthly Table
    static getPNLTable(userId, hotelid, orgID, currentDate, cb) {
        
        return new Promise((resolve, reject) => {
            let tableRowmappingsData = [];
            let tableColummappingsData = [];
            let TableData = [];

            Promise.all([     
                new Promise((resolve, reject) => {
                    CreateowntablemappingsHelper.getColumnMasterListData(Constants.DashboardTableName.PNLTableRowName, 
                    (err, result) => {
                        if (err) {
                            log.error(err)
                            reject(err);
                        }

                        tableRowmappingsData = result;
                        resolve();
                    });
                }),       
                new Promise((resolve, reject) => {
                    PNLHelper.getPnlTableMapping(userId,Constants.PNLType.PNLMonthly, (err, tablemappings_result) => {
                        if (err) {
                            log.error(err)
                            reject(err);
                        }
                        if (tablemappings_result) {
                            tableColummappingsData = tablemappings_result;
                        }
                        resolve();
                    });
                })
            ]).then(resp => {
                let prArr = [];
                if(tableRowmappingsData.length > 0){
                    tableRowmappingsData.forEach(async (rowItem, index) => {
                        let rowName = rowItem.kpikey;
                        let objRow = new PnlTableRowData();
                        prArr.push(
                            new Promise((resolve, reject) => {
                                PNLHelper.getTableColumndata(rowName, tableColummappingsData, currentDate, hotelid, ColumnValueDate_result  => {
                                
                                    objRow.rowname = rowItem.columname;
                                    objRow.roworder = rowItem.displayorder;
                                    objRow.glcode = '0000.00';
                                    objRow.id = rowItem.id;
                                    objRow.parentid = 0;
                                    objRow.rowdata = ColumnValueDate_result;
                                    TableData.push(objRow);
                                    resolve();
                                });
                            })
                        )
                    });
                }
                else{
                    prArr = [];
                }

                // Dynamic records based on P&L Setttings
                Promise.all(prArr).then(res => {                    
                    let  lstRevenue = Utils.sort(TableData,"roworder");
                    let lstRevenueCnt = lstRevenue.length;

                    // new Promise((resolve,reject) => {
                    //     mdoglcodemaster.getMDOGLCodeMasterMappingOnlyActives(orgID,(err,monthlyResult) => {
                    //         if(err){
                    //             reject(err);
                    //         }
                    //         else{
                    //            // monthlyResult = monthlyResult.MDOGLCodeMappingTable;
                    //            if (monthlyResult != null)
                    //           monthlyResult.forEach(item =>{

                    //             let parent = monthlyResult.find(parentitem => parentitem.ID = item.ParentId);
                    //             let parentMappingStatus = (item.ParentId == 0)?true:parent.MappingStatus;

                    //             if(item.MappingStatus == true && parentMappingStatus == true){
                    //                 let rowName = item.DisplayDescription ==''?item.Description:item.DisplayDescription;;
                    //                 let objRow = new PnlTableRowData();
                    //                 prArr.push(
                    //                     new Promise((resolve, reject) => {
                    //                         PNLHelper.getTableColumndata(rowName, tableColummappingsData, currentDate, hotelid, ColumnValueDate_result  => {
                                            
                    //                             objRow.rowname = rowName;
                    //                             objRow.roworder = lstRevenueCnt;
                    //                             objRow.glcode = item.GLCode;
                    //                             objRow.id = item.ID;
                    //                             objRow.parentid = item.ParentId;
                    //                             objRow.rowdata = ColumnValueDate_result;
                    //                             lstRevenueCnt++;
                    //                             lstRevenue.push(objRow);
                    //                             resolve();
                    //                         });
                    //                     })
                    //                 )
                    //             }
              
                    //           })
                            
                    //           resolve();
                    //       }
                    //       })
                    // })
                   
                   

               PNLHelper.getExpensesdataFilterActives( orgID,tableColummappingsData, currentDate, hotelid,lstRevenue, expDate_result  => {
                 //  PNLHelper.getExpensesdata( tableColummappingsData, currentDate, hotelid,lstRevenue, expDate_result  => {
                   
                        PNLHelper.getLabourExpenseData(tableColummappingsData, currentDate, hotelid,lstRevenue, expDate_result  => {
                            resolve();
                            return cb(null, lstRevenue);
                        });  
                    });                   
                });
            })
        })
    }

    static getTableColumndata(rowName, tableColummappingsData, currentDate, hotelid, cb) {

        let yeasterday = new Date(currentDate);
        let startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
        let enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
        
        let ColumnValueDate = [];
        let hoteldashboardcalculationsData = [];
        let hotelbudgetdashboardcalculationsData = [];
        let cnt = tableColummappingsData.length;
        // return new Promise((resolve, reject) => {
      
            tableColummappingsData.forEach((colItem, index) => {

                if (colItem.columperiod == 'Current' || colItem.columperiod == 'MTD' || colItem.columperiod == 'YTD') {
                    startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                    enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
                }                
                else if (colItem.columperiod == 'QTD') {
                    let now = new Date();
                    let quarter = Math.floor((now.getMonth() / 3));
                    startdate = new Date(now.getFullYear(), quarter * 3, 1);
                    enddate = new Date(startdate.getFullYear(), startdate.getMonth() + 3, 0);
                }
                else {
                    startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                    enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
                }

                Promise.all([
                    new Promise((resolve, reject) => {
                        HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, hoteldashboardcalculations_result) => {
                            
                            if (hoteldashboardcalculations_result) {
                                hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                            }
                            resolve();
                        });
                    }),
                    new Promise((resolve, reject) => {
                        HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(hotelid, startdate, enddate, (err, hotelbudgetdashboardcalculations_result) => {
                            
                            if (hotelbudgetdashboardcalculations_result) {
                                hotelbudgetdashboardcalculationsData = hotelbudgetdashboardcalculations_result;
                            }
                            resolve();
                        });
                    }),
                ]).then(resp => {
                    let rowCatName = '';
                    let rowBudgetCatName = '';
                    let rowForecastCatName = '';
                    let ColumPeriod = '';
                    let columnvalue = 0;
                    let smactual = 0;
                    let smbudget = 0;
                    let smforcast = 0;
                    let objColum = new PnlTableColumData();
                    if (colItem.columperiod == 'Current' || colItem.columperiod == 'CurrentMonth' ||colItem.columperiod == 'MTD' || colItem.columperiod == 'YTD' || colItem.ColumPeriod == 'TTM') {
                        ColumPeriod = colItem.columperiod == ('Current' || 'CurrentMonth') ? '' : colItem.columperiod;
                        rowCatName = rowName + ColumPeriod;
                        rowBudgetCatName = (colItem.columperiod == ('Current' || 'CurrentMonth') ? 'Budget' : colItem.columperiod) + rowName;
                        rowForecastCatName = (colItem.columperiod == 'Current' ? '' : colItem.columperiod) + 'Forecast' + rowName;
                    }
                    else {
                        rowCatName = rowName;
                    }
                    if(rowName == 'NoOfRoomSold')
                    {
                        rowBudgetCatName =  (colItem.columperiod == 'Current' ? ''+'BudgetRoomSold' : colItem.columperiod+'BudgetRooms') ;
                        rowForecastCatName = (colItem.columperiod == 'Current' ? '' : colItem.columperiod)+'ForecastRoomSold';
                    }
                    else if(rowName == 'AvailableRooms'){
                        rowBudgetCatName ='BudgetNumberofAvailableRooms';
                        rowForecastCatName = 'BudgetNumberofAvailableRooms' ;
                    }

                    if (colItem.columname == 'ACTUALS') {
                        smactual = _.sumBy(hoteldashboardcalculationsData, rowCatName);
                        columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                    }
                    else if (colItem.columname == 'BUDGET') {
                        smbudget = _.sumBy(hotelbudgetdashboardcalculationsData, rowBudgetCatName);
                        columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                    }
                    else if (colItem.columname == 'FORECAST') {
                        smforcast = _.sumBy(hotelbudgetdashboardcalculationsData, rowForecastCatName);
                        columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                    }

                    objColum.columnvalue = columnvalue;
                    objColum.columnname = colItem.columname;
                    objColum.columnperiod = colItem.columperiod;
                    ColumnValueDate.push(objColum);

                    if (cnt == ColumnValueDate.length) {
                        return cb(ColumnValueDate);
                    }
                })
            });
       
        // });     
    }

    static getExpensesdataOnlyActive(organizationid,tableColummappingsData, currentDate, hotelid,lstRevenue,cb) {
        return new Promise((resolve, reject) => {
            let hotelExpensDataList = [];       
            let hotelbudgetlist  = [];     
            let cnt = lstRevenue.length+1;
            let yeasterday = new Date(currentDate);
            let startdate = new Date(yeasterday.getFullYear(), 1,1, 0, 0, 0);
            let enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
                        
            Promise.all([
            new Promise((resolve, reject) => {



                var lstMDOGLCodeMasterData = [];
                let mdohmgMappingAggregate = MDOGLCodeHMGMappingSchema.aggregate();
                
                mdohmgMappingAggregate.match({
                     [MDOGLCodeHMGMappingSchemaFields.OrganizationID]: organizationid ,
                    [MDOGLCodeHMGMappingSchemaFields.Status]: true 
                    
                })

                mdohmgMappingAggregate.lookup({
                    from: dbtable.MDOGLCODEMASTER,
                    let: { glcode: `$${MDOGLCodeHMGMappingSchemaFields.MDOGLCode}` },
                    pipeline: [
                        {
                            $match:
                            {
                                $expr: { $eq: ["$$glcode", `$${MDOGLCodeMasterSchemaFields.GLCode}`] }
                            }
        
                        },
                        {
                            $project: {
                                "_id": 1,
                                [MDOGLCodeMasterSchemaFields.GLCode]: 1,
                                [MDOGLCodeMasterSchemaFields.ID]: 1,
                                [MDOGLCodeMasterSchemaFields.ParentId]: 1,
                                [MDOGLCodeMasterSchemaFields.IsActive]: 1,
                                [MDOGLCodeMasterSchemaFields.Description]: 1,
                                [MDOGLCodeMasterSchemaFields.DisplayDescription]: 1,
                           }
                        }
                    ],
                    as: "mdoglmaster"
                })
        
                mdohmgMappingAggregate.lookup({
                    from: dbtable.HOTELEXPENSEDASHBOARDCALCULATION,
                    let: { glcode: `$${MDOGLCodeHMGMappingSchemaFields.HMGGLCode}` },
                    pipeline: [
                        {
                            $match:
                            {
                             "HotelID":hotelid,
                              "Category": { $in: ["Expense","UndistributedExpense","FixedExpense","ITDAExpense"]},
                                "Date": { "$gte": startdate, "$lt": enddate},      
                                $expr: { $eq: ["$$glcode", `$${HotelexpensedashboardcalculationsSchemaFields.GLCode}`] }
                            }
        
                        },
                        {
                            $project: {
                                "_id": 1,
                                [HotelexpensedashboardcalculationsSchemaFields.GLCode]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.ID]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.HotelID]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.Date]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.Description]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.Category]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.Expense]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.MTDExpense]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.YTDExpense]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.MTDBudget]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.YTDBudget]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.MTDForecast]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.YTDforecast]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.DisplayDescription]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.UpdatedBy]: 1,
                                [HotelexpensedashboardcalculationsSchemaFields.UpdatedDateTime]: 1,
                           }
                        }
                    ],
                    as: "hotelexpense"
                })

                mdohmgMappingAggregate.lookup({
                    from: dbtable.HOTELBUDGETEXPENSEFORM,
                    let: { glcode: `$${MDOGLCodeHMGMappingSchemaFields.HMGGLCode}` },
                    pipeline: [
                        {
                            $match:
                            {
                             "HotelID":hotelid,
                            "IsDelete": false,
                            "DateFrom": { "$gte": new Date(startdate) }, 
                            "DateTo": {"$lte": new Date(enddate) } , 
                                $expr: { $eq: ["$$glcode", `$${HotelbudgetexpenseformSchemaFields.GLCode}`] }
                            }
        
                        },
                        {
                            $project: {
                                "_id": 1,
                                [HotelbudgetexpenseformSchemaFields.GLCode]: 1,
                                [HotelbudgetexpenseformSchemaFields.ID]: 1,
                                [HotelbudgetexpenseformSchemaFields.HotelID]: 1,
                                [HotelbudgetexpenseformSchemaFields.HotelName]: 1,
                                [HotelbudgetexpenseformSchemaFields.DepartmentID]: 1,
                                [HotelbudgetexpenseformSchemaFields.DateFrom]: 1,
                                [HotelbudgetexpenseformSchemaFields.DateTo]: 1,
                                [HotelbudgetexpenseformSchemaFields.IsGLCodeBudget]: 1,
                                [HotelbudgetexpenseformSchemaFields.TotalHotelBudget]: 1,
                                [HotelbudgetexpenseformSchemaFields.HotelBudgetHours]: 1,
                                [HotelbudgetexpenseformSchemaFields.UpdatedBy]: 1,
                                [HotelbudgetexpenseformSchemaFields.UpdatedDateTime]: 1,
                                [HotelbudgetexpenseformSchemaFields.IsDelete]: 1,
                           }
                        }
                    ],
                    as: "hotelbudgetexpense"
                })
        
                return mdohmgMappingAggregate.exec((err, result) => {
                    if (err) {
                        log.error(err);
                    }
                    if (!result || result.length == 0) {
                        log.debug("MDOGL and HMG GL mapping result not found");
                        log.error(err);
                        reject(err);
                    }
                    else {
                        result.forEach(x=>  {
                            if (x.hotelexpense && x.hotelexpense.length > 0)
                                hotelExpensDataList.push(x.hotelexpense)
                            if (x.hotelbudgetexpense && x.hotelbudgetexpense.length > 0)
                                hotelbudgetlist.push(x.hotelbudgetexpense)
                        });
                        
                        resolve();
                    }
                });



                // HotelexpensedashboardcalculationsSchema.find({[HotelexpensedashboardcalculationsSchemaFields.HotelID]: hotelid, [HotelexpensedashboardcalculationsSchemaFields.Category]: { $in: ["Expense","UndistributedExpense","FixedExpense","ITDAExpense"]}, [HotelexpensedashboardcalculationsSchemaFields.Date]: { "$gte": startdate, "$lt": enddate}},
                // (err, resp) => {
                //     // console.log(resp, 'hotelExpensDataList');
                //     if(err) {
                //         log.error(err)
                //         reject(err);
                //     }
                //     hotelExpensDataList = resp;
                //     resolve();
                // })
            })
            // ,
            // new Promise((resolve, reject) => {
                
            //     HotelbudgetexpenseformSchema.find({ [HotelbudgetexpenseformSchemaFields.HotelID]: hotelid, 
            //     [HotelbudgetexpenseformSchemaFields.IsDelete]: false, 
            //     [HotelbudgetexpenseformSchemaFields.DateFrom]: { "$gte": new Date(startdate) }, 
            //     [HotelbudgetexpenseformSchemaFields.DateTo]: {"$lte": new Date(enddate) } }, 
            //     (err, resultset) => {
            //         if(err) {
            //         log.error(err);
            //         reject(err);
            //         }
            //         hotelbudgetlist = resultset;
            //         resolve();
            //     })
            //     })
            ])
            
        .then(res=> {
            let prArr = [];
            let groupdata = _(hotelExpensDataList)
                    .groupBy('DisplayDescription')
                    .map((objs, Key) => ({
                        'DisplayDescription': Key,
                        // 'DisplayDescription': _.get(_.find(objs, function(o) { return true; }), 'DisplayDescription') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'DisplayDescription'),
                        'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'GLCode')
                        })).value();
            if(groupdata.length > 0) {
                groupdata.forEach(element => {
                prArr.push(
                    new Promise((resolve, reject) => {                
                    let ColumnValueDate =[];
                    tableColummappingsData.forEach((colItem, index) => {  
                        var lstExp = [];
                        let columnvalue = 0;
                        let smactual = 0;
                        let smbudget = 0;
                        let smforcast = 0;
                        let objColum = new PnlTableColumData();
                        let startdate = new Date();
                        let enddate = new Date();
                        let rowBudgetCatName = (colItem.columperiod == ('Current' || 'Month') ? '' : colItem.columperiod) + 'Budget';
                        let rowForecastCatName = (colItem.columperiod == ('Current'|| 'Month') ? '' : colItem.columperiod) + 'Forecast';        
                        
                        if (colItem.columperiod == "MTD")
                        {
                            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
                            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                        } 
                        else if (colItem.columperiod == 'QTD') {
                            let now = new Date();
                            let quarter = Math.floor((now.getMonth() / 3));
                            startdate = new Date(now.getFullYear(), quarter * 3, 1);
                            enddate = new Date(startdate.getFullYear(), startdate.getMonth() + 3, 0);
                        }
                        else if (colItem.columperiod == "YTD")
                        {
                            startdate = new Date(yeasterday.getFullYear(), 1, 1, 0, 0, 0);
                            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                        }
                        else
                        {
                            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                        }
    
                        lstExp = hotelExpensDataList.filter(d => {
                            var stime = new Date(d.Date);
                            var etime = new Date(d.Date);
                            return (d.DisplayDescription === element.DisplayDescription && stime >= startdate && etime <= enddate);
                        });
                        let lstBud = hotelbudgetlist.filter(d => {
                            var stime = new Date(d.DateFrom);
                            var etime = new Date(d.DateTo);
                            return (d.Description === element.DisplayDescription && stime >= startdate && etime <= enddate);
                        });
                        if (colItem.columname == 'ACTUALS') {
                            smactual = _.sumBy(lstExp, 'Expense');
                            columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                        }
                        else if (colItem.columname == 'BUDGET') {
                            smbudget = _.sumBy(lstExp, rowBudgetCatName);
                            if(smbudget == null || 0){
                                smbudget = _.sumBy(lstBud, 'TotalHotelBudget');
                            }
                            columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                        }
                        else if (colItem.columname == 'FORECAST') {
                            smforcast = _.sumBy(lstExp, rowForecastCatName);
                            if(smbudget == null || 0){
                                smbudget = _.sumBy(lstBud, 'TotalHotelForcast');
                            }
                            columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                        }
    
                        objColum.columnvalue = columnvalue;
                        objColum.columnname = colItem.columname;
                        objColum.columnperiod = colItem.columperiod;
                        ColumnValueDate.push(objColum);
    
                        if(tableColummappingsData.length == ColumnValueDate.length){
                            cnt++;
                            let objRow = new PnlTableRowData();
                            objRow.rowname = element.DisplayDescription;
                            objRow.glcode = element.GLCode;
                            objRow.rowdata = ColumnValueDate;
                            objRow.roworder = cnt;
                            lstRevenue.push(objRow);
                            resolve();
                        }
                    })                    
                    })
                )
                })
            } else {
                prArr = [];
            }
            Promise.all(prArr).then(res => {
                resolve();
                return cb(lstRevenue);
            });
            })
        })
        }


    static getExpensesdata(tableColummappingsData, currentDate, hotelid,lstRevenue,cb) {
    return new Promise((resolve, reject) => {
        let hotelExpensDataList = [];       
        let hotelbudgetlist  = [];     
        let cnt = lstRevenue.length+1;
        let yeasterday = new Date(currentDate);
        let startdate = new Date(yeasterday.getFullYear(), 1,1, 0, 0, 0);
        let enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
        let mdohmgmappingslist  = [];       
        Promise.all([
            new Promise((resolve,reject) => {
                    mdoglcodemaster.getMDOGLCodeMasterMappingOnlyActives(orgID,(err,mdohmgmappings) => {
                        if(err){
                            reject(err);
                        }
                        else{
                          if (mdohmgmappings != null)
                            mdohmgmappingslist = mdohmgmappings;                        
                          resolve();
                      }
                      })
                }),
        new Promise((resolve, reject) => {
            HotelexpensedashboardcalculationsSchema.find({[HotelexpensedashboardcalculationsSchemaFields.HotelID]: hotelid, [HotelexpensedashboardcalculationsSchemaFields.Category]: { $in: ["Expense","UndistributedExpense","FixedExpense","ITDAExpense"]}, [HotelexpensedashboardcalculationsSchemaFields.Date]: { "$gte": startdate, "$lt": enddate}},
            (err, resp) => {
                // console.log(resp, 'hotelExpensDataList');
                if(err) {
                    log.error(err)
                    reject(err);
                }
                hotelExpensDataList = resp;
                resolve();
            })
        }),
        new Promise((resolve, reject) => {
            HotelbudgetexpenseformSchema.find({ [HotelbudgetexpenseformSchemaFields.HotelID]: hotelid, 
            [HotelbudgetexpenseformSchemaFields.IsDelete]: false, 
            [HotelbudgetexpenseformSchemaFields.DateFrom]: { "$gte": new Date(startdate) }, 
            [HotelbudgetexpenseformSchemaFields.DateTo]: {"$lte": new Date(enddate) } }, 
            (err, resultset) => {
                if(err) {
                log.error(err);
                reject(err);
                }
                hotelbudgetlist = resultset;
                resolve();
            })
            })
        ]).then(res=> {
        let prArr = [];
        let groupdata = _(hotelExpensDataList)
                .groupBy('DisplayDescription')
                .map((objs, Key) => ({
                    'DisplayDescription': Key,
                    // 'DisplayDescription': _.get(_.find(objs, function(o) { return true; }), 'DisplayDescription') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'DisplayDescription'),
                    'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'GLCode')
                    })).value();
        if(groupdata.length > 0) {
            groupdata.forEach(element => {
            prArr.push(
                new Promise((resolve, reject) => {                
                let ColumnValueDate =[];
                tableColummappingsData.forEach((colItem, index) => {  
                    var lstExp = [];
                    let columnvalue = 0;
                    let smactual = 0;
                    let smbudget = 0;
                    let smforcast = 0;
                    let objColum = new PnlTableColumData();
                    let startdate = new Date();
                    let enddate = new Date();
                    let rowBudgetCatName = (colItem.columperiod == ('Current' || 'Month') ? '' : colItem.columperiod) + 'Budget';
                    let rowForecastCatName = (colItem.columperiod == ('Current'|| 'Month') ? '' : colItem.columperiod) + 'Forecast';        
                    
                    if (colItem.columperiod == "MTD")
                    {
                        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
                        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                    } 
                    else if (colItem.columperiod == 'QTD') {
                        let now = new Date();
                        let quarter = Math.floor((now.getMonth() / 3));
                        startdate = new Date(now.getFullYear(), quarter * 3, 1);
                        enddate = new Date(startdate.getFullYear(), startdate.getMonth() + 3, 0);
                    }
                    else if (colItem.columperiod == "YTD")
                    {
                        startdate = new Date(yeasterday.getFullYear(), 1, 1, 0, 0, 0);
                        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                    }
                    else
                    {
                        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                    }

                    lstExp = hotelExpensDataList.filter(d => {
                        var stime = new Date(d.Date);
                        var etime = new Date(d.Date);
                        return (d.DisplayDescription === element.DisplayDescription && stime >= startdate && etime <= enddate);
                    });
                    let lstBud = hotelbudgetlist.filter(d => {
                        var stime = new Date(d.DateFrom);
                        var etime = new Date(d.DateTo);
                        return (d.Description === element.DisplayDescription && stime >= startdate && etime <= enddate);
                    });
                    if (colItem.columname == 'ACTUALS') {
                        smactual = _.sumBy(lstExp, 'Expense');
                        columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                    }
                    else if (colItem.columname == 'BUDGET') {
                        smbudget = _.sumBy(lstExp, rowBudgetCatName);
                        if(smbudget == null || 0){
                            smbudget = _.sumBy(lstBud, 'TotalHotelBudget');
                        }
                        columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                    }
                    else if (colItem.columname == 'FORECAST') {
                        smforcast = _.sumBy(lstExp, rowForecastCatName);
                        if(smbudget == null || 0){
                            smbudget = _.sumBy(lstBud, 'TotalHotelForcast');
                        }
                        columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                    }

                    objColum.columnvalue = columnvalue;
                    objColum.columnname = colItem.columname;
                    objColum.columnperiod = colItem.columperiod;
                    ColumnValueDate.push(objColum);

                    if(tableColummappingsData.length == ColumnValueDate.length){
                        cnt++;
                        let objRow = new PnlTableRowData();
                        objRow.rowname = element.DisplayDescription;
                        objRow.glcode = element.GLCode;
                        objRow.rowdata = ColumnValueDate;
                        objRow.roworder = cnt;
                        lstRevenue.push(objRow);
                        resolve();
                    }
                })                    
                })
            )
            })
        } else {
            prArr = [];
        }
        Promise.all(prArr).then(res => {
            resolve();
            return cb(lstRevenue);
        });
        })
    })
    }

    static getExpensesdataFilterActives(orgID,tableColummappingsData, currentDate, hotelid,lstRevenue,cb) {
        return new Promise((resolve, reject) => {
            let hotelExpensDataList = [];       
            let hotelbudgetlist  = [];     
            let cnt = lstRevenue.length+1;
            let yeasterday = new Date(currentDate);
            let startdate = new Date(yeasterday.getFullYear(), 1,1, 0, 0, 0);
            let enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
            let mdohmgmappingslist  = [];       
            Promise.all([
                new Promise((resolve,reject) => {
                        mdoglcodemaster.getMDOGLCodeMasterMappingOnlyActives(orgID,(err,mdohmgmappings) => {
                            if(err){
                                reject(err);
                            }
                            else{
                              if (mdohmgmappings != null)
                                mdohmgmappingslist = mdohmgmappings;                        
                              resolve();
                          }
                          })
                    }),
            new Promise((resolve, reject) => {
                HotelexpensedashboardcalculationsSchema.find({[HotelexpensedashboardcalculationsSchemaFields.HotelID]: hotelid, [HotelexpensedashboardcalculationsSchemaFields.Category]: { $in: ["Expense","UndistributedExpense","FixedExpense","ITDAExpense"]}, [HotelexpensedashboardcalculationsSchemaFields.Date]: { "$gte": startdate, "$lt": enddate}},
                (err, resp) => {
                    // console.log(resp, 'hotelExpensDataList');
                    if(err) {
                        log.error(err)
                        reject(err);
                    }
                    hotelExpensDataList = resp;
                    resolve();
                })
            }),
            new Promise((resolve, reject) => {
                HotelbudgetexpenseformSchema.find({ [HotelbudgetexpenseformSchemaFields.HotelID]: hotelid, 
                [HotelbudgetexpenseformSchemaFields.IsDelete]: false, 
                [HotelbudgetexpenseformSchemaFields.DateFrom]: { "$gte": new Date(startdate) }, 
                [HotelbudgetexpenseformSchemaFields.DateTo]: {"$lte": new Date(enddate) } }, 
                (err, resultset) => {
                    if(err) {
                    log.error(err);
                    reject(err);
                    }
                    hotelbudgetlist = resultset;
                    resolve();
                })
                })
            ]).then(res=> {
                hotelExpensDataList = hotelExpensDataList.filter(x=> mdohmgmappingslist.findIndex(y=> y.HMGGLCode == x.GLCode ) > -1);
                hotelbudgetlist = hotelbudgetlist.filter(x=> mdohmgmappingslist.findIndex(y=> y.HMGGLCode == x.GLCode ) > -1);

            let prArr = [];
            let groupdata = _(hotelExpensDataList)
                    .groupBy('DisplayDescription')
                    .map((objs, Key) => ({
                        'DisplayDescription': Key,
                        // 'DisplayDescription': _.get(_.find(objs, function(o) { return true; }), 'DisplayDescription') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'DisplayDescription'),
                        'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'GLCode')
                        })).value();
            if(groupdata.length > 0) {
                groupdata.forEach(element => {
                prArr.push(
                    new Promise((resolve, reject) => {                
                    let ColumnValueDate =[];
                    tableColummappingsData.forEach((colItem, index) => {  
                        var lstExp = [];
                        let columnvalue = 0;
                        let smactual = 0;
                        let smbudget = 0;
                        let smforcast = 0;
                        let objColum = new PnlTableColumData();
                        let startdate = new Date();
                        let enddate = new Date();
                        let rowBudgetCatName = (colItem.columperiod == ('Current' || 'Month') ? '' : colItem.columperiod) + 'Budget';
                        let rowForecastCatName = (colItem.columperiod == ('Current'|| 'Month') ? '' : colItem.columperiod) + 'Forecast';        
                        
                        if (colItem.columperiod == "MTD")
                        {
                            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
                            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                        } 
                        else if (colItem.columperiod == 'QTD') {
                            let now = new Date();
                            let quarter = Math.floor((now.getMonth() / 3));
                            startdate = new Date(now.getFullYear(), quarter * 3, 1);
                            enddate = new Date(startdate.getFullYear(), startdate.getMonth() + 3, 0);
                        }
                        else if (colItem.columperiod == "YTD")
                        {
                            startdate = new Date(yeasterday.getFullYear(), 1, 1, 0, 0, 0);
                            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                        }
                        else
                        {
                            startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                            enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                        }
    
                        lstExp = hotelExpensDataList.filter(d => {
                            var stime = new Date(d.Date);
                            var etime = new Date(d.Date);
                            return (d.DisplayDescription === element.DisplayDescription && stime >= startdate && etime <= enddate);
                        });
                        let lstBud = hotelbudgetlist.filter(d => {
                            var stime = new Date(d.DateFrom);
                            var etime = new Date(d.DateTo);
                            return (d.Description === element.DisplayDescription && stime >= startdate && etime <= enddate);
                        });
                        if (colItem.columname == 'ACTUALS') {
                            smactual = _.sumBy(lstExp, 'Expense');
                            columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                        }
                        else if (colItem.columname == 'BUDGET') {
                            smbudget = _.sumBy(lstExp, rowBudgetCatName);
                            if(smbudget == null || 0){
                                smbudget = _.sumBy(lstBud, 'TotalHotelBudget');
                            }
                            columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                        }
                        else if (colItem.columname == 'FORECAST') {
                            smforcast = _.sumBy(lstExp, rowForecastCatName);
                            if(smbudget == null || 0){
                                smbudget = _.sumBy(lstBud, 'TotalHotelForcast');
                            }
                            columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                        }
    
                        objColum.columnvalue = columnvalue;
                        objColum.columnname = colItem.columname;
                        objColum.columnperiod = colItem.columperiod;
                        ColumnValueDate.push(objColum);
    
                        if(tableColummappingsData.length == ColumnValueDate.length){
                            cnt++;
                            let objRow = new PnlTableRowData();
                            objRow.rowname = element.DisplayDescription;
                            objRow.glcode = element.GLCode;
                            objRow.rowdata = ColumnValueDate;
                            objRow.roworder = cnt;
                            lstRevenue.push(objRow);
                            resolve();
                        }
                    })                    
                    })
                )
                })
            } else {
                prArr = [];
            }
            Promise.all(prArr).then(res => {
                resolve();
                return cb(lstRevenue);
            });
            })
        })
        }
    
    static getLabourExpenseData(tableColummappingsData, currentDate, hotelid,lstRevenue,cb) {
    return new Promise((resolve, reject) => {
        let hotelExpensDataList = [];
        let glCodeList = [];
        let cnt = lstRevenue.length+1;
        let yeasterday = new Date(currentDate);
        let startdate = new Date(yeasterday.getFullYear(), 1,1, 0, 0, 0);
        let enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
                    
        Promise.all([
        new Promise((resolve, reject) => {
            HoteleffectivenesscalculationsSchema.find({$and:[
                {[HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelid}, 
                {[HoteleffectivenesscalculationsSchemaFields.Date]: { "$gte": startdate, "$lt": enddate }},
                { $or:[
                    {[HoteleffectivenesscalculationsSchemaFields.ReportName]:{ $in:['Adams_Keegan_Payroll_Report', 'Labor Allocation Report', 'Manual Entry', 'ADP Pay Roll Detail'] }},
                    {[HoteleffectivenesscalculationsSchemaFields.ReportName]:null}, 
                ]}
            ]},(err, resp) => {
                // console.log(resp, 'hotelExpensDataList');
                if(err) {
                    log.error(err)
                    reject(err);
                }
                hotelExpensDataList = resp;                
                resolve();
            })
        }),
        new Promise((resolve, reject) => {
            GlcodemasterSchema.find({[GlcodemasterSchemaFields.HotelID]: hotelid},
                (err, result) => {
                    if(err) {
                        log.error(err)
                        reject(err)
                    }
                    if(result != null) {
                    glCodeList = result;
                    }
                    resolve();
                });
        })
        ]).then(res=> {
        let prArr = [];
        let groupdata = _(hotelExpensDataList)
                .groupBy('Department')
                .map((objs, key) => ({'Department': key}))
                .value();
        if(groupdata.length > 0) {
            groupdata.forEach(element => {
            prArr.push(
                new Promise((resolve, reject) => {                
                let ColumnValueDate =[];
                tableColummappingsData.forEach((colItem, index) => {  
                    var lstExp = [];
                    let columnvalue = 0;
                    let smactual = 0;
                    let smbudget = 0;
                    let smforcast = 0;
                    let objColum = new PnlTableColumData();
                    let startdate = new Date();
                    let enddate = new Date();
                    if (colItem.columperiod == "MTD")
                    {
                        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), 1, 0, 0, 0);
                        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                    }
                    else if (colItem.columperiod == "YTD")
                    {
                        startdate = new Date(yeasterday.getFullYear(), 1, 1, 0, 0, 0);
                        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                    }
                    else
                    {
                        startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                        enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
                    }

                    lstExp = hotelExpensDataList.filter(d => {
                        var stime = new Date(d.Date);
                        var etime = new Date(d.Date);
                        return (d.Department === element.Department && stime >= startdate && etime <= enddate);
                    });
                    let depart = glCodeList.filter(d => {
                        return(d.GLDescripton == element.Department)
                    })
                    if (colItem.columname == 'ACTUALS') {
                        let Wages = _.sumBy(lstExp, 'Wages');
                        let OTWages = _.sumBy(lstExp, 'OTWages');
                        let SalaryGratuity = _.sumBy(lstExp, 'SalaryGratuity');
                        let PayrollTaxes = _.sumBy(lstExp, 'PayrollTaxes');
                        let ContractWages = _.sumBy(lstExp, 'ContractWages');
                        smactual = Wages+OTWages+SalaryGratuity+PayrollTaxes+ContractWages;
                        columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                    }
                    else if (colItem.columname == 'BUDGET') {
                        smbudget = _.sumBy(lstExp, 'PlanWages');
                        columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                    }
                    else if (colItem.columname == 'FORECAST') {
                        smforcast = _.sumBy(lstExp, 'ForecastWages');
                        columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                    }

                    objColum.columnvalue = columnvalue;
                    objColum.columnname = colItem.columname;
                    objColum.columnperiod = colItem.columperiod;
                    ColumnValueDate.push(objColum);

                    if(tableColummappingsData.length == ColumnValueDate.length){
                        cnt++;
                        let objRow = new PnlTableRowData();
                        objRow.rowname = element.Department;
                        objRow.glcode = depart.length > 0 ? depart[0].GLCode:'0000.00';
                        objRow.rowdata = ColumnValueDate;
                        objRow.roworder = cnt;
                        lstRevenue.push(objRow);
                        resolve();
                    }
                })                    
                })
            )
            })
        } else {
            prArr = [];
        }
        Promise.all(prArr).then(res => {
            resolve();
            return cb(lstRevenue);
        });
        })
    })
    }

      
   //#endregion

    //#region PNL Yearly Table
    static getPNLAnnualTable_GraphQL(userid, hotelid, datamode,year, cb) {
        //get myp hotelid from cmp_id
        return HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
            if (err) {
                cb(err, null);
            }
            if (!hoteldata) {
                cb(Constants.HotelNotFound, null);
            }
            else {
                PNLHelper.getPNLAnnualTable(userid, hoteldata.ID,hoteldata.OrganizationID, datamode,year, cb, (err, result) => {
                    if (err) {
                        cb(err, null);
                    }
                    cb(null, result);
                });
            }
        });

    }

    static getPNLAnnualTable(userId, hotelid,orgID, datamode,year, cb) {
        let tableRowmappingsData = [];
        let lstActualBudgetData = [];
        let tableVarianceColumn = [];
        let TableData = [];
        let varianceColumnName='';
        return Promise.all([     
            new Promise((resolve, reject) => {
                CreateowntablemappingsHelper.getColumnMasterListData(Constants.DashboardTableName.PNLTableRowName, (err, result) => {
                    if (err) {
                        reject(err);
                    }
                    if (result) {
                        tableRowmappingsData = result;
                    }
                    resolve();
                });
            }),   
            new Promise((resolve, reject) => {
                PNLHelper.getPnlTableMapping(userId,Constants.PNLType.PNLYearly, (err, tablemappings_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (tablemappings_result) {
                        
                        varianceColumnName = tablemappings_result[0].columname
                        if(varianceColumnName == 'ACTUALS'){
                            let curdt = new Date(Date.now());
                            let startDate =  new Date(year, curdt.getMonth(), curdt.getDate() - 2, 0, 0, 0);
                            let endDate =  new Date(year, curdt.getMonth(), curdt.getDate() - 2, 23, 59, 59);
                            
                            HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, startDate, endDate, (err, hoteldashboardcalculations_result) => {
                                tableVarianceColumn = hoteldashboardcalculations_result;
                                resolve();
                            })                           
                       }
                       else{                        
                            let startDate =  new Date(year,12,31,0, 0, 0);
                            let endDate =  new Date(year,12,31,23,59, 59);
                            HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(hotelid, startDate, endDate, (err, hotelbudgetdashboardcalculations_result) => {
                                tableVarianceColumn = hotelbudgetdashboardcalculations_result;
                                resolve();
                            })                                       
                       }
                    }
                   
                });
            }),
            new Promise((resolve, reject) => {
                PNLHelper.getAnnualDataByDatamode(hotelid,datamode,year, (err, result) => {
                    if (err) {
                        reject(err);
                    }
                    if (result) {
                        lstActualBudgetData = result;
                    }
                    resolve();
                });
            }), 
        ]).then(resp => {

            if(tableRowmappingsData.length > 0){
                tableRowmappingsData.forEach(async (rowItem, index) => {
                    let rowName = rowItem.kpikey;
                    let objRow = new PnlTableRowData();

                    PNLHelper.getAnnualTableColumndata(rowName, datamode,lstActualBudgetData,varianceColumnName,tableVarianceColumn, ColumnValueDate_result  => {
                        objRow.rowname = rowItem.columname;
                        objRow.roworder = rowItem.displayorder;
                        objRow.glcode = '0000.00';
                        objRow.rowdata = ColumnValueDate_result;
                        TableData.push(objRow);

                        if (tableRowmappingsData.length == TableData.length){
                            let  lstRevenue = Utils.sort(TableData,"roworder");    
                            
                        //to add the  active record filter 
                        let tableColummappingsData = [];   
                        let prArr = [];
                        let lstRevenueCnt = lstRevenue.length;

                        new Promise((resolve,reject) => {
                            mdoglcodemaster.getMDOGLCodeMasterMapping(orgID,(err,monthlyResult) => {
                                if(err){
                                    reject(err);
                                }
                                else{
                                   // monthlyResult = monthlyResult.MDOGLCodeMappingTable;
                                  monthlyResult.forEach(item =>{
    
                                    let parent = monthlyResult.find(parentitem => parentitem.ID = item.ParentId);
                                    let parentMappingStatus = (item.ParentId == 0)?true:parent.MappingStatus;
    
                                    if(item.MappingStatus == true && parentMappingStatus == true){
                                        let rowName = item.DisplayDescription ==''?item.Description:item.DisplayDescription;;
                                        let objRow = new PnlTableRowData();
                                        // prArr.push(
                                            // new Promise((resolve, reject) => {
                                    PNLHelper.getAnnualTableColumndata("ROOMS AVAILABLE", datamode,lstActualBudgetData,varianceColumnName,tableVarianceColumn, ColumnValueDate_result  => {
                    
                                                    objRow.rowname = rowName;
                                                    objRow.roworder = lstRevenueCnt;
                                                    objRow.glcode = item.GLCode;
                                                    objRow.id = item.ID;
                                                    objRow.parentid = item.ParentId;
                                                    objRow.rowdata = ColumnValueDate_result;
                                                    lstRevenueCnt++;
                                                    lstRevenue.push(objRow);
                                            //         resolve();
                                                });
                                            // })
                                        // )
                                    }
                  
                                  })
                                
                                  resolve();
                              }
                              })
                        })

                        PNLHelper.getAnnualExpensesdataFilterActives(orgID,hotelid,datamode,year,varianceColumnName,lstRevenue, expDate_result  => {
                            //PNLHelper.getAnnualExpensesdata(hotelid,datamode,year,varianceColumnName,lstRevenue, expDate_result  => {
                                
                                PNLHelper.getAnnualLabourExpenseData(hotelid,datamode,year,varianceColumnName,lstRevenue, expDate_result  => {
                                    return cb(null, lstRevenue);
                                });  
                            });
                        }
                            
                    });
                });
            }
            else{
                return cb(null, TableData);
            }
        }, err => {
            return cb(err);
        })
    }

    static getAnnualTableColumndata(rowName, datamode,lstActualBudgetData,varianceColumnName,tableVarianceColumn, cb) {
        let cnt = lstActualBudgetData.length;
        var ColumnValueDate =[];
        let sumcolumnvalue = 0;
        lstActualBudgetData.forEach((element,index)=>{
            
            let rowCatName = '';
            let rowBudgetCatName = '';
            let rowForecastCatName = '';
            let columnvalue = 0;       
            let varianceValue = 0;     
            let smactual = 0;
            let smbudget = 0;
            let smforcast = 0;
            let smvariance = 0;
            let objColum = new PnlTableColumData();
            var columperiod = 'MTD';

            rowCatName = rowName + columperiod;
            if(rowName == 'NoOfRoomSold')
            {
                rowBudgetCatName =  'MTDBudgetRooms' ;
                rowForecastCatName = 'MTDForecastRoomSold';
            }
            else if(rowName == 'TotalRevenue' || rowName == 'FANDBRevenue' || rowName == 'OtherRevenue')
            {
                rowBudgetCatName =  columperiod+ rowName ;
                rowForecastCatName = columperiod+ 'Forecast' + rowName;
            }
            else if(rowName == 'ADR' || rowName == 'Occupancy'){
                rowBudgetCatName =  'Budget'+ rowName + columperiod ;
                rowForecastCatName = 'Forecast' + rowName + columperiod ;
            }
            else if(rowName == 'AvailableRooms'){
                rowBudgetCatName ='BudgetNumberofAvailableRooms';
                rowForecastCatName = 'BudgetNumberofAvailableRooms' ;
            }
            var lstRevData = lstActualBudgetData.filter(d => {
                var time = new Date(d.Date);
                return (time >= element.Date && time <= element.Date);
            });

            if (datamode == 'ACTUALS') {
                smactual = _.sumBy(lstRevData, rowCatName);
                columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
            }
            else if (datamode == 'BUDGET') {
                smbudget = _.sumBy(lstRevData, rowBudgetCatName);
                columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
            }
            else if (datamode == 'FORECAST') {
                smforcast = _.sumBy(lstRevData, rowForecastCatName);
                columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
            }

            objColum.columnvalue = columnvalue;
            objColum.columnname = moment(element.Date).format('MMM');
            objColum.columnperiod = columperiod;
            ColumnValueDate.push(objColum);
            sumcolumnvalue = sumcolumnvalue + parseFloat(columnvalue == null ? 0 : columnvalue);

            if (cnt == ColumnValueDate.length) {
                var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                ColumnValueDate.sort(function (a, b) {
                    return months.indexOf(a.columnname) - months.indexOf(b.columnname);
                });
                
                let objTotal = new PnlTableColumData();
                objTotal.columnvalue =  parseFloat(sumcolumnvalue == null ? 0 : sumcolumnvalue).toFixed(2);
                objTotal.columnname = "Total";
                objTotal.columnperiod = "";
                ColumnValueDate.push(objTotal);

                if (varianceColumnName == 'ACTUALS') {
                    smvariance = _.sumBy(tableVarianceColumn, rowCatName);
                    varianceValue = parseFloat(smvariance == null ? 0 : smvariance).toFixed(2);
                }
                else if (varianceColumnName == 'BUDGET') {
                    smvariance = _.sumBy(tableVarianceColumn, rowBudgetCatName);
                    varianceValue = parseFloat(smvariance == null ? 0 : smvariance).toFixed(2);
                }
                else if (varianceColumnName == 'FORECAST') {
                    smvariance = _.sumBy(tableVarianceColumn, rowForecastCatName);
                    varianceValue = parseFloat(smvariance == null ? 0 : smvariance).toFixed(2);
                }
                let objVariance = new PnlTableColumData();
                objVariance.columnvalue =  varianceValue;
                objVariance.columnname = varianceColumnName;
                objVariance.columnperiod = "";
                ColumnValueDate.push(objVariance);

                return cb(ColumnValueDate);
            }
            
        });
    }
    static getAnnualDataByDatamode(hotelid,datamode,year,cb){
        var lstMonthwisedata = [];
        let startDate = new Date(year, 1, 1);
        startDate = moment(startDate).startOf('year').format('YYYY-MM-DD');
        let endDate = moment(startDate).endOf('year').format('YYYY-MM-DD');
        let curdt = new Date(Date.now());
        new Promise((resolve, reject) => {
            for (var m = 0; m <= 11; m++) { 
                let month = m;
                let  ed = Utils.daysInMonth(new Date(year, m, 1, 0, 0, 0));
                startDate = new Date(year, m, ed, 0, 0, 0);
                endDate = new Date(year, m, ed, 23, 59, 59);        
                //let monthEndDate = moment(m).endOf('month').format("YYYY-MM-DD");
                var hoteldashboardcalculationsData = [];
                if (year == curdt.getFullYear() && month == curdt.getMonth()) {
                    startDate =  new Date(year, month, curdt.getDate() - 2, 0, 0, 0);
                    endDate =  new Date(year, month, curdt.getDate() - 2, 23, 59, 59);
                }
                var cnt = 1;
                if(datamode == 'ACTUALS'){
                    new Promise((resolve, reject) => {
                        HoteldashboardcalculationsHelper.GetDataBetweenDate(hotelid, startDate, endDate, (err, hoteldashboardcalculations_result) => {
                            
                            if (hoteldashboardcalculations_result.length > 0) {
                                hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                                lstMonthwisedata.push(hoteldashboardcalculationsData[0]);
                                cnt++;
                            }
                            else{
                                cnt++;
                            }
                            if (cnt == 12){
                                resolve();                                
                                return cb(null, lstMonthwisedata);
                            }
                            
                        })
                    })
               }
               else{
                new Promise((resolve, reject) => {
                    HotelbudgetdashboardcalculationsHelper.GetDataBetweenDate(hotelid, startDate, endDate, (err, hotelbudgetdashboardcalculations_result) => {
                        if (hotelbudgetdashboardcalculations_result.length > 0) {
                            lstMonthwisedata.push(hotelbudgetdashboardcalculations_result[0]);
                            cnt++;
                        }
                        else{
                            cnt++;
                        }
                        if (cnt == 12){
                            resolve();                                
                            return cb(null, lstMonthwisedata);
                        }
                        
                    })
                })                
               }
            }           
        }).then(resp => {
            cb(null, lstMonthwisedata);
        }, err => {
            return cb(err);
        })

    }

    static getAnnualExpensesdata(hotelid,datamode,year,varianceColumnName,lstRevenue,cb) {
        return new Promise((resolve, reject) => {
            let hotelExpensDataList = [];       
            let hotelbudgetlist  = [];     
            let lstcnt = lstRevenue.length+1;
            let startdate = new Date(year, 1, 1);
            startdate = moment(startdate).startOf('year').format('YYYY-MM-DD');
            let enddate = moment(startdate).endOf('year').format('YYYY-MM-DD');
            let curdt = new Date(Date.now());

            Promise.all([
            new Promise((resolve, reject) => {
                HotelexpensedashboardcalculationsSchema.find({[HotelexpensedashboardcalculationsSchemaFields.HotelID]: hotelid, [HotelexpensedashboardcalculationsSchemaFields.Category]: { $in: ["Expense","UndistributedExpense","FixedExpense","ITDAExpense"]}, [HotelexpensedashboardcalculationsSchemaFields.Date]: { "$gte": startdate, "$lt": enddate}},
                (err, resp) => {
                    // console.log(resp, 'hotelExpensDataList');
                    if(err) {
                        log.error(err)
                        reject(err);
                    }
                    hotelExpensDataList = resp;
                    resolve();
                })
            }),
            new Promise((resolve, reject) => {
                HotelbudgetexpenseformSchema.find({ [HotelbudgetexpenseformSchemaFields.HotelID]: hotelid, 
                [HotelbudgetexpenseformSchemaFields.IsDelete]: false, 
                [HotelbudgetexpenseformSchemaFields.DateFrom]: { "$gte": new Date(startdate) }, 
                [HotelbudgetexpenseformSchemaFields.DateTo]: {"$lte": new Date(enddate) } }, 
                (err, resultset) => {
                    if(err) {
                    log.error(err);
                    reject(err);
                    }
                    hotelbudgetlist = resultset;
                    resolve();
                })
                })
            ]).then(res=> {
            let prArr = [];
            let groupdata = _(hotelExpensDataList)
            .groupBy('DisplayDescription')
            .map((objs, Key) => ({
                'DisplayDescription': Key,
                'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'GLCode')
                })).value();
            if(groupdata.length > 0) {
                groupdata.forEach(element => {
                    prArr.push(
                        new Promise((resolve, reject) => {                
                            let ColumnValueDate =[];
                            let sumVarianceAmt=0;
                            let sumcolumnvalue = 0;
                            for (var m = 0; m <= 11; m++) { 
                                let month = m;
                                let  ed = Utils.daysInMonth(new Date(year, m, 1, 0, 0, 0));
                                let startDate = new Date(year, m, 1, 0, 0, 0);
                                let endDate = new Date(year, m, ed, 23, 59, 59);        
                                
                                if (year == curdt.getFullYear() && month == curdt.getMonth()) {
                                    startDate =  new Date(year, month, curdt.getDate() - 2, 0, 0, 0);
                                    endDate =  new Date(year, month, curdt.getDate() - 2, 23, 59, 59);
                                }
                                
                                var lstExp = [];
                                let columnvalue = 0;
                                let smactual = 0;
                                let smbudget = 0;
                                let smforcast = 0;
                                let objColum = new PnlTableColumData();
                                let rowBudgetCatName = 'MTDBudget';
                                let rowForecastCatName = 'MTDForecast';        
                                    
                                lstExp = hotelExpensDataList.filter(d => {
                                    var stime = new Date(d.Date);
                                    var etime = new Date(d.Date);
                                    return (d.DisplayDescription === element.DisplayDescription && stime >= startDate && etime <= endDate);
                                });
                                let lstBud = hotelbudgetlist.filter(d => {
                                    var stime = new Date(d.DateFrom);
                                    var etime = new Date(d.DateTo);
                                    return (d.Description === element.DisplayDescription && stime >= startDate && etime <= endDate);
                                });
                                if (datamode == 'ACTUALS') {
                                    smactual = _.sumBy(lstExp, 'Expense');
                                    columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                                }
                                else if (datamode == 'BUDGET') {
                                    smbudget = _.sumBy(lstExp, rowBudgetCatName);
                                    if(smbudget == null || 0){
                                        smbudget = _.sumBy(lstBud, 'TotalHotelBudget');
                                    }
                                    columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                                }
                                else if (datamode == 'FORECAST') {
                                    smforcast = _.sumBy(lstExp, rowForecastCatName);
                                    if(smbudget == null || 0){
                                        smbudget = _.sumBy(lstBud, 'TotalHotelForcast');
                                    }
                                    columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                                }
            
                                objColum.columnvalue = columnvalue;
                                objColum.columnname = moment(startDate).format('MMM');
                                objColum.columnperiod = 'MTD';
                                ColumnValueDate.push(objColum);
                                sumcolumnvalue = sumcolumnvalue + parseFloat(columnvalue == null ? 0 : columnvalue);
                                
                                //Calculation for variance column
                                let varAmt =0;
                                if (varianceColumnName == 'ACTUALS') {
                                    varAmt = _.sumBy(lstExp, 'Expense');
                                }
                                else if (varianceColumnName == 'BUDGET') {
                                    varAmt = _.sumBy(lstExp, rowBudgetCatName);
                                    if(varAmt == null || 0){
                                        varAmt = _.sumBy(lstBud, 'TotalHotelBudget');
                                    }
                                }
                                else if (varianceColumnName == 'FORECAST') {
                                    varAmt = _.sumBy(lstExp, rowForecastCatName);
                                    if(varAmt == null || 0){
                                        varAmt = _.sumBy(lstBud, 'TotalHotelForcast');
                                    }
                                }
                                sumVarianceAmt = sumVarianceAmt + parseFloat(varAmt == null ? 0 : varAmt);
                                if(ColumnValueDate.length == 12){
                                    lstcnt++;
                                    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                    ColumnValueDate.sort(function (a, b) {
                                        return months.indexOf(a.columnname) - months.indexOf(b.columnname);
                                    });
                                    
                                    // Total Column
                                    let objTotal = new PnlTableColumData();
                                    objTotal.columnvalue =  parseFloat(sumcolumnvalue == null ? 0 : sumcolumnvalue).toFixed(2);
                                    objTotal.columnname = "Total";
                                    objTotal.columnperiod = "";
                                    ColumnValueDate.push(objTotal);

                                    //Variance Column                                    
                                    let objVariance = new PnlTableColumData();
                                    objVariance.columnvalue = parseFloat(sumVarianceAmt == null ? 0 : sumVarianceAmt).toFixed(2);
                                    objVariance.columnname = varianceColumnName;
                                    objVariance.columnperiod = "";
                                    ColumnValueDate.push(objVariance);

                                    let objRow = new PnlTableRowData();
                                    objRow.rowname = element.DisplayDescription;
                                    objRow.glcode = element.GLCode;
                                    objRow.rowdata = ColumnValueDate;
                                    objRow.roworder = lstcnt;
                                    lstRevenue.push(objRow);
                                    resolve();
                                }
                            }
                        })                    
                    )
                })
            } else {
                prArr = [];
            }
            Promise.all(prArr).then(res => {
                resolve();
                return cb(lstRevenue);
            });
            })
        })
    }

    static getAnnualExpensesdataFilterActives(orgID,hotelid,datamode,year,varianceColumnName,lstRevenue,cb) {
        return new Promise((resolve, reject) => {
            let hotelExpensDataList = [];       
            let hotelbudgetlist  = [];     
            let lstcnt = lstRevenue.length+1;
            let startdate = new Date(year, 1, 1);
            startdate = moment(startdate).startOf('year').format('YYYY-MM-DD');
            let enddate = moment(startdate).endOf('year').format('YYYY-MM-DD');
            let curdt = new Date(Date.now());
            let mdohmgmappingslist  = [];       
            Promise.all([
                new Promise((resolve,reject) => {
                        mdoglcodemaster.getMDOGLCodeMasterMappingOnlyActives(orgID,(err,mdohmgmappings) => {
                            if(err){
                                reject(err);
                            }
                            else{
                              if (mdohmgmappings != null)
                                mdohmgmappingslist = mdohmgmappings;                        
                              resolve();
                          }
                          })
                    }),
            new Promise((resolve, reject) => {
                HotelexpensedashboardcalculationsSchema.find({[HotelexpensedashboardcalculationsSchemaFields.HotelID]: hotelid, [HotelexpensedashboardcalculationsSchemaFields.Category]: { $in: ["Expense","UndistributedExpense","FixedExpense","ITDAExpense"]}, [HotelexpensedashboardcalculationsSchemaFields.Date]: { "$gte": startdate, "$lt": enddate}},
                (err, resp) => {
                    // console.log(resp, 'hotelExpensDataList');
                    if(err) {
                        log.error(err)
                        reject(err);
                    }
                    hotelExpensDataList = resp;
                    resolve();
                })
            }),
            new Promise((resolve, reject) => {
                HotelbudgetexpenseformSchema.find({ [HotelbudgetexpenseformSchemaFields.HotelID]: hotelid, 
                [HotelbudgetexpenseformSchemaFields.IsDelete]: false, 
                [HotelbudgetexpenseformSchemaFields.DateFrom]: { "$gte": new Date(startdate) }, 
                [HotelbudgetexpenseformSchemaFields.DateTo]: {"$lte": new Date(enddate) } }, 
                (err, resultset) => {
                    if(err) {
                    log.error(err);
                    reject(err);
                    }
                    hotelbudgetlist = resultset;
                    resolve();
                })
                })
            ]).then(res=> {

                hotelExpensDataList = hotelExpensDataList.filter(x=> mdohmgmappingslist.findIndex(y=> y.HMGGLCode == x.GLCode ) > -1);
                hotelbudgetlist = hotelbudgetlist.filter(x=> mdohmgmappingslist.findIndex(y=> y.HMGGLCode == x.GLCode ) > -1);

            let prArr = [];
            let groupdata = _(hotelExpensDataList)
            .groupBy('DisplayDescription')
            .map((objs, Key) => ({
                'DisplayDescription': Key,
                'GLCode': _.get(_.find(objs, function(o) { return true; }), 'GLCode') == undefined ? 0 : _.get(_.find(objs, function(o) { return true; }), 'GLCode')
                })).value();
            if(groupdata.length > 0) {
                groupdata.forEach(element => {
                    prArr.push(
                        new Promise((resolve, reject) => {                
                            let ColumnValueDate =[];
                            let sumVarianceAmt=0;
                            let sumcolumnvalue = 0;
                            for (var m = 0; m <= 11; m++) { 
                                let month = m;
                                let  ed = Utils.daysInMonth(new Date(year, m, 1, 0, 0, 0));
                                let startDate = new Date(year, m, 1, 0, 0, 0);
                                let endDate = new Date(year, m, ed, 23, 59, 59);        
                                
                                if (year == curdt.getFullYear() && month == curdt.getMonth()) {
                                    startDate =  new Date(year, month, curdt.getDate() - 2, 0, 0, 0);
                                    endDate =  new Date(year, month, curdt.getDate() - 2, 23, 59, 59);
                                }
                                
                                var lstExp = [];
                                let columnvalue = 0;
                                let smactual = 0;
                                let smbudget = 0;
                                let smforcast = 0;
                                let objColum = new PnlTableColumData();
                                let rowBudgetCatName = 'MTDBudget';
                                let rowForecastCatName = 'MTDForecast';        
                                    
                                lstExp = hotelExpensDataList.filter(d => {
                                    var stime = new Date(d.Date);
                                    var etime = new Date(d.Date);
                                    return (d.DisplayDescription === element.DisplayDescription && stime >= startDate && etime <= endDate);
                                });
                                let lstBud = hotelbudgetlist.filter(d => {
                                    var stime = new Date(d.DateFrom);
                                    var etime = new Date(d.DateTo);
                                    return (d.Description === element.DisplayDescription && stime >= startDate && etime <= endDate);
                                });
                                if (datamode == 'ACTUALS') {
                                    smactual = _.sumBy(lstExp, 'Expense');
                                    columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                                }
                                else if (datamode == 'BUDGET') {
                                    smbudget = _.sumBy(lstExp, rowBudgetCatName);
                                    if(smbudget == null || 0){
                                        smbudget = _.sumBy(lstBud, 'TotalHotelBudget');
                                    }
                                    columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                                }
                                else if (datamode == 'FORECAST') {
                                    smforcast = _.sumBy(lstExp, rowForecastCatName);
                                    if(smbudget == null || 0){
                                        smbudget = _.sumBy(lstBud, 'TotalHotelForcast');
                                    }
                                    columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                                }
            
                                objColum.columnvalue = columnvalue;
                                objColum.columnname = moment(startDate).format('MMM');
                                objColum.columnperiod = 'MTD';
                                ColumnValueDate.push(objColum);
                                sumcolumnvalue = sumcolumnvalue + parseFloat(columnvalue == null ? 0 : columnvalue);
                                
                                //Calculation for variance column
                                let varAmt =0;
                                if (varianceColumnName == 'ACTUALS') {
                                    varAmt = _.sumBy(lstExp, 'Expense');
                                }
                                else if (varianceColumnName == 'BUDGET') {
                                    varAmt = _.sumBy(lstExp, rowBudgetCatName);
                                    if(varAmt == null || 0){
                                        varAmt = _.sumBy(lstBud, 'TotalHotelBudget');
                                    }
                                }
                                else if (varianceColumnName == 'FORECAST') {
                                    varAmt = _.sumBy(lstExp, rowForecastCatName);
                                    if(varAmt == null || 0){
                                        varAmt = _.sumBy(lstBud, 'TotalHotelForcast');
                                    }
                                }
                                sumVarianceAmt = sumVarianceAmt + parseFloat(varAmt == null ? 0 : varAmt);
                                if(ColumnValueDate.length == 12){
                                    lstcnt++;
                                    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                    ColumnValueDate.sort(function (a, b) {
                                        return months.indexOf(a.columnname) - months.indexOf(b.columnname);
                                    });
                                    
                                    // Total Column
                                    let objTotal = new PnlTableColumData();
                                    objTotal.columnvalue =  parseFloat(sumcolumnvalue == null ? 0 : sumcolumnvalue).toFixed(2);
                                    objTotal.columnname = "Total";
                                    objTotal.columnperiod = "";
                                    ColumnValueDate.push(objTotal);

                                    //Variance Column                                    
                                    let objVariance = new PnlTableColumData();
                                    objVariance.columnvalue = parseFloat(sumVarianceAmt == null ? 0 : sumVarianceAmt).toFixed(2);
                                    objVariance.columnname = varianceColumnName;
                                    objVariance.columnperiod = "";
                                    ColumnValueDate.push(objVariance);

                                    let objRow = new PnlTableRowData();
                                    objRow.rowname = element.DisplayDescription;
                                    objRow.glcode = element.GLCode;
                                    objRow.rowdata = ColumnValueDate;
                                    objRow.roworder = lstcnt;
                                    lstRevenue.push(objRow);
                                    resolve();
                                }
                            }
                        })                    
                    )
                })
            } else {
                prArr = [];
            }
            Promise.all(prArr).then(res => {
                resolve();
                return cb(lstRevenue);
            });
            })
        })
    }
    
    static getAnnualLabourExpenseData(hotelid,datamode,year,varianceColumnName,lstRevenue,cb) {
    return new Promise((resolve, reject) => {
        let hotelExpensDataList = [];
        let glCodeList = [];
        let cnt = lstRevenue.length+1;
        let startdate = new Date(year, 1, 1);
        startdate = moment(startdate).startOf('year').format('YYYY-MM-DD');
        let enddate = moment(startdate).endOf('year').format('YYYY-MM-DD');
        let curdt = new Date(Date.now());

        Promise.all([
        new Promise((resolve, reject) => {
            HoteleffectivenesscalculationsSchema.find({$and:[
                {[HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelid}, 
                {[HoteleffectivenesscalculationsSchemaFields.Date]: { "$gte": startdate, "$lt": enddate }},
                { $or:[
                    {[HoteleffectivenesscalculationsSchemaFields.ReportName]:{ $in:['Adams_Keegan_Payroll_Report', 'Labor Allocation Report', 'Manual Entry', 'ADP Pay Roll Detail'] }},
                    {[HoteleffectivenesscalculationsSchemaFields.ReportName]:null}, 
                ]}
            ]},(err, resp) => {
                // console.log(resp, 'hotelExpensDataList');
                if(err) {
                    log.error(err)
                    reject(err);
                }
                hotelExpensDataList = resp;                
                resolve();
            })
        }),
        new Promise((resolve, reject) => {
            GlcodemasterSchema.find({[GlcodemasterSchemaFields.HotelID]: hotelid},
                (err, result) => {
                    if(err) {
                        log.error(err)
                        reject(err)
                    }
                    if(result != null) {
                    glCodeList = result;
                    }
                    resolve();
                });
        })
        ]).then(res=> {
        let prArr = [];
        let groupdata = _(hotelExpensDataList)
        .groupBy('Department')
        .map((objs, key) => ({'Department': key}))
        .value();

        if(groupdata.length > 0) {
            groupdata.forEach(element => {
            prArr.push(
                new Promise((resolve, reject) => {                
                let ColumnValueDate =[];
                let sumcolumnvalue = 0;
                let sumVarianceAmt = 0;
                let depart = glCodeList.filter(d => {
                    return(d.GLDescripton == element.Department)
                })
                for (var m = 0; m <= 11; m++) { 
                    let month = m;
                    let  ed = Utils.daysInMonth(new Date(year, m, 1, 0, 0, 0));
                    let startDate = new Date(year, m, 1, 0, 0, 0);
                    let endDate = new Date(year, m, ed, 23, 59, 59);        
                    
                    if (year == curdt.getFullYear() && month == curdt.getMonth()) {
                        startDate =  new Date(year, month, curdt.getDate() - 2, 0, 0, 0);
                        endDate =  new Date(year, month, curdt.getDate() - 2, 23, 59, 59);
                    }
                    
                    var lstExp = [];
                    let columnvalue = 0;
                    let smactual = 0;
                    let smbudget = 0;
                    let smforcast = 0;
                    let objColum = new PnlTableColumData();
                    
                    lstExp = hotelExpensDataList.filter(d => {
                        var stime = new Date(d.Date);
                        var etime = new Date(d.Date);
                        return (d.Department === element.Department && stime >= startDate && etime <= endDate);
                    });
                    
                    if (datamode == 'ACTUALS') {
                        let Wages = _.sumBy(lstExp, 'Wages');
                        let OTWages = _.sumBy(lstExp, 'OTWages');
                        let SalaryGratuity = _.sumBy(lstExp, 'SalaryGratuity');
                        let PayrollTaxes = _.sumBy(lstExp, 'PayrollTaxes');
                        let ContractWages = _.sumBy(lstExp, 'ContractWages');
                        smactual = Wages+OTWages+SalaryGratuity+PayrollTaxes+ContractWages;
                        columnvalue = parseFloat(smactual == null ? 0 : smactual).toFixed(2);
                    }
                    else if (datamode == 'BUDGET') {
                        smbudget = _.sumBy(lstExp, 'PlanWages');
                        columnvalue = parseFloat(smbudget == null ? 0 : smbudget).toFixed(2);
                    }
                    else if (datamode == 'FORECAST') {
                        smforcast = _.sumBy(lstExp, 'ForecastWages');
                        columnvalue = parseFloat(smforcast == null ? 0 : smforcast).toFixed(2);
                    }

                    objColum.columnvalue = columnvalue;
                    objColum.columnname = moment(startDate).format('MMM');
                    objColum.columnperiod = 'MTD';
                    ColumnValueDate.push(objColum);
                    sumcolumnvalue = sumcolumnvalue + parseFloat(columnvalue == null ? 0 : columnvalue);
                                
                    //Calculation for variance column
                    let varAmt=0;
                    if (varianceColumnName == 'ACTUALS') {
                        let Wagesv = _.sumBy(lstExp, 'Wages');
                        let OTWagesv = _.sumBy(lstExp, 'OTWages');
                        let SalaryGratuityv = _.sumBy(lstExp, 'SalaryGratuity');
                        let PayrollTaxesv = _.sumBy(lstExp, 'PayrollTaxes');
                        let ContractWagesv = _.sumBy(lstExp, 'ContractWages');
                        varAmt = parseFloat(Wagesv == null ? 0 : Wagesv)+parseFloat(OTWagesv == null ? 0 : OTWagesv)+parseFloat(SalaryGratuityv == null ? 0 : SalaryGratuityv)+parseFloat(PayrollTaxesv == null ? 0 : PayrollTaxesv)+parseFloat(ContractWagesv == null ? 0 : ContractWagesv);
                    }
                    else if (varianceColumnName == 'BUDGET') {
                        varAmt = _.sumBy(lstExp, 'PlanWages');
                    }
                    else if (varianceColumnName == 'FORECAST') {
                        varAmt = _.sumBy(lstExp, 'ForecastWages');
                    }
                    sumVarianceAmt = sumVarianceAmt + parseFloat(varAmt == null ? 0 : varAmt);
                    if(ColumnValueDate.length == 12){
                        var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        ColumnValueDate.sort(function (a, b) {
                            return months.indexOf(a.columnname) - months.indexOf(b.columnname);
                        });
                        
                        // Total Column
                        let objTotal = new PnlTableColumData();
                        objTotal.columnvalue =  parseFloat(sumcolumnvalue == null ? 0 : sumcolumnvalue).toFixed(2);
                        objTotal.columnname = "Total";
                        objTotal.columnperiod = "";
                        ColumnValueDate.push(objTotal);

                        //Variance Column                                    
                        let objVariance = new PnlTableColumData();
                        objVariance.columnvalue =  parseFloat(sumVarianceAmt == null ? 0 : sumVarianceAmt).toFixed(2);
                        objVariance.columnname = varianceColumnName;
                        objVariance.columnperiod = "";
                        ColumnValueDate.push(objVariance);

                        cnt++;
                        let objRow = new PnlTableRowData();
                        objRow.rowname = element.Department;
                        objRow.glcode = depart.length > 0 ? depart[0].GLCode:'0000.00';
                        objRow.rowdata = ColumnValueDate;
                        objRow.roworder = cnt;
                        lstRevenue.push(objRow);
                        resolve();
                    }               
                }
            })
            )
            })
        } else {
            prArr = [];
        }
        Promise.all(prArr).then(res => {
            resolve();
            return cb(lstRevenue);
        });
        })
    })
    }
        
   //#endregion
}

module.exports = PNLHelper;