const Constants = require('../common/constants');
const Utils = require('../common/utils');
const moment = require('moment');
const _ = require('lodash');

const Pickupdashboarddata = require('../pickup/models/pickupdashboarddata');
const Pickupdata = require('../pickup/models/pickupdata');
const Pickupreportdata = require('../pickup/models/pickupreportdata');
const Summeryreportdata = require('../pickup/models/summeryreportdata');
const Hoteldata = require('../hotels/models/hoteldata');

const { Hotelrevenue: HotelrevenueSchema, SchemaField: HotelrevenueSchemaFields } = require('../models/hotelrevenue');
const { Pickupreport: PickupreportSchema, SchemaField: PickupSchemaFields } = require('../models/pickupreport');
const { Hotelbudget: HotelbudgetSchema, SchemaField: HotelbudgetSchemaFields } = require('../models/hotelbudget');
const { Hoteldashboardcalculations: HoteldashboardcalculationsSchema, SchemaField: HoteldashboardcalculationsSchemaFields } = require('../models/hoteldashboardcalculations');
const { Hotelbudgetdashboardcalculations: HotelbudgetdashboardcalculationsSchema, SchemaField: HotelbudgetdashboardcalculationsSchemaFields } = require('../models/hotelbudgetdashboardcalculations');

const UserHelper = require('./user_helper');
const HotelsHelper = require('./hotels_helper');
const PickupHelper = require('./pickup_helper');
var log = require('log4js').getLogger("pickup_helper");

class MonthlyPickupsHelper {
  static getMonthlyPickupData(hotelId, month, currentdate, userconfigdata, cb) {

    let HotelId = parseInt(hotelId);
    let pickuprpt1Amount = 0;
    let pickuprpt1RoomSold = 0;
    let transientDelta1 = 0;
    let TotalAvailRoom = 0;

    let TotalRoomsActual = 0;
    let TotalRoomsBudget = 0;
    let TotalRoomsBudgetVariance = 0;
    let TotalRoomsForcastBudget = 0;
    let TotalRoomsForcastVariance = 0;
    let TotalReveneActual = 0;
    let TotalReveneBudget = 0;
    let TotalReveneBudgetVariance = 0;
    let TotalRevenueForcastBudget = 0;
    let TotalRevenueForcastVariance = 0;
    let TotalADTActual = 0;
    let TotalADTBudget = 0;
    let TotalADTBudgetVariance = 0;
    let TotalADTForcastBudget = 0;
    let TotalADTForcastVariance = 0;
    let TotalOccuActual = 0;
    let TotalOccuBudget = 0;
    let TotalOccuBudgetVariance = 0;
    let TotalOccuForcastBudget = 0;
    let TotalOccuForcastVariance = 0;
    let TotalpickupToday = 0;
    let TotalpickupMTD = 0;
    let TotalRevparActual = 0;
    let TotalRevparBudget = 0;
    let TotalRevparBudgetVariance = 0;
    let TotalRevparForcastBudget = 0;
    let TotalRevparForcastVariance = 0;

    let dt = new Date();
    if (!currentdate) {
      dt = new Date();
    }
    else {
      dt = new Date(currentdate);
    }

    let mtdpickupList = [];
    let dict = [];
    let totalNoOfDays = Utils.daysInMonth(currentdate);

    // let startdate = new Date(dt.getFullYear(), dt.getMonth(), 1, 23, 59, 59);
    let startdate = moment(dt).startOf('month');
    // let enddate = new Date(dt.getFullYear(), dt.getMonth(), totalNoOfDays, 23, 59, 59);
    let enddate = moment(dt).endOf('month');
    //let enddate = new Date(Utils.addDays(dt, 5));
    // console.log(startdate, 'sd');

    // console.log(enddate, 'ed');
    let currentDate = dt;
    let PickupReportDataModelList = [];


    let hotelRoomBudgetData = [];
    let hotelData = [];
    let pickupReportsList = [];

    let HotelRevenueData = [];
    let rptDate = new Date(currentDate).toISOString();

    // dal.GetHotelRevenues(startdate, enddate, HotelId );
    let HotelRevenueFCData = [];
    return Promise.all([
      new Promise((resolve, reject) => {
        MonthlyPickupsHelper.getHotelBudgetDashboardCalculation(startdate, enddate, HotelId, (err, result) => {
          if (err) {
            reject(err);
          }
          if (result) {
            hotelRoomBudgetData = result;
          }
          resolve();
        });
      }),
      new Promise((resolve, reject) => {
        HotelsHelper.GetHotelRevenueData(HotelId, (err, hoteldata) => {
          if (err) {
            reject(err)
          }
          if (hoteldata) {
            hotelData = hoteldata;
          }
          resolve();
        });
      }),
      new Promise((resolve, reject) => {
        MonthlyPickupsHelper.getPickReportTableDataForPickup(HotelId, currentDate, currentDate, enddate, (err, pickuprlist) => {
          if (err) {
            reject(err);
          }
          if (pickuprlist) {
            pickupReportsList = pickuprlist;
          }
          resolve();
        });
      }),
      new Promise((resolve, reject) => {
        MonthlyPickupsHelper.getHotelRevenues(startdate, enddate, HotelId, (err, hrevData) => {
          if (err) {
            reject(err);
          }
          if (hrevData) {
            HotelRevenueData = hrevData;
            // console.log('4')
          }
          resolve();
        });
      }),
      new Promise((resolve, reject) => {
        MonthlyPickupsHelper.getHotelRevenuesForPickupReport(currentDate, currentDate, enddate, HotelId, (err, hrevFCData) => {
          if (err) {
            reject(err);
          }
          if (hrevFCData) {
            HotelRevenueFCData = hrevFCData;
            // console.log('5')
          }
          resolve();
        });
      }),
      new Promise((resolve, reject) => {
        MonthlyPickupsHelper.getPickReportDeltaForMTD_v2(HotelId, currentDate, startdate, enddate, (err, hrevData) => {
          if (err) {
            reject(err);
          }
          if (hrevData) {
            mtdpickupList = hrevData;
            // console.log('4')
          }
          resolve();
        });
      }),

    ]).then(async resp => {
      for (var date = moment(startdate); date.isBefore(enddate); date.add(1, 'days')) {

        let mPickupReportDataModel = {};


        let data = _.find(pickupReportsList, function (x) {
          return new Date(moment(x.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString();
        });

        let totalroomssold = 0;
        let totalrevenue = 0;
        let transientRoomSold = 0;

        if (data != undefined) {

          let totalroomssold = data.NoOfRoomSold != null ? data.NoOfRoomSold : 0;
          let totalrevenue = data.TotalRevenue != null ? data.TotalRevenue : 0;
          let transientRoomSold = data.TransientRoomsSold != null ? data.TransientRoomsSold : 0;

          let dayDate = new Date(date).toISOString();

          if (dayDate == rptDate) {

            totalroomssold = 0;
            totalrevenue = 0;
            transientRoomSold = 0;

            if (HotelRevenueData.length > 0) {
              let sumRoomSold = 0;
              let sumtotalrevenue = 0;
              HotelRevenueData.forEach(element => {
                if (new Date(moment(element.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString()) {
                  sumRoomSold = element.NoOfReference + sumRoomSold;
                  sumtotalrevenue = element.Amount + sumtotalrevenue;
                }
              });
              totalroomssold = sumRoomSold;
              totalrevenue = sumtotalrevenue;
            }

          }


          let valset = await new Promise((resolve, reject) => PickupHelper.getPickUpDelta(HotelId, date, currentDate, 1, totalrevenue, totalroomssold, transientRoomSold, (err, result) => {
            if (err) {
              reject(err);
            }
            resolve(result);
          })
          )
          if (valset) {
            pickuprpt1Amount = valset.rptamount;
            pickuprpt1RoomSold = valset.rptroomsold;
            transientDelta1 = valset.transientDelta;
          }
        }




        mPickupReportDataModel.Day = moment(date).format('ddd');;
        mPickupReportDataModel.Date = moment(date).format("YYYY-MM-DD");

        mPickupReportDataModel.AvailRoom = hotelData.NumberofAvailableRooms;
        TotalAvailRoom += mPickupReportDataModel.AvailRoom;

        if (moment(date).format('YYYY-MM-DD') > moment(currentDate).format('YYYY-MM-DD')) {
          if (HotelRevenueFCData != null) {
            // mPickupReportDataModel.RoomsActual = HotelRevenueFCData.Where(x => x.Date == date).Sum(x => x.NoOfReference);
            let sum = 0;
            HotelRevenueFCData.forEach(element => {
              if (new Date(moment(element.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString()) {
                sum = element.NoOfRoomSold + sum;
              }
            });

            mPickupReportDataModel.RoomsActual = sum;
          } else {
            mPickupReportDataModel.RoomsActual = 0;
          }
        }
        else {
          if (HotelRevenueData.length > 0) {
            let sum = 0;
            HotelRevenueData.forEach(element => {
              if (new Date(moment(element.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString()) {
                sum = element.NoOfReference + sum;
              }
            });
            mPickupReportDataModel.RoomsActual = sum;
          } else {
            mPickupReportDataModel.RoomsActual = 0;
          }
        }

        TotalRoomsActual += mPickupReportDataModel.RoomsActual;
        let temp = _.find(hotelRoomBudgetData, function (o) { return new Date(moment(o.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format("YYYY-MM-DD")).toISOString(); }); //------------------------------------------->
        // console.log(hotelRoomBudgetData[4].Date.toISOString(), 'kakakakakaa');
        // console.log(new Date(moment(date).format("YYYY-MM-DD")).toISOString(), 'kakakakakaa2222');
        if (temp == null || temp == undefined)
          mPickupReportDataModel.RoomsBudget = 0;
        else
          mPickupReportDataModel.RoomsBudget = temp.BudgetRoomSold;

        TotalRoomsBudget += mPickupReportDataModel.RoomsBudget == null ? 0 : parseFloat(mPickupReportDataModel.RoomsBudget);

        mPickupReportDataModel.RoomsBudgetVariance = (mPickupReportDataModel.RoomsActual - mPickupReportDataModel.RoomsBudget);
        TotalRoomsBudgetVariance += mPickupReportDataModel.RoomsBudgetVariance == null ? 0 : parseFloat(mPickupReportDataModel.RoomsBudgetVariance);

        // mPickupReportDataModel.RoomsForcastBudget = _.find(hotelRoomBudgetData, function(o) { return o.Date.toISOString() == date.toISOString(); }).ForecastRoomSold;
        let temp2 = _.find(hotelRoomBudgetData, function (o) { return new Date(moment(o.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString(); });

        mPickupReportDataModel.RoomsForcastBudget = 0;
        if (temp2 == null || undefined || temp2.ForecastRoomSold == null)
          mPickupReportDataModel.RoomsForcastBudget = 0;
        else
          mPickupReportDataModel.RoomsForcastBudget = temp2.ForecastRoomSold == null ? 0 : temp2.ForecastRoomSold;


        TotalRoomsForcastBudget += mPickupReportDataModel.RoomsForcastBudget == null ? 0 : mPickupReportDataModel.RoomsForcastBudget;
        mPickupReportDataModel.RoomsForcastVariance = 0;
        if (mPickupReportDataModel.RoomsForcastBudget != 0) {
          mPickupReportDataModel.RoomsForcastVariance = mPickupReportDataModel.RoomsActual - mPickupReportDataModel.RoomsForcastBudget;
          TotalRoomsForcastVariance += mPickupReportDataModel.RoomsForcastVariance == null ? 0 : mPickupReportDataModel.RoomsForcastVariance;
        }

        if (date > currentDate) {
          if (HotelRevenueFCData != null) {
            let sum = 0;
            HotelRevenueFCData.forEach(element => {
              if (new Date(moment(element.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString()) {
                sum = element.TotalRevenue + sum;
              }
            });
            mPickupReportDataModel.ReveneActual = sum.toFixed(2);
          } else {
            mPickupReportDataModel.ReveneActual = 0;
          }
        }
        else {
          if (HotelRevenueData != null) {
            let sum = 0;
            HotelRevenueData.forEach(element => {
              if (new Date(moment(element.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString()) {
                sum = element.Amount + sum;
              }
            });
            mPickupReportDataModel.ReveneActual = sum.toFixed(2);
          } else {
            mPickupReportDataModel.ReveneActual = 0;
          }
        }

        TotalReveneActual += mPickupReportDataModel.ReveneActual == null ? 0 : parseFloat(mPickupReportDataModel.ReveneActual);

        // mPickupReportDataModel.ReveneBudget = _.find(hotelRoomBudgetData, function(o) { return o.Date.toISOString() == date.toISOString(); }).BudgetRoomRevenue;
        let temp3 = _.find(hotelRoomBudgetData, function (o) { return new Date(moment(o.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString(); });
        if (temp3 == null || undefined)
          mPickupReportDataModel.ReveneBudget = 0;
        else
          mPickupReportDataModel.ReveneBudget = (temp3.BudgetRoomRevenue).toFixed(2);

        TotalReveneBudget += mPickupReportDataModel.ReveneBudget == null ? 0 : parseFloat(mPickupReportDataModel.ReveneBudget);

        mPickupReportDataModel.ReveneBudgetVariance = (mPickupReportDataModel.ReveneActual - mPickupReportDataModel.ReveneBudget).toFixed(2);
        TotalReveneBudgetVariance += mPickupReportDataModel.ReveneBudgetVariance == null ? 0 : parseFloat(mPickupReportDataModel.ReveneBudgetVariance);

        // mPickupReportDataModel.RevenueForcastBudget = _.find(hotelRoomBudgetData, function(o) { return o.Date.toISOString() == date.toISOString(); }).ForecastRoomRevenue;
        let temp4 = _.find(hotelRoomBudgetData, function (o) { return new Date(moment(o.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString(); });
        if (temp4 == null || undefined || temp4.ForecastRoomRevenue == null)
          mPickupReportDataModel.RevenueForcastBudget = 0;
        else
          mPickupReportDataModel.RevenueForcastBudget = temp4.ForecastRoomRevenue == null ? 0 : parseFloat(temp4.ForecastRoomRevenue).toFixed(2);

        TotalRevenueForcastBudget += mPickupReportDataModel.RevenueForcastBudget == null ? 0 : parseFloat(mPickupReportDataModel.RevenueForcastBudget);

        mPickupReportDataModel.RevenueForcastVariance = 0;
        if (mPickupReportDataModel.RevenueForcastBudget != 0) {
          mPickupReportDataModel.RevenueForcastVariance = (mPickupReportDataModel.ReveneActual - mPickupReportDataModel.RevenueForcastBudget);
          TotalRevenueForcastVariance += mPickupReportDataModel.RevenueForcastVariance == null ? 0 : parseFloat(mPickupReportDataModel.RevenueForcastVariance);

        }

        if (mPickupReportDataModel.RoomsActual == 0) {
          mPickupReportDataModel.ADTActual = 0;
        } else {
          mPickupReportDataModel.ADTActual = (mPickupReportDataModel.ReveneActual / mPickupReportDataModel.RoomsActual);
        }

        TotalADTActual += mPickupReportDataModel.ADTActual == null ? 0 : parseFloat(mPickupReportDataModel.ADTActual);

        if (mPickupReportDataModel.RoomsBudget == 0) { mPickupReportDataModel.ADTBudget = 0; }
        else { mPickupReportDataModel.ADTBudget = (mPickupReportDataModel.ReveneBudget / mPickupReportDataModel.RoomsBudget) }
        TotalADTBudget += mPickupReportDataModel.ADTBudget == null ? 0 : parseFloat(mPickupReportDataModel.ADTBudget);

        mPickupReportDataModel.ADTBudgetVariance = (mPickupReportDataModel.ADTActual - mPickupReportDataModel.ADTBudget).toFixed(2);
        TotalADTBudgetVariance += (mPickupReportDataModel.TotalADTBudgetVariance == null && isNaN(mPickupReportDataModel.TotalADTBudgetVariance)) ? 0 : mPickupReportDataModel.TotalADTBudgetVariance;

        if (!isFinite(mPickupReportDataModel.ADTBudgetVariance)) {
          mPickupReportDataModel.ADTBudgetVariance = 0;
        }
        mPickupReportDataModel.ADTForcastBudget = 0;
        if (mPickupReportDataModel.RevenueForcastBudget != 0 && mPickupReportDataModel.RoomsForcastBudget != 0) {
          mPickupReportDataModel.ADTForcastBudget = (mPickupReportDataModel.RevenueForcastBudget / mPickupReportDataModel.RoomsForcastBudget);
          TotalADTForcastBudget += mPickupReportDataModel.ADTForcastBudget == null ? 0 : parseFloat(mPickupReportDataModel.ADTForcastBudget);
        }

        mPickupReportDataModel.ADTForcastVariance = 0;
        if (mPickupReportDataModel.ADTActual != 0 && mPickupReportDataModel.ADTForcastBudget != 0) {
          mPickupReportDataModel.ADTForcastVariance = mPickupReportDataModel.ADTActual - mPickupReportDataModel.ADTForcastBudget;
          TotalADTForcastVariance += mPickupReportDataModel.TotalADTForcastVariance == null ? 0 : mPickupReportDataModel.TotalADTForcastVariance;
        }

        mPickupReportDataModel.OccuActual = ((mPickupReportDataModel.RoomsActual / mPickupReportDataModel.AvailRoom) * 100);
        TotalOccuActual += mPickupReportDataModel.TotalOccuActual == null ? 0 : mPickupReportDataModel.TotalOccuActual;

        mPickupReportDataModel.OccuBudget = ((mPickupReportDataModel.RoomsBudget / mPickupReportDataModel.AvailRoom) * 100);
        TotalOccuBudget += mPickupReportDataModel.OccuBudget == null ? 0 : parseFloat(mPickupReportDataModel.OccuBudget);
        mPickupReportDataModel.OccuBudgetVariance = (mPickupReportDataModel.OccuActual - mPickupReportDataModel.OccuBudget);
        TotalOccuBudgetVariance += mPickupReportDataModel.OccuBudgetVariance == null ? 0 : parseFloat(mPickupReportDataModel.OccuBudgetVariance);

        mPickupReportDataModel.OccuForcastBudget = ((mPickupReportDataModel.RoomsForcastBudget / mPickupReportDataModel.AvailRoom) * 100).toFixed(2);
        TotalOccuForcastBudget += mPickupReportDataModel.TotalOccuForcastBudget == null ? 0 : mPickupReportDataModel.TotalOccuForcastBudget;

        mPickupReportDataModel.OccuForcastVariance = 0;
        if (mPickupReportDataModel.OccuActual != 0 && mPickupReportDataModel.OccuForcastBudget != 0) {
          mPickupReportDataModel.OccuForcastVariance = (mPickupReportDataModel.OccuActual - mPickupReportDataModel.OccuForcastBudget).toFixed(2);
          TotalOccuForcastVariance += mPickupReportDataModel.OccuForcastVariance == null ? 0 : parseFloat(mPickupReportDataModel.OccuForcastVariance);
        }
        mPickupReportDataModel.pickupToday = parseInt(pickuprpt1RoomSold);
        mPickupReportDataModel.pickupRevenue = pickuprpt1Amount.toFixed(2);

        TotalpickupToday += mPickupReportDataModel.pickupToday;

        // if (HotelRevenueData != null) {
        //   let sum = 0;
        //   dict.forEach(element => {
        //     if (element.Date.toISOString() == date.toISOString()) {
        //       sum = element.value + sum;
        //     }
        //   });
        //   mPickupReportDataModel.pickupMTD = sum.toFixed(2);
        // } else {
        //   mPickupReportDataModel.pickupMTD = 0;
        // }

        //TotalpickupMTD += parseFloat(mPickupReportDataModel.pickupMTD);

        mPickupReportDataModel.pickupMTD = 0;

        if (mtdpickupList && mtdpickupList.length > 0) {
          let sum = 0;
          mtdpickupList.forEach(element => {
            if (element.Date <= date) {
              sum = element.NoOfRoomSold + sum;
            }
          });
          mPickupReportDataModel.pickupMTD = sum.toFixed(2);
        }

        mPickupReportDataModel.RevparActual = (mPickupReportDataModel.ADTActual * mPickupReportDataModel.OccuActual) / 100;
        TotalRevparActual += (mPickupReportDataModel.RevparActual == null && isNaN(mPickupReportDataModel.RevparActual)) ? 0 : parseFloat(mPickupReportDataModel.RevparActual);

        mPickupReportDataModel.RevparBudget = (mPickupReportDataModel.ADTBudget * mPickupReportDataModel.OccuBudget) / 100;
        TotalRevparBudget += (mPickupReportDataModel.TotalRevparBudget == null || isNaN(mPickupReportDataModel.TotalRevparBudget)) ? 0 : mPickupReportDataModel.TotalRevparBudget;

        mPickupReportDataModel.RevparForcastBudget = (mPickupReportDataModel.RevenueForcastBudget / mPickupReportDataModel.AvailRoom).toFixed(2);
        TotalRevparForcastBudget += mPickupReportDataModel.RevparForcastBudget == null ? 0 : parseFloat(mPickupReportDataModel.RevparForcastBudget);

        mPickupReportDataModel.RoomsBudget = mPickupReportDataModel.RoomsBudget.toFixed(2);
        mPickupReportDataModel.RoomsBudgetVariance = mPickupReportDataModel.RoomsBudgetVariance.toFixed(2);
        mPickupReportDataModel.RevenueForcastVariance = mPickupReportDataModel.RevenueForcastVariance.toFixed(2);
        mPickupReportDataModel.ADTActual = mPickupReportDataModel.ADTActual.toFixed(2);
        mPickupReportDataModel.ADTBudget = mPickupReportDataModel.ADTBudget.toFixed(2);
        mPickupReportDataModel.OccuBudget = mPickupReportDataModel.OccuBudget.toFixed(2);
        mPickupReportDataModel.OccuBudgetVariance = mPickupReportDataModel.OccuBudgetVariance.toFixed(2);
        mPickupReportDataModel.OccuActual = mPickupReportDataModel.OccuActual.toFixed(2);
        mPickupReportDataModel.RevparActual = mPickupReportDataModel.RevparActual.toFixed(2);
        mPickupReportDataModel.RevparBudget = mPickupReportDataModel.RevparBudget.toFixed(2);
        // mPickupReportDataModel.TotalAvailRoom = null;
        // mPickupReportDataModel.TotalRoomsActual = null;
        // mPickupReportDataModel.TotalRoomsBudget = null;
        // mPickupReportDataModel.TotalRoomsBudgetVariance = null;
        // mPickupReportDataModel.TotalRoomsForcastBudget = null;
        // mPickupReportDataModel.TotalRoomsForcastVariance = null;
        // mPickupReportDataModel.TotalReveneActual = null;
        // mPickupReportDataModel.TotalReveneBudget = null;
        // mPickupReportDataModel.TotalReveneBudgetVariance = null;
        // mPickupReportDataModel.TotalRevenueForcastBudget = null;
        // mPickupReportDataModel.TotalRevenueForcastVariance = null;
        // mPickupReportDataModel.TotalADTActual = null;
        // mPickupReportDataModel.TotalADTBudget = null;
        // mPickupReportDataModel.TotalADTBudgetVariance = null;
        // mPickupReportDataModel.TotalADTForcastBudget = null;
        // mPickupReportDataModel.TotalADTForcastVariance = null;
        // mPickupReportDataModel.TotalOccuActual = null;
        // mPickupReportDataModel.TotalOccuBudget = null;
        // mPickupReportDataModel.TotalOccuBudgetVariance = null;
        // mPickupReportDataModel.TotalOccuForcastBudget = null;
        // mPickupReportDataModel.TotalOccuForcastVariance = null;
        // mPickupReportDataModel.TotalpickupToday = null;
        // mPickupReportDataModel.TotalpickupMTD = null;
        // mPickupReportDataModel.TotalRevparActual = null;
        // mPickupReportDataModel.TotalRevparBudget = null;
        // mPickupReportDataModel.TotalRevparBudgetVariance = null;
        // mPickupReportDataModel.TotalRevparForcastBudget = null;
        // mPickupReportDataModel.TotalRevparForcastVariance = null;


        //add formatting
        let obj = {};
        Object.keys(mPickupReportDataModel).forEach(function (key, index) {

          if (!isNaN((mPickupReportDataModel[key]))) {
            if (mPickupReportDataModel[key] != null) {
              obj[key] = parseFloat(mPickupReportDataModel[key]).toFixed(2);
            } else {
              obj[key] = mPickupReportDataModel[key];
            }
          } else {
            obj[key] = mPickupReportDataModel[key];
          }
        });

        PickupReportDataModelList.push(obj);
        // });
      }
      // PickupReportDataModelList.push(mPickupReportDataModel);

      PickupReportDataModelList[0].TotalAvailRoom = TotalAvailRoom;
      PickupReportDataModelList[0].TotalRoomsActual = TotalRoomsActual;
      PickupReportDataModelList[0].TotalRoomsBudget = TotalRoomsBudget.toFixed(2);
      PickupReportDataModelList[0].TotalRoomsBudgetVariance = TotalRoomsBudgetVariance.toFixed(2);
      PickupReportDataModelList[0].TotalRoomsForcastBudget = TotalRoomsForcastBudget;
      PickupReportDataModelList[0].TotalRoomsForcastVariance = TotalRoomsForcastVariance;
      PickupReportDataModelList[0].TotalReveneActual = TotalReveneActual.toFixed(2);
      PickupReportDataModelList[0].TotalReveneBudget = TotalReveneBudget.toFixed(2);
      PickupReportDataModelList[0].TotalReveneBudgetVariance = TotalReveneBudgetVariance.toFixed(2);
      PickupReportDataModelList[0].TotalRevenueForcastBudget = TotalRevenueForcastBudget;
      PickupReportDataModelList[0].TotalRevenueForcastVariance = TotalRevenueForcastVariance;

      if (PickupReportDataModelList[0].TotalReveneActual != 0 && PickupReportDataModelList[0].TotalRoomsActual != 0) {
        TotalADTActual = (PickupReportDataModelList[0].TotalReveneActual / PickupReportDataModelList[0].TotalRoomsActual);
        PickupReportDataModelList[0].TotalADTActual = TotalADTActual.toFixed(2);
      }

      if (PickupReportDataModelList[0].TotalReveneBudget != 0 && PickupReportDataModelList[0].TotalRoomsBudget != 0) {
        TotalADTBudget = (PickupReportDataModelList[0].TotalReveneBudget / PickupReportDataModelList[0].TotalRoomsBudget);
        PickupReportDataModelList[0].TotalADTBudget = TotalADTBudget.toFixed(2);
      }

      if (PickupReportDataModelList[0].TotalADTActual != 0 && PickupReportDataModelList[0].TotalADTBudget != 0) {
        TotalADTBudgetVariance = (PickupReportDataModelList[0].TotalADTActual - PickupReportDataModelList[0].TotalADTBudget);
        PickupReportDataModelList[0].TotalADTBudgetVariance = isNaN(TotalADTBudgetVariance) ? 0 : TotalADTBudgetVariance.toFixed(2);
      }

      PickupReportDataModelList[0].TotalADTForcastBudget = 0;
      if (PickupReportDataModelList[0].TotalRevenueForcastBudget != 0 && PickupReportDataModelList[0].TotalRoomsForcastBudget != 0) {
        TotalADTForcastBudget = (PickupReportDataModelList[0].TotalRevenueForcastBudget / PickupReportDataModelList[0].TotalRoomsForcastBudget);
        PickupReportDataModelList[0].TotalADTForcastBudget = TotalADTForcastBudget.toFixed(2);
      }

      PickupReportDataModelList[0].TotalADTForcastVariance = 0;
      if (PickupReportDataModelList[0].TotalADTActual != 0 && PickupReportDataModelList[0].TotalADTForcastBudget != 0) {
        TotalADTForcastVariance = (PickupReportDataModelList[0].TotalADTActual - PickupReportDataModelList[0].TotalADTForcastBudget);
        PickupReportDataModelList[0].TotalADTForcastVariance = TotalADTForcastVariance.toFixed(2);
      }


      if (PickupReportDataModelList[0].TotalRoomsActual != 0 && PickupReportDataModelList[0].TotalAvailRoom != 0) {
        TotalOccuActual = ((PickupReportDataModelList[0].TotalRoomsActual / PickupReportDataModelList[0].TotalAvailRoom) * 100);
        PickupReportDataModelList[0].TotalOccuActual = TotalOccuActual.toFixed(2);
      }
      if (PickupReportDataModelList[0].TotalRoomsBudget != 0 && PickupReportDataModelList[0].TotalAvailRoom != 0) {
        TotalOccuBudget = ((PickupReportDataModelList[0].TotalRoomsBudget / PickupReportDataModelList[0].TotalAvailRoom) * 100);
        PickupReportDataModelList[0].TotalOccuBudget = TotalOccuBudget.toFixed(2);
      }

      if (PickupReportDataModelList[0].TotalOccuBudget != 0 && PickupReportDataModelList[0].TotalOccuActual != 0) {
        TotalOccuBudgetVariance = PickupReportDataModelList[0].TotalOccuActual - PickupReportDataModelList[0].TotalOccuBudget;
        PickupReportDataModelList[0].TotalOccuBudgetVariance = isNaN(TotalOccuBudgetVariance) ? 0 : TotalOccuBudgetVariance.toFixed(2);
      }
      PickupReportDataModelList[0].TotalOccuForcastBudget = 0;
      if (PickupReportDataModelList[0].TotalRoomsForcastBudget != 0 && PickupReportDataModelList[0].TotalAvailRoom != 0) {
        TotalOccuForcastBudget = ((PickupReportDataModelList[0].TotalRoomsForcastBudget / PickupReportDataModelList[0].TotalAvailRoom) * 100);
        PickupReportDataModelList[0].TotalOccuForcastBudget = TotalOccuForcastBudget.toFixed(2);
      }

      PickupReportDataModelList[0].TotalOccuForcastVariance = 0;
      if (PickupReportDataModelList[0].TotalOccuForcastBudget != 0 && PickupReportDataModelList[0].TotalOccuActual != 0) {
        TotalOccuForcastVariance = PickupReportDataModelList[0].TotalOccuActual - PickupReportDataModelList[0].TotalOccuForcastBudget;
        PickupReportDataModelList[0].TotalOccuForcastVariance = TotalOccuForcastVariance.toFixed(2);
      }

      PickupReportDataModelList[0].TotalpickupToday = TotalpickupToday;
      PickupReportDataModelList[0].TotalpickupMTD = PickupReportDataModelList[PickupReportDataModelList.length - 1].pickupMTD;

      PickupReportDataModelList[0].TotalRevparActual = 0;
      if (PickupReportDataModelList[0].TotalADTActual != 0 && PickupReportDataModelList[0].TotalOccuActual != 0) {
        TotalRevparActual = (PickupReportDataModelList[0].TotalADTActual * PickupReportDataModelList[0].TotalOccuActual) / 100;
        PickupReportDataModelList[0].TotalRevparActual = isNaN(TotalRevparActual) ? 0 : TotalRevparActual.toFixed(2);
      }

      PickupReportDataModelList[0].TotalRevparBudget = 0;
      if (PickupReportDataModelList[0].TotalADTBudget != 0 && PickupReportDataModelList[0].TotalOccuBudget != 0) {
        TotalRevparBudget = (PickupReportDataModelList[0].TotalADTBudget * PickupReportDataModelList[0].TotalOccuBudget) / 100;
        PickupReportDataModelList[0].TotalRevparBudget = isNaN(TotalRevparBudget) ? 0 : TotalRevparBudget.toFixed(2);
      }

      PickupReportDataModelList[0].TotalRevparBudgetVariance = 0;
      if (PickupReportDataModelList[0].TotalRevparBudget != 0 && PickupReportDataModelList[0].TotalRevparActual != 0) {
        TotalRevparBudgetVariance = PickupReportDataModelList[0].TotalRevparActual - PickupReportDataModelList[0].TotalRevparBudget;
        PickupReportDataModelList[0].TotalRevparBudgetVariance = isNaN(TotalRevparBudgetVariance) ? 0: TotalRevparBudgetVariance.toFixed(2);
      }


      PickupReportDataModelList[0].TotalRevparForcastBudget = TotalRevparForcastBudget.toFixed(2);
      PickupReportDataModelList[0].TotalRevparForcastVariance = TotalRevparForcastVariance.toFixed(2);

      return cb(null, PickupReportDataModelList);

    }, err => {
      return cb(err);
    });


  }

  static getHotelBudgetDashboardCalculation(startdate, enddate, hotelId, cb) {

    let starttime = new Date();
    startdate = startdate.toISOString();
    startdate = new Date(startdate);
    enddate = enddate.toISOString();
    enddate = new Date(enddate);

    HotelbudgetdashboardcalculationsSchema.find({ [HotelbudgetdashboardcalculationsSchemaFields.HotelID]: hotelId, [HotelbudgetdashboardcalculationsSchemaFields.Date]: { "$gte": startdate, "$lte": enddate } },
      (err, hotelDashboardCalculationList) => {

        if (err) {
          log.error(err)
          cb(err, null);
        }
        if (!hotelDashboardCalculationList) {
          return cb("Monthly Dashboard Calculations data not found ", null);
        }
        return cb(null, hotelDashboardCalculationList);
      });

  }

  static getPickReportTableDataForPickup(hotelId, currentDate, startdate, enddate, cb) {
    let pickupReportsList = [];

    currentDate = currentDate.toISOString();
    currentDate = new Date(currentDate);
    startdate = startdate.toISOString();
    startdate = new Date(startdate);
    enddate = enddate.toISOString();
    enddate = new Date(enddate);

    // console.log(currentDate , 'cd')
    // console.log(startdate , 'sd')
    // console.log(enddate , 'ed')

    PickupreportSchema.find({ [PickupSchemaFields.HotelID]: hotelId, [PickupSchemaFields.ReportedDateTime]: currentDate, [PickupSchemaFields.Date]: { "$gte": startdate, "$lte": enddate } },
      (err, result) => {
        if (err) {
          log.error(err)
          cb(err, null);
        }
        if (!result) {
          return cb("Pickup report data not found ", null);
        }

        pickupReportsList = _.orderBy(result, ['UpdatedDateTime'], ['asc']);

        return cb(null, pickupReportsList);
      });
  }

  static getHotelRevenues(startdate, enddate, hotelid, cb) {
    let hotelRevenueNoLockViewroomRevenueList = [];
    let roomRevenueList = [];

    startdate = startdate.toISOString();
    startdate = new Date(startdate);
    enddate = enddate.toISOString();
    enddate = new Date(enddate);

    if (new Date(startdate) >= new Date()) {
      let category = 'ForcastRoomRevenue';
      HotelrevenueSchema.find({ [HotelrevenueSchemaFields.HotelID]: hotelid, [HotelrevenueSchemaFields.Category]: category, [HotelrevenueSchemaFields.Description]: ["forecast", "blocks", "group"], [HotelrevenueSchemaFields.IsDelete]: false, [HotelrevenueSchemaFields.Date]: { "$gte": startdate, "$lte": enddate } },
        (err, result) => {
          if (err) {
            log.error(err)
            cb(err, null);
          }
          if (!result) {
            return cb("hotel revenue data not found ", null);
          }
          hotelRevenueNoLockViewroomRevenueList = result;

          hotelRevenueNoLockViewroomRevenueList.forEach(element => {
            let hotelRevenue = {
              Amount: element.Amount,
              AmountMTD: element.AmountMTD,
              AmountYTD: element.AmountYTD,
              HotelID: element.HotelID,
              ID: element.ID,
              NumberofAvailableRooms: element.NumberofAvailableRooms,
              Category: element.Category,
              Date: element.Date,
              Description: element.Description,
              GroupBlock: element.GroupBlock,
              GroupRoomRevenue: element.GroupRoomRevenue,
              GroupRoomsSold: element.GroupRoomsSold,
              IsDelete: element.IsDelete,
              NoOfReference: element.NoOfReference,
              PMSCode: element.PMSCode,
              PMSType: element.PMSType,
              ReportedDateTime: element.ReportedDateTime,
              ReportName: element.ReportName,
              TransientRoomRevenue: element.TransientRoomRevenue,
              TransientRoomsSold: element.TransientRoomsSold,
              UpdatedBy: element.UpdatedBy,
              UpdatedDateTime: element.UpdatedDateTime
            }
            roomRevenueList.push(hotelRevenue);
          });

          return cb(null, roomRevenueList)
        });
    } else {
      HotelrevenueSchema.find({ [HotelrevenueSchemaFields.HotelID]: hotelid, [HotelrevenueSchemaFields.Category]: "RoomRevenue", [HotelrevenueSchemaFields.IsDelete]: false, [HotelrevenueSchemaFields.Date]: { "$gte": startdate, "$lte": enddate } },
        (err, result) => {
          if (err) {
            log.error(err)
            cb(err, null);
          }
          // console.log(result)
          if (!result) {
            return cb("hotel revenue data not found ", null);
          }
          hotelRevenueNoLockViewroomRevenueList = result;

          hotelRevenueNoLockViewroomRevenueList.forEach(element => {
            let hotelRevenue = {
              Amount: element.Amount,
              AmountMTD: element.AmountMTD,
              AmountYTD: element.AmountYTD,
              HotelID: element.HotelID,
              ID: element.ID,
              NumberofAvailableRooms: element.NumberofAvailableRooms,
              Category: element.Category,
              Date: element.Date,
              Description: element.Description,
              GroupBlock: element.GroupBlock,
              GroupRoomRevenue: element.GroupRoomRevenue,
              GroupRoomsSold: element.GroupRoomsSold,
              IsDelete: element.IsDelete,
              NoOfReference: element.NoOfReference,
              PMSCode: element.PMSCode,
              PMSType: element.PMSType,
              ReportedDateTime: element.ReportedDateTime,
              ReportName: element.ReportName,
              TransientRoomRevenue: element.TransientRoomRevenue,
              TransientRoomsSold: element.TransientRoomsSold,
              UpdatedBy: element.UpdatedBy,
              UpdatedDateTime: element.UpdatedDateTime
            }
            roomRevenueList.push(hotelRevenue);
          });

          return cb(null, roomRevenueList)
        });
    }

    // hotelRevenueNoLockViewroomRevenueList.forEach(element => {
    //   let hotelRevenue = {
    //     Amount: element.Amount,
    //     AmountMTD: element.AmountMTD,
    //     AmountYTD: element.AmountYTD,
    //     HotelID: element.HotelID,
    //     ID: element.ID,
    //     NumberofAvailableRooms: element.NumberofAvailableRooms,
    //     Category: element.Category,
    //     Date: element.Date,
    //     Description: element.Description,
    //     GroupBlock: element.GroupBlock,
    //     GroupRoomRevenue: element.GroupRoomRevenue,
    //     GroupRoomsSold: element.GroupRoomsSold,
    //     IsDelete: element.IsDelete,
    //     NoOfReference: element.NoOfReference,
    //     PMSCode: element.PMSCode,
    //     PMSType: element.PMSType,
    //     ReportedDateTime: element.ReportedDateTime,
    //     ReportName: element.ReportName,
    //     TransientRoomRevenue: element.TransientRoomRevenue,
    //     TransientRoomsSold: element.TransientRoomsSold,
    //     UpdatedBy: element.UpdatedBy,
    //     UpdatedDateTime: element.UpdatedDateTime
    //   }
    //   roomRevenueList.push(hotelRevenue);
    // });

    // return cb(null, roomRevenueList)
  }

  static getHotelRevenuesForPickupReport(reportdate, startdate, enddate, HotelId, cb) {
    let RRevenueListFC = [];
    PickupreportSchema.find({
      [PickupSchemaFields.HotelID]: HotelId,
      [PickupSchemaFields.ReportedDateTime]: reportdate, [PickupSchemaFields.Date]: { "$gte": startdate, "$lte": enddate }
    },
      (err, result) => {
        if (err) {
          log.error(err)
          cb(err, null);
        }
        // console.log(result)
        if (!result) {
          return cb("pickup report data not found ", null);
        }
        RRevenueListFC = result;
        RRevenueListFC = _.orderBy(RRevenueListFC, ['Date'], ['asc']);
        return cb(null, RRevenueListFC);
      });


  }

  static getHotelRevenuesForPickup(startdate, enddate, HotelId, cb) {
    let RRevenueListFC = [];

    let pArr = [];
    for (var m = moment(startdate); m.isBefore(enddate); m.add(1, 'days')) {
      let hotelRevenue = [];
      pArr.push(
        HotelrevenueSchema.find({ [HotelrevenueSchemaFields.HotelID]: HotelId, [HotelrevenueSchemaFields.Category]: "ForcastRoomRevenue", [HotelrevenueSchemaFields.IsDelete]: false, [HotelrevenueSchemaFields.Description]: { $in: ["Forecast", "Blocks", "Group"] }, [HotelrevenueSchemaFields.Date]: new Date(moment(m).format('YYYY-MM-DD')).toISOString() },
          (err, result) => {
            if (err) {
              log.error(err)
              cb(err, null);
            }
            // console.log(result)
            if (!result) {
              return cb("hotel revenue data not found ", null);
            }
            hotelRevenue = result;
            if (hotelRevenue.length > 0) {
              hotelRevenue = _.orderBy(hotelRevenue, ['ReportedDateTime'], ['asc']);
              RRevenueListFC.push(hotelRevenue[(hotelRevenue.length) - 1]);
            }
          })
      )
    }
    Promise.all(pArr).then(resp => {
      return cb(null, RRevenueListFC);
    })
  }

  static getPickReportDeltaForMTD_v2(hotelId, currentDate, startdate, enddate, cb) {
    currentDate = new Date(currentDate).toISOString();
    startdate = new Date(startdate).toISOString();
    enddate = new Date(enddate).toISOString();

    let pickupReportsList = [];
    let pickupReportsListDelta = [];
    let pickupReportsListFinal = [];

    PickupreportSchema.find({
      [PickupSchemaFields.HotelID]: hotelId,
      [PickupSchemaFields.ReportedDateTime]: currentDate, [PickupSchemaFields.Date]: { "$gt": currentDate, "$lte": enddate }
    },
      (err, result) => {
        if (err) {
          log.error(err)
          cb(err, null);
        }
        // console.log(result)
        if (!result) {
          return cb("pickup report data not found ", null);
        }
        pickupReportsList = result;

        //hotelrevenue
        HoteldashboardcalculationsSchema.findOne({
          [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId,
          [HoteldashboardcalculationsSchemaFields.Date]: { "$gte": currentDate, "$lte": currentDate }
        },
          (err1, result1) => {
            if (err1) {
              log.error(err1)
            }
            // console.log(result)
            if (result1) {

              var objPickupReport = {};
              objPickupReport.HotelID = result1.HotelID;
              objPickupReport.NoOfRoomSold = result1.NoOfRoomSold;
              objPickupReport.TotalRevenue = result1.TotalRevenue;
              objPickupReport.Date = result1.Date;
              objPickupReport.ReportedDateTime = currentDate;
              pickupReportsList.push(objPickupReport);
            }

            //currentDateDelta
            let currentDateDelta = new Date(currentDate);
            currentDateDelta = Utils.addDays(currentDateDelta, -1);
            PickupreportSchema.find({
              [PickupSchemaFields.HotelID]: hotelId,
              [PickupSchemaFields.ReportedDateTime]: currentDateDelta, [PickupSchemaFields.Date]: { "$gt": currentDateDelta, "$lte": enddate }
            },
              (err2, result2) => {
                if (err2) {
                  log.error(err2)
                }
                // console.log(result)
                if (result2) {
                  pickupReportsListDelta = result2;
                }

                //hotelrevenue delta
                HoteldashboardcalculationsSchema.findOne({
                  [HoteldashboardcalculationsSchemaFields.HotelID]: hotelId,
                  [HoteldashboardcalculationsSchemaFields.Date]: { "$gte": currentDateDelta, "$lte": currentDateDelta }
                },
                  (err3, result3) => {
                    if (err3) {
                      log.error(err3)
                    }
                    // console.log(result)
                    if (result3) {

                      var objPickupReport = {};
                      objPickupReport.HotelID = result3.HotelID;
                      objPickupReport.NoOfRoomSold = result3.NoOfRoomSold;
                      objPickupReport.TotalRevenue = result3.TotalRevenue;
                      objPickupReport.Date = result3.Date;
                      objPickupReport.ReportedDateTime = currentDateDelta;
                      pickupReportsListDelta.push(objPickupReport);
                    }


                    pickupReportsList.forEach(function (item) {

                      if (pickupReportsListDelta && pickupReportsListDelta.length > 0) {

                        var deltaroomsold = 0;
                        var deltaroomrevenue = 0;

                        // let data = _.find(pickupReportsList, function (x) {
                        //   return new Date(moment(x.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(date).format('YYYY-MM-DD')).toISOString();
                        // });

                        let filtered_item = pickupReportsListDelta.filter(x => {
                          return new Date(moment(x.Date).format('YYYY-MM-DD')).toISOString() == new Date(moment(item.Date).format('YYYY-MM-DD')).toISOString();
                        });

                        if (filtered_item.length > 0) {
                          filtered_item = filtered_item[0];
                          deltaroomsold = filtered_item.NoOfRoomSold;
                          deltaroomrevenue = filtered_item.TotalRevenue;
                        }

                        var objPickupReport = {};
                        objPickupReport.HotelID = item.HotelID;
                        objPickupReport.NoOfRoomSold = item.NoOfRoomSold - deltaroomsold;
                        objPickupReport.TotalRevenue = item.TotalRevenue - deltaroomrevenue;
                        objPickupReport.Date = item.Date;
                        objPickupReport.ReportedDateTime = item.ReportedDateTime;
                        pickupReportsListFinal.push(objPickupReport);

                      }

                    });

                    pickupReportsListFinal = _.orderBy(pickupReportsListFinal, ['Date'], ['asc']);

                    return cb(null, pickupReportsListFinal);
                  });

              });
          });

        // pickupReportsList = _.orderBy(pickupReportsList, ['ReportedDateTime'], ['asc']);

        // return cb(null, pickupReportsList);
      });
  }

  static getPickReportDeltaForMTD(hotelId, currentDate, startdate, enddate, cb) {
    currentDate = new Date(currentDate).toISOString();
    startdate = new Date(startdate).toISOString();
    enddate = new Date(enddate).toISOString();

    let pickupReportsList = [];

    PickupreportSchema.find({
      [PickupSchemaFields.HotelID]: hotelId,
      [PickupSchemaFields.Date]: currentDate, [PickupSchemaFields.ReportedDateTime]: { "$gt": startdate, "$lte": enddate }
    },
      (err, result) => {
        if (err) {
          log.error(err)
          cb(err, null);
        }
        // console.log(result)
        if (!result) {
          return cb("pickup report data not found ", null);
        }
        pickupReportsList = result;
        pickupReportsList = _.orderBy(pickupReportsList, ['ReportedDateTime'], ['asc']);

        return cb(null, pickupReportsList);
      });
  }

  static calculateDelta(pickupList, cb) {
    let dict = [];
    let delta1 = '';

    for (let index = 1; index < pickupList.Count; index++) {
      let rptdate = pickupList[index].ReportedDateTime;
      delta1 = pickupList[index].NoOfRoomSold - pickupList[index - 1].NoOfRoomSold;
      dict.push({
        "Date": rptdate,
        "value": delta1
      });
    }
    return cb(null, dict);
  }

  static getMonthlyPickupData_GraphQL(hotelId, month, currentdate, cb) {

    //get myp hotelid from cmp_id
    return HotelsHelper.getHotelDataByCMPID(hotelId, (err, hoteldata) => {
      if (err) {
        cb(err, null);
      }
      if (!hoteldata) {
        cb(Constants.HotelNotFound, null);
      }
      else {
        MonthlyPickupsHelper.getMonthlyPickupData(hoteldata.ID, month, currentdate, cb, (err, result) => {
          // console.log(result, 'called')
          if (err) {
            cb(err, null);
          }
          cb(null, result);
        });
      }
    });

  }
}

module.exports = MonthlyPickupsHelper;