
const { Createowntablemappingsgroup: CreateowntablemappingsgroupsSchema, SchemaField: CreateowntablemappingsgroupsSchemaFields } = require('../models/createowntablemappingsgroups');
const dbtable = require('../schema/db_table');
var log = require('log4js').getLogger("createowntablemappingsgroup_helper");
const SequenceHelper = require('./sequence_helper');
const DBTable = require('../schema/db_table');

class CreateowntablemappingsgroupHelper {

    static createGroup(data, cb) {
        log.debug('Call createGroup, userid:' + data.userid + 'groupname: ' + data.name);
        var today = new Date();
        SequenceHelper.getValueForNextSequence(DBTable.CREATEOWNTABLEMAPPINGGROUP, (err, result) => {
            if (result) {
                let id = parseInt(result);
                var createowntablemappingsgroup = {
                    [CreateowntablemappingsgroupsSchemaFields.ID]: id,
                    [CreateowntablemappingsgroupsSchemaFields.GroupName]: data.name,
                    [CreateowntablemappingsgroupsSchemaFields.GroupColor]: data.color,
                    [CreateowntablemappingsgroupsSchemaFields.DisplayOrder]: id,
                    [CreateowntablemappingsgroupsSchemaFields.UserID]: data.userid,
                    [CreateowntablemappingsgroupsSchemaFields.UpdateDateTime]: today,
                    [CreateowntablemappingsgroupsSchemaFields.kpilist]: data.kpilist
                };

                let createowntablemappingsgroupsSchema = new CreateowntablemappingsgroupsSchema(createowntablemappingsgroup);
                createowntablemappingsgroupsSchema.save((err, createowntablemappingsgroup_result) => {
                    if (err)
                        return cb(err, null);
                    else {
                        return cb(null, createowntablemappingsgroup_result);
                    }
                })
            }
            else {
                return cb(new Error(HttpMsg.internalErrorMsg), null);
            }
        });
    }


    static editGroup(data, cb) {

        log.debug('Call editGroup, userid:' + data.userid + 'groupname: ' + data.name + "groupid:" + data.groupid);
        var today = new Date();
        CreateowntablemappingsgroupsSchema.findOneAndUpdate(
            {
                [CreateowntablemappingsgroupsSchemaFields.ID]: data.groupid,
            },
            {
                [CreateowntablemappingsgroupsSchemaFields.GroupName]: data.name,
                [CreateowntablemappingsgroupsSchemaFields.GroupColor]: data.color,
                [CreateowntablemappingsgroupsSchemaFields.UserID]: data.userid,
                [CreateowntablemappingsgroupsSchemaFields.UpdateDateTime]: today,
                [CreateowntablemappingsgroupsSchemaFields.kpilist]: data.kpilist
            },
            {
                new: true
            }
        ).exec((err, result) => {
            cb(null, result);
        })

    }



    static createGroup_graphQL(userid, name, color, kpilist, cb) {
        log.debug('Call createGroup, userid:' + userid + 'groupname: ' + name);
        var today = new Date();
        var kpilistjson = [];

        kpilist.forEach((element, index) => {
            kpilistjson.push({ KPIKey: element });
        });

        SequenceHelper.getValueForNextSequence(DBTable.CREATEOWNTABLEMAPPINGGROUP, (err, result) => {
            if (result) {
                let id = parseInt(result);
                var createowntablemappingsgroup = {
                    [CreateowntablemappingsgroupsSchemaFields.ID]: id,
                    [CreateowntablemappingsgroupsSchemaFields.GroupName]: name,
                    [CreateowntablemappingsgroupsSchemaFields.GroupColor]: color,
                    [CreateowntablemappingsgroupsSchemaFields.DisplayOrder]: id,
                    [CreateowntablemappingsgroupsSchemaFields.UserID]: userid,
                    [CreateowntablemappingsgroupsSchemaFields.UpdateDateTime]: today,
                    [CreateowntablemappingsgroupsSchemaFields.kpilist]: kpilistjson
                };

                let createowntablemappingsgroupsSchema = new CreateowntablemappingsgroupsSchema(createowntablemappingsgroup);
                createowntablemappingsgroupsSchema.save((err, createowntablemappingsgroup_result) => {
                    if (err)
                        return cb(err, null);
                    else {
                        return cb(null, createowntablemappingsgroup_result);
                    }
                })
            }
            else {
                return cb(new Error(HttpMsg.internalErrorMsg), null);
            }
        });
    }

    static GetKPIGroupData(userid, cb) {
        log.debug('Call GetKPIGroupData, userid:' + userid);
        CreateowntablemappingsgroupsSchema.find({ [CreateowntablemappingsgroupsSchemaFields.UserID]: userid }, (err, result) => {
            cb(null, result);
        })
    }


    static editGroup_graphQL(userid, groupid, name, color, kpilist, cb) {
        log.debug('Call editGroup_graphQL, userid:' + userid + 'groupname: ' + name + "groupid:" + groupid);
        var today = new Date();
        var kpilistjson = [];

        kpilist.forEach((element, index) => {
            kpilistjson.push({ KPIKey: element });
        });
        CreateowntablemappingsgroupsSchema.findOneAndUpdate(
            {
                [CreateowntablemappingsgroupsSchemaFields.ID]: groupid,
            },
            {
                [CreateowntablemappingsgroupsSchemaFields.GroupName]: name,
                [CreateowntablemappingsgroupsSchemaFields.GroupColor]: color,
                [CreateowntablemappingsgroupsSchemaFields.UserID]: userid,
                [CreateowntablemappingsgroupsSchemaFields.UpdateDateTime]: today,
                [CreateowntablemappingsgroupsSchemaFields.kpilist]: kpilistjson
            },
            {
                new: true
            }
        ).exec((err, result) => {
            cb(null, result);
        })
    }



    static removeGroup(userid, groupid, cb) {

        log.debug('Call removeGroup, userid:' + userid + 'groupid:' + groupid);

        return CreateowntablemappingsgroupsSchema.deleteOne({ [CreateowntablemappingsgroupsSchemaFields.ID]: groupid }, (err, result) => {
            if (err) {
                log.error(err);
            }
            cb(null, result);
        })
    }

}

module.exports = CreateowntablemappingsgroupHelper;
