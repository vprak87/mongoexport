const axios = require('axios');
const qs = require('qs');
var log = require('log4js').getLogger("rest_helper");

class RESTHelper {

    static POST(url, data, cb) {

        return axios.post(url, qs.stringify(data))
            .then(function (response) {
                log.debug(response);
                cb(null, response);
            })
            .catch(function (error) {
                log.error(error);
                cb(error, null);
            });
    }


    static GET(url, cb) {

        return axios.get(url)
            .then(function (response) {
                log.debug(response);
                cb(null, response);
            })
            .catch(function (error) {
                log.error(error);
                cb(error, null);
            });
    }


    static DELETE(url, data, cb) {

        return axios.delete(url, { data: { id: data.id } })
            .then(function (response) {
                log.debug(response);
                cb(null, response);
            })
            .catch(function (error) {
                log.error(error);
                cb(error, null);
            });
    }
    static GET_OtaRateData(baseURL,url,accessToken,OTASubscriptionID,date,shopLength,bar,ota, cb) {
        // Set config defaults when creating the instance
        const instance = axios.create({
            baseURL: baseURL
        });
        
        // Alter defaults after instance has been created
        instance.defaults.headers.common['Token'] = accessToken;         
        instance.get(url,{ params: { token:accessToken,subscriptionId: OTASubscriptionID,fromDate:date,shopLength:shopLength,bar:bar,ota:ota } })       
        .then(function (response) {
            cb(null, response);
        })
        .catch(function (error) {
            log.error(error);
            cb(error, null);
        });
    }
    static GET_OtaDemandData(baseURL,url,accessToken,OTASubscriptionID, cb) {
        // Set config defaults when creating the instance
        const instance = axios.create({
            baseURL: baseURL
        });
        
        // Alter defaults after instance has been created
        instance.defaults.headers.common['Token'] = accessToken;         
        instance.get(url,{ params: { token:accessToken,subscriptionId: OTASubscriptionID} })       
        .then(function (response) {
            cb(null, response);
        })
        .catch(function (error) {
            cb(error, null);
        });
    }
    static GET_FBPageLike(baseURL,url,fbpageurl, cb) {
        // Set config defaults when creating the instance
        const instance = axios.create({
            baseURL: baseURL
        });
        
        // Alter defaults after instance has been created
        instance.defaults.headers.common['Token'] = '';         
        instance.post(url,{ params: {href:fbpageurl,show_facepile:false,hide_cover:true }})       
        .then(function (response) {

            cb(null, response);
        })
        .catch(function (error) {
            cb(error, null);
        });
    }
    static GET_CurrancyExchange(baseURL,url,fromdata,todata, cb) {
        // Set config defaults when creating the instance
        const instance = axios.create({
            baseURL: baseURL
        });
        
        // Alter defaults after instance has been created
        instance.defaults.headers.common['Token'] = '';         
        instance.get(url,{ params: {from:fromdata,to:todata }})       
        .then(function (response) {
            cb(null, response);
        })
        .catch(function (error) {
            cb(error, null);
        });
    }
}

module.exports = RESTHelper;
