const { ScreenshotScheduler: ScreenshotSchedulerSchema, SchemaField: ScreenshotSchedulerSchemaFields } = require('../models/screenshotscheduler');
const dbtable = require('../schema/db_table');
const SequenceHelper = require('../helpers/sequence_helper')
const ScreenshotSchedulerData = require('../screenshotscheduler/models/screenshotschedulerdata'); 
const _ = require('lodash');
const log = require('log4js').getLogger("screenshotscheduler_helper");

class ScreenShotSchedulerHelper {
    
    static createOrUpdateScreenshotScheduler(id,userid, baseurl, page, schedulepageurl,createddate, cb) {

        ScreenshotSchedulerSchema.findOne({ [ScreenshotSchedulerSchemaFields.ID]: id }, (err, scheduler) => {
            if (err) {
                log.error(err);
            }
            if (!scheduler) {
               //#region  
                log.debug('Call Create ScreenshotScheduler , userid:' + userid + ' baseurl:' + baseurl + 'page:' + page+ ' createddate:' + createddate);
                SequenceHelper.getValueForNextSequence(dbtable.SCREENSHOTSCHEDULER, (err, seq_result) => {
                    if (seq_result) {
                        let id = parseInt(seq_result);

                        var screenshotscheduler = {
                            [ScreenshotSchedulerSchemaFields.ID]: id,
                            [ScreenshotSchedulerSchemaFields.BaseURL]: baseurl,
                            [ScreenshotSchedulerSchemaFields.Page]: page,
                            [ScreenshotSchedulerSchemaFields.SchedulePageURL]: schedulepageurl,
                            [ScreenshotSchedulerSchemaFields.CreatedDate]: createddate,
                            [ScreenshotSchedulerSchemaFields.UserID]: userid
                        };

                        let screenshotschedulerSchema = new ScreenshotSchedulerSchema(screenshotscheduler);
                        screenshotschedulerSchema.save((err, result) => {
                            if (err)
                                return cb(err, null);
                            else {
                                return cb(null, [result]);
                            }
                        })
                    }
                    else {
                        return cb(new Error(HttpMsg.internalErrorMsg), null);
                    }
                });
               //#endregion
            }
            else {
                log.debug('Call update ScreenshotScheduler, userid:' + userid + ' baseurl:' + baseurl + 'page:' + page+ ' createddate:' + createddate);
       
                ScreenshotSchedulerSchema.findOneAndUpdate(                    
                    {
                        [ScreenshotSchedulerSchemaFields.ID]: id,
                    },
                    {
                        [ScreenshotSchedulerSchemaFields.BaseURL]: baseurl,
                        [ScreenshotSchedulerSchemaFields.Page]: page,
                        [ScreenshotSchedulerSchemaFields.SchedulePageURL]: schedulepageurl,
                        [ScreenshotSchedulerSchemaFields.CreatedDate]: createddate,
                    },
                    {
                        new: true
                    }
                ).exec((err, result) => {           
                    if (err) {
                        log.error(err);
                    }
                    
                    if(result){                        
                        return cb(null, [result]);
                    }
                })
            }
        });
    }

    static getScreenshotSchedulerByUserId(userId, cb) {
        var lstScreenshotSchedulerData = [];
        return ScreenshotSchedulerSchema.find({
            $and: [{ [ScreenshotSchedulerSchemaFields.UserID]: userId },]
        }, (err, result) => {
            if (err) {
                log.error(err);
            }
            if (result.length <= 0) {
                return cb('ScreenshotSchedulernotfound', null);
            }
            else {
                result.forEach((element, index) => {
                    var ScreenshotScheduler = new ScreenshotSchedulerData();
                    ScreenshotScheduler._id = element._id,
                    ScreenshotScheduler.ID = element.ID,
                    ScreenshotScheduler.BaseURL = element.BaseURL,
                    ScreenshotScheduler.Page = element.Page,
                    ScreenshotScheduler.SchedulePageURL = element.SchedulePageURL,                                
                    ScreenshotScheduler.CreatedDate = element.CreatedDate,
                    ScreenshotScheduler.UserID = element.UserID
                    lstScreenshotSchedulerData.push(ScreenshotScheduler);
                });
                cb(null, lstScreenshotSchedulerData);
            }

        });
    }
    static deletelstScreenshot(id, cb) {
        ScreenshotSchedulerSchema.deleteOne({ [ScreenshotSchedulerSchemaFields.ID]: id }, (err, result) => {
            if (err) {
                log.error(err);
            }

            cb(null, result);
        })
    }

    
    static getScreenshotSchedulerByUserId_GraphQL(userid, cb) {
        return ScreenShotSchedulerHelper.getScreenshotSchedulerByUserId(userid, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static deletelstScreenshot_GraphQL(id, cb) {
        ScreenShotSchedulerHelper.deletelstScreenshot(id, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static createOrUpdateScreenshotScheduler_GraphQL(id,userid, baseurl, page, schedulepageurl,createddate, cb) {
        ScreenShotSchedulerHelper.createOrUpdateScreenshotScheduler(id,userid, baseurl, page, schedulepageurl,createddate, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
}

module.exports = ScreenShotSchedulerHelper;