const HoteldashboardcalculationsHelper = require('./hoteldashboardcalculations_helper');
const HotelrevenueHelper = require('./hotelrevenue_helper');
const HotelgssHelper = require('./hotelgss_helper');

const HoteleffectivenesscalculationsHelper = require('./hoteleffectivenesscalculations_helper');
const HotelbudgetdashboardcalculationsHelper = require('./hotelbudgetdashboardcalculations_helper');
const HotelsHelper = require('./hotels_helper');
const RESTHelper = require('./rest_helper');
const Constants = require('../common/constants');
const Utils = require('../common/utils');
const Scorecardrevenuedata = require('../scorecard/models/scorecardrevenuedata');
const Scorecardrevenuelineitemdata = require('../scorecard/models/scorecardrevenuelineitemdata');
const Scorecardprofitlineitemdata = require('../scorecard/models/scorecardprofitlineitemdata');
const Scorecardprofitdata = require('../scorecard/models/scorecardprofitdata');
const Scorecardstrdata = require('../scorecard/models/scorecardstrdata');
const Scorecardstrchangeoverpydata = require('../scorecard/models/scorecardstrchangeoverpydata');
const Scorecardstrchangeoverpychartdata = require('../scorecard/models/scorecardstrchangeoverpychartdata');
const Scorecardstrindexchangechartdata = require('../scorecard/models/scorecardstrindexchangechartdata');
const Scorecardstrrankchartdata = require('../scorecard/models/scorecardstrrankchartdata');
//const Revenuemissingdates = require('../scorecard/models/revenuemissingdates');

const Scorecardstrreportdata = require('../scorecard/models/scorecardstrreportdata');
const Scorecardstrindexchangedata = require('../scorecard/models/scorecardstrindexchangedata');
const Scorecardstrrankdata = require('../scorecard/models/scorecardstrrankdata');
const Scorecardlabordata = require('../scorecard/models/scorecardlabordata');
const Scorecardlaborlineitemdata = require('../scorecard/models/scorecardlaborlineitemdata');
const Scorecardservicegsslineitemdata = require('../scorecard/models/scorecardservicegsslineitemdata');

const Scorecardconfigdata = require('../scorecard/models/scorecardconfigdata');

const UserHelper = require('./user_helper');
const StarreportHelper = require('./starreport_helper');
const HotelroomstatusdashboardcalculationsHelper = require('./hotelroomstatusdashboardcalculations_helper');
const config = require('../../appsettings.js');



const Scorecardservicelineitemdata = require('../scorecard/models/scorecardservicelineitemdata');
const Scorecardservicedata = require('../scorecard/models/scorecardservicedata');


const { Revinatehoteldata: RevinatehoteldataSchema, SchemaField: RevinatehoteldataSchemaFields } = require('../models/revinatehoteldata');
var log = require('log4js').getLogger("scorecard_helper");
const _ = require('lodash');
class ScorecardHelper {

    static getRevenueData(hotelid, reportdate, period, userconfigdata, cb) {

        period = period.toLowerCase();

        var dtreportdate = new Date(reportdate);

        //LastYear date
        var dtreportdate_LastYear = new Date(dtreportdate);
        var startDateLY = new Date(dtreportdate_LastYear);

        let hoteldashboardcalculationsData = [];
        let hoteldashboardcalculationsData_LastYear = [];
        let hotelroomstatusdashboardcalculationsData = [];
        let hotelbudgetdashboardcalculationsData = [];
        let hotelsData = [];

        var startDate = new Date(dtreportdate);
        var endDate = new Date(dtreportdate);
        var days = 1;

        if (period == "mtd") {
            startDate = Utils.firstDayOfMonth(dtreportdate);
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfMonth(dtreportdate_LastYear);
        }
        else if (period == "ytd") {
            startDate = Utils.firstDayOfYear(dtreportdate);
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfYear(dtreportdate_LastYear);
        }
        else if (period == "ttm") {
            startDate = Utils.firstDayOfMonth(dtreportdate);
            startDate = Utils.lastYearDate(startDate);

            startDateLY = Utils.firstDayOfMonth(startDate);
            startDateLY = Utils.lastYearDate(startDateLY);

            endDate = Utils.firstDayOfMonth(dtreportdate);
            endDate.setDate(startDate.getDate() - 1);

            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
        }
        else {
            dtreportdate_LastYear = Utils.sameDayLastYear(startDate);
            startDateLY = dtreportdate_LastYear;
        }

        days = Utils.dateDiffInDays(startDate, endDate);


        return Promise.all([
            new Promise((resolve, reject) => {
                // get hotels data
                HotelsHelper.GetData(hotelid, (err, hotels_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotels_result) {
                        hotelsData = hotels_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations data
                HoteldashboardcalculationsHelper.GetLatestMTDData(hotelid, dtreportdate, startDate, (err, hoteldashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_result) {
                        hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations_LastYear data
                HoteldashboardcalculationsHelper.GetLatestMTDData(hotelid, dtreportdate_LastYear, startDateLY, (err, hoteldashboardcalculations_LastYear_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_LastYear_result) {
                        hoteldashboardcalculationsData_LastYear = hoteldashboardcalculations_LastYear_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get hotelroomstatusdashboardcalculations  data
                HotelroomstatusdashboardcalculationsHelper.GetLatestMTDData(hotelid, dtreportdate, startDate, (err, hotelroomstatusdashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelroomstatusdashboardcalculations_result) {
                        hotelroomstatusdashboardcalculationsData = hotelroomstatusdashboardcalculations_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get hotelbudgetdashboardcalculations  data
                HotelbudgetdashboardcalculationsHelper.GetLatestMTDData(hotelid, dtreportdate, startDate, (err, hotelbudgetdashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelbudgetdashboardcalculations_result) {
                        hotelbudgetdashboardcalculationsData = hotelbudgetdashboardcalculations_result;
                    }
                    resolve();
                });

            })

        ]).then(resp => {


            let objScorecardrevenuedata = new Scorecardrevenuedata();
            objScorecardrevenuedata.HotelID = hotelid;
            objScorecardrevenuedata.CurrentDT = reportdate;
            if (hotelsData && hotelsData.length > 0) {
                objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD = hotelsData[0].NumberofAvailableRooms;
                objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD = objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD * days;
                objScorecardrevenuedata.HotelName = hotelsData[0].HotelName;
                objScorecardrevenuedata.OrganisationName = hotelsData[0].CompanyName[0].CompanyName;
            }
            if (hoteldashboardcalculationsData) {

                if (period == "mtd") {
                    objScorecardrevenuedata.NoOfRoomSold = hoteldashboardcalculationsData.NoOfRoomSoldMTD;
                    objScorecardrevenuedata.RoomRevenue = hoteldashboardcalculationsData.TotalRevenueMTD;
                    objScorecardrevenuedata.FANDBRevenue = hoteldashboardcalculationsData.FANDBRevenueMTD;
                    objScorecardrevenuedata.OtherRevenue = hoteldashboardcalculationsData.OtherRevenueMTD;
                    objScorecardrevenuedata.Occupancy = hoteldashboardcalculationsData.OccupancyMTD;
                    objScorecardrevenuedata.ADR = hoteldashboardcalculationsData.ADRMTD;
                    objScorecardrevenuedata.RevPAR = hoteldashboardcalculationsData.RevPARMTD;

                }
                else if (period == "ytd") {
                    objScorecardrevenuedata.NoOfRoomSold = hoteldashboardcalculationsData.NoOfRoomSoldYTD;
                    objScorecardrevenuedata.RoomRevenue = hoteldashboardcalculationsData.TotalRevenueYTD;
                    objScorecardrevenuedata.FANDBRevenue = hoteldashboardcalculationsData.FANDBRevenueYTD;
                    objScorecardrevenuedata.OtherRevenue = hoteldashboardcalculationsData.OtherRevenueYTD;
                    objScorecardrevenuedata.Occupancy = hoteldashboardcalculationsData.OccupancyYTD;
                    objScorecardrevenuedata.ADR = hoteldashboardcalculationsData.ADRYTD;
                    objScorecardrevenuedata.RevPAR = hoteldashboardcalculationsData.RevPARYTD;

                }
                else if (period == "ttm") {
                    objScorecardrevenuedata.NoOfRoomSold = hoteldashboardcalculationsData.NoOfRoomSoldTTM;
                    objScorecardrevenuedata.RoomRevenue = hoteldashboardcalculationsData.TotalRevenueTTM;
                    objScorecardrevenuedata.FANDBRevenue = hoteldashboardcalculationsData.FANDBRevenueTTM;
                    objScorecardrevenuedata.OtherRevenue = hoteldashboardcalculationsData.OtherRevenueTTM;
                    objScorecardrevenuedata.Occupancy = hoteldashboardcalculationsData.OccupancyTTM;
                    objScorecardrevenuedata.ADR = hoteldashboardcalculationsData.ADRTTM;
                    objScorecardrevenuedata.RevPAR = hoteldashboardcalculationsData.RevPARTTM;

                }
                else {
                    objScorecardrevenuedata.NoOfRoomSold = hoteldashboardcalculationsData.NoOfRoomSold;
                    objScorecardrevenuedata.RoomRevenue = hoteldashboardcalculationsData.TotalRevenue;
                    objScorecardrevenuedata.FANDBRevenue = hoteldashboardcalculationsData.FANDBRevenue;
                    objScorecardrevenuedata.OtherRevenue = hoteldashboardcalculationsData.OtherRevenue;
                    objScorecardrevenuedata.Occupancy = hoteldashboardcalculationsData.Occupancy;
                    objScorecardrevenuedata.ADR = hoteldashboardcalculationsData.ADR;
                    objScorecardrevenuedata.RevPAR = hoteldashboardcalculationsData.RevPAR;

                }


                objScorecardrevenuedata.TotalRevenue = objScorecardrevenuedata.RoomRevenue + objScorecardrevenuedata.FANDBRevenue + objScorecardrevenuedata.OtherRevenue;
                objScorecardrevenuedata.BudgetNoOfRoomSoldVariance = objScorecardrevenuedata.NoOfRoomSold;
                objScorecardrevenuedata.NoOfRoomSoldVarianceLY = objScorecardrevenuedata.NoOfRoomSold;
                objScorecardrevenuedata.BudgetRoomRevenueVariance = objScorecardrevenuedata.RoomRevenue;
                objScorecardrevenuedata.BudgetFANDBVariance = objScorecardrevenuedata.FANDBRevenue;
                objScorecardrevenuedata.RoomRevenueVarianceLY = objScorecardrevenuedata.RoomRevenue;
                objScorecardrevenuedata.FANDBVarianceLY = objScorecardrevenuedata.FANDBRevenue;
                objScorecardrevenuedata.BudgetOtherVariance = objScorecardrevenuedata.OtherRevenue;
                objScorecardrevenuedata.OtherVarianceLY = objScorecardrevenuedata.OtherRevenue;
                objScorecardrevenuedata.BudgetRoomRevenueMTD = hoteldashboardcalculationsData.BudgetRoomRevenue;
                objScorecardrevenuedata.BudgetTotalRevenueVariance = objScorecardrevenuedata.TotalRevenue;
                objScorecardrevenuedata.TotalRevenueVarianceLY = objScorecardrevenuedata.TotalRevenue;
                objScorecardrevenuedata.BudgetOccupancyVariance = objScorecardrevenuedata.Occupancy;
                objScorecardrevenuedata.OccupancyVarianceLY = objScorecardrevenuedata.Occupancy;
                objScorecardrevenuedata.BudgetADRVariance = objScorecardrevenuedata.ADR;
                objScorecardrevenuedata.ADRVarianceLY = objScorecardrevenuedata.ADR;
                objScorecardrevenuedata.BudgetRevParVariance = objScorecardrevenuedata.RevPAR;
                objScorecardrevenuedata.RevPARVarianceLY = objScorecardrevenuedata.RevPAR;


            }

            if (hoteldashboardcalculationsData_LastYear) {

                if (period == "mtd") {
                    objScorecardrevenuedata.NoOfRoomSoldLY = hoteldashboardcalculationsData_LastYear.NoOfRoomSoldMTD;
                    objScorecardrevenuedata.RoomRevenueLY = hoteldashboardcalculationsData_LastYear.TotalRevenueMTD;
                    objScorecardrevenuedata.FANDBRevenueLY = hoteldashboardcalculationsData_LastYear.FANDBRevenueMTD;
                    objScorecardrevenuedata.OtherRevenueLY = hoteldashboardcalculationsData_LastYear.OtherRevenueMTD;
                    objScorecardrevenuedata.OccupancyLY = hoteldashboardcalculationsData_LastYear.OccupancyMTD;
                    objScorecardrevenuedata.ADRLY = hoteldashboardcalculationsData_LastYear.ADRMTD;
                    objScorecardrevenuedata.RevPARLY = hoteldashboardcalculationsData_LastYear.RevPARMTD;


                }
                else if (period == "ytd") {
                    objScorecardrevenuedata.NoOfRoomSoldLY = hoteldashboardcalculationsData_LastYear.NoOfRoomSoldYTD;
                    objScorecardrevenuedata.RoomRevenueLY = hoteldashboardcalculationsData_LastYear.TotalRevenueYTD;
                    objScorecardrevenuedata.FANDBRevenueLY = hoteldashboardcalculationsData_LastYear.FANDBRevenueYTD;
                    objScorecardrevenuedata.OtherRevenueLY = hoteldashboardcalculationsData_LastYear.OtherRevenueYTD;
                    objScorecardrevenuedata.OccupancyLY = hoteldashboardcalculationsData_LastYear.OccupancyYTD;
                    objScorecardrevenuedata.ADRLY = hoteldashboardcalculationsData_LastYear.ADRYTD;
                    objScorecardrevenuedata.RevPARLY = hoteldashboardcalculationsData_LastYear.RevPARYTD;

                }
                else if (period == "ttm") {
                    objScorecardrevenuedata.NoOfRoomSoldLY = hoteldashboardcalculationsData_LastYear.NoOfRoomSoldTTM;
                    objScorecardrevenuedata.RoomRevenueLY = hoteldashboardcalculationsData_LastYear.TotalRevenueTTM;
                    objScorecardrevenuedata.FANDBRevenueLY = hoteldashboardcalculationsData_LastYear.FANDBRevenueTTM;
                    objScorecardrevenuedata.OtherRevenueLY = hoteldashboardcalculationsData_LastYear.OtherRevenueTTM;
                    objScorecardrevenuedata.OccupancyLY = hoteldashboardcalculationsData_LastYear.OccupancyTTM;
                    objScorecardrevenuedata.ADRLY = hoteldashboardcalculationsData_LastYear.ADRTTM;
                    objScorecardrevenuedata.RevPARLY = hoteldashboardcalculationsData_LastYear.RevPARTTM;

                }
                else {
                    objScorecardrevenuedata.NoOfRoomSoldLY = hoteldashboardcalculationsData_LastYear.NoOfRoomSold;
                    objScorecardrevenuedata.RoomRevenueLY = hoteldashboardcalculationsData_LastYear.TotalRevenue;
                    objScorecardrevenuedata.FANDBRevenueLY = hoteldashboardcalculationsData_LastYear.FANDBRevenue;
                    objScorecardrevenuedata.OtherRevenueLY = hoteldashboardcalculationsData_LastYear.OtherRevenue;
                    objScorecardrevenuedata.OccupancyLY = hoteldashboardcalculationsData_LastYear.Occupancy;
                    objScorecardrevenuedata.ADRLY = hoteldashboardcalculationsData_LastYear.ADR;
                    objScorecardrevenuedata.RevPARLY = hoteldashboardcalculationsData_LastYear.RevPAR;

                }
                objScorecardrevenuedata.TotalRevenueLY = objScorecardrevenuedata.RoomRevenueLY + objScorecardrevenuedata.FANDBRevenueLY + objScorecardrevenuedata.OtherRevenueLY;
                objScorecardrevenuedata.NoOfRoomSoldVarianceLY = objScorecardrevenuedata.NoOfRoomSoldVarianceLY - objScorecardrevenuedata.NoOfRoomSoldLY;
                objScorecardrevenuedata.RoomRevenueVarianceLY = objScorecardrevenuedata.RoomRevenueVarianceLY - objScorecardrevenuedata.RoomRevenueLY;
                objScorecardrevenuedata.FANDBVarianceLY = objScorecardrevenuedata.FANDBVarianceLY - objScorecardrevenuedata.FANDBRevenueLY;
                objScorecardrevenuedata.OtherVarianceLY = objScorecardrevenuedata.OtherVarianceLY - objScorecardrevenuedata.OtherRevenueLY;
                objScorecardrevenuedata.TotalRevenueVarianceLY = objScorecardrevenuedata.TotalRevenueVarianceLY - objScorecardrevenuedata.TotalRevenueLY;
                objScorecardrevenuedata.OccupancyVarianceLY = objScorecardrevenuedata.OccupancyVarianceLY - objScorecardrevenuedata.OccupancyLY;
                objScorecardrevenuedata.ADRVarianceLY = objScorecardrevenuedata.ADRVarianceLY - objScorecardrevenuedata.ADRLY;
                objScorecardrevenuedata.RevPARVarianceLY = objScorecardrevenuedata.RevPARVarianceLY - objScorecardrevenuedata.RevPARLY;

            }

            if (hotelroomstatusdashboardcalculationsData) {
                if (period == "mtd") {
                    objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD = objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD - hotelroomstatusdashboardcalculationsData.OutOfOrderRoomsMTD;
                }
                else if (period == "ytd") {
                    objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD = objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD - hotelroomstatusdashboardcalculationsData.OutOfOrderRoomsYTD;
                }
                else if (period == "ttm") {
                    objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD = objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD - hotelroomstatusdashboardcalculationsData.OutOfOrderRoomsTTM;
                }
                else {
                    objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD = objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD - hotelroomstatusdashboardcalculationsData.OutOfOrderRooms;
                }
            }

            if (hotelbudgetdashboardcalculationsData) {

                objScorecardrevenuedata.BudgetTotalNumberofAvailableRooms = hotelbudgetdashboardcalculationsData.BudgetNumberofAvailableRooms * days;

                if (period == "mtd") {
                    objScorecardrevenuedata.BudgetTotalNoofRoomsSold = hotelbudgetdashboardcalculationsData.MTDBudgetRooms;
                    objScorecardrevenuedata.BudgetRoomRevenue = hotelbudgetdashboardcalculationsData.MTDBudget;
                    objScorecardrevenuedata.BudgetFANDBRevenue = hotelbudgetdashboardcalculationsData.MTDFANDBRevenue;
                    objScorecardrevenuedata.BudgetOtherRevenue = hotelbudgetdashboardcalculationsData.MTDOtherRevenue;
                    objScorecardrevenuedata.BudgetOccupancy = hotelbudgetdashboardcalculationsData.BudgetOccupancyMTD;
                    objScorecardrevenuedata.BudgetADR = hotelbudgetdashboardcalculationsData.BudgetADRMTD;


                }
                else if (period == "ytd") {
                    objScorecardrevenuedata.BudgetTotalNoofRoomsSold = hotelbudgetdashboardcalculationsData.YTDBudgetRooms;
                    objScorecardrevenuedata.BudgetRoomRevenue = hotelbudgetdashboardcalculationsData.YTDBudget;
                    objScorecardrevenuedata.BudgetFANDBRevenue = hotelbudgetdashboardcalculationsData.YTDFANDBRevenue;
                    objScorecardrevenuedata.BudgetOtherRevenue = hotelbudgetdashboardcalculationsData.YTDOtherRevenue;
                    objScorecardrevenuedata.BudgetOccupancy = hotelbudgetdashboardcalculationsData.BudgetOccupancyYTD;
                    objScorecardrevenuedata.BudgetADR = hotelbudgetdashboardcalculationsData.BudgetADRYTD;


                }
                else if (period == "ttm") {
                    objScorecardrevenuedata.BudgetTotalNoofRoomsSold = hotelbudgetdashboardcalculationsData.TTMBudgetRooms;
                    objScorecardrevenuedata.BudgetRoomRevenue = hotelbudgetdashboardcalculationsData.TTMBudget;
                    objScorecardrevenuedata.BudgetFANDBRevenue = hotelbudgetdashboardcalculationsData.TTMFANDBRevenue;
                    objScorecardrevenuedata.BudgetOtherRevenue = hotelbudgetdashboardcalculationsData.TTMOtherRevenue;
                    objScorecardrevenuedata.BudgetOccupancy = hotelbudgetdashboardcalculationsData.BudgetOccupancyTTM;
                    objScorecardrevenuedata.BudgetADR = hotelbudgetdashboardcalculationsData.BudgetADRTTM;

                }
                else {
                    objScorecardrevenuedata.BudgetTotalNoofRoomsSold = hotelbudgetdashboardcalculationsData.BudgetRoomSold;
                    objScorecardrevenuedata.BudgetRoomRevenue = hotelbudgetdashboardcalculationsData.BudgetRoomRevenue;
                    objScorecardrevenuedata.BudgetFANDBRevenue = hotelbudgetdashboardcalculationsData.BudgetFANDBRevenue;
                    objScorecardrevenuedata.BudgetOtherRevenue = hotelbudgetdashboardcalculationsData.BudgetOtherRevenue;
                    objScorecardrevenuedata.BudgetOccupancy = hotelbudgetdashboardcalculationsData.BudgetOccupancy;
                    objScorecardrevenuedata.BudgetADR = hotelbudgetdashboardcalculationsData.BudgetADR;

                }

                objScorecardrevenuedata.BudgetNoOfRoomSoldVariance = objScorecardrevenuedata.BudgetNoOfRoomSoldVariance - objScorecardrevenuedata.BudgetTotalNoofRoomsSold;
                objScorecardrevenuedata.BudgetRoomRevenueVariance = objScorecardrevenuedata.BudgetRoomRevenueVariance - objScorecardrevenuedata.BudgetRoomRevenue;
                objScorecardrevenuedata.BudgetFANDBVariance = objScorecardrevenuedata.BudgetFANDBVariance - objScorecardrevenuedata.BudgetFANDBRevenue;
                objScorecardrevenuedata.BudgetOtherVariance = objScorecardrevenuedata.BudgetOtherVariance - objScorecardrevenuedata.BudgetOtherRevenue;
                objScorecardrevenuedata.BudgetTotalRevenueVariance = objScorecardrevenuedata.BudgetTotalRevenueVariance - objScorecardrevenuedata.BudgetRoomRevenue;

                objScorecardrevenuedata.BudgetRoomRevenueMTD = objScorecardrevenuedata.BudgetRoomRevenue + objScorecardrevenuedata.BudgetOtherRevenue + objScorecardrevenuedata.BudgetFANDBRevenue;
                objScorecardrevenuedata.BudgetOccupancyVariance = objScorecardrevenuedata.BudgetOccupancyVariance - objScorecardrevenuedata.BudgetOccupancy;
                objScorecardrevenuedata.BudgetADRVariance = objScorecardrevenuedata.BudgetADRVariance - objScorecardrevenuedata.BudgetADR;

                if (objScorecardrevenuedata.BudgetOccupancy != 0 && objScorecardrevenuedata.BudgetADR != 0) {
                    objScorecardrevenuedata.BudgetRevPar = (objScorecardrevenuedata.BudgetOccupancy * objScorecardrevenuedata.BudgetADR) / 100;
                }
                objScorecardrevenuedata.BudgetRevParVariance = objScorecardrevenuedata.BudgetRevParVariance - objScorecardrevenuedata.BudgetRevPar;

            }

            let objScorecardTotalRevenuePer = Constants.DefaultValues.ScorecardTotalRevenuePer;
            if (userconfigdata != null && userconfigdata.ScorecardTotalRevenuePer != 0) {
                objScorecardTotalRevenuePer = userconfigdata.ScorecardTotalRevenuePer;
            }

            if (objScorecardrevenuedata.BudgetTotalRevenueVariance < 0) {

                let ninty5perBudget = (objScorecardTotalRevenuePer * objScorecardrevenuedata.BudgetRoomRevenueMTD) / 100;

                objScorecardrevenuedata.BudgetTotalRevenueVariancePer = objScorecardTotalRevenuePer;

                if (objScorecardrevenuedata.TotalRevenue >= ninty5perBudget) {
                    objScorecardrevenuedata.BudgetTotalRevenueVarianceIsYellow = true;
                }
                else {
                    objScorecardrevenuedata.BudgetTotalRevenueVarianceIsRed = true;
                }
            }
            else {
                objScorecardrevenuedata.BudgetTotalRevenueVarianceIsGreen = true;
            }

            if (objScorecardrevenuedata.TotalRevenueVarianceLY < 0) {
                let ninty5perBudget = (objScorecardTotalRevenuePer * objScorecardrevenuedata.TotalRevenueLY) / 100;

                objScorecardrevenuedata.TotalRevenueVarianceLYPer = objScorecardTotalRevenuePer;

                if (objScorecardrevenuedata.TotalRevenue >= ninty5perBudget) {
                    objScorecardrevenuedata.TotalRevenueVarianceLYIsYellow = true;
                }
                else {
                    objScorecardrevenuedata.TotalRevenueVarianceLYIsRed = true;
                }
            }
            else {
                objScorecardrevenuedata.TotalRevenueVarianceLYIsGreen = true;
            }

            objScorecardrevenuedata = objScorecardrevenuedata.setFormat(objScorecardrevenuedata);

            //Scorecardrevenuelineitemdata
            let lstScorecardrevenuelineitemdata = [];

            //#region  Rms Available line item
            let objRmsAvailable = new Scorecardrevenuelineitemdata();
            objRmsAvailable.title = "Rms Available";
            objRmsAvailable.actual = objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD;
            objRmsAvailable.plan = objScorecardrevenuedata.BudgetTotalNumberofAvailableRooms;
            objRmsAvailable.variance = "-";
            objRmsAvailable.lastyear = objScorecardrevenuedata.TotalNumberofAvailableRoomsMTD;
            objRmsAvailable.lastyearvariance = "-";
            //#endregion

            //#region Rms Sold line item
            let objRmsSold = new Scorecardrevenuelineitemdata();
            objRmsSold.title = "Rms Sold";
            objRmsSold.actual = objScorecardrevenuedata.NoOfRoomSold;
            objRmsSold.plan = objScorecardrevenuedata.BudgetTotalNoofRoomsSold;
            objRmsSold.variance = objScorecardrevenuedata.BudgetNoOfRoomSoldVariance;
            objRmsSold.lastyear = objScorecardrevenuedata.NoOfRoomSoldLY;
            objRmsSold.lastyearvariance = objScorecardrevenuedata.NoOfRoomSoldVarianceLY;
            //#endregion

            //#region Room Revenue line item
            let objRoomRevenue = new Scorecardrevenuelineitemdata();
            objRoomRevenue.title = "Room Revenue";
            objRoomRevenue.actual = objScorecardrevenuedata.RoomRevenue;
            objRoomRevenue.plan = objScorecardrevenuedata.BudgetRoomRevenue;
            objRoomRevenue.variance = objScorecardrevenuedata.BudgetRoomRevenueVariance;
            objRoomRevenue.lastyear = objScorecardrevenuedata.RoomRevenueLY;
            objRoomRevenue.lastyearvariance = objScorecardrevenuedata.RoomRevenueVarianceLY;
            //#endregion

            //#region F&B Revenue line item
            let objFnBRevenue = new Scorecardrevenuelineitemdata();
            objFnBRevenue.title = "F&B Revenue";
            objFnBRevenue.actual = objScorecardrevenuedata.FANDBRevenue;
            objFnBRevenue.plan = objScorecardrevenuedata.BudgetFANDBRevenue;
            objFnBRevenue.variance = objScorecardrevenuedata.BudgetFANDBVariance;
            objFnBRevenue.lastyear = objScorecardrevenuedata.FANDBRevenueLY;
            objFnBRevenue.lastyearvariance = objScorecardrevenuedata.FANDBVarianceLY;
            //#endregion

            //#region Other Revenue line item
            let objOtherRevenue = new Scorecardrevenuelineitemdata();
            objOtherRevenue.title = "Other Revenue";
            objOtherRevenue.actual = objScorecardrevenuedata.OtherRevenue;
            objOtherRevenue.plan = objScorecardrevenuedata.BudgetOtherRevenue;
            objOtherRevenue.variance = objScorecardrevenuedata.BudgetOtherVariance;
            objOtherRevenue.lastyear = objScorecardrevenuedata.OtherRevenueLY;
            objOtherRevenue.lastyearvariance = objScorecardrevenuedata.OtherVarianceLY;
            //#endregion

            //#region Total Revenue line item
            let objTotalRevenue = new Scorecardrevenuelineitemdata();
            objTotalRevenue.title = "Total Revenue";
            objTotalRevenue.actual = objScorecardrevenuedata.TotalRevenue;
            objTotalRevenue.plan = objScorecardrevenuedata.BudgetRoomRevenueMTD;
            objTotalRevenue.variance = objScorecardrevenuedata.BudgetTotalRevenueVariance;
            objTotalRevenue.lastyear = objScorecardrevenuedata.TotalRevenueLY;
            objTotalRevenue.lastyearvariance = objScorecardrevenuedata.TotalRevenueVarianceLY;



            if (objScorecardrevenuedata.BudgetTotalRevenueVarianceIsGreen) {
                objTotalRevenue.variancetooltipcolor = Constants.Colors.Green;
                objTotalRevenue.variancetooltip = "Actual - Plan greater than 0";
            }
            else if (objScorecardrevenuedata.BudgetTotalRevenueVarianceIsYellow) {
                objTotalRevenue.variancetooltipcolor = Constants.Colors.Orange;
                objTotalRevenue.variancetooltip = "Actual- Plan less than 0 and Actual >=" + objScorecardrevenuedata.BudgetTotalRevenueVariancePer + " % of plan";
            }
            else if (objScorecardrevenuedata.BudgetTotalRevenueVarianceIsRed) {
                objTotalRevenue.variancetooltipcolor = Constants.Colors.Red;
                objTotalRevenue.variancetooltip = "Actual- Plan less than 0 and Actual <=" + objScorecardrevenuedata.BudgetTotalRevenueVariancePer + " % of plan";
            }


            if (objScorecardrevenuedata.TotalRevenueVarianceLYIsGreen) {
                objTotalRevenue.lastyearvariancetooltipcolor = Constants.Colors.Green;
                objTotalRevenue.lastyearvariancetooltip = "Actual - PrYear greater than 0";
            }
            else if (objScorecardrevenuedata.TotalRevenueVarianceLYIsYellow) {
                objTotalRevenue.lastyearvariancetooltipcolor = Constants.Colors.Orange;
                objTotalRevenue.lastyearvariancetooltip = "Actual - PrYear less than 0 and Actual >=" + objScorecardrevenuedata.TotalRevenueVarianceLYPer + " % of prYear";
            }
            else if (objScorecardrevenuedata.TotalRevenueVarianceLYIsRed) {
                objTotalRevenue.lastyearvariancetooltipcolor = Constants.Colors.Red;
                objTotalRevenue.lastyearvariancetooltip = "Actual - PrYear less than 0 and Actual <=" + objScorecardrevenuedata.TotalRevenueVarianceLYPer + " % of prYear";
            }
            //#endregion

            //#region Occupancy line item
            let objOccupancy = new Scorecardrevenuelineitemdata();
            objOccupancy.title = "Occupancy";
            objOccupancy.actual = objScorecardrevenuedata.Occupancy;
            objOccupancy.plan = objScorecardrevenuedata.BudgetOccupancy;
            objOccupancy.variance = objScorecardrevenuedata.BudgetOccupancyVariance;
            objOccupancy.lastyear = objScorecardrevenuedata.OccupancyLY;
            objOccupancy.lastyearvariance = objScorecardrevenuedata.OccupancyVarianceLY;
            //#endregion

            //#region ADR line item
            let objADR = new Scorecardrevenuelineitemdata();
            objADR.title = "ADR";
            objADR.actual = objScorecardrevenuedata.ADR;
            objADR.plan = objScorecardrevenuedata.BudgetADR;
            objADR.variance = objScorecardrevenuedata.BudgetADRVariance;
            objADR.lastyear = objScorecardrevenuedata.ADRLY;
            objADR.lastyearvariance = objScorecardrevenuedata.ADRVarianceLY;
            //#endregion

            //#region RevPar line item
            let objRevPar = new Scorecardrevenuelineitemdata();
            objRevPar.title = "RevPar";
            objRevPar.actual = objScorecardrevenuedata.RevPAR;
            objRevPar.plan = objScorecardrevenuedata.BudgetRevPar;
            objRevPar.variance = objScorecardrevenuedata.BudgetRevParVariance;
            objRevPar.lastyear = objScorecardrevenuedata.RevPARLY;
            objRevPar.lastyearvariance = objScorecardrevenuedata.RevPARVarianceLY;
            //#endregion

            lstScorecardrevenuelineitemdata.push(objRmsAvailable.setFormat(objRmsAvailable));
            lstScorecardrevenuelineitemdata.push(objRmsSold.setFormat(objRmsSold));
            lstScorecardrevenuelineitemdata.push(objRoomRevenue.setFormat(objRoomRevenue));
            lstScorecardrevenuelineitemdata.push(objFnBRevenue.setFormat(objFnBRevenue));
            lstScorecardrevenuelineitemdata.push(objOtherRevenue.setFormat(objOtherRevenue));
            lstScorecardrevenuelineitemdata.push(objTotalRevenue.setFormat(objTotalRevenue));
            lstScorecardrevenuelineitemdata.push(objOccupancy.setFormat(objOccupancy));
            lstScorecardrevenuelineitemdata.push(objADR.setFormat(objADR));
            lstScorecardrevenuelineitemdata.push(objRevPar.setFormat(objRevPar));



            cb(null, lstScorecardrevenuelineitemdata);

        }, err => {
            return cb(err);
        })

    }

    static getRevenueData_GraphQL(userid, hotelid, reportdate, period, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    ScorecardHelper.getRevenueData(hoteldata.ID, reportdate, period, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }


    static getProfitData_GraphQL(userid, hotelid, reportdate, period, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    ScorecardHelper.getProfitData(hoteldata.ID, reportdate, period, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }


    static getProfitData(hotelid, reportdate, period, userconfigdata, cb) {

        period = period.toLowerCase();

        var dtreportdate = new Date(reportdate);

        //LastYear date
        var dtreportdate_LastYear = new Date(dtreportdate);
        var startDateLY = new Date(dtreportdate);

        //TBD get same day lastyear for current period
        dtreportdate_LastYear.setFullYear(dtreportdate.getFullYear() - 1);

        var startDate = new Date(dtreportdate);
        var endDate = new Date(dtreportdate);
        var days = 1;

        if (period == "mtd") {
            startDate = Utils.firstDayOfMonth(dtreportdate);
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfMonth(dtreportdate_LastYear);
        }
        else if (period == "ytd") {
            startDate = Utils.firstDayOfYear(dtreportdate);
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfYear(dtreportdate_LastYear);
        }
        else if (period == "ttm") {
            startDate = Utils.firstDayOfMonth(dtreportdate);
            startDate = Utils.lastYearDate(startDate);

            startDateLY = Utils.firstDayOfMonth(startDate);
            startDateLY = Utils.lastYearDate(startDateLY);

            endDate = Utils.firstDayOfMonth(dtreportdate);
            endDate.setDate(startDate.getDate() - 1);

            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
        }
        else {
            dtreportdate_LastYear = Utils.sameDayLastYear(startDate);
            startDateLY = dtreportdate_LastYear;
        }

        days = Utils.dateDiffInDays(startDate, endDate);


        let hoteldashboardcalculationsData = [];
        let hoteldashboardcalculationsData_LastYear = [];
        let GOP = 0;
        let GOPPlan = 0;
        let GOPPY = 0;
        let NOI = 0;
        let NOIPlan = 0;
        let NOIPY = 0;

        let hotelbudgetdashboardcalculationsData = [];

        return Promise.all([

            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations data
                HoteldashboardcalculationsHelper.GetLatestMTDData(hotelid, dtreportdate, startDate, (err, hoteldashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_result && hoteldashboardcalculations_result.length > 0) {
                        hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations_LastYear data
                HoteldashboardcalculationsHelper.GetLatestMTDData(hotelid, dtreportdate_LastYear, startDate, (err, hoteldashboardcalculations_LastYear_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_LastYear_result && hoteldashboardcalculations_LastYear_result.length > 0) {
                        hoteldashboardcalculationsData_LastYear = hoteldashboardcalculations_LastYear_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get GOP data
                HotelrevenueHelper.GetProfitDataSumAmount(hotelid, startDate, endDate, Constants.RevenueDescription.GOP, (err, hotelrevenueHelper_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelrevenueHelper_result) {
                        GOP = hotelrevenueHelper_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get GOPPlan data
                HotelrevenueHelper.GetProfitDataSumAmount(hotelid, startDate, endDate, Constants.RevenueDescription.GOPPlan, (err, hotelrevenueHelper_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelrevenueHelper_result) {
                        GOPPlan = hotelrevenueHelper_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get GOPPY data
                HotelrevenueHelper.GetProfitDataSumAmount(hotelid, startDateLY, dtreportdate_LastYear, Constants.RevenueDescription.GOP, (err, hotelrevenueHelper_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelrevenueHelper_result) {
                        GOPPY = hotelrevenueHelper_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get NOI data
                HotelrevenueHelper.GetProfitDataSumAmount(hotelid, startDate, endDate, Constants.RevenueDescription.NOI, (err, hotelrevenueHelper_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelrevenueHelper_result) {
                        NOI = hotelrevenueHelper_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get NOIPlan data
                HotelrevenueHelper.GetProfitDataSumAmount(hotelid, startDate, endDate, Constants.RevenueDescription.NOIPlan, (err, hotelrevenueHelper_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelrevenueHelper_result) {
                        NOIPlan = hotelrevenueHelper_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get NOIPY data
                HotelrevenueHelper.GetProfitDataSumAmount(hotelid, startDateLY, dtreportdate_LastYear, Constants.RevenueDescription.NOI, (err, hotelrevenueHelper_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelrevenueHelper_result) {
                        NOIPY = hotelrevenueHelper_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get hotelbudgetdashboardcalculations  data
                HotelbudgetdashboardcalculationsHelper.GetLatestMTDData(hotelid, dtreportdate, startDate, (err, hotelbudgetdashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelbudgetdashboardcalculations_result) {
                        hotelbudgetdashboardcalculationsData = hotelbudgetdashboardcalculations_result;
                    }
                    resolve();
                });

            })
        ]).then(resp => {


            let objScorecardprofitdata = new Scorecardprofitdata();
            objScorecardprofitdata.HotelID = hotelid;
            objScorecardprofitdata.CurrentDT = reportdate;
            objScorecardprofitdata.GOP = GOP;
            objScorecardprofitdata.GOPPlan = GOPPlan;
            objScorecardprofitdata.GOPPY = GOPPY;
            objScorecardprofitdata.NOI = NOI;
            objScorecardprofitdata.NOIPlan = NOIPlan;
            objScorecardprofitdata.NOIPY = NOIPY;
            objScorecardprofitdata.VarianceGOPBudget = objScorecardprofitdata.GOP - objScorecardprofitdata.GOPPlan;
            objScorecardprofitdata.VarianceGOPPY = objScorecardprofitdata.GOP - objScorecardprofitdata.GOPPY;
            objScorecardprofitdata.VarianceNOIBudget = objScorecardprofitdata.NOI - objScorecardprofitdata.NOIPlan;
            objScorecardprofitdata.VarianceNOIPY = objScorecardprofitdata.NOI - objScorecardprofitdata.NOIPY;




            objScorecardprofitdata.BudgetRoomRevenueMTD = 0;
            if (hotelbudgetdashboardcalculationsData && hotelbudgetdashboardcalculationsData.length > 0) {
                if (period == "mtd") {
                    objScorecardprofitdata.BudgetRoomRevenueMTD = hotelbudgetdashboardcalculationsData.MTDTotalRevenue;
                }
                else if (period == "ytd") {
                    objScorecardprofitdata.BudgetRoomRevenueMTD = hotelbudgetdashboardcalculationsData.YTDTotalRevenue;
                }
                else if (period == "ttm") {
                    objScorecardprofitdata.BudgetRoomRevenueMTD = hotelbudgetdashboardcalculationsData.TTMTotalRevenue;
                }
                else {
                    objScorecardprofitdata.BudgetRoomRevenueMTD = hotelbudgetdashboardcalculationsData.BudgetTotalRevenue;
                }
            }

            objScorecardprofitdata.TotalRevenue = 0;
            if (hoteldashboardcalculationsData && hoteldashboardcalculationsData.length > 0) {

                if (period == "mtd") {
                    objScorecardprofitdata.TotalRevenue = hoteldashboardcalculationsData.TotalRevenueMTD + hoteldashboardcalculationsData.FANDBRevenueMTD + hoteldashboardcalculationsData.OtherRevenueMTD;
                }
                else if (period == "ytd") {
                    objScorecardprofitdata.TotalRevenue = hoteldashboardcalculationsData.TotalRevenueYTD + hoteldashboardcalculationsData.FANDBRevenueYTD + hoteldashboardcalculationsData.OtherRevenueYTD;
                }
                else if (period == "ttm") {
                    objScorecardprofitdata.TotalRevenue = hoteldashboardcalculationsData.TotalRevenueTTM + hoteldashboardcalculationsData.FANDBRevenueTTM + hoteldashboardcalculationsData.OtherRevenueTTM;
                }
                else {
                    objScorecardprofitdata.TotalRevenue = hoteldashboardcalculationsData.TotalRevenue + hoteldashboardcalculationsData.FANDBRevenue + hoteldashboardcalculationsData.OtherRevenue;
                }
            }

            objScorecardprofitdata.TotalRevenueLY = 0;
            if (hoteldashboardcalculationsData_LastYear && hoteldashboardcalculationsData_LastYear.length > 0) {
                if (period == "mtd") {
                    objScorecardprofitdata.TotalRevenueLY = hoteldashboardcalculationsData_LastYear.TotalRevenueMTD + hoteldashboardcalculationsData_LastYear.FANDBRevenueMTD + hoteldashboardcalculationsData_LastYear.OtherRevenueMTD;
                }
                else if (period == "ytd") {
                    objScorecardprofitdata.TotalRevenueLY = hoteldashboardcalculationsData_LastYear.TotalRevenueYTD + hoteldashboardcalculationsData_LastYear.FANDBRevenueYTD + hoteldashboardcalculationsData_LastYear.OtherRevenueYTD;
                }
                else if (period == "ttm") {
                    objScorecardprofitdata.TotalRevenueLY = hoteldashboardcalculationsData_LastYear.TotalRevenueTTM + hoteldashboardcalculationsData_LastYear.FANDBRevenueTTM + hoteldashboardcalculationsData_LastYear.OtherRevenueTTM;
                }
                else {
                    objScorecardprofitdata.TotalRevenueLY = hoteldashboardcalculationsData_LastYear.TotalRevenue + hoteldashboardcalculationsData_LastYear.FANDBRevenue + hoteldashboardcalculationsData_LastYear.OtherRevenue;
                }
            }

            if (objScorecardprofitdata.GOP != 0 && objScorecardprofitdata.TotalRevenue != 0) {
                objScorecardprofitdata.GOPPer = (objScorecardprofitdata.GOP / objScorecardprofitdata.TotalRevenue) * 100;
            }
            if (objScorecardprofitdata.NOI != 0 && objScorecardprofitdata.TotalRevenue != 0) {
                objScorecardprofitdata.NOIPer = (objScorecardprofitdata.NOI / objScorecardprofitdata.TotalRevenue) * 100;
            }
            if (objScorecardprofitdata.GOPPlan != 0 && objScorecardprofitdata.BudgetRoomRevenueMTD != 0) {
                objScorecardprofitdata.GOPBudgetPer = (objScorecardprofitdata.GOPPlan / objScorecardprofitdata.BudgetRoomRevenueMTD) * 100;
            }
            if (objScorecardprofitdata.NOIPlan != 0 && objScorecardprofitdata.BudgetRoomRevenueMTD != 0) {
                objScorecardprofitdata.NOIBudgetPer = (objScorecardprofitdata.NOIPlan / objScorecardprofitdata.BudgetRoomRevenueMTD) * 100;
            }

            if (objScorecardprofitdata.GOPPY != 0 && objScorecardprofitdata.TotalRevenueLY != 0) {
                objScorecardprofitdata.GOPPYPer = (objScorecardprofitdata.GOPPY / objScorecardprofitdata.TotalRevenueLY) * 100;
            }

            if (objScorecardprofitdata.NOIPY != 0 && objScorecardprofitdata.TotalRevenueLY != 0) {
                objScorecardprofitdata.NOIPYper = (objScorecardprofitdata.NOIPY / objScorecardprofitdata.TotalRevenueLY) * 100;
            }

            if (objScorecardprofitdata.GOP != 0 && objScorecardprofitdata.GOPPlan != 0) {
                objScorecardprofitdata.VarianceGOPPerBudget = (objScorecardprofitdata.GOP / objScorecardprofitdata.GOPPlan) * 100;
            }

            if (objScorecardprofitdata.NOI != 0 && objScorecardprofitdata.NOIPlan != 0) {
                objScorecardprofitdata.VarianceNOIPerBudget = (objScorecardprofitdata.NOI / objScorecardprofitdata.NOIPlan) * 100;
            }
            if (objScorecardprofitdata.GOP != 0 && objScorecardprofitdata.GOPPY != 0) {
                objScorecardprofitdata.VarianceGOPPerPY = (objScorecardprofitdata.GOP / objScorecardprofitdata.GOPPY) * 100;
            }
            if (objScorecardprofitdata.NOI != 0 && objScorecardprofitdata.NOIPY != 0) {
                objScorecardprofitdata.VarianceNOIPerPY = (objScorecardprofitdata.NOI / objScorecardprofitdata.NOIPY) * 100;
            }


            let objScorecardGOPBudgetPer = Constants.DefaultValues.ScorecardGOPBudgetPer;

            if (objScorecardprofitdata.GOPBudgetPer != undefined) {

                if (objScorecardprofitdata.VarianceGOPPerBudget > objScorecardprofitdata.GOPBudgetPer) {
                    objScorecardprofitdata.VarianceGOPPerBudgetIsGreen = true;
                }
                else {
                    let ninty5perBudget = (objScorecardGOPBudgetPer * objScorecardprofitdata.VarianceGOPPerBudget) / 100;
                    if (objScorecardprofitdata.GOPBudgetPer >= ninty5perBudget) {
                        objScorecardprofitdata.VarianceGOPPerBudgetIsYellow = true;
                    }
                    else {
                        objScorecardprofitdata.VarianceGOPPerBudgetIsRed = true;
                    }
                }
            }
            else {
                objScorecardprofitdata.VarianceGOPPerBudgetIsGreen = true;
            }


            if (objScorecardprofitdata.GOPPYPer != undefined) {

                if (objScorecardprofitdata.VarianceGOPPerPY > objScorecardprofitdata.GOPPYPer) {
                    objScorecardprofitdata.VarianceGOPPerPYIsGreen = true;
                }
                else {
                    let ninty5perBudget = (objScorecardGOPBudgetPer * objScorecardprofitdata.VarianceGOPPerPY) / 100;
                    if (objScorecardprofitdata.VarianceGOPPerPY >= ninty5perBudget) {
                        objScorecardprofitdata.VarianceGOPPerPYIsYellow = true;
                    }
                    else {
                        objScorecardprofitdata.VarianceGOPPerPYIsRed = true;
                    }
                }
            }
            else {
                objScorecardprofitdata.VarianceGOPPerPYIsGreen = true;
            }


            if (objScorecardprofitdata.NOIBudgetPer != undefined) {

                if (objScorecardprofitdata.VarianceNOIPerBudget > objScorecardprofitdata.NOIBudgetPer) {
                    objScorecardprofitdata.VarianceNOIPerBudgetIsGreen = true;
                }
                else {
                    let ninty5perBudget = (objScorecardGOPBudgetPer * objScorecardprofitdata.VarianceNOIPerBudget) / 100;
                    if (objScorecardprofitdata.NOIBudgetPer >= ninty5perBudget) {
                        objScorecardprofitdata.VarianceNOIPerBudgetIsYellow = true;
                    }
                    else {
                        objScorecardprofitdata.VarianceNOIPerBudgetIsRed = true;
                    }
                }
            }
            else {
                objScorecardprofitdata.VarianceNOIPerBudgetIsGreen = true;
            }

            if (objScorecardprofitdata.NOIPYper != undefined) {

                if (objScorecardprofitdata.VarianceNOIPerPY > objScorecardprofitdata.NOIPYper) {
                    objScorecardprofitdata.VarianceNOIPerPYIsGreen = true;
                }
                else {
                    let ninty5perBudget = (objScorecardGOPBudgetPer * objScorecardprofitdata.VarianceNOIPerPY) / 100;
                    if (objScorecardprofitdata.NOIPYper >= ninty5perBudget) {
                        objScorecardprofitdata.VarianceNOIPerPYIsYellow = true;
                    }
                    else {
                        objScorecardprofitdata.VarianceNOIPerPYIsRed = true;
                    }
                }
            }
            else {
                objScorecardprofitdata.VarianceNOIPerPYIsGreen = true;
            }


            objScorecardprofitdata = objScorecardprofitdata.setFormat(objScorecardprofitdata);

            //Scorecardprofitlineitemdata
            let lstScorecardprofitlineitemdata = [];

            //#region GOP line item
            let objGOP = new Scorecardprofitlineitemdata();
            objGOP.title = "GOP";
            objGOP.actual = objScorecardprofitdata.GOP;
            objGOP.actualpercentage = objScorecardprofitdata.GOPPer + Constants.Suffix.Percentage;
            objGOP.plan = objScorecardprofitdata.GOPPlan;
            objGOP.planpercentage = objScorecardprofitdata.GOPBudgetPer + Constants.Suffix.Percentage;
            objGOP.variance = objScorecardprofitdata.VarianceGOPBudget;
            objGOP.variancepercentage = objScorecardprofitdata.VarianceGOPPerBudget + Constants.Suffix.Percentage;


            if (objScorecardprofitdata.VarianceGOPPerBudgetIsGreen) {
                objGOP.variancetooltipcolor = Constants.Colors.Green;
                objGOP.variancetooltip = "Actual - Plan greater than 0";
            }
            else if (objScorecardprofitdata.VarianceGOPPerBudgetIsYellow) {
                objGOP.variancetooltipcolor = Constants.Colors.Orange;
                objGOP.variancetooltip = "Actual- Plan less than 0 and Actual >=" + Utils.formatValue(objScorecardprofitdata.GOPBudgetPer, Constants.NumeralFormats.NoDecimal) + " % of plan";
            }
            else if (objScorecardprofitdata.VarianceGOPPerBudgetIsRed) {
                objGOP.variancetooltipcolor = Constants.Colors.Red;
                objGOP.variancetooltip = "Actual- Plan less than 0 and Actual <=" + Utils.formatValue(objScorecardprofitdata.GOPBudgetPer, Constants.NumeralFormats.NoDecimal) + " % of plan";
            }


            objGOP.lastyear = objScorecardprofitdata.GOPPY;
            objGOP.lastyearpercentage = objScorecardprofitdata.GOPPYPer + Constants.Suffix.Percentage;
            objGOP.lastyearvariance = objScorecardprofitdata.VarianceGOPPY;
            objGOP.lastyearvariancepercentage = objScorecardprofitdata.VarianceGOPPerPY + Constants.Suffix.Percentage;


            if (objScorecardprofitdata.VarianceGOPPerPYIsGreen) {
                objGOP.lastyearvariancetooltipcolor = Constants.Colors.Green;
                objGOP.lastyearvariancetooltip = "Actual - Plan greater than 0";
            }
            else if (objScorecardprofitdata.VarianceGOPPerPYIsYellow) {
                objGOP.lastyearvariancetooltipcolor = Constants.Colors.Orange;
                objGOP.lastyearvariancetooltip = "Actual- Plan less than 0 and Actual >=" + Utils.formatValue(objScorecardprofitdata.GOPPYPer, Constants.NumeralFormats.NoDecimal) + " % of plan";
            }
            else if (objScorecardprofitdata.VarianceGOPPerPYIsRed) {
                objGOP.lastyearvariancetooltipcolor = Constants.Colors.Red;
                objGOP.lastyearvariancetooltip = "Actual- Plan less than 0 and Actual <=" + Utils.formatValue(objScorecardprofitdata.GOPPYPer, Constants.NumeralFormats.NoDecimal) + " % of plan";
            }


            //#endregion

            //#region NOI line item
            let objNOI = new Scorecardprofitlineitemdata();
            objNOI.title = "NOI";
            objNOI.actual = objScorecardprofitdata.NOI;
            objNOI.actualpercentage = objScorecardprofitdata.NOIPer + Constants.Suffix.Percentage;
            objNOI.plan = objScorecardprofitdata.NOIPlan;
            objNOI.planpercentage = objScorecardprofitdata.NOIBudgetPer + Constants.Suffix.Percentage;
            objNOI.variance = objScorecardprofitdata.VarianceNOIBudget;
            objNOI.variancepercentage = objScorecardprofitdata.VarianceNOIPerBudget + Constants.Suffix.Percentage;


            if (objScorecardprofitdata.VarianceNOIPerBudgetIsGreen) {
                objNOI.variancetooltipcolor = Constants.Colors.Green;
                objNOI.variancetooltip = "Actual - Plan greater than 0";
            }
            else if (objScorecardprofitdata.VarianceNOIPerBudgetIsYellow) {
                objNOI.variancetooltipcolor = Constants.Colors.Orange;
                objNOI.variancetooltip = "Actual- Plan less than 0 and Actual >=" + Utils.formatValue(objScorecardprofitdata.NOIBudgetPer, Constants.NumeralFormats.NoDecimal) + " % of plan";
            }
            else if (objScorecardprofitdata.VarianceNOIPerBudgetIsRed) {
                objNOI.variancetooltipcolor = Constants.Colors.Red;
                objNOI.variancetooltip = "Actual- Plan less than 0 and Actual <=" + Utils.formatValue(objScorecardprofitdata.NOIBudgetPer, Constants.NumeralFormats.NoDecimal) + " % of plan";
            }


            objNOI.lastyear = objScorecardprofitdata.NOIPY;
            objNOI.lastyearpercentage = objScorecardprofitdata.NOIPYper + Constants.Suffix.Percentage;
            objNOI.lastyearvariance = objScorecardprofitdata.VarianceNOIPY;
            objNOI.lastyearvariancepercentage = objScorecardprofitdata.VarianceNOIPerPY + Constants.Suffix.Percentage;


            if (objScorecardprofitdata.VarianceNOIPerPYIsGreen) {
                objNOI.lastyearvariancetooltipcolor = Constants.Colors.Green;
                objNOI.lastyearvariancetooltip = "Actual - Plan greater than 0";
            }
            else if (objScorecardprofitdata.VarianceNOIPerPYIsYellow) {
                objNOI.lastyearvariancetooltipcolor = Constants.Colors.Orange;
                objNOI.lastyearvariancetooltip = "Actual- Plan less than 0 and Actual >=" + Utils.formatValue(objScorecardprofitdata.NOIPYper, Constants.NumeralFormats.NoDecimal) + " % of plan";
            }
            else if (objScorecardprofitdata.VarianceNOIPerPYIsRed) {
                objGOP.lastyearvariancetooltipcolor = Constants.Colors.Red;
                objNOI.lastyearvariancetooltip = "Actual- Plan less than 0 and Actual <=" + Utils.formatValue(objScorecardprofitdata.NOIPYper, Constants.NumeralFormats.NoDecimal) + " % of plan";
            }


            //#endregion


            lstScorecardprofitlineitemdata.push(objGOP.setFormat(objGOP));
            lstScorecardprofitlineitemdata.push(objNOI.setFormat(objNOI));

            cb(null, lstScorecardprofitlineitemdata);

        }, err => {
            return cb(err);
        })

    }

    static getSTRData(hotelid, reportdate, period, reporttype, userconfigdata, cb) {

        period = period.toLowerCase();

        reporttype = reporttype.toLowerCase();

        var dtreportdate = new Date(reportdate);

        //LastYear date
        var dtreportdate_LastYear = new Date(dtreportdate);
        var startDateLY = new Date(dtreportdate);

        //TBD get same day lastyear for current period
        dtreportdate_LastYear.setFullYear(dtreportdate.getFullYear() - 1);

        var startDate = new Date(dtreportdate);
        var endDate = new Date(dtreportdate);
        startDate = Utils.firstDayOfMonth(dtreportdate);

        if (period == "mtd") {
            endDate = Utils.lastDayOfMonth(dtreportdate);
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfMonth(dtreportdate_LastYear);
        }
        else if (period == "ytd") {
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfYear(dtreportdate_LastYear);
        }
        else if (period == "ttm") {
            startDate = Utils.firstDayOfMonth(dtreportdate);
            startDate = Utils.lastYearDate(startDate);

            startDateLY = Utils.firstDayOfMonth(startDate);
            startDateLY = Utils.lastYearDate(startDateLY);

            endDate = Utils.firstDayOfMonth(dtreportdate);
            endDate.setDate(startDate.getDate() - 1);

            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
        }
        else {
            dtreportdate_LastYear = Utils.sameDayLastYear(startDate);
            startDateLY = dtreportdate_LastYear;
        }


        //get last six month wise data
        let starreport_data = [];
        let starreport_data_1 = [];
        let starreport_data_2 = [];
        let starreport_data_3 = [];
        let starreport_data_4 = [];
        let starreport_data_5 = [];

        let starreport_data_month = [];
        let starreport_data_1_month = [];
        let starreport_data_2_month = [];
        let starreport_data_3_month = [];
        let starreport_data_4_month = [];
        let starreport_data_5_month = [];



        var startDate_month_1 = new Date(startDate);
        startDate_month_1.setMonth(startDate.getMonth() - 5);
        startDate_month_1 = Utils.firstDayOfMonth(startDate_month_1);
        var endDate_month_1 = Utils.lastDayOfMonth(startDate_month_1);

        var startDate_month_2 = new Date(startDate);
        startDate_month_2.setMonth(startDate.getMonth() - 4);
        startDate_month_2 = Utils.firstDayOfMonth(startDate_month_2);
        var endDate_month_2 = Utils.lastDayOfMonth(startDate_month_2);


        var startDate_month_3 = new Date(startDate);
        startDate_month_3.setMonth(startDate.getMonth() - 3);
        startDate_month_3 = Utils.firstDayOfMonth(startDate_month_3);
        var endDate_month_3 = Utils.lastDayOfMonth(startDate_month_3);


        var startDate_month_4 = new Date(startDate);
        startDate_month_4.setMonth(startDate.getMonth() - 2);
        startDate_month_4 = Utils.firstDayOfMonth(startDate_month_4);
        var endDate_month_4 = Utils.lastDayOfMonth(startDate_month_4);

        var startDate_month_5 = new Date(startDate);
        startDate_month_5.setMonth(startDate.getMonth() - 1);
        startDate_month_5 = Utils.firstDayOfMonth(startDate_month_5);
        var endDate_month_5 = Utils.lastDayOfMonth(startDate_month_5);

        let currentMnnthName = Utils.getFormattedDate(dtreportdate, 'MMM');


        return Promise.all([

            new Promise((resolve, reject) => {

                // get STAR MonthWiseData data  month last 5th month
                StarreportHelper.getMonthWiseData(hotelid, startDate_month_1, endDate_month_1, (err, starreport_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (starreport_result) {
                        starreport_data_1 = starreport_result;
                    }

                    if (reporttype == 'month') {
                        StarreportHelper.getMonthWiseDataForMonthView(hotelid, startDate_month_1, endDate_month_1, (err, starreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (starreport_result) {
                                starreport_data_1_month = starreport_result;
                            }
                            resolve();
                        });
                    }
                    else {
                        resolve();
                    }
                });


            }),
            new Promise((resolve, reject) => {
                // get STAR MonthWiseData data last 4th month
                StarreportHelper.getMonthWiseData(hotelid, startDate_month_2, endDate_month_2, (err, starreport_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (starreport_result) {
                        starreport_data_2 = starreport_result;
                    }
                    if (reporttype == 'month') {

                        StarreportHelper.getMonthWiseDataForMonthView(hotelid, startDate_month_2, endDate_month_2, (err, starreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (starreport_result) {
                                starreport_data_2_month = starreport_result;
                            }
                            resolve();
                        });
                    }
                    else {
                        resolve();
                    }
                });

            }),
            new Promise((resolve, reject) => {
                // get STAR MonthWiseData data last 3rd month
                StarreportHelper.getMonthWiseData(hotelid, startDate_month_3, endDate_month_3, (err, starreport_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (starreport_result) {
                        starreport_data_3 = starreport_result;
                    }
                    if (reporttype == 'month') {

                        StarreportHelper.getMonthWiseDataForMonthView(hotelid, startDate_month_3, endDate_month_3, (err, starreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (starreport_result) {
                                starreport_data_3_month = starreport_result;
                            }
                            resolve();
                        });
                    }
                    else {
                        resolve();
                    }
                });


            }),
            new Promise((resolve, reject) => {
                // get STAR MonthWiseData data last 2nd month
                StarreportHelper.getMonthWiseData(hotelid, startDate_month_4, endDate_month_4, (err, starreport_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (starreport_result) {
                        starreport_data_4 = starreport_result;
                    }

                    if (reporttype == 'month') {

                        StarreportHelper.getMonthWiseDataForMonthView(hotelid, startDate_month_4, endDate_month_4, (err, starreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (starreport_result) {
                                starreport_data_4_month = starreport_result;
                            }
                            resolve();
                        });
                    }
                    else {
                        resolve();
                    }
                });



            }),
            new Promise((resolve, reject) => {
                // get STAR MonthWiseData data last  month
                StarreportHelper.getMonthWiseData(hotelid, startDate_month_5, endDate_month_5, (err, starreport_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (starreport_result) {
                        starreport_data_5 = starreport_result;
                    }

                    if (reporttype == 'month') {
                        StarreportHelper.getMonthWiseDataForMonthView(hotelid, startDate_month_5, endDate_month_5, (err, starreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (starreport_result) {
                                starreport_data_5_month = starreport_result;
                            }
                            resolve();
                        });
                    }
                    else {
                        resolve();
                    }
                });
            }),
            new Promise((resolve, reject) => {
                // get STAR MonthWiseData data current  month
                StarreportHelper.getMonthWiseData(hotelid, startDate, endDate, (err, starreport_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (starreport_result) {
                        starreport_data = starreport_result;
                    }

                    if (reporttype == 'month') {
                        StarreportHelper.getMonthWiseDataForMonthView(hotelid, startDate, endDate, (err, starreport_result) => {
                            if (err) {
                                reject(err);
                            }
                            if (starreport_result) {
                                starreport_data_month = starreport_result;
                            }
                            resolve();
                        });
                    }
                    else {
                        resolve();
                    }
                });


            }),


        ]).then(resp => {


            let lstScorecardstrdata = [];
            if (reporttype == 'month') {

                if (starreport_data_1_month) {

                    let objScorecardstrdata1 = new Scorecardstrdata();
                    objScorecardstrdata1.HotelID = hotelid;
                    objScorecardstrdata1.DTCurMth = currentMnnthName;
                    objScorecardstrdata1.MonthName = starreport_data_1_month.MonthName;
                    objScorecardstrdata1.OccChg = starreport_data_1_month.OccChgMyProperty;
                    objScorecardstrdata1.ADRChg = starreport_data_1_month.AdrChgMyProperty;
                    objScorecardstrdata1.RevParChg = starreport_data_1_month.RevParChgMyProperty;
                    objScorecardstrdata1.MPI = starreport_data_1_month.OccChgIndex;
                    objScorecardstrdata1.ARI = starreport_data_1_month.AdrChgIndex;
                    objScorecardstrdata1.RGI = starreport_data_1_month.RevParChgIndex;

                    // for chart data
                    objScorecardstrdata1.OccAct = starreport_data_1_month.OccMyProperty;
                    objScorecardstrdata1.OccIndex = starreport_data_1_month.OccIndex;
                    objScorecardstrdata1.AdrAct = starreport_data_1_month.AdrMyProperty;
                    objScorecardstrdata1.AdrIndex = starreport_data_1_month.AdrIndex;
                    objScorecardstrdata1.RevParAct = starreport_data_1_month.RevParMyProperty;
                    objScorecardstrdata1.RevParIndex = starreport_data_1_month.RevParIndex;

                    if (starreport_data_1) {
                        objScorecardstrdata1.OccRankAVG = starreport_data_1.OccRank;
                        objScorecardstrdata1.AdrRankAVG = starreport_data_1.AdrRank;
                        objScorecardstrdata1.RevParRankAVG = starreport_data_1.RevParRank;
                    }

                    lstScorecardstrdata.push(objScorecardstrdata1);
                }

                if (starreport_data_2_month) {
                    let objScorecardstrdata2 = new Scorecardstrdata();
                    objScorecardstrdata2.HotelID = hotelid;
                    objScorecardstrdata2.DTCurMth = currentMnnthName;
                    objScorecardstrdata2.MonthName = starreport_data_2_month.MonthName;
                    objScorecardstrdata2.OccChg = starreport_data_2_month.OccChgMyProperty;
                    objScorecardstrdata2.ADRChg = starreport_data_2_month.AdrChgMyProperty;
                    objScorecardstrdata2.RevParChg = starreport_data_2_month.RevParChgMyProperty;
                    objScorecardstrdata2.MPI = starreport_data_2_month.OccChgIndex;
                    objScorecardstrdata2.ARI = starreport_data_2_month.AdrChgIndex;
                    objScorecardstrdata2.RGI = starreport_data_2_month.RevParChgIndex;
                    // for chart data
                    objScorecardstrdata2.OccAct = starreport_data_2_month.OccMyProperty;
                    objScorecardstrdata2.OccIndex = starreport_data_2_month.OccIndex;
                    objScorecardstrdata2.AdrAct = starreport_data_2_month.AdrMyProperty;
                    objScorecardstrdata2.AdrIndex = starreport_data_2_month.AdrIndex;
                    objScorecardstrdata2.RevParAct = starreport_data_2_month.RevParMyProperty;
                    objScorecardstrdata2.RevParIndex = starreport_data_2_month.RevParIndex;

                    if (starreport_data_2) {
                        objScorecardstrdata2.OccRankAVG = starreport_data_2.OccRank;
                        objScorecardstrdata2.AdrRankAVG = starreport_data_2.AdrRank;
                        objScorecardstrdata2.RevParRankAVG = starreport_data_2.RevParRank;
                    }

                    lstScorecardstrdata.push(objScorecardstrdata2);
                }

                if (starreport_data_3_month) {
                    let objScorecardstrdata3 = new Scorecardstrdata();
                    objScorecardstrdata3.HotelID = hotelid;
                    objScorecardstrdata3.DTCurMth = currentMnnthName;
                    objScorecardstrdata3.MonthName = starreport_data_3_month.MonthName;
                    objScorecardstrdata3.OccChg = starreport_data_3_month.OccChgMyProperty;
                    objScorecardstrdata3.ADRChg = starreport_data_3_month.AdrChgMyProperty;
                    objScorecardstrdata3.RevParChg = starreport_data_3_month.RevParChgMyProperty;
                    objScorecardstrdata3.MPI = starreport_data_3_month.OccChgIndex;
                    objScorecardstrdata3.ARI = starreport_data_3_month.AdrChgIndex;
                    objScorecardstrdata3.RGI = starreport_data_3_month.RevParChgIndex;


                    // for chart data
                    objScorecardstrdata3.OccAct = starreport_data_3_month.OccMyProperty;
                    objScorecardstrdata3.OccIndex = starreport_data_3_month.OccIndex;
                    objScorecardstrdata3.AdrAct = starreport_data_3_month.AdrMyProperty;
                    objScorecardstrdata3.AdrIndex = starreport_data_3_month.AdrIndex;
                    objScorecardstrdata3.RevParAct = starreport_data_3_month.RevParMyProperty;
                    objScorecardstrdata3.RevParIndex = starreport_data_3_month.RevParIndex;

                    if (starreport_data_3) {
                        objScorecardstrdata3.OccRankAVG = starreport_data_3.OccRank;
                        objScorecardstrdata3.AdrRankAVG = starreport_data_3.AdrRank;
                        objScorecardstrdata3.RevParRankAVG = starreport_data_3.RevParRank;
                    }

                    lstScorecardstrdata.push(objScorecardstrdata3);
                }

                if (starreport_data_4_month) {
                    let objScorecardstrdata4 = new Scorecardstrdata();
                    objScorecardstrdata4.HotelID = hotelid;
                    objScorecardstrdata4.DTCurMth = currentMnnthName;
                    objScorecardstrdata4.MonthName = starreport_data_4_month.MonthName;
                    objScorecardstrdata4.OccChg = starreport_data_4_month.OccChgMyProperty;
                    objScorecardstrdata4.ADRChg = starreport_data_4_month.AdrChgMyProperty;
                    objScorecardstrdata4.RevParChg = starreport_data_4_month.RevParChgMyProperty;
                    objScorecardstrdata4.MPI = starreport_data_4_month.OccChgIndex;
                    objScorecardstrdata4.ARI = starreport_data_4_month.AdrChgIndex;
                    objScorecardstrdata4.RGI = starreport_data_4_month.RevParChgIndex;


                    // for chart data
                    objScorecardstrdata4.OccAct = starreport_data_4_month.OccMyProperty;
                    objScorecardstrdata4.OccIndex = starreport_data_4_month.OccIndex;
                    objScorecardstrdata4.AdrAct = starreport_data_4_month.AdrMyProperty;
                    objScorecardstrdata4.AdrIndex = starreport_data_4_month.AdrIndex;
                    objScorecardstrdata4.RevParAct = starreport_data_4_month.RevParMyProperty;
                    objScorecardstrdata4.RevParIndex = starreport_data_4_month.RevParIndex;

                    if (starreport_data_4) {

                        objScorecardstrdata4.OccRankAVG = starreport_data_4.OccRank;
                        objScorecardstrdata4.AdrRankAVG = starreport_data_4.AdrRank;
                        objScorecardstrdata4.RevParRankAVG = starreport_data_4.RevParRank;
                    }


                    lstScorecardstrdata.push(objScorecardstrdata4);
                }

                if (starreport_data_5_month) {
                    let objScorecardstrdata5 = new Scorecardstrdata();
                    objScorecardstrdata5.HotelID = hotelid;
                    objScorecardstrdata5.DTCurMth = currentMnnthName;
                    objScorecardstrdata5.MonthName = starreport_data_5_month.MonthName;
                    objScorecardstrdata5.OccChg = starreport_data_5_month.OccChgMyProperty;
                    objScorecardstrdata5.ADRChg = starreport_data_5_month.AdrChgMyProperty;
                    objScorecardstrdata5.RevParChg = starreport_data_5_month.RevParChgMyProperty;
                    objScorecardstrdata5.MPI = starreport_data_5_month.OccChgIndex;
                    objScorecardstrdata5.ARI = starreport_data_5_month.AdrChgIndex;
                    objScorecardstrdata5.RGI = starreport_data_5_month.RevParChgIndex;

                    // for chart data
                    objScorecardstrdata5.OccAct = starreport_data_5_month.OccMyProperty;
                    objScorecardstrdata5.OccIndex = starreport_data_5_month.OccIndex;
                    objScorecardstrdata5.AdrAct = starreport_data_5_month.AdrMyProperty;
                    objScorecardstrdata5.AdrIndex = starreport_data_5_month.AdrIndex;
                    objScorecardstrdata5.RevParAct = starreport_data_5_month.RevParMyProperty;
                    objScorecardstrdata5.RevParIndex = starreport_data_5_month.RevParIndex;

                    if (starreport_data_5) {
                        objScorecardstrdata5.OccRankAVG = starreport_data_5.OccRank;
                        objScorecardstrdata5.AdrRankAVG = starreport_data_5.AdrRank;
                        objScorecardstrdata5.RevParRankAVG = starreport_data_5.RevParRank;
                    }

                    lstScorecardstrdata.push(objScorecardstrdata5);
                }

                if (starreport_data_month) {
                    let objScorecardstrdata = new Scorecardstrdata();
                    objScorecardstrdata.HotelID = hotelid;
                    objScorecardstrdata.DTCurMth = currentMnnthName;
                    objScorecardstrdata.MonthName = starreport_data_month.MonthName;
                    objScorecardstrdata.OccChg = starreport_data_month.OccChgMyProperty;
                    objScorecardstrdata.ADRChg = starreport_data_month.AdrChgMyProperty;
                    objScorecardstrdata.RevParChg = starreport_data_month.RevParChgMyProperty;
                    objScorecardstrdata.MPI = starreport_data_month.OccChgIndex;
                    objScorecardstrdata.ARI = starreport_data_month.AdrChgIndex;
                    objScorecardstrdata.RGI = starreport_data_month.RevParChgIndex;

                    // for chart data
                    objScorecardstrdata.OccAct = starreport_data_month.OccMyProperty;
                    objScorecardstrdata.OccIndex = starreport_data_month.OccIndex;
                    objScorecardstrdata.AdrAct = starreport_data_month.AdrMyProperty;
                    objScorecardstrdata.AdrIndex = starreport_data_month.AdrIndex;
                    objScorecardstrdata.RevParAct = starreport_data_month.RevParMyProperty;
                    objScorecardstrdata.RevParIndex = starreport_data_month.RevParIndex;

                    if (starreport_data) {

                        objScorecardstrdata.OccRankAVG = starreport_data.OccRank;
                        objScorecardstrdata.AdrRankAVG = starreport_data.AdrRank;
                        objScorecardstrdata.RevParRankAVG = starreport_data.RevParRank;
                    }

                    lstScorecardstrdata.push(objScorecardstrdata);
                }


            }
            else {

                // reporttype == week 
                if (starreport_data_1) {

                    let objScorecardstrdata1 = new Scorecardstrdata();
                    objScorecardstrdata1.HotelID = hotelid;
                    objScorecardstrdata1.DTCurMth = currentMnnthName;
                    objScorecardstrdata1.MonthName = starreport_data_1.MonthName;
                    objScorecardstrdata1.OccChg = starreport_data_1.OccChgMyProperty;
                    objScorecardstrdata1.ADRChg = starreport_data_1.AdrChgMyProperty;
                    objScorecardstrdata1.RevParChg = starreport_data_1.RevParChgMyProperty;
                    objScorecardstrdata1.MPI = starreport_data_1.OccChgIndex;
                    objScorecardstrdata1.ARI = starreport_data_1.AdrChgIndex;
                    objScorecardstrdata1.RGI = starreport_data_1.RevParChgIndex;
                    objScorecardstrdata1.OccRankAVG = starreport_data_1.OccRank;
                    objScorecardstrdata1.AdrRankAVG = starreport_data_1.AdrRank;
                    objScorecardstrdata1.RevParRankAVG = starreport_data_1.RevParRank;

                    // for chart data
                    objScorecardstrdata1.OccAct = starreport_data_1.OccMyProperty;
                    objScorecardstrdata1.OccIndex = starreport_data_1.OccIndex;
                    objScorecardstrdata1.AdrAct = starreport_data_1.AdrMyProperty;
                    objScorecardstrdata1.AdrIndex = starreport_data_1.AdrIndex;
                    objScorecardstrdata1.RevParAct = starreport_data_1.RevParMyProperty;
                    objScorecardstrdata1.RevParIndex = starreport_data_1.RevParIndex;


                    lstScorecardstrdata.push(objScorecardstrdata1);
                }

                if (starreport_data_2) {
                    let objScorecardstrdata2 = new Scorecardstrdata();
                    objScorecardstrdata2.HotelID = hotelid;
                    objScorecardstrdata2.DTCurMth = currentMnnthName;
                    objScorecardstrdata2.MonthName = starreport_data_2.MonthName;
                    objScorecardstrdata2.OccChg = starreport_data_2.OccChgMyProperty;
                    objScorecardstrdata2.ADRChg = starreport_data_2.AdrChgMyProperty;
                    objScorecardstrdata2.RevParChg = starreport_data_2.RevParChgMyProperty;
                    objScorecardstrdata2.MPI = starreport_data_2.OccChgIndex;
                    objScorecardstrdata2.ARI = starreport_data_2.AdrChgIndex;
                    objScorecardstrdata2.RGI = starreport_data_2.RevParChgIndex;
                    objScorecardstrdata2.OccRankAVG = starreport_data_2.OccRank;
                    objScorecardstrdata2.AdrRankAVG = starreport_data_2.AdrRank;
                    objScorecardstrdata2.RevParRankAVG = starreport_data_2.RevParRank;

                    // for chart data
                    objScorecardstrdata2.OccAct = starreport_data_2.OccMyProperty;
                    objScorecardstrdata2.OccIndex = starreport_data_2.OccIndex;
                    objScorecardstrdata2.AdrAct = starreport_data_2.AdrMyProperty;
                    objScorecardstrdata2.AdrIndex = starreport_data_2.AdrIndex;
                    objScorecardstrdata2.RevParAct = starreport_data_2.RevParMyProperty;
                    objScorecardstrdata2.RevParIndex = starreport_data_2.RevParIndex;

                    lstScorecardstrdata.push(objScorecardstrdata2);
                }

                if (starreport_data_3) {
                    let objScorecardstrdata3 = new Scorecardstrdata();
                    objScorecardstrdata3.HotelID = hotelid;
                    objScorecardstrdata3.DTCurMth = currentMnnthName;
                    objScorecardstrdata3.MonthName = starreport_data_3.MonthName;
                    objScorecardstrdata3.OccChg = starreport_data_3.OccChgMyProperty;
                    objScorecardstrdata3.ADRChg = starreport_data_3.AdrChgMyProperty;
                    objScorecardstrdata3.RevParChg = starreport_data_3.RevParChgMyProperty;
                    objScorecardstrdata3.MPI = starreport_data_3.OccChgIndex;
                    objScorecardstrdata3.ARI = starreport_data_3.AdrChgIndex;
                    objScorecardstrdata3.RGI = starreport_data_3.RevParChgIndex;
                    objScorecardstrdata3.OccRankAVG = starreport_data_3.OccRank;
                    objScorecardstrdata3.AdrRankAVG = starreport_data_3.AdrRank;
                    objScorecardstrdata3.RevParRankAVG = starreport_data_3.RevParRank;

                    // for chart data
                    objScorecardstrdata3.OccAct = starreport_data_3.OccMyProperty;
                    objScorecardstrdata3.OccIndex = starreport_data_3.OccIndex;
                    objScorecardstrdata3.AdrAct = starreport_data_3.AdrMyProperty;
                    objScorecardstrdata3.AdrIndex = starreport_data_3.AdrIndex;
                    objScorecardstrdata3.RevParAct = starreport_data_3.RevParMyProperty;
                    objScorecardstrdata3.RevParIndex = starreport_data_3.RevParIndex;

                    lstScorecardstrdata.push(objScorecardstrdata3);
                }

                if (starreport_data_4) {
                    let objScorecardstrdata4 = new Scorecardstrdata();
                    objScorecardstrdata4.HotelID = hotelid;
                    objScorecardstrdata4.DTCurMth = currentMnnthName;
                    objScorecardstrdata4.MonthName = starreport_data_4.MonthName;
                    objScorecardstrdata4.OccChg = starreport_data_4.OccChgMyProperty;
                    objScorecardstrdata4.ADRChg = starreport_data_4.AdrChgMyProperty;
                    objScorecardstrdata4.RevParChg = starreport_data_4.RevParChgMyProperty;
                    objScorecardstrdata4.MPI = starreport_data_4.OccChgIndex;
                    objScorecardstrdata4.ARI = starreport_data_4.AdrChgIndex;
                    objScorecardstrdata4.RGI = starreport_data_4.RevParChgIndex;
                    objScorecardstrdata4.OccRankAVG = starreport_data_4.OccRank;
                    objScorecardstrdata4.AdrRankAVG = starreport_data_4.AdrRank;
                    objScorecardstrdata4.RevParRankAVG = starreport_data_4.RevParRank;

                    // for chart data
                    objScorecardstrdata4.OccAct = starreport_data_4.OccMyProperty;
                    objScorecardstrdata4.OccIndex = starreport_data_4.OccIndex;
                    objScorecardstrdata4.AdrAct = starreport_data_4.AdrMyProperty;
                    objScorecardstrdata4.AdrIndex = starreport_data_4.AdrIndex;
                    objScorecardstrdata4.RevParAct = starreport_data_4.RevParMyProperty;
                    objScorecardstrdata4.RevParIndex = starreport_data_4.RevParIndex;


                    lstScorecardstrdata.push(objScorecardstrdata4);
                }

                if (starreport_data_5) {
                    let objScorecardstrdata5 = new Scorecardstrdata();
                    objScorecardstrdata5.HotelID = hotelid;
                    objScorecardstrdata5.DTCurMth = currentMnnthName;
                    objScorecardstrdata5.MonthName = starreport_data_5.MonthName;
                    objScorecardstrdata5.OccChg = starreport_data_5.OccChgMyProperty;
                    objScorecardstrdata5.ADRChg = starreport_data_5.AdrChgMyProperty;
                    objScorecardstrdata5.RevParChg = starreport_data_5.RevParChgMyProperty;
                    objScorecardstrdata5.MPI = starreport_data_5.OccChgIndex;
                    objScorecardstrdata5.ARI = starreport_data_5.AdrChgIndex;
                    objScorecardstrdata5.RGI = starreport_data_5.RevParChgIndex;
                    objScorecardstrdata5.OccRankAVG = starreport_data_5.OccRank;
                    objScorecardstrdata5.AdrRankAVG = starreport_data_5.AdrRank;
                    objScorecardstrdata5.RevParRankAVG = starreport_data_5.RevParRank;

                    // for chart data
                    objScorecardstrdata5.OccAct = starreport_data_5.OccMyProperty;
                    objScorecardstrdata5.OccIndex = starreport_data_5.OccIndex;
                    objScorecardstrdata5.AdrAct = starreport_data_5.AdrMyProperty;
                    objScorecardstrdata5.AdrIndex = starreport_data_5.AdrIndex;
                    objScorecardstrdata5.RevParAct = starreport_data_5.RevParMyProperty;
                    objScorecardstrdata5.RevParIndex = starreport_data_5.RevParIndex;

                    lstScorecardstrdata.push(objScorecardstrdata5);
                }

                if (starreport_data) {
                    let objScorecardstrdata = new Scorecardstrdata();
                    objScorecardstrdata.HotelID = hotelid;
                    objScorecardstrdata.DTCurMth = currentMnnthName;
                    objScorecardstrdata.MonthName = starreport_data.MonthName;
                    objScorecardstrdata.OccChg = starreport_data.OccChgMyProperty;
                    objScorecardstrdata.ADRChg = starreport_data.AdrChgMyProperty;
                    objScorecardstrdata.RevParChg = starreport_data.RevParChgMyProperty;
                    objScorecardstrdata.MPI = starreport_data.OccChgIndex;
                    objScorecardstrdata.ARI = starreport_data.AdrChgIndex;
                    objScorecardstrdata.RGI = starreport_data.RevParChgIndex;
                    objScorecardstrdata.OccRankAVG = starreport_data.OccRank;
                    objScorecardstrdata.AdrRankAVG = starreport_data.AdrRank;
                    objScorecardstrdata.RevParRankAVG = starreport_data.RevParRank;

                    // for chart data
                    objScorecardstrdata.OccAct = starreport_data.OccMyProperty;
                    objScorecardstrdata.OccIndex = starreport_data.OccIndex;
                    objScorecardstrdata.AdrAct = starreport_data.AdrMyProperty;
                    objScorecardstrdata.AdrIndex = starreport_data.AdrIndex;
                    objScorecardstrdata.RevParAct = starreport_data.RevParMyProperty;
                    objScorecardstrdata.RevParIndex = starreport_data.RevParIndex;

                    lstScorecardstrdata.push(objScorecardstrdata);
                }

            }



            let objScorecardSTRCurrentMonthPer = Constants.DefaultValues.ScorecardSTRCurrentMonthPer;
            if (userconfigdata != null && userconfigdata.ScorecardSTRCurrentMonthPer != 0) {
                objScorecardSTRCurrentMonthPer = userconfigdata.ScorecardSTRCurrentMonthPer;
            }

            //#region % Change over PY
            let lstScorecardstrChangeoverPYdata = [];
            lstScorecardstrdata.forEach(function (item) {

                let objScorecardstrchangeoverpydata = new Scorecardstrchangeoverpydata();
                objScorecardstrchangeoverpydata.monthname = item.MonthName;
                objScorecardstrchangeoverpydata.occ = item.OccChg;
                objScorecardstrchangeoverpydata.adr = item.ADRChg;
                objScorecardstrchangeoverpydata.revpar = item.RevParChg;

                if (item.DTCurMth == item.MonthName) {

                    if (objScorecardstrchangeoverpydata.occ == undefined || objScorecardstrchangeoverpydata.occ >= 0) {
                        if (objScorecardstrchangeoverpydata.occ >= objScorecardSTRCurrentMonthPer) {
                            objScorecardstrchangeoverpydata.occtooltipcolor = Constants.Colors.Green;
                            objScorecardstrchangeoverpydata.occtooltip = ">=" + objScorecardSTRCurrentMonthPer;
                        }
                        else {
                            objScorecardstrchangeoverpydata.occtooltipcolor = Constants.Colors.Orange;
                            objScorecardstrchangeoverpydata.occtooltip = "<" + objScorecardSTRCurrentMonthPer;

                        }
                    }
                    else {
                        objScorecardstrchangeoverpydata.occtooltipcolor = Constants.Colors.Red;
                        objScorecardstrchangeoverpydata.occtooltip = "<=0";
                    }


                    if (objScorecardstrchangeoverpydata.adr == undefined || objScorecardstrchangeoverpydata.adr >= 0) {
                        if (objScorecardstrchangeoverpydata.adr >= objScorecardSTRCurrentMonthPer) {
                            objScorecardstrchangeoverpydata.adrtooltipcolor = Constants.Colors.Green;
                            objScorecardstrchangeoverpydata.adrtooltip = ">=" + objScorecardSTRCurrentMonthPer;
                        }
                        else {
                            objScorecardstrchangeoverpydata.adrtooltipcolor = Constants.Colors.Orange;
                            objScorecardstrchangeoverpydata.adrtooltip = "<" + objScorecardSTRCurrentMonthPer;

                        }
                    }
                    else {
                        objScorecardstrchangeoverpydata.adrtooltipcolor = Constants.Colors.Red;
                        objScorecardstrchangeoverpydata.adrtooltip = "<=0";
                    }

                    if (objScorecardstrchangeoverpydata.revpar == undefined || objScorecardstrchangeoverpydata.revpar >= 0) {
                        if (objScorecardstrchangeoverpydata.revpar >= objScorecardSTRCurrentMonthPer) {
                            objScorecardstrchangeoverpydata.revpartooltipcolor = Constants.Colors.Green;
                            objScorecardstrchangeoverpydata.revpartooltip = ">=" + objScorecardSTRCurrentMonthPer;
                        }
                        else {
                            objScorecardstrchangeoverpydata.revpartooltipcolor = Constants.Colors.Orange;
                            objScorecardstrchangeoverpydata.revpartooltip = "<" + objScorecardSTRCurrentMonthPer;

                        }
                    }
                    else {
                        objScorecardstrchangeoverpydata.revpartooltipcolor = Constants.Colors.Red;
                        objScorecardstrchangeoverpydata.revpartooltip = "<=0";
                    }


                }
                lstScorecardstrChangeoverPYdata.push(objScorecardstrchangeoverpydata.setFormat(objScorecardstrchangeoverpydata));
            });
            //#endregion
            //#region % Change over PY - Chart Data
            let lstScorecardstrChangeoverPYChartdata = [];
            lstScorecardstrdata.forEach(function (item) {

                let objScorecardstrchangeoverpychartdata = new Scorecardstrchangeoverpychartdata();
                objScorecardstrchangeoverpychartdata.monthname = item.MonthName;
                objScorecardstrchangeoverpychartdata.occ = item.OccAct;
                objScorecardstrchangeoverpychartdata.adr = item.AdrAct;
                objScorecardstrchangeoverpychartdata.revpar = item.RevParAct;

                lstScorecardstrChangeoverPYChartdata.push(objScorecardstrchangeoverpychartdata.setFormat(objScorecardstrchangeoverpychartdata));
            });
            //#endregion

            //#region Index % Change
            let lstScorecardstrIndexChangedata = [];
            lstScorecardstrdata.forEach(function (item) {

                let objScorecardstrindexchangedata = new Scorecardstrindexchangedata();
                objScorecardstrindexchangedata.monthname = item.MonthName;
                objScorecardstrindexchangedata.occ = item.MPI;
                objScorecardstrindexchangedata.adr = item.ARI;
                objScorecardstrindexchangedata.revpar = item.RGI;

                if (item.DTCurMth == item.MonthName) {

                    if (objScorecardstrindexchangedata.occ == undefined || objScorecardstrindexchangedata.occ >= 0) {
                        if (objScorecardstrindexchangedata.occ >= objScorecardSTRCurrentMonthPer) {
                            objScorecardstrindexchangedata.occtooltipcolor = Constants.Colors.Green;
                            objScorecardstrindexchangedata.occtooltip = ">=" + objScorecardSTRCurrentMonthPer;
                        }
                        else {
                            objScorecardstrindexchangedata.occtooltipcolor = Constants.Colors.Orange;
                            objScorecardstrindexchangedata.occtooltip = "<" + objScorecardSTRCurrentMonthPer;

                        }
                    }
                    else {
                        objScorecardstrindexchangedata.occtooltipcolor = Constants.Colors.Red;
                        objScorecardstrindexchangedata.occtooltip = "<=0";
                    }


                    if (objScorecardstrindexchangedata.adr == undefined || objScorecardstrindexchangedata.adr >= 0) {
                        if (objScorecardstrindexchangedata.adr >= objScorecardSTRCurrentMonthPer) {
                            objScorecardstrindexchangedata.adrtooltipcolor = Constants.Colors.Green;
                            objScorecardstrindexchangedata.adrtooltip = ">=" + objScorecardSTRCurrentMonthPer;
                        }
                        else {
                            objScorecardstrindexchangedata.adrtooltipcolor = Constants.Colors.Orange;
                            objScorecardstrindexchangedata.adrtooltip = "<" + objScorecardSTRCurrentMonthPer;

                        }
                    }
                    else {
                        objScorecardstrindexchangedata.adrtooltipcolor = Constants.Colors.Red;
                        objScorecardstrindexchangedata.adrtooltip = "<=0";
                    }

                    if (objScorecardstrindexchangedata.revpar == undefined || objScorecardstrindexchangedata.revpar >= 0) {
                        if (objScorecardstrindexchangedata.revpar >= objScorecardSTRCurrentMonthPer) {
                            objScorecardstrindexchangedata.revpartooltipcolor = Constants.Colors.Green;
                            objScorecardstrindexchangedata.revpartooltip = ">=" + objScorecardSTRCurrentMonthPer;
                        }
                        else {
                            objScorecardstrindexchangedata.revpartooltipcolor = Constants.Colors.Orange;
                            objScorecardstrindexchangedata.revpartooltip = "<" + objScorecardSTRCurrentMonthPer;

                        }
                    }
                    else {
                        objScorecardstrindexchangedata.revpartooltipcolor = Constants.Colors.Red;
                        objScorecardstrindexchangedata.revpartooltip = "<=0";
                    }


                }

                lstScorecardstrIndexChangedata.push(objScorecardstrindexchangedata.setFormat(objScorecardstrindexchangedata));
            });
            //#endregion
            //#region Index % Change - Chart Data
            let lstScorecardstrIndexChangeChartdata = [];
            lstScorecardstrdata.forEach(function (item) {

                let objScorecardstrindexchangechartdata = new Scorecardstrindexchangechartdata();
                objScorecardstrindexchangechartdata.monthname = item.MonthName;
                objScorecardstrindexchangechartdata.occ = item.OccIndex;
                objScorecardstrindexchangechartdata.adr = item.AdrIndex;
                objScorecardstrindexchangechartdata.revpar = item.RevParIndex;

                lstScorecardstrIndexChangeChartdata.push(objScorecardstrindexchangechartdata.setFormat(objScorecardstrindexchangechartdata));
            });
            //#endregion

            //#region Rank
            let lstScorecardstrRankdata = [];
            lstScorecardstrdata.forEach(function (item) {

                let objScorecardstrrankdata = new Scorecardstrrankdata();
                objScorecardstrrankdata.monthname = item.MonthName;
                objScorecardstrrankdata.occ = item.OccRankAVG;
                objScorecardstrrankdata.adr = item.AdrRankAVG;
                objScorecardstrrankdata.revpar = item.RevParRankAVG;

                if (item.DTCurMth == item.MonthName) {

                    if (objScorecardstrrankdata.occ == undefined) {
                        objScorecardstrrankdata.occ = "N/A";
                    }
                    if (objScorecardstrrankdata.occ != "N/A") {

                        if (item.OccRankAVG >= objScorecardSTRCurrentMonthPer) {
                            objScorecardstrrankdata.occtooltipcolor = Constants.Colors.Green;
                            objScorecardstrrankdata.occtooltip = ">=" + objScorecardSTRCurrentMonthPer;
                        }
                        else {
                            objScorecardstrrankdata.occtooltipcolor = Constants.Colors.Orange;
                            objScorecardstrrankdata.occtooltip = "<=" + objScorecardSTRCurrentMonthPer;

                        }
                    }
                    else {
                        objScorecardstrrankdata.occtooltipcolor = Constants.Colors.Red;
                        objScorecardstrrankdata.occtooltip = "<=0";
                    }

                    if (objScorecardstrrankdata.adr == undefined) {
                        objScorecardstrrankdata.adr = "N/A";
                    }


                    if (objScorecardstrrankdata.adr != "N/A") {
                        if (item.AdrRankAVG >= objScorecardSTRCurrentMonthPer) {
                            objScorecardstrrankdata.adrtooltipcolor = Constants.Colors.Green;
                            objScorecardstrrankdata.adrtooltip = ">=" + objScorecardSTRCurrentMonthPer;
                        }
                        else {
                            objScorecardstrrankdata.adrtooltipcolor = Constants.Colors.Orange;
                            objScorecardstrrankdata.adrtooltip = "<=" + objScorecardSTRCurrentMonthPer;

                        }
                    }
                    else {
                        objScorecardstrrankdata.adrtooltipcolor = Constants.Colors.Red;
                        objScorecardstrrankdata.adrtooltip = "<=0";
                    }

                    if (objScorecardstrrankdata.revpar == undefined) {
                        objScorecardstrrankdata.revpar = "N/A";
                    }


                    if (objScorecardstrrankdata.revpar != "N/A") {
                        if (item.RevParRankAVG >= objScorecardSTRCurrentMonthPer) {
                            objScorecardstrrankdata.revpartooltipcolor = Constants.Colors.Green;
                            objScorecardstrrankdata.revpartooltip = ">=" + objScorecardSTRCurrentMonthPer;
                        }
                        else {
                            objScorecardstrrankdata.revpartooltipcolor = Constants.Colors.Orange;
                            objScorecardstrrankdata.revpartooltip = "<" + objScorecardSTRCurrentMonthPer;

                        }
                    }
                    else {
                        objScorecardstrrankdata.revpartooltipcolor = Constants.Colors.Red;
                        objScorecardstrrankdata.revpartooltip = "<=0";
                    }
                }
                lstScorecardstrRankdata.push(objScorecardstrrankdata.setFormat(objScorecardstrrankdata));
            });
            //#endregion
            //#region Rank - Chart Data
            let lstScorecardstrRankChartdata = [];
            lstScorecardstrdata.forEach(function (item) {

                let objScorecardstrRankChartdata = new Scorecardstrrankchartdata();
                objScorecardstrRankChartdata.monthname = item.MonthName;
                objScorecardstrRankChartdata.occ = item.OccRankAVG;
                objScorecardstrRankChartdata.adr = item.AdrRankAVG;
                objScorecardstrRankChartdata.revpar = item.RevParRankAVG;

                lstScorecardstrRankChartdata.push(objScorecardstrRankChartdata.setFormat(objScorecardstrRankChartdata));
            });
            //#endregion

            let objScorecardstrreportdata = new Scorecardstrreportdata();
            objScorecardstrreportdata.strchangeoverpydata = lstScorecardstrChangeoverPYdata;
            objScorecardstrreportdata.strchangeoverpychartdata = lstScorecardstrChangeoverPYChartdata;
            objScorecardstrreportdata.strindexchangedata = lstScorecardstrIndexChangedata;
            objScorecardstrreportdata.strindexchangechartdata = lstScorecardstrIndexChangeChartdata;
            objScorecardstrreportdata.strrankdata = lstScorecardstrRankdata;
            objScorecardstrreportdata.strrankchartdata = lstScorecardstrRankChartdata;

            cb(null, objScorecardstrreportdata);

        }, err => {
            return cb(err);
        })

    }


    static getSTRData_GraphQL(userid, hotelid, reportdate, period, reporttype, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    ScorecardHelper.getSTRData(hoteldata.ID, reportdate, period, reporttype, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });
        });
    }

    static getLaborData(hotelid, reportdate, period, userconfigdata, cb) {

        period = period.toLowerCase();

        var dtreportdate = new Date(reportdate);

        //LastYear date
        var dtreportdate_LastYear = new Date(dtreportdate);
        var startDateLY = new Date(dtreportdate);

        //TBD get same day lastyear for current period
        dtreportdate_LastYear.setFullYear(dtreportdate.getFullYear() - 1);

        var startDate = new Date(dtreportdate);
        var endDate = new Date(dtreportdate);
        var days = 1;

        if (period == "mtd") {
            startDate = Utils.firstDayOfMonth(dtreportdate);
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfMonth(dtreportdate_LastYear);
        }
        else if (period == "ytd") {
            startDate = Utils.firstDayOfYear(dtreportdate);
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfYear(dtreportdate_LastYear);
        }
        else if (period == "ttm") {
            startDate = Utils.firstDayOfMonth(dtreportdate);
            startDate = Utils.lastYearDate(startDate);

            startDateLY = Utils.firstDayOfMonth(startDate);
            startDateLY = Utils.lastYearDate(startDateLY);

            endDate = Utils.firstDayOfMonth(dtreportdate);
            endDate.setDate(startDate.getDate() - 1);

            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
        }
        else {
            dtreportdate_LastYear = Utils.sameDayLastYear(startDate);
            startDateLY = dtreportdate_LastYear;
        }

        days = Utils.dateDiffInDays(startDate, endDate);


        let hoteldashboardcalculationsData = [];
        let hoteldashboardcalculationsData_LastYear = [];
        let hotelbudgetdashboardcalculationsData = [];
        let hoteleffectivenesscalculationsData = [];
        let hoteleffectivenesscalculationsData_LastYear = [];

        return Promise.all([

            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations data
                HoteldashboardcalculationsHelper.GetData(hotelid, dtreportdate, (err, hoteldashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_result) {
                        hoteldashboardcalculationsData = hoteldashboardcalculations_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get Hoteldashboardcalculations_LastYear data
                HoteldashboardcalculationsHelper.GetData(hotelid, dtreportdate_LastYear, (err, hoteldashboardcalculations_LastYear_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteldashboardcalculations_LastYear_result) {
                        hoteldashboardcalculationsData_LastYear = hoteldashboardcalculations_LastYear_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get #LABOURCURYER data
                HoteleffectivenesscalculationsHelper.GetDepartmentWiseData(hotelid, startDate, endDate, (err, hoteleffectivenesscalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteleffectivenesscalculations_result) {
                        hoteleffectivenesscalculationsData = hoteleffectivenesscalculations_result;
                    }
                    resolve();
                });

            }),
            new Promise((resolve, reject) => {
                // get LABOURCURYERLastYear data
                HoteleffectivenesscalculationsHelper.GetDepartmentWiseData(hotelid, startDateLY, dtreportdate_LastYear, (err, hoteleffectivenesscalculations_LastYear_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hoteleffectivenesscalculations_LastYear_result) {
                        hoteleffectivenesscalculationsData_LastYear = hoteleffectivenesscalculations_LastYear_result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get hotelbudgetdashboardcalculations  data
                HotelbudgetdashboardcalculationsHelper.GetData(hotelid, dtreportdate, (err, hotelbudgetdashboardcalculations_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelbudgetdashboardcalculations_result) {
                        hotelbudgetdashboardcalculationsData = hotelbudgetdashboardcalculations_result;
                    }
                    resolve();
                });

            })
        ]).then(resp => {


            let objScorecardLabourPORVariance = Constants.DefaultValues.ScorecardLabourPORVariance;
            if (userconfigdata != null && userconfigdata.ScorecardLabourPORVariance != 0) {
                objScorecardLabourPORVariance = userconfigdata.ScorecardLabourPORVariance;
            }

            //Scorecardlaborlineitemdata
            let lstScorecardlaborlineitemdata = [];
            if (hoteleffectivenesscalculationsData != null && hoteleffectivenesscalculationsData.length > 0) {
                hoteleffectivenesscalculationsData = Utils.sort(hoteleffectivenesscalculationsData, '_id');
                hoteleffectivenesscalculationsData.forEach(function (item) {

                    let objScorecardlaborlineitemdata = new Scorecardlaborlineitemdata();
                    objScorecardlaborlineitemdata.title = item._id;
                    objScorecardlaborlineitemdata.actual = item.Wages;
                    objScorecardlaborlineitemdata.plan = item.PlanWages;
                    objScorecardlaborlineitemdata.actualpor = 0;
                    objScorecardlaborlineitemdata.planpor = 0;
                    objScorecardlaborlineitemdata.variance = item.Wages - item.PlanWages;

                    let noOfRoomSold = 0;
                    if (hoteldashboardcalculationsData) {
                        if (period == "mtd") {
                            noOfRoomSold = hoteldashboardcalculationsData.NoOfRoomSoldMTD;
                        }
                        else if (period == "ytd") {
                            noOfRoomSold = hoteldashboardcalculationsData.NoOfRoomSoldYTD;
                        }
                        else if (period == "ttm") {
                            noOfRoomSold = hoteldashboardcalculationsData.NoOfRoomSoldTTM;
                        }
                        else {
                            noOfRoomSold = hoteldashboardcalculationsData.NoOfRoomSold;
                        }
                        if (noOfRoomSold && noOfRoomSold > 0) {
                            objScorecardlaborlineitemdata.actualpor = objScorecardlaborlineitemdata.actual / noOfRoomSold;
                        }
                    }


                    let budgetTotalNoofRoomsSold = 0;
                    if (hotelbudgetdashboardcalculationsData) {
                        if (period == "mtd") {
                            budgetTotalNoofRoomsSold = hotelbudgetdashboardcalculationsData.MTDBudgetRooms;
                        }
                        else if (period == "ytd") {
                            budgetTotalNoofRoomsSold = hotelbudgetdashboardcalculationsData.YTDBudgetRooms;
                        }
                        else if (period == "ttm") {
                            budgetTotalNoofRoomsSold = hotelbudgetdashboardcalculationsData.TTMBudgetRooms;
                        }
                        else {
                            budgetTotalNoofRoomsSold = hotelbudgetdashboardcalculationsData.BudgetRoomSold;
                        }
                        if (budgetTotalNoofRoomsSold && budgetTotalNoofRoomsSold > 0) {
                            objScorecardlaborlineitemdata.planpor = objScorecardlaborlineitemdata.plan / budgetTotalNoofRoomsSold;
                        }
                    }

                    objScorecardlaborlineitemdata.variancepor = objScorecardlaborlineitemdata.actualpor - objScorecardlaborlineitemdata.planpor;
                    if (objScorecardlaborlineitemdata.variancepor > objScorecardLabourPORVariance) {
                        objScorecardlaborlineitemdata.variancetooltipcolor = Constants.Colors.Red;
                        objScorecardlaborlineitemdata.variancetooltip = "Actual-Plan POR>" + objScorecardLabourPORVariance;
                    }
                    else {
                        objScorecardlaborlineitemdata.variancetooltipcolor = Constants.Colors.Orange;
                        objScorecardlaborlineitemdata.variancetooltip = "Actual-Plan POR<" + objScorecardLabourPORVariance;
                    }

                    objScorecardlaborlineitemdata.lastyear = 0;
                    if (hoteleffectivenesscalculationsData_LastYear) {

                        //find by department name
                        var objhoteleffectivenesscalculationsData_LastYear = hoteleffectivenesscalculationsData_LastYear.filter(d => {
                            return (d._id == objScorecardlaborlineitemdata.title);
                        });

                        if (objhoteleffectivenesscalculationsData_LastYear != null && objhoteleffectivenesscalculationsData_LastYear.length > 0) {
                            objScorecardlaborlineitemdata.lastyear = objhoteleffectivenesscalculationsData_LastYear[0].PlanWages;
                        }
                    }

                    if (hoteldashboardcalculationsData_LastYear) {

                        let noOfRoomSoldLY = 0;
                        if (period == "mtd") {
                            noOfRoomSoldLY = hoteldashboardcalculationsData_LastYear.NoOfRoomSoldMTD;
                        }
                        else if (period == "ytd") {
                            noOfRoomSoldLY = hoteldashboardcalculationsData_LastYear.NoOfRoomSoldYTD;
                        }
                        else if (period == "ttm") {
                            noOfRoomSoldLY = hoteldashboardcalculationsData_LastYear.NoOfRoomSoldTTM;
                        }
                        else {
                            noOfRoomSoldLY = hoteldashboardcalculationsData_LastYear.NoOfRoomSold;
                        }
                        if (noOfRoomSoldLY && noOfRoomSoldLY > 0) {
                            objScorecardlaborlineitemdata.lastyearpor = objScorecardlaborlineitemdata.lastyear / noOfRoomSoldLY;
                        }

                    }

                    objScorecardlaborlineitemdata.lastyearvariancepor = objScorecardlaborlineitemdata.actualpor - objScorecardlaborlineitemdata.lastyearpor;

                    if (objScorecardlaborlineitemdata.lastyearvariancepor > objScorecardLabourPORVariance) {
                        objScorecardlaborlineitemdata.lastyearvariancetooltipcolor = Constants.Colors.Red;
                        objScorecardlaborlineitemdata.lastyearvariancetooltip = "Actual-Plan POR>" + objScorecardLabourPORVariance;
                    }
                    else {
                        objScorecardlaborlineitemdata.lastyearvariancetooltipcolor = Constants.Colors.Orange;
                        objScorecardlaborlineitemdata.lastyearvariancetooltip = "Actual-Plan POR<" + objScorecardLabourPORVariance;
                    }

                    lstScorecardlaborlineitemdata.push(objScorecardlaborlineitemdata.setFormat(objScorecardlaborlineitemdata));

                });
            }

            cb(null, lstScorecardlaborlineitemdata);

        }, err => {
            return cb(err);
        })

    }

    static getLaborData_GraphQL(userid, hotelid, reportdate, period, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    ScorecardHelper.getLaborData(hoteldata.ID, reportdate, period, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }


    static GetConfigs_GraphQL(userid, cd) {

        UserHelper.getUserConfigData(userid, (err, result) => {
            if (err) {
                cd(err, null);
            }
            var objScorecardconfigdata = new Scorecardconfigdata();
            objScorecardconfigdata.userid = userid;
            if (result) {
                objScorecardconfigdata.scorecardrevenuewidget = result.ScorecardRevenueWidget;
                objScorecardconfigdata.scorecardstrwidget = result.ScorecardSTRWidget;
                objScorecardconfigdata.scorecardlabourwidget = result.ScorecardLabourWidget;
                objScorecardconfigdata.scorecardprofitwidget = result.ScorecardProfitWidget;
                objScorecardconfigdata.scorecardservicewidget = result.ScorecardServiceWidget;
                objScorecardconfigdata.scorecardtotalrevenueper = result.ScorecardTotalRevenuePer;
                objScorecardconfigdata.scorecardstrcurrentmonthper = result.ScorecardSTRCurrentMonthPer;
                objScorecardconfigdata.scorecardlabourporvariance = result.ScorecardLabourPORVariance;
                objScorecardconfigdata.scorecardservicescore = result.ScorecardServiceScore;
                objScorecardconfigdata.scorecardserviceweightedper = result.ScorecardServiceWeightedPer;
            }
            cd(null, objScorecardconfigdata);
        });
    }

    static SaveConfigs_GraphQL(userid, scorecardrevenuewidget, scorecardstrwidget, scorecardlabourwidget, scorecardprofitwidget, scorecardservicewidget,
        scorecardtotalrevenueper, scorecardstrcurrentmonthper, scorecardlabourporvariance,
        scorecardservicescore, scorecardserviceweightedper, cd) {

        UserHelper.getUserConfigData(userid, (err, result) => {
            if (err) {
                cd(err, null);
            }
            var objScorecardconfigdata = new Scorecardconfigdata();
            objScorecardconfigdata.userid = userid;
            objScorecardconfigdata.scorecardrevenuewidget = scorecardrevenuewidget;
            objScorecardconfigdata.scorecardstrwidget = scorecardstrwidget;
            objScorecardconfigdata.scorecardlabourwidget = scorecardlabourwidget;
            objScorecardconfigdata.scorecardprofitwidget = scorecardprofitwidget;
            objScorecardconfigdata.scorecardservicewidget = scorecardservicewidget;
            objScorecardconfigdata.scorecardtotalrevenueper = scorecardtotalrevenueper;
            objScorecardconfigdata.scorecardstrcurrentmonthper = scorecardstrcurrentmonthper;
            objScorecardconfigdata.scorecardlabourporvariance = scorecardlabourporvariance;
            objScorecardconfigdata.scorecardservicescore = scorecardservicescore;
            objScorecardconfigdata.scorecardserviceweightedper = scorecardserviceweightedper;
            UserHelper.saveUserConfigData_Scorecard(objScorecardconfigdata, (save_err, save_result) => {
                if (save_err) {
                    cd(save_err, null);
                }

                //move it to SQL server as well for sync
                if (config.appsettings.sync_to_SQLServer) {

                    //db write to SQL server and sync will handle the data in mangodb
                    var json_postdata = [];
                    json_postdata.userid = userid;
                    json_postdata.ScorecardRevenueWidget = objScorecardconfigdata.scorecardrevenuewidget;
                    json_postdata.ScorecardSTRWidget = objScorecardconfigdata.scorecardstrwidget;
                    json_postdata.ScorecardLabourWidget = objScorecardconfigdata.scorecardlabourwidget;
                    json_postdata.ScorecardProfitWidget = objScorecardconfigdata.scorecardprofitwidget;
                    json_postdata.ScorecardServiceWidget = objScorecardconfigdata.scorecardservicewidget;
                    json_postdata.ScorecardTotalRevenuePer = objScorecardconfigdata.scorecardtotalrevenueper;
                    json_postdata.ScorecardSTRCurrentMonthPer = objScorecardconfigdata.scorecardstrcurrentmonthper;
                    json_postdata.ScorecardLabourPORVariance = objScorecardconfigdata.scorecardlabourporvariance;
                    json_postdata.ScorecardServiceScore = objScorecardconfigdata.scorecardservicescore;
                    json_postdata.ScorecardServiceWeightedPer = objScorecardconfigdata.scorecardserviceweightedper;
                    //Config/UpdateScorecard in SQL server
                    RESTHelper.POST(Constants.Urls.UpdateScorecardConfig, json_postdata, (api_err, sync_result) => {
                        if (api_err)
                            log.error(api_err);
                        log.debug(sync_result);
                    });
                }

                cd(null, objScorecardconfigdata);
            });
        });
    }

    static getServiceData(hotelid, reportdate, period, userconfigdata, cb) {

        period = period.toLowerCase();

        var dtreportdate = new Date(reportdate);

        //LastYear date
        var dtreportdate_LastYear = new Date(dtreportdate);
        var startDateLY = new Date(dtreportdate);

        //TBD get same day lastyear for current period
        dtreportdate_LastYear.setFullYear(dtreportdate.getFullYear() - 1);

        var startDate = new Date(dtreportdate);
        var endDate = new Date(dtreportdate);
        startDate = Utils.firstDayOfMonth(dtreportdate);

        if (period == "mtd") {
            endDate = Utils.lastDayOfMonth(dtreportdate);
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfMonth(dtreportdate_LastYear);
        }
        else if (period == "ytd") {
            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
            startDateLY = Utils.firstDayOfYear(dtreportdate_LastYear);
        }
        else if (period == "ttm") {
            startDate = Utils.firstDayOfMonth(dtreportdate);
            startDate = Utils.lastYearDate(startDate);

            startDateLY = Utils.firstDayOfMonth(startDate);
            startDateLY = Utils.lastYearDate(startDateLY);

            endDate = Utils.firstDayOfMonth(dtreportdate);
            endDate.setDate(startDate.getDate() - 1);

            dtreportdate_LastYear = Utils.lastYearDate(dtreportdate);
        }
        else {
            dtreportdate_LastYear = Utils.sameDayLastYear(startDate);
            startDateLY = dtreportdate_LastYear;
        }


        //get last three month wise data

        let gssreport_data_month = [];
        let gssreport_data_1_month = [];
        let gssreport_data_2_month = [];


        var startDate_month_1 = new Date(startDate);
        startDate_month_1.setMonth(startDate.getMonth() - 2);
        startDate_month_1 = Utils.firstDayOfMonth(startDate_month_1);
        var endDate_month_1 = Utils.lastDayOfMonth(startDate_month_1);


        var startDate_month_2 = new Date(startDate);
        startDate_month_2.setMonth(startDate.getMonth() - 1);
        startDate_month_2 = Utils.firstDayOfMonth(startDate_month_2);
        var endDate_month_2 = Utils.lastDayOfMonth(startDate_month_2);

        let currentMnnthName = Utils.getFormattedDate(dtreportdate, 'MMM');
        let MnnthName1 = Utils.getFormattedDate(startDate_month_1, 'MMM');
        let MnnthName2 = Utils.getFormattedDate(startDate_month_2, 'MMM');

        let lsthotelids = [];
        lsthotelids.push(hotelid);

        return Promise.all([

            new Promise((resolve, reject) => {
                // get GSS Hotelgssdata data last 2nd month
                HotelgssHelper.GetPriorityData(lsthotelids, startDate_month_1, endDate_month_1, 1, (err, hotelgssdata_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelgssdata_result && hotelgssdata_result.length > 0) {
                        gssreport_data_1_month = hotelgssdata_result[0];
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get GSS Hotelgssdata data last 2nd month
                HotelgssHelper.GetPriorityData(lsthotelids, startDate_month_2, endDate_month_2, 1, (err, hotelgssdata_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelgssdata_result && hotelgssdata_result.length > 0) {
                        gssreport_data_2_month = hotelgssdata_result[0];
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get GSS Hotelgssdata data last  month
                HotelgssHelper.GetPriorityData(lsthotelids, startDate, endDate, 1, (err, hotelgssdata_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotelgssdata_result && hotelgssdata_result.length > 0) {
                        gssreport_data_month = hotelgssdata_result[0];
                    }
                    resolve();
                });

            })


        ]).then(resp => {


            let lstScorecardgssdata = [];

            //#region Constants.ScorecardServiceItems.BrandAverage
            let lstScorecardservicelineitemdataBrandAverage_Items = [];

            let objScorecardservicelineitemdataBrandAverage = new Scorecardservicelineitemdata();
            objScorecardservicelineitemdataBrandAverage.title = Constants.ScorecardServiceItems.BrandAverage;

            let objScorecardservicelineitemdataBrandAverage_Month1 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataBrandAverage_Month1.title = Constants.ScorecardServiceItems.BrandAverage;
            objScorecardservicelineitemdataBrandAverage_Month1.monthname = MnnthName1;

            let objScorecardservicelineitemdataBrandAverage_Month2 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataBrandAverage_Month2.title = Constants.ScorecardServiceItems.BrandAverage;
            objScorecardservicelineitemdataBrandAverage_Month2.monthname = MnnthName2;

            let objScorecardservicelineitemdataBrandAverage_Month3 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataBrandAverage_Month3.title = Constants.ScorecardServiceItems.BrandAverage;
            objScorecardservicelineitemdataBrandAverage_Month3.monthname = currentMnnthName;

            lstScorecardservicelineitemdataBrandAverage_Items.push(objScorecardservicelineitemdataBrandAverage_Month1.setFormat(objScorecardservicelineitemdataBrandAverage_Month1));
            lstScorecardservicelineitemdataBrandAverage_Items.push(objScorecardservicelineitemdataBrandAverage_Month2.setFormat(objScorecardservicelineitemdataBrandAverage_Month2));
            lstScorecardservicelineitemdataBrandAverage_Items.push(objScorecardservicelineitemdataBrandAverage_Month3.setFormat(objScorecardservicelineitemdataBrandAverage_Month3));

            objScorecardservicelineitemdataBrandAverage.items = lstScorecardservicelineitemdataBrandAverage_Items;
            lstScorecardgssdata.push(objScorecardservicelineitemdataBrandAverage);

            ////#endregion

            //#region Constants.ScorecardServiceItems.HotelGSSRate
            let lstScorecardservicelineitemdataHotelGSSRate_Items = [];

            let objScorecardservicelineitemdataHotelGSSRate = new Scorecardservicelineitemdata();
            objScorecardservicelineitemdataHotelGSSRate.title = Constants.ScorecardServiceItems.HotelGSSRate;

            let objScorecardservicelineitemdataHotelGSSRate_Month1 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataHotelGSSRate_Month1.title = Constants.ScorecardServiceItems.HotelGSSRate;
            objScorecardservicelineitemdataHotelGSSRate_Month1.monthname = MnnthName1;

            let objScorecardservicelineitemdataHotelGSSRate_Month2 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataHotelGSSRate_Month2.title = Constants.ScorecardServiceItems.HotelGSSRate;
            objScorecardservicelineitemdataHotelGSSRate_Month2.monthname = MnnthName2;

            let objScorecardservicelineitemdataHotelGSSRate_Month3 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataHotelGSSRate_Month3.title = Constants.ScorecardServiceItems.HotelGSSRate;
            objScorecardservicelineitemdataHotelGSSRate_Month3.monthname = currentMnnthName;


            if (gssreport_data_1_month) {
                objScorecardservicelineitemdataHotelGSSRate_Month1.value = gssreport_data_1_month.actual;
            }
            if (gssreport_data_2_month) {
                objScorecardservicelineitemdataHotelGSSRate_Month2.value = gssreport_data_2_month.actual;
            }

            if (gssreport_data_month) {
                objScorecardservicelineitemdataHotelGSSRate_Month3.value = gssreport_data_month.actual;
            }

            lstScorecardservicelineitemdataHotelGSSRate_Items.push(objScorecardservicelineitemdataHotelGSSRate_Month1.setFormat(objScorecardservicelineitemdataHotelGSSRate_Month1));
            lstScorecardservicelineitemdataHotelGSSRate_Items.push(objScorecardservicelineitemdataHotelGSSRate_Month2.setFormat(objScorecardservicelineitemdataHotelGSSRate_Month2));
            lstScorecardservicelineitemdataHotelGSSRate_Items.push(objScorecardservicelineitemdataHotelGSSRate_Month3.setFormat(objScorecardservicelineitemdataHotelGSSRate_Month3));

            objScorecardservicelineitemdataHotelGSSRate.items = lstScorecardservicelineitemdataHotelGSSRate_Items;
            lstScorecardgssdata.push(objScorecardservicelineitemdataHotelGSSRate);

            ////#endregion


            //#region Constants.ScorecardServiceItems.Variance
            let lstScorecardservicelineitemdataVariance_Items = [];

            let objScorecardservicelineitemdataVariance = new Scorecardservicelineitemdata();
            objScorecardservicelineitemdataVariance.title = Constants.ScorecardServiceItems.Variance;

            let objScorecardservicelineitemdataVariance_Month1 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataVariance_Month1.title = Constants.ScorecardServiceItems.Variance;
            objScorecardservicelineitemdataVariance_Month1.monthname = MnnthName1;

            let objScorecardservicelineitemdataVariance_Month2 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataVariance_Month2.title = Constants.ScorecardServiceItems.Variance;
            objScorecardservicelineitemdataVariance_Month2.monthname = MnnthName2;

            let objScorecardservicelineitemdataVariance_Month3 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataVariance_Month3.title = Constants.ScorecardServiceItems.Variance;
            objScorecardservicelineitemdataVariance_Month3.monthname = currentMnnthName;


            if (gssreport_data_1_month) {
                if (gssreport_data_1_month.actual != 0 && gssreport_data_1_month.actual != null) {
                    objScorecardservicelineitemdataVariance_Month1.value = gssreport_data_1_month.actual / 100;
                }
            }
            if (gssreport_data_2_month) {
                if (gssreport_data_2_month.actual != 0 && gssreport_data_2_month.actual != null) {
                    objScorecardservicelineitemdataVariance_Month2.value = gssreport_data_2_month.actual / 100;
                }
            }

            if (gssreport_data_month) {
                if (gssreport_data_month.actual != 0 && gssreport_data_month.actual != null) {
                    objScorecardservicelineitemdataVariance_Month3.value = gssreport_data_month.actual / 100;
                }
            }

            lstScorecardservicelineitemdataVariance_Items.push(objScorecardservicelineitemdataVariance_Month1.setFormat(objScorecardservicelineitemdataVariance_Month1));
            lstScorecardservicelineitemdataVariance_Items.push(objScorecardservicelineitemdataVariance_Month2.setFormat(objScorecardservicelineitemdataVariance_Month2));
            lstScorecardservicelineitemdataVariance_Items.push(objScorecardservicelineitemdataVariance_Month3.setFormat(objScorecardservicelineitemdataVariance_Month3));

            objScorecardservicelineitemdataVariance.items = lstScorecardservicelineitemdataVariance_Items;
            lstScorecardgssdata.push(objScorecardservicelineitemdataVariance);

            ////#endregion


            //#region Constants.ScorecardServiceItems.PercentageToBrand
            let lstScorecardservicelineitemdataPercentageToBrand_Items = [];

            let objScorecardservicelineitemdataPercentageToBrand = new Scorecardservicelineitemdata();
            objScorecardservicelineitemdataPercentageToBrand.title = Constants.ScorecardServiceItems.PercentageToBrand;

            let objScorecardservicelineitemdataPercentageToBrand_Month1 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataPercentageToBrand_Month1.title = Constants.ScorecardServiceItems.PercentageToBrand;
            objScorecardservicelineitemdataPercentageToBrand_Month1.monthname = MnnthName1;

            let objScorecardservicelineitemdataPercentageToBrand_Month2 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataPercentageToBrand_Month2.title = Constants.ScorecardServiceItems.PercentageToBrand;
            objScorecardservicelineitemdataPercentageToBrand_Month2.monthname = MnnthName2;

            let objScorecardservicelineitemdataPercentageToBrand_Month3 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataPercentageToBrand_Month3.title = Constants.ScorecardServiceItems.PercentageToBrand;
            objScorecardservicelineitemdataPercentageToBrand_Month3.monthname = currentMnnthName;

            lstScorecardservicelineitemdataPercentageToBrand_Items.push(objScorecardservicelineitemdataPercentageToBrand_Month1.setFormat(objScorecardservicelineitemdataPercentageToBrand_Month1));
            lstScorecardservicelineitemdataPercentageToBrand_Items.push(objScorecardservicelineitemdataPercentageToBrand_Month2.setFormat(objScorecardservicelineitemdataPercentageToBrand_Month2));
            lstScorecardservicelineitemdataPercentageToBrand_Items.push(objScorecardservicelineitemdataPercentageToBrand_Month3.setFormat(objScorecardservicelineitemdataPercentageToBrand_Month3));

            objScorecardservicelineitemdataPercentageToBrand.items = lstScorecardservicelineitemdataPercentageToBrand_Items;
            lstScorecardgssdata.push(objScorecardservicelineitemdataPercentageToBrand);

            ////#endregion

            //#region Constants.ScorecardServiceItems.CHIHotelRanking
            let lstScorecardservicelineitemdataCHIHotelRanking_Items = [];

            let objScorecardservicelineitemdataCHIHotelRanking = new Scorecardservicelineitemdata();
            objScorecardservicelineitemdataCHIHotelRanking.title = Constants.ScorecardServiceItems.CHIHotelRanking;

            let objScorecardservicelineitemdataCHIHotelRanking_Month1 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataCHIHotelRanking_Month1.title = Constants.ScorecardServiceItems.CHIHotelRanking;
            objScorecardservicelineitemdataCHIHotelRanking_Month1.monthname = MnnthName1;

            let objScorecardservicelineitemdataCHIHotelRanking_Month2 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataCHIHotelRanking_Month2.title = Constants.ScorecardServiceItems.CHIHotelRanking;
            objScorecardservicelineitemdataCHIHotelRanking_Month2.monthname = MnnthName2;

            let objScorecardservicelineitemdataCHIHotelRanking_Month3 = new Scorecardservicegsslineitemdata();
            objScorecardservicelineitemdataCHIHotelRanking_Month3.title = Constants.ScorecardServiceItems.CHIHotelRanking;
            objScorecardservicelineitemdataCHIHotelRanking_Month3.monthname = currentMnnthName;

            lstScorecardservicelineitemdataCHIHotelRanking_Items.push(objScorecardservicelineitemdataCHIHotelRanking_Month1.setFormat(objScorecardservicelineitemdataCHIHotelRanking_Month1));
            lstScorecardservicelineitemdataCHIHotelRanking_Items.push(objScorecardservicelineitemdataCHIHotelRanking_Month2.setFormat(objScorecardservicelineitemdataCHIHotelRanking_Month2));
            lstScorecardservicelineitemdataCHIHotelRanking_Items.push(objScorecardservicelineitemdataCHIHotelRanking_Month3.setFormat(objScorecardservicelineitemdataCHIHotelRanking_Month3));

            objScorecardservicelineitemdataCHIHotelRanking.items = lstScorecardservicelineitemdataCHIHotelRanking_Items;
            lstScorecardgssdata.push(objScorecardservicelineitemdataCHIHotelRanking);

            ////#endregion




            let objScorecardservicedata = new Scorecardservicedata();
            objScorecardservicedata.servicegssdata = lstScorecardgssdata;
            // objScorecardstrreportdata.strchangeoverpychartdata = lstScorecardstrChangeoverPYChartdata;
            // objScorecardstrreportdata.strindexchangedata = lstScorecardstrIndexChangedata;
            // objScorecardstrreportdata.strindexchangechartdata = lstScorecardstrIndexChangeChartdata;
            // objScorecardstrreportdata.strrankdata = lstScorecardstrRankdata;
            // objScorecardstrreportdata.strrankchartdata = lstScorecardstrRankChartdata;
            
            /*period = period.toLowerCase();

            var dtreportdate = new Date(reportdate);
    
            //LastYear date
            var dtreportdate_LastYear = new Date(dtreportdate);
            var startDateLY = new Date(dtreportdate);
    
            //TBD get same day lastyear for current period
            dtreportdate_LastYear.setFullYear(dtreportdate.getFullYear() - 1);
    
            var startDate = new Date(dtreportdate);
            var endDate = new Date(dtreportdate);
            startDate = Utils.firstDayOfMonth(dtreportdate);*/
            // period = "MTD";
            // //hotelid, yeasterday, "reviewssnapshot", period
            // let y = new Promise((resolve,reject)=>{
            //     RevinatehoteldataSchema.find({
            //         [RevinatehoteldataSchemaFields.HotelId]:hotelid,
            //         //[RevinatehoteldataSchemaFields.Date]:"2019-10-03 05:30:00.000",
            //         [RevinatehoteldataSchemaFields.ApiName]:"reviewssnapshot",
            //         [RevinatehoteldataSchemaFields.Period]:"MTD",
            //         [RevinatehoteldataSchemaFields.CompetitorHotelSlug]:""

            //     }).exec((err,revinentdata)=>{
            //         if(err){
            //             log.debug('Revenent hoteldata not available');
            //             cd(err,null);
            //         }
            //         resolve(revinentdata)
            //     })
               
            // })
            // y.then(revinentdata=>{

            //     //if(revinentdata.length>0){
                    
            //         _.filter(revinentdata,(key)=>{
            //         //    let JsonConvert = new JsonConvert();
            //         //    let user = jsonConvert.deserializeObject(JSON.parse(key.Data), user);
            //         console.log(JSON.parse(key.Id))
            //            console.log(JSON.stringify(key.Data))
                        
            //         })
                    
            //     // }else{
            //     //     log.debug('Revenent hoteldata not available')
            //     //     cb(null,revinentdata)
            //     // }
                
            // })
            
            cb(null, objScorecardservicedata);    

        }, err => {
            return cb(err);
        })

    }

    static getServiceData_GraphQL(userid, hotelid, reportdate, period, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    ScorecardHelper.getServiceData(hoteldata.ID, reportdate, period, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }

    static GetMissingDatesRevenue(hotelid, period, currentDate, cd) {
        hotelid = (hotelid == null ? "0" : hotelid);
        currentDate = (currentDate == null ? Utils.getFormattedDate(new Date(), "YYYY-MM-DD") : currentDate);

        let result = [];
        let yesterday = currentDate;
        let startDate = Utils.getFormattedDate(new Date(), "YYYY-MM-DD");
        let endDate = Utils.getFormattedDate(new Date(), "YYYY-MM-DD");

        period = period.toLowerCase();

        if (period == "mtd") {
            startDate = Utils.firstDayOfMonth(yesterday);
            endDate = Utils.endofDay(yesterday);
        }
        else if (period == "ytd") {
            startDate = Utils.firstDayOfYear(yesterday);
            endDate = Utils.endofDay(yesterday);
        }
        else if (period == "ttm") {
            startDate = Utils.firstDayOfMonth(yesterday);
            startDate = Utils.lastYearDate(startDate);
            endDate = Utils.firstDayOfMonth(yesterday);
            endDate.setDate(startDate.getDate() - 1);
        }
        else if (period == "current") {
            startDate = Utils.startofDay(yesterday);
            endDate = Utils.endofDay(yesterday);
        }

        startDate = new Date(Utils.getFormattedDate(startDate, "YYYY-MM-DD"));
        endDate = new Date(Utils.getFormattedDate(endDate, "YYYY-MM-DD"));

        HoteldashboardcalculationsHelper.GetMissingDatesRevenue(hotelid, startDate, endDate, (err, missingrevenuedates) => {
            let lstmissingDates = "";
            _.filter(missingrevenuedates, (key) => {                
                result.push({ "date": key,"month":Utils.getFormattedDate(key,"MMM") })
            })
            
            let query = _.map(_.groupBy(result, 'month'), (element, idx) => { return { key: idx,data:element} });
            _.filter(query,(element)=>{
                lstmissingDates = lstmissingDates + element.key + "-";

                _.filter(element.data,(element)=>{
                    lstmissingDates = lstmissingDates + Utils.getFormattedDate(element.date,"DD") + ",";
                })
            })
            
            cd(null,[{"missingdates":lstmissingDates}])
        })


    }

}

module.exports = ScorecardHelper;
