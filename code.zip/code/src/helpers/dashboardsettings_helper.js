const { Dashboardsetting: DashboardsettingSchema, SchemaField: DashboardsettingSchemaFields } = require('../models/dashboardsetting');
const dbtable = require('../schema/db_table');
const Utils = require('../common/utils');
const _ = require('lodash');
var log = require('log4js').getLogger("hotels_helper");

class DashboardSettingsHelper {
    static GetQuarter(fromDate)
    {
        let month =  fromDate.getMonth()- 1;
        let month2 = Math.abs(month / 3) + 1;
        return month2;
    } 
    static AddQuarters(originalDate,quarters){
        return Utils.addMonths(originalDate,quarters * 3);
    }   
    static GetFirstDayOfQuarter(date){
        return DashboardSettingsHelper.AddQuarters(new Date(date.getFullYear(),1,1), DashboardSettingsHelper.GetQuarter(date) - 1);
    }
    static GetLaborSection1(cd){
        let UserID =2;  
        DashboardsettingSchema.findOne({[DashboardsettingSchemaFields.UserID]: UserID },[DashboardsettingSchemaFields.LaborSection1], (err, result) => {
            if (err) {
                cd(err, null);
            }
            
            cd(null,result);
        })
    }
    static GetLaborSection2(cd){
        let UserID =2;  
        DashboardsettingSchema.findOne({[DashboardsettingSchemaFields.UserID]: UserID },[DashboardsettingSchemaFields.LaborSection2], (err, result) => {
            if (err) {
                cd(err, null);
            }
            cd(null,result);
        })
    }
    static GetDashboardSetting(userId,cd){
        
        DashboardsettingSchema.findOne({[DashboardsettingSchemaFields.UserID]: userId }, (err, result) => {
            if (err) {
                cd(err, null);
            }
            
            cd(null,result);
        })
    }
    static GetWeekDay(CurrentDate,laborwidgetday,cd){
        let data=[];    
        let WeekDay = CurrentDate;

                let dayname = laborwidgetday;
               
                let num = 0;

                if (dayname == "Sunday")
                {
                    num = 0;
                }
                else if (dayname == "Monday")
                {
                    num = 1;
                }
                else if (dayname == "Tuesday")
                {
                    num = 2;
                }
                else if (dayname == "Wednesday")
                {
                    num = 3;
                }
                else if (dayname == "Thursday")
                {
                    num = 4;
                }
                else if (dayname == "Friday")
                {
                    num = 5;
                }
                else if (dayname == "Saturday")
                {
                    num = 6;
                }  
                
                let sweekdate = Utils.addDate(CurrentDate,parseInt(-Utils.getDateNumofWeek(CurrentDate) + num)) ;  
                                 
                if (sweekdate > CurrentDate)
                {
                    
                    sweekdate = Utils.addDate(sweekdate,-7);
                }
                
                WeekDay = sweekdate;            
                cd(null, WeekDay);
           
       
    }
    
}
module.exports = DashboardSettingsHelper;


