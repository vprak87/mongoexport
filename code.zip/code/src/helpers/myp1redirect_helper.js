const RESTHelper = require('./rest_helper');
const Constants = require('../common/constants');
const config = require('../../appsettings.js');
const Myp1redirectdata = require('../myp1redirect/models/myp1redirectdata');

var log = require('log4js').getLogger("myp1redirect_helper");

class MYP1RedirectHelper {

    static getUserToken(userid, cb) {

        var geturl = Constants.Urls.GetToken + "?userid=" + userid;
        return RESTHelper.GET(geturl, (api_err, get_result) => {
            if (api_err) {
                log.error(api_err);
                cb(api_err, null);
            }
            else {
                log.debug(get_result.data);
                cb(null, get_result.data);
            }
        });
    }

    static getUserToken_GraphQL(userid, cb) {

        return MYP1RedirectHelper.getUserToken(userid, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });

    }
    static getURLDatawithParams(token, pagename, type, id, reportdate, period, cb) {

        if (id > 0) {
            id = id;
        }
        else {
            id = 0;
        }
        var objMyp1redirectdata = new Myp1redirectdata();
        pagename = pagename.toLowerCase();
        if (pagename == "revenuebreakdown") {
            //#region For RevenueBreakdown
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id + "&type=" + type + "&period=" + period + "&fromdate=" + reportdate;
            //#endregion
        }
        else if (pagename == "portfoliodashboard") {
            //#region For PortfolioDashboard
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id + "&type=" + type + "&fromdate=" + reportdate;
            //#endregion
        }
        else if (pagename == "replytocomment") {
            //#region For ReplyToComment
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id;
            //#endregion
        }
        else if (pagename == "labor") {
            //#region For Labor
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id + "&type=" + type + "&fromdate=" + reportdate;
            //#endregion
        }
        else if (pagename == "strrollup") {
            //#region For STRRollUp
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id + "&type=" + type + "&fromdate=" + reportdate;
            //#endregion
        }
        else if (pagename == "strweekly") {
            //#region For STRWeekly
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id + "&type=" + type + "&fromdate=" + reportdate;
            //#endregion
        }
        else if (pagename == "PickupSummaryReport") {
            //#region For STRWeekly
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id + "&type=" + type + "&fromdate=" + reportdate;
            //#endregion
        }
        else if (pagename == "MonthlyPickup") {
            //#region For MonthlyPickup
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id + "&type=" + type + "&fromdate=" + reportdate;
            //#endregion
        }
        else if (pagename == "PickupReport") {
            //#region For PickupReport
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id + "&type=" + type + "&fromdate=" + reportdate;
            //#endregion
        }
        else if (pagename == "StarReportsDefault") {
            //#region For StarReportsDefault
            objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + pagename + "&id=" + id + "&type=" + type + "&fromdate=" + reportdate;
            //#endregion
        }
        cb(null, objMyp1redirectdata);
    }

    static getURLData(token, cb) {

        var lstMyp1redirectdata = [];

        //make array list of all pages for redirection needed

        //#region  Constants.PageNames._306090Report;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "30/60/90 Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames._306090Report;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion


        //#region  Constants.PageNames.MedalliaReport;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Medallia Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.MedalliaReport;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.GSSMonthlyReport;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "GSS Rollup Monthly Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.GSSMonthlyReport;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.GSSRollUpReport;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "GSS Rollup Yearly Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.GSSRollUpReport;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.RevinatePopularity;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Popularity";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.RevinatePopularity;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.RevinateRatingComparisons;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Rating Comparisons";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.RevinateRatingComparisons;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.RevinateSentimentAnalysis;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Sentiment Analysis";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.RevinateSentimentAnalysis;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.ReviewPro;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "ReviewPro Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.ReviewPro;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.TrustYouSurveyComparison;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Comparisons Overview";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.TrustYouSurveyComparison;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.TrustYouSurveyReviews;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Reviews";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.TrustYouSurveyReviews;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.TrustYouSurveyStatistics;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Survey Statistics";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.TrustYouSurveyStatistics;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.ContactSupport;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Contact Support";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.ContactSupport;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.VRUReport;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "VRU Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.VRUReport;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.Configuration;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Configuration";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.Configuration;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.TrialBalanceBreakDown;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "TrialBalance BreakDown";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.TrialBalanceBreakDown;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion


        //#region  Constants.PageNames.Labor;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Labor";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.Labor;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion


        //#region  Constants.PageNames.STRRollUp;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "STR Portfolio";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.STRRollUp;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion



        //#region  Constants.PageNames.PLStatementMonthly;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Profit And Loss Statement - Monthly Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.PLStatementMonthly;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion


        //#region  Constants.PageNames.PLStatementYearly;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Profit And Loss Statement - Yearly Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.PLStatementYearly;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.PickupSummaryReport;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Pickup Summary Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.PickupSummaryReport;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.MonthlyPickup;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Monthly Pickup";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.MonthlyPickup;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.PickupReport;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Pickup Report";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.PickupReport;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.StarReportsDefault;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Star Reports Default";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.StarReportsDefault;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.STRWeekly;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "STR Weekly";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.STRWeekly;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.CashDetail;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "Cash Detail";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.CashDetail;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion

        //#region  Constants.PageNames.ARAging;
        var objMyp1redirectdata = new Myp1redirectdata();
        objMyp1redirectdata.title = "AR Aging";
        objMyp1redirectdata.url = config.appsettings.myp1_redirecturl + "?token=" + token + "&pagename=" + Constants.PageNames.ARAging;
        lstMyp1redirectdata.push(objMyp1redirectdata);
        //#endregion
        cb(null, lstMyp1redirectdata);
    }




}
module.exports = MYP1RedirectHelper
