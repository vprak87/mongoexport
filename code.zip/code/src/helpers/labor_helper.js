const Utils = require('../common/utils');
const Constants = require('../common/constants');
const { Hoteleffectivenesscalculations: HoteleffectivenesscalculationsSchema, SchemaField: HoteleffectivenesscalculationsSchemaFields } = require('../models/hoteleffectivenesscalculations');
const { Hotelbudgetexpenseform: HotelbudgetexpenseformSchema, SchemaField: HotelbudgetexpenseformSchemaFields } = require('../models/hotelbudgetexpenseform');
const { Hotels: HotelsSchema, SchemaField: HotelsSchemaFields } = require('../models/hotels');
const { Organisationcredentials: OrganisationcredentialsSchema, SchemaField: OrganisationcredentialsSchemaFields } = require('../models/organisationcredentials');
const { User: UserSchema, SchemaField: UserSchemaFields } = require('../models/user');
const Hoteleffectivenesscalculationsdata = require('../labor/models/hoteleffectivenesscalculations');
const Hotelshelper = require('../helpers/hotels_helper');
const UserHelper = require('../helpers/user_helper');
const config = require('../../appsettings.js');
const RESTHelper = require('./rest_helper');
const HotelbudgetHelper = require('../helpers/hotelbudgets_helper');

const Payrollvsrevenuevsoccchartdata = require('../labor/models/payrollvsrevenuevsoccchartdata');
const Laborconfigdata = require('../labor/models/laborconfigdata');
const HoteldashboardcalculationsHelper = require('../helpers/hoteldashboardcalculations_helper');
const HotelrevenueHelper = require('../helpers/hotelrevenue_helper');
const OccupancyData = require('../labor/models/occupancydata');
const ActVsBudVsLsYrChartData = require('../labor/models/actvsbudvslsyrchartdata');
const UserHotelXrefHelper = require('../helpers/userhotelxref_helper');
const Payrolldepartmentwisechartdata = require('../labor/models/payrolldepartmentwisechartdata');
const HotelroomstatusesHelper = require('../helpers/hotelroomstatuses_helper');
const GetActualVsPayrollChartData = require('../labor/models/actualvspayrollchartdata');
const PayrollActualvsPlanTableList = require('../labor/models/payrollactualvsplantabledata');
const Hotelbudgetexpenseformdata = require('../labor/models/hotelbudgetexpenseformdata');
const HotelBudgetExpenseFormsHelper = require('../helpers/hotelbudgetexpenseforms_helper');
const DepartmentHelper = require('../helpers/department_helper');
const DashboardSettingsHelper = require('../helpers/dashboardsettings_helper');
const PayrollActualvsPlanModelData = require('../labor/models/payrollactualvsplanmodeldata');
const PayrollActualvsBudgetModelData = require('../labor/models/payrollactualvsbudgetmodeldata');
const Hoteleffectivenessusermodeldata = require('../labor/models/hoteleffectivenessusermodeldata');
const PayrollActualvsBudgetHoursModelData = require('../labor/models/payrollactualvsbudgethoursmodeldata');
const _ = require('lodash');

var log = require('log4js').getLogger("labor_helper");


let LaborSection1 = 'Daily';
let LaborSection2 = 'Weekly';
let chartTitle = "Hours";
class LaborHelper {

    constructor() { }
    static getLaborDataPayrollvsRevenuevsOcc_GraphQL(hotelId, period, currentDate, cd) {
        Hotelshelper.getHotelDataByCMPID(hotelId, (err, hoteldata) => {
            if (err) {
                cd(err, null);
            }
            if (!hoteldata) {
                cd(Constants.HotelNotFound, null);
            }
            else {
                LaborHelper.GetPayrollVsRevenueVsOcc([hoteldata][0].ID, period, currentDate, (err, result) => {
                    if (err) {
                        cd(err, null);
                    }
                    cd(null, result);
                })
            }
        })

    }
    static GetAvailableRoomsMinusOutOfOrder(hr, cd) {
        let AvailableRooms = 0;
        let daterv = [];
        let hotelId = [];
        let startDate = "";
        let endDate = "";
        let oor = 0;
        hr.forEach((element, index) => {
            if (index == 0)
                AvailableRooms = AvailableRooms + element.NumberofAvailableRooms;
        })

        if (AvailableRooms != 0) {
            //-----region Out of Rooms
            hr.forEach((element, index) => {
                if (index == 0)
                    daterv.push(element);

            })

            if (daterv.length != 0) {
                hr.forEach(element => {
                    hotelId.push(element.HotelID);

                })

                startDate = hr[0].Date;
                endDate = hr[hr.length - 1].Date;
                HotelroomstatusesHelper.GetOutOfOrderRooms(hotelId, startDate, endDate, (err, result) => {
                    oor = result;
                    AvailableRooms = AvailableRooms - oor;
                    cd(null, AvailableRooms);
                })

            }

        } else {
            cd(null, AvailableRooms);
        }

    }

    static GetHotelListByUserIdFromSession(hotelId, userID, cd) {
        let hotelIds = [];
        if (userID == null) cd(null, hotelIds);

        let RoleId = 2;
        if (RoleId == 1) {
            hotelIds.push(hotelId);
            cd(null, hotelIds)

        } else {
            UserHotelXrefHelper.getUserHotelList((err, result) => {

                let matches = [];

                result.forEach(element => {

                    if (matches.length == 0) {

                        if (element.HotelID == parseInt(hotelId, 10)) {
                            matches.push(element.HotelID)
                        }

                    }



                })


                if (matches.length == 0) {
                    hotelIds = [];
                }
                else {
                    hotelIds = [];
                    hotelIds.push(matches[0]);
                }

                cd(null, matches);
            })

        }


    }
    static getLaborData_GraphQL(hotelId, period, currentDate, cd) {
        Hotelshelper.getHotelDataByCMPID(hotelId, (err, hoteldata) => {
            if (err) {
                cd(err, null);
            }
            if (!hoteldata) {
                cd(Constants.HotelNotFound, null);
            }
            else {
                LaborHelper.GetPayrollDepartmentWiseData([hoteldata][0].ID, period, currentDate, (err, result) => {
                    if (err) {
                        cd(err, null);
                    }
                    cd(null, result);
                })
            }
        })

    }

    static GetPayrollDepartmentWiseData(hotelId, period, currentDate, cd) {
        //TODO
        /*let rbcmChart = new Payrolldepartmentwisechartdata();
        let hotelIdList = new Promise(function(resolve, reject) {
                LaborHelper.GetHotelListByUserIdFromSession(hotelId,UserID,(err,result)=>{
                if (err) {
                    reject(err);
                }
                resolve(result)
                });
    
        });
    
        hotelIdList.then(resp => {
            if(resp.length>0){
                  
                LaborHelper.GetPayrollDepartmentWiseDataCal(resp,period,currentDate,(err,result)=>{
                    cd(null,result)
                });
                         
            }else{
                cd(null,[rbcmChart])
            }
        })*/
        LaborHelper.GetPayrollDepartmentWiseDataCal(hotelId, period, currentDate, (err, result) => {
            let rbcmChart = [];

            if (result != null && result.length > 0) {
                _.filter(result, function (data) {
                    let payrolldepartmentwisechartdata = new Payrolldepartmentwisechartdata();
                    if (data.Department == "Hourly") {
                        data.Department = "FD Hourly";
                    }
                    payrolldepartmentwisechartdata.label = data.id;
                    payrolldepartmentwisechartdata.categoryvalue = data.Category;
                    payrolldepartmentwisechartdata.value = data.Wages;
                    rbcmChart.push(payrolldepartmentwisechartdata);
                })
            }


            cd(null, rbcmChart)
        });
    }
    static GetPayrollDepartmentWiseDataCal(hotelId, period, currentDate, cd) {
        let rev = new Hoteleffectivenesscalculationsdata();

        let yeasterday = new Date(currentDate);
        let lastYear = Utils.lastYearDate(yeasterday);
        let startdate = new Date(yeasterday);
        let enddate = new Date(yeasterday);
        let st = new Date();
        let et = new Date();
        let result_1 = [];
        let result_2 = [];
        let groupdataList = [];
        let hotelEffectivenessMappingModelList = new Hoteleffectivenesscalculationsdata();
        period = period.toLowerCase();
        if (period == "mtd") {
            startdate = Utils.startofMonth(yeasterday);
            enddate = Utils.endofDay(yeasterday);
            st = Utils.startofMonth(lastYear);
            et = Utils.endofDay(lastYear)
        }
        else if (period == "ytd") {
            startdate = Utils.startofYear(yeasterday);
            enddate = Utils.endofDay(yeasterday);
            st = Utils.startofYear(lastYear)
            et = Utils.endofDay(lastYear)
        }
        else if (period == "ttm") {
            startdate = Utils.firstDayOfMonth(yeasterday);
            startdate = Utils.lastYearDate(startdate);

            st = Utils.firstDayOfMonth(startdate);
            st = Utils.lastYearDate(st);

            enddate = Utils.firstDayOfMonth(yeasterday);
            enddate.setDate(startdate.getDate() - 1);

            st = Utils.lastYearDate(yeasterday);

        }
        else {
            st = lastYear;
            et = Utils.endofDay(lastYear);
        }
        startdate = new Date(Utils.getFormattedDate(startdate, "YYYY-MM-DD"));
        enddate = new Date(Utils.getFormattedDate(enddate, "YYYY-MM-DD"));

        LaborHelper.GetHotelEffectivenessCalculations(hotelId, startdate, enddate, (err, payrollvsdepartment) => {


            if (payrollvsdepartment != null && payrollvsdepartment.length > 0) {
                //_.orderBy(payrollvsdepartment, [function(data) { return data.Wages !=null && data.Wages >0; }, 'id'], ['asc']);
                payrollvsdepartment = _.filter(payrollvsdepartment, function (data) {
                    if (data.Wages != null && data.Wages > 0) {
                        return data;
                    }
                })

            }
            payrollvsdepartment = _.orderBy(payrollvsdepartment, ['id'], ['asc'])
            cd(null, payrollvsdepartment);

        });
    }
    static GetHotelEffectivenessCalculations(hotelId, startdate, enddate, cd) {
        let result_1 = [];
        let result_2 = [];
        let groupdataList = [];
        let hotelEffectivenessMappingModelList = new Hoteleffectivenesscalculationsdata();
        return Promise.all([
            new Promise((resolve, reject) => {
                // get hotels data
                HoteleffectivenesscalculationsSchema.find(
                    {
                        [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                        [HoteleffectivenesscalculationsSchemaFields.FromDate]: { $lte: enddate },
                        [HoteleffectivenesscalculationsSchemaFields.ToDate]: { $gte: enddate },
                        [HoteleffectivenesscalculationsSchemaFields.Category]: { $in: ["Weekly", "Bi-Weekly", "Monthly"] }
                    }
                ).exec((err, result) => {
                    if (err) {
                        reject(err);
                    }

                    result_1 = result;
                    resolve()
                })

            }),
            new Promise((resolve, reject) => {
                // get hotels data
                HoteleffectivenesscalculationsSchema.find(
                    {
                        [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                        [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: startdate, $lte: enddate }
                    }


                ).exec((err, result) => {

                    if (err) {
                        reject(err);
                    }

                    result_2 = result;
                    resolve()
                })


            })
        ]).then(resp => {

            if (result_1.length == 0) {
                result_1 = result_2;
            }

            if (result_1.length == 0 && result_1 == null) {
                cd(null, hotelEffectivenessMappingModelList);
            }
            else {
                cd(null, _.map(_.groupBy(result_1, 'Department'), (o, idx) => { return { id: idx, Wages: _.sumBy(o, 'Wages'), Hours: _.sumBy(o, 'Hours'), Category: o[0].Category } }))

            }
        })

    }

    static GetPayrollVsRevenueVsOcc(hotelId, period, currentDate, cd) {
        //TO DO
        /*let rrccList = new Payrollvsrevenuevsoccchartdata();

        let hotelIdList = new Promise(function(resolve, reject) {
            LaborHelper.GetHotelListByUserIdFromSession(hotelId,UserID,(err,result)=>{

            if (err) {
                reject(err);
            }
            resolve(result)
            });

        });

        hotelIdList.then(resp => {

        
            if(resp.length>0){
                
                LaborHelper.GetPayrollVsRevenueVsOccCal(period,resp,currentDate,(err,result)=>{
                    cd(null,result)
                });
                        
            }else{
                cd(null,[rrccList])
            }
        })*/
        LaborHelper.GetPayrollVsRevenueVsOccCal(period, hotelId, currentDate, (err, result) => {
            cd(null, result)
        });
    }

    static GetPayrollVsRevenueVsOccCal(days, hotelId, currentDate, cd) {

        let daysMinus = (-1) * days + 1;

        let yeasterday = new Date(currentDate);


        let previousday = new Date(Utils.addDate(yeasterday, daysMinus));

        /*let startdate = Utils.startofDay(previousday)
        let enddate = Utils.endofDay(yeasterday);*/
        let startdate = new Date(previousday.getFullYear(), previousday.getMonth(), previousday.getDate(), 0, 0, 0);
        let enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);

        startdate = new Date(Utils.getFormattedDate(startdate, "YYYY-MM-DD"));

        enddate = new Date(Utils.getFormattedDate(enddate, "YYYY-MM-DD"));


        let hid = hotelId[0];

        let hotel = [];

        let daysIncrement = 1;

        let HotelEffectivenesWithcat = [];

        let HotelEffectivenes = [];

        let HotelDashboardCalcul = [];

        let roomRevenueList = [];

        let groupdataList = [];

        let hr = [];

        let adrREVList = [];

        let availableRoomsthisYear = 0;

        let period = "Current";

        return Promise.all([
            new Promise(function (resolve, reject) {
                hotel = [];
                Hotelshelper.GetHotelRevenueData(hid, (err, result) => {
                    if (err) {
                        reject(err);
                    }
                    hotel = result;
                    resolve()
                })
            }),
            new Promise(function (resolve, reject) {
                HotelEffectivenesWithcat = [];
                HoteleffectivenesscalculationsSchema.find(
                    {
                        [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                        [HoteleffectivenesscalculationsSchemaFields.FromDate]: { $gte: startdate },
                        [HoteleffectivenesscalculationsSchemaFields.ToDate]: { $lte: enddate },
                        [HoteleffectivenesscalculationsSchemaFields.Category]: { $in: ["Weekly", "Bi-Weekly", "Monthly"] }
                    }
                ).exec((err, result) => {
                    if (err) {
                        reject(err);
                    }

                    HotelEffectivenesWithcat = result;
                    resolve()
                })
            }),
            new Promise(function (resolve, reject) {
                HotelEffectivenes = [];
                HoteleffectivenesscalculationsSchema.find(
                    {
                        [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                        [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: startdate, $lte: enddate }
                    }
                ).exec(function (err, result) {
                    if (err) {
                        reject(err);
                    }

                    HotelEffectivenes = result;
                    resolve()
                })
            }),
            new Promise(function (resolve, reject) {
                HotelDashboardCalcul = [];
                HoteldashboardcalculationsHelper.GetPayrollData(hotelId, startdate, enddate, (err, result) => {
                    if (err) {
                        reject(err);
                    }

                    HotelDashboardCalcul = result;
                    resolve()
                })

            }),
            new Promise(function (resolve, reject) {
                roomRevenueList = [];
                HotelrevenueHelper.GetPayRollData(hotelId, startdate, enddate, (err, result) => {
                    if (err) {
                        reject(err);
                    }

                    roomRevenueList = result;
                    resolve()
                })

            })

        ]).then(resp => {
            for (let dt = startdate; dt <= enddate; dt = new Date(startdate.setDate(startdate.getDate() + daysIncrement))) {

                //dt = new Date(dt);
                let revenue = "0";
                let payroll = 0;
                //let Occupancydata = new OccupancyData();

                let rev = [];

                let result = [];


                /*HotelEffectivenesWithcat.forEach(element=>{
                    if(element.FromDate<=dt && element.ToDate >= dt ){
                    result.push(element);
                    
                    }
                })*/

                _.filter(HotelEffectivenesWithcat, function (data) {
                    if (data.FromDate <= dt && data.ToDate >= dt) {
                        result.push(data);
                    }
                })

                if (result == null || result.length == 0) {
                    _.filter(HotelEffectivenes, function (data) {
                        if (data.Date >= dt && data.Date <= dt) {
                            result.push(data);
                        }
                    })
                }

                log.debug('Group data:' + result);

                if (result != null) {
                    let x = _.chain(result).groupBy("Department").map((value, key) => ({ _id: key, data: value })).value();
                    let Wages = [];
                    let Hours = [];
                    x.forEach(key => {
                        Wages.push(_.sumBy(key.data, 'Wages'));
                        Hours.push(_.sumBy(key.data, 'Hours'));
                    })

                    let temp = [];
                    x.forEach(key => {
                        _.filter(key.data, function (Catdata) {
                            temp.push(Catdata.Category)
                        })
                    })

                    x.forEach((key, index) => {
                        rev.push({ "Department": key._id, "Category": temp[index], "Wages": Wages[index], "Hours": Hours[index] })
                    })

                }

                if (rev.length > 0) {

                    payroll = _.sumBy(rev, "Wages")

                    let revCategory = rev[0];

                    if (revCategory.Category == "Weekly") {
                        payroll = payroll / 7;
                    }
                    else if (revCategory.Category == "Bi-Weekly") {
                        payroll = payroll / (7 * 2);
                    }
                    else if (revCategory.Category == "Monthly") {
                        let totaldays = Utils.getDaysinMonth(dt.getFullYear(), dt.getMonth());
                        payroll = payroll / totaldays;
                    }
                }
                //----------------- ActVsBudVsLsYrChartmodel ------------------           

                let abl = new ActVsBudVsLsYrChartData();
                let hdcCurrent = [];
                _.filter(HotelDashboardCalcul, function (data) {
                    if (new Date(data.Date).getTime() == dt.getTime()) {
                        hdcCurrent.push(data);
                    }
                })
                abl.RRActual = 0;
                abl.FBActual = 0;
                abl.OIActual = 0;
                abl.TOActual = 0;

                if (hdcCurrent != null && hdcCurrent.length > 0) {
                    abl.RRActual = _.sumBy(hdcCurrent, "TotalRevenue");
                    abl.FBActual = _.sumBy(hdcCurrent, "FANDBRevenue");
                    abl.OIActual = _.sumBy(hdcCurrent, "OtherRevenue");
                    abl.TOActual = abl.RRActual + abl.FBActual + abl.OIActual;
                }

                if (abl != null) {
                    revenue = abl.TOActual.toString();
                }

                //------------------------------- OccupancyModel -------------------------------------------------
                let occupancy = new OccupancyData();
                // For Current Year
                let avgActual = 0;
                let hdList = [];
                HotelDashboardCalcul.forEach(element => {
                    if (new Date(element.Date) >= dt && new Date(element.Date) <= dt) {
                        hdList.push(element);
                    }
                })

                if (hdList.length == 0) {
                    let lstRoomRevenue = [];

                    _.filter(roomRevenueList, function (data) {
                        if (element.Date >= dt && element.Date <= dt) {
                            lstRoomRevenue.push(element);
                        }
                    })

                    let totalRoomsthisYear = _.sumBy(lstRoomRevenue, "NoOfReference");

                    if (hid == hotelId) {
                        let hr = [];
                        hr.push(_.find(lstRoomRevenue, { 'HotelID': hid }))

                    }

                    return new Promise(function (resolve, reject) {
                        availableRoomsthisYear = 0;
                        return LaborHelper.GetAvailableRoomsMinusOutOfOrder(hr, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            availableRoomsthisYear = availableRoomsthisYear + result;

                            resolve();
                        })
                    }).then(resp => {
                        if (availableRoomsthisYear == 0) {
                            avgActual = 0;
                        } else {
                            avgActual = totalRoomsthisYear * 100 / availableRoomsthisYear;
                        }

                        if (avgActual == 0) {
                            occupancy.Actual = "0";
                        } else {
                            occupancy.Actual = avgActual.toString();
                        }

                        let adrrev = new Payrollvsrevenuevsoccchartdata();
                        adrrev.Date = Utils.getFormattedDate(dt, "YYYY-MM-DD");
                        adrrev.Occ = Math.round(occupancy.Actual).toString();
                        adrrev.Revenue = (Math.round(revenue * 100) / 100).toString();
                        adrrev.Payroll = (Math.round(payroll * 100) / 100).toString();
                        adrrev.PayrollPercentage = "0";
                        if (revenue != "0") {
                            let per = (payroll * 100) / revenue;
                            adrrev.PayrollPercentage = per.toString();
                        }


                        return new Promise(function (resolve, reject) {
                            adrREVList.push(adrrev);
                            resolve();

                        }).then(function (values) {
                            cd(null, adrREVList)
                        });

                    })

                } else {

                    occupancy.Actual = _.meanBy(hdList, 'Occupancy').toString();
                }
                let adrrev = new Payrollvsrevenuevsoccchartdata();
                adrrev.Date = Utils.getFormattedDate(dt, "YYYY-MM-DD");
                adrrev.Occ = Math.round(occupancy.Actual);
                adrrev.Revenue = (Math.round(revenue * 100) / 100).toString();
                adrrev.Payroll = (Math.round(payroll * 100) / 100).toString();
                adrrev.PayrollPercentage = "0";
                if (revenue != "0") {
                    let per = (payroll * 100) / revenue;
                    adrrev.PayrollPercentage = per.toString();
                }
                adrREVList.push(adrrev);
            }

            cd(null, adrREVList)
        })

    }

    static GetActualVsPayrollCal(hotelId, period, currentDate, cd) {
        let finalretList = [];
        let startdate = new Date();
        let enddate = new Date();
        let startDateLastYear = new Date();
        let endDateLastYear = new Date();
        let ttmdata = "";

        if (period.toLowerCase() == "current") {
            let yeasterday = new Date(currentDate);
            //startdate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 0, 0, 0);
            //startdate = Utils.startofDay(yeasterday);
            startdate = yeasterday.toISOString();
            /*enddate = new Date(yeasterday.setHours(yeasterday.getHours()+23));
            enddate = new Date(enddate.setMinutes(yeasterday.getMinutes()+59));
            enddate = new Date(enddate.setSeconds(yeasterday.getSeconds()+59));*/
            enddate = Utils.endofDay(yeasterday);

            //enddate = new Date(yeasterday.getFullYear(), yeasterday.getMonth(), yeasterday.getDate(), 23, 59, 59);
            startDateLastYear = Utils.sameDayLastYear(startdate);
            endDateLastYear = Utils.sameDayLastYear(enddate);
        }
        else if (period.toLowerCase() == "mtd") {
            let yeasterday = new Date(currentDate);
            //startdate = Utils.firstDayOfMonth(yeasterday);
            startdate = Utils.firstDayOfMonth(yeasterday);
            enddate = Utils.lastDayOfMonth(yeasterday);
            startDateLastYear = Utils.sameDayLastYear(startdate);
            endDateLastYear = Utils.sameDayLastYear(enddate);
        }
        else if (period.toLowerCase() == "ytd") {
            let yeasterday = new Date(currentDate);
            startdate = Utils.firstDayOfYear(yeasterday);
            enddate = Utilis.lastDayOfYear(yeasterday);
            startDateLastYear = Utils.sameDayLastYear(startdate);
            endDateLastYear = Utils.sameDayLastYear(enddate);
        }
        else if (period.toLowerCase() == "ttm") {
            let yeasterday = DateTime.Parse(currentDate);
            let ttmdata = Utils.GetTTMDates(yeasterday);
            startdate = ttmdata[0];
            enddate = ttmdata[1];
            startDateLastYear = Utils.sameDayLastYear(startdate);
            endDateLastYear = Utils.sameDayLastYear(enddate);
        }


        let hotelbudgetlist = [];

        let newhotelbudgetlist = [];

        let hpList = [];
        let hotel = [];

        let retList = [];
        return Promise.all([
            new Promise(function (resolve, reject) {
                Hotelshelper.GetHotelRevenueData(hotelId, (err, result) => {
                    if (err) {
                        reject(err);
                    }

                    hotel = result;
                    resolve()
                })
            }),
        ]).then(resp => {

            //dt.setDate(dt.getDate() + 1)
            let hpListArray = [];
            let hpListArray1 = [];
            let hpListArray2;
            hpList = [];
            //for (let dt = new Date(startdate); dt <=new Date(enddate);dt =new Date(Utils.addDate(dt,1))){
            for (let dt = startdate; dt <= enddate; dt = new Date(Utils.addDate(dt, 1))) {

                hpListArray.push(new Promise(function (resolve, reject) {
                    HotelBudgetExpenseFormsHelper.GetHotelBudgetExpenseFormsDataCal0(hotelId, dt, (err, result) => {
                        if (err) {
                            reject(err);
                        }

                        if (result.length != 0) {
                            hpList.push(result);
                        }

                        resolve()
                    })

                }))

            }

            Promise.all(hpListArray).then(resp => {
                hotelbudgetlist = hpList;
                let FinalResult1;
                let FinalResult2;
                let newhotelbudgetlist = [];
                let depListArray;
                if (hpList.length == 0) {
                    hpList = [];
                    for (let dt = startdate; dt <= enddate; dt = new Date(Utils.addDate(dt, 1))) {
                        //dt = new Date(dt);


                        //hpListArray1 =  
                        hpListArray1.push(new Promise(function (resolve, reject) {
                            HotelbudgetexpenseformSchema.find({
                                $and: [
                                    { [HotelbudgetexpenseformSchemaFields.HotelID]: hotelId },
                                    { [HotelbudgetexpenseformSchemaFields.IsDelete]: false },
                                    { [HotelbudgetexpenseformSchemaFields.DepartmentID]: { $gt: 0 } },
                                    { [HotelbudgetexpenseformSchemaFields.DateFrom]: { $lte: dt } },
                                    { [HotelbudgetexpenseformSchemaFields.ToDate]: { $gte: dt } }
                                ]
                            }).exec((err, result) => {

                                if (err) {
                                    reject(err);
                                }
                                if (result.length > 0)
                                    hpList.push(result);
                                resolve();
                            })

                        }));
                    }
                    Promise.all(hpListArray1).then(resp => {
                        hotelbudgetlist = hpList;

                        //-----#region average budget dep wise
                        let avghotelbudgetlist = new Hotelbudgetexpenseformdata();
                        let groupdataList = [];

                        //hpListArray2 =  
                        //return new Promise(function(resolve, reject) {

                        if (hotelbudgetlist.length > 0) {
                            groupdataList.push(_.map(_.groupBy(hotelbudgetlist, 'DepartmentID'), (o, idx) => { return { id: idx, HotelID: o[0].HotelID, GLCode: o[0].GLCode, TotalHotelBudget: _.sumBy(o, 'TotalHotelBudget') } }));

                        }

                        groupdataList.forEach(key => {
                            let avgbudget = 0;
                            let avgbudgethours = 0;
                            for (let dt = startdate; dt <= enddate; dt = new Date(Utils.addDate(dt, 1))) {

                                let hpList;
                                hotelbudgetlist.forEach(element => {
                                    if (element.HotelID == hotelId &&
                                        element.DepartmentID == key.id &&
                                        element.DateFrom <= dt && element.DateTo >= dt) {
                                        hpList = element;

                                    }
                                })



                                if (hpList == undefined || hpList == null || [hpList].length == 0) {
                                    avgbudget = avgbudget + 0;
                                    avgbudgethours = avgbudgethours + 0;
                                } else {
                                    [hpList].forEach(element => {
                                        let todate = element.DateTo.toString();
                                        let fromdate = element.DateFrom.toString();
                                        let TDays = Math.floor(todate - fromdate) + 1;
                                        avgbudget = avgbudget + (element.TotalHotelBudget / TDays);
                                        let hotelBudgetHours = element.HotelBudgetHours == null ? 0 : element.HotelBudgetHours;
                                        if (hotelBudgetHours != 0)
                                            avgbudgethours = avgbudgethours + parseFloat(element.HotelBudgetHours / TDays);
                                    })
                                }

                            }


                            let data = new Hotelbudgetexpenseformdata();
                            data.GLCode = key.GLCode;
                            data.HotelID = key.HotelID;
                            data.DepartmentID = key.DepartmentID;
                            data.TotalHotelBudget = avgbudget;
                            data.HotelBudgetHours = avgbudgethours;
                            newhotelbudgetlist.push(data);



                        })

                        //})                     

                    })
                    //}

                } else {

                    let avghotelbudgetlist = new Hotelbudgetexpenseformdata();
                    let groupCodes = [];
                    groupCodes.push(_.map(_.groupBy(hotelbudgetlist[0], 'GLCode'), (o, idx) => { return { id: idx, HotelID: o[0].HotelID, DepartmentID: o[0].DepartmentID, TotalHotelBudget: _.sumBy(o, 'TotalHotelBudget') } }));


                    let avgbudget = 0;

                    let hpList = [];

                    if (groupCodes != null) {

                        groupCodes[0].forEach(key => {
                            for (let dt = startdate; dt <= enddate; dt = new Date(Utils.addDate(dt, 1))) {
                                hotelbudgetlist[0].forEach(element => {
                                    if (element.HotelID == hotelId && element.GLCode == key.id && element.DateFrom <= dt && element.DateTo >= dt) {
                                        hpList.push(element)
                                    }
                                })


                                hpList.forEach(element => {
                                    if (!(element)) {
                                        avgbudget = avgbudget + 0;
                                        avgbudgethours = avgbudgethours + 0;
                                    } else {
                                        let todate = element.DateTo;
                                        let fromdate = element.DateFrom;
                                        let TDays = Utils.dateDiffInDays(fromdate, todate);
                                        avgbudget = avgbudget + parseFloat(element.TotalHotelBudget / TDays);

                                    }

                                })
                            }


                            let data = new Hotelbudgetexpenseformdata();
                            data.GLCode = key.id;
                            data.HotelID = key.HotelID;
                            data.DepartmentID = key.DepartmentID;
                            data.TotalHotelBudget = avgbudget;
                            newhotelbudgetlist.push(data);

                        })


                        //#endregion

                    }

                }

                hotelbudgetlist.push(_.map(_.groupBy(newhotelbudgetlist, 'DepartmentID'), (o, idx) => { return { id: idx, HotelID: o[0].HotelID, TotalHotelBudget: _.sumBy(o, 'TotalHotelBudget') } }));

                let depList = [];
                return new Promise(function (resolve, reject) {
                    DepartmentHelper.GetSelectedOrganizationData(hotel.OrganizationID, (err, result) => {
                        if (err) {
                            reject(err);
                        }

                        depList.push(result);
                        resolve()
                    })
                }).then(resp => {

                    depList.forEach(key => {
                        let chartitem = new GetActualVsPayrollChartData();

                        chartitem.Type = key.Name;

                        let budget = 0;

                        let depbudget = [];
                        if (hotelbudgetlist.length > 0) {
                            hotelbudgetlist.forEach(element => {
                                if (element.DepartmentID == key.Id) {
                                    depbudget.push(element)
                                }
                            })
                        }

                        if (depbudget.length > 0) {
                            depbudget.forEach(element => {
                                budget = element.TotalHotelBudget;
                            })

                        }

                        chartitem.PayrollBudget = Math.round(budget);
                        retList.push(chartitem);
                    })

                    let hotelIds = [];
                    hotelIds.push(hotel.ID);
                    let rev = [];
                    return new Promise(function (resolve, reject) {
                        LaborHelper.PayrollVsDepartmentData(hotelIds, period, currentDate, (err, result) => {
                            if (err) {
                                reject(err);
                            }

                            rev.push(result);
                            resolve()

                        })
                    }).then(resp => {
                        if (retList != null && retList.length > 0) {

                            retList.forEach(element => {

                                if (rev != null && rev.length > 0) {

                                    let matches = [];
                                    rev[0].forEach(item => {
                                        if (item.id == element.Type) {
                                            matches.push(item);
                                        }

                                    })



                                    if (matches != null) {
                                        let payroll = 0;
                                        matches.forEach(x => {

                                            if (x.Wages == null) {
                                                payroll = 0;
                                            } else {
                                                payroll = x.Wages;
                                            }
                                            element.PayrollActual = parseFloat(payroll).toFixed(2);
                                            element.Category = x.Category;
                                        })


                                    }
                                }
                                if (element.PayrollActual > 0 || element.PayrollBudget > 0) {
                                    finalretList.push(element);
                                }
                            })
                        }

                        if (finalretList == null) {
                            cd(null, finalretList.push({ "Type": "", "Category": "", "PayrollActual": 0.00, "PayrollBudget": 0.00 }));
                        } else {
                            cd(null, finalretList)
                        }



                    })



                })



            })



        })
    }

    static PayrollVsDepartmentData(hotelId, period, currentDate, cd) {

        let rev = new Hoteleffectivenesscalculationsdata();
        let startdate = new Date();
        let enddate = new Date();
        let st = new Date();
        let et = new Date();
        let yeasterday = new Date(currentDate);
        let lastYear = Utils.lastYearDate(yeasterday);

        let result_1 = [];
        let result_2 = [];
        let groupdataList = [];

        if (period.toLowerCase() == "current") {
            startdate = Utils.startofDay(yeasterday);
            enddate = Utils.endofDay(yeasterday);
            st = Utils.startofDay(lastYear);
            et = Utils.endofDay(lastYear);

        }
        else if (period.toLowerCase() == "mtd") {
            startdate = Utils.firstDayOfMonth(yeasterday);
            enddate = Utils.endofDay(yeasterday);
            st = Utils.firstDayOfMonth(lastYear);
            et = Utils.endofDay(lastYear);
        }
        else if (period.toLowerCase() == "ytd") {

            startdate = Utils.firstDayOfYear(yeasterday);
            enddate = Utils.endofDay(yeasterday);
            st = Utils.firstDayOfYear(lastYear);
            et = Utils.endofDay(lastYear);
        }
        else if (period.toLowerCase() == "ttm") {
            var result = Utils.GetTTMDates(yeasterday);

            startdate = result[0];
            enddate = result[1];
            st = Utils.addYears(startdate, -1);
            et = Utils.addYears(enddate, -1);
        }

        let hotelEffectivenessMappingModelList = new Hoteleffectivenesscalculationsdata();
        let calculationsdata;
        return new Promise(function (resolve, reject) {
            LaborHelper.GetHotelEffectivenessCalculations(hotelId[0], startdate, enddate, (err, result) => {
                if (err) {
                    reject(err);
                }

                calculationsdata = result;
                resolve()
            })
        }).then(resp => {
            calculationsdata.forEach(element => {
                if (element.Wages != null && element.Wages.length > 0) {
                    _.orderBy(payrollvsdepartment, ['Department'], ['asc'])
                }
            })
            cd(null, calculationsdata);
        })
    }

    static getActualvsPayroll_GraphQL(hotelId, period, currentDate, cd) {
        Hotelshelper.getHotelDataByCMPID(hotelId, (err, hoteldata) => {
            if (err) {
                cd(err, null);
            }
            if (!hoteldata) {
                cd(Constants.HotelNotFound, null);
            }
            else {
                LaborHelper.GetActualVsPayrollCal([hoteldata][0].ID, period, currentDate, (err, result) => {
                    if (err) {
                        cd(err, null)
                    }

                    if (result == false) {

                        cd(null, [{ "Type": "", "Category": "", "PayrollActual": 0.00, "PayrollBudget": 0.00 }]);
                    } else {
                        cd(null, result)
                    }


                });
            }
        })

    }
    static GetActualVsPayroll(hotelId, period, currentDate, cd) {
        //TO DO
        /*let rbcmChart = new GetActualVsPayrollChartData();
    
        let hotelIdList = new Promise(function(resolve, reject) {
            LaborHelper.GetHotelListByUserIdFromSession(hotelId,UserID,(err,result)=>{
            if (err) {
                reject(err);
            }
            resolve(result)
            });
        });
    
        hotelIdList.then(resp => {
            if(resp.length>0){
                LaborHelper.GetActualVsPayrollCal(resp,period,currentDate,(err,result)=>{
                    cd(null,result)
                });
            }else{
                cd(null,[rbcmChart])
            }
        })*/
        LaborHelper.GetActualVsPayrollCal(hotelId, period, currentDate, (err, result) => {
            cd(null, result)
        });
    }
    static getHouseKeepingPerRoom_GraphQL(userid, hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, cd) {
        Hotelshelper.getHotelDataByCMPID(hotelId, (err, hoteldata) => {
            if (err) {
                cd(err, null);
            }
            if (!hoteldata) {
                cd(Constants.HotelNotFound, null);
            }
            else {
                let hoteldataList = [];
                let y = new Promise((resolve,reject)=>{
                    HotelsSchema.find({[HotelsSchemaFields.ID]:[hoteldata][0].ID}).exec((res,hoteldata)=>{
                        resolve(hoteldata)
    
                    })
                })
                y.then(hoteldata=>{
                    let orgid;
                   _.filter(hoteldata,(key)=>{orgid=key.OrganizationID})

                    LaborHelper.GetHouseKeepingPerRoom(orgid,userid, hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, (err, result) => {
                        if (err) {
                            cd(err, null)
                        }
                        cd(null, result)
                    })
                })

            }
        })
    }
    static GetHouseKeepingPerRoomCal(userid, hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, cd) {
        let newModel = new PayrollActualvsPlanTableList();
        let yeasterday = new Date(currentDate);
        newModel.CurrentDate = yeasterday;
        return new Promise(function (resolve, reject) {
            DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                if (err) {
                    cd(err, null);
                }
                newModel.WeekStartDate = result;
                resolve();
            })
        }).then(resp => {
            let sdate = Utils.firstDayOfMonth(yeasterday);
            let LaborSection1 = laborsection1;
            let LaborSection2 = laborsection2;
            let GetWeekDayresult;
                if (LaborSection1==null && LaborSection2==null) {
                    newModel.CurrentDate = yeasterday;
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.WeekStartDate = result;
                            resolve();
                        });
                    })

                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Daily") {
                    newModel.CurrentDate = yeasterday;
                    newModel.WeekStartDate = yeasterday;
                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Weekly") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })

                    newModel.WeekStartDate = newModel.CurrentDate;
                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Monthly") {
                    newModel.CurrentDate = sdate;
                    newModel.WeekStartDate = sdate;
                }
                if (LaborSection1 == "Quarter" && LaborSection2 == "Quarter") {
                    newModel.CurrentDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);

                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Weekly") {
                    newModel.CurrentDate = yeasterday;
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.WeekStartDate = result;
                            resolve();
                        });
                    })

                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Monthly") {
                    newModel.CurrentDate = yeasterday;
                    newModel.WeekStartDate = sdate;
                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Quarter") {
                    newModel.CurrentDate = yeasterday;
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Daily") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })

                    newModel.WeekStartDate = yeasterday;

                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Monthly") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })

                    newModel.WeekStartDate = sdate;
                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Quarter") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }

                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })

                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);

                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Daily") {
                    newModel.CurrentDate = sdate;
                    newModel.WeekStartDate = yeasterday;
                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Weekly") {
                    newModel.CurrentDate = sdate;
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.WeekStartDate = result;
                            resolve();
                        });
                    })

                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Quarter") {
                    newModel.CurrentDate = sdate;
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                }

                if (!GetWeekDayresult) {
                    let hotel = [];
                    let users = [];
                    return Promise.all([
                        new Promise((resolve, reject) => {
                            LaborHelper.GetPayrollHouseKeepingData(hotelId, yeasterday, period, (err, result) => {
                                if (err) {
                                    reject(err);
                                }
                                newModel.PayrollActualvsPlanTableList = result;
                                resolve();
                            });
                        })
                    ]).then(resp => {


                        let totalhousekeeping = 0
                        _.filter(newModel.PayrollActualvsPlanTableList, function (data) {
                            if (data.Department = "Total")
                                totalhousekeeping = _.sumBy([data], 'ActualPORHours')
                        })

                        if (newModel.PayrollActualvsPlanTableList.length > 0) {
                            newModel.PayrollActualvsPlanTableList[0].ActualPORHours = totalhousekeeping * 60;
                        }

                        cd(null, newModel)
                    })
                } else if (typeof GetWeekDayresult.then == "function") {

                    let hotel = [];
                    let users = [];
                    return Promise.all([
                        new Promise((resolve, reject) => {
                            LaborHelper.GetPayrollHouseKeepingData(hotelId, yeasterday, period, (err, result) => {
                                if (err) {
                                    reject(err);
                                }

                                newModel.PayrollActualvsPlanTableList = result;
                                resolve();
                            });
                        })
                    ]).then(resp => {

                        let totalhousekeeping = 0
                        _.filter(newModel.PayrollActualvsPlanTableList, function (data) {
                            if (data.Department = "Total")
                                totalhousekeeping = _.sumBy([data], 'ActualPORHours')
                        })

                        if (newModel.PayrollActualvsPlanTableList.length > 0) {
                            newModel.PayrollActualvsPlanTableList[0].ActualPORHours = totalhousekeeping * 60;
                        }
                        cd(null, newModel)
                    })
                }

        })

    }
    static GetActiveOrganisationList(cd) {
        let userModels = [];
        let organisationCredentials = null;
        OrganisationcredentialsSchema.find({}).exec((err, result) => {
            organisationCredentials = result;
            if (organisationCredentials == null) cd(null, userModels);
            let user = [];
            return new Promise((resolve, reject) => {
                organisationCredentials.forEach(element => {
                    UserSchema.findOne({ [UserSchemaFields.ID]: element.OrganizationID }).exec((err, result) => {
                        if (err) {
                            reject(err)
                        }
                        user.push(result);
                        resolve(user);
                    })
                })
            }).then(user => {

                organisationCredentials.forEach(element => {
                    let model = new Hoteleffectivenessusermodeldata();
                    model.IsActive = !element.IsDelete;
                    model.OranizationId = element.OrganisationID;
                    model.UserName = element.Username;
                    model.ID = element.ID;
                    if (user != null) {
                        model.OranizationName = user.CompanyName;
                    }
                    userModels.push(model);
                })
                if (userModels != null && userModels.length > 0) {
                    userModels = _.orderBy(userModels, ['OranizationId'], ['asc']);
                }
                cd(null, userModels);
            })


        })
    }
    static GetPayrollHouseKeepingData(hotelId, date, period, cd) {
        let PayrollActualvsPlanModelList = [];
        let startdate = new Date();
        let enddate = new Date();
        let st = new Date();
        let et = new Date();
        let yeasterday = date;
        let lastYear = Utils.addYears(yeasterday, -1);
        period = period.toLowerCase();

        if (period == "mtd") {
            startdate = Utils.startofMonth(date);
            enddate = Utils.endofDay(date);
            st = Utils.startofMonth(lastYear);
            et = Utils.endofDay(lastYear);
        }
        else if (period == "ytd") {
            startdate = Utils.startofYear(date);
            enddate = Utils.endofDay(date);
            st = Utils.startofYear(lastYear);
            et = Utils.endofDay(lastYear);
        }
        else if(period == "current" || period==null){
            startdate = new Date(yeasterday);
            enddate = Utils.endofDay(yeasterday);
            st = new Date(lastYear);
            et = Utils.endofDay(lastYear);
        }
        enddate = new Date(Utils.getFormattedDate(enddate, 'YYYY-MM-DD'));

        let hotel = [];
        let roomRevenueList1 = new Hoteleffectivenesscalculationsdata();
        let roomRevenueList2 = new Hoteleffectivenesscalculationsdata();
        let roomRevenueList = [];
        return Promise.all([
            new Promise((resolve, reject) => {
                Hotelshelper.GetHotelRevenueData(hotelId, (err, result) => {
                    if (err) {
                        reject(err);
                    }

                    hotel = result;
                    resolve();
                })
            }),
            new Promise((resolve, reject) => {
                HoteleffectivenesscalculationsSchema.find(
                    {
                        [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                        [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: startdate, $lte: enddate },
                        [HoteleffectivenesscalculationsSchemaFields.Department]: { $in: ["Housekeeping", "Bi-Weekly", "Monthly", "Room Attendant", "Laundry", "Public Spaces"] }

                    }).exec((err, result) => {
                        if (err) {
                            reject(err);
                        }

                        roomRevenueList1 = result;

                        resolve();
                    })
            }),
            new Promise((resolve, reject) => {
                HoteleffectivenesscalculationsSchema.find(
                    {
                        [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                        [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: startdate,$lte: enddate },
                        [HoteleffectivenesscalculationsSchemaFields.Department]: "Housekeeping"
                    }
                ).exec((err, result) => {
                    if (err) {
                        reject(err);
                    }

                    roomRevenueList2 = result;
                    resolve();
                })
            }),
        ]).then(resp => {

            let OrganizationID = '';
            if (hotel != null && hotel.length > 0) {
                [hotel].forEach(element => {
                    OrganizationID = element.OrganizationID;
                })
            }

            if (OrganizationID == 2436) {
                roomRevenueList = roomRevenueList1;
            } else {
                roomRevenueList = _.filter(roomRevenueList2, function (data) {
                    return data.Department == "Housekeeping";
                })
            }

            let days = Utils.getDaysinMonth(date.getFullYear(), date.getMonth());

            let hotelofroom;
            let hotelofroom1 = 0;
            let hotelofroom2 = 0;
            let hotelofroom3 = 0;
            return new Promise((resolve, reject) => {
                if (roomRevenueList != null && roomRevenueList.length > 0) {
                    _.filter(roomRevenueList, function (element) {
                        HoteldashboardcalculationsHelper.GetPayrollHouseKeepingData(hotelId, element.Date, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            hotelofroom = result;
                            resolve();
                        })

                    })
                } else {
                    hotelofroom;
                    resolve();
                }

            }).then(resp => {
                if (roomRevenueList != null && roomRevenueList.length > 0) {
                    _.filter(roomRevenueList, function (element) {
                        let payrollActualvsPlanModel = new PayrollActualvsPlanModelData();
                        payrollActualvsPlanModel.PlanHours = element.PlanHours == null ? 0 : element.PlanHours;
                        payrollActualvsPlanModel.ActualHours = element.Hours == null ? 0 : element.Hours;
                        payrollActualvsPlanModel.ActualPORHours = (element.Hours == null || hotelofroom == 0) ? 0 : element.Hours / hotelofroom;
                        payrollActualvsPlanModel.Department = element.Department;
                        payrollActualvsPlanModel.Date = element.Date;
                        payrollActualvsPlanModel.HotelID = element.HotelID;
                        payrollActualvsPlanModel.organizationCode = OrganizationID;
                        PayrollActualvsPlanModelList.push(payrollActualvsPlanModel);
                    })
                }


                let periodYtd = null;
                let periodMtd = null;
                let periodCurrent = null;

                if (period != "mtd" && period != "ytd") {

                    periodCurrent= new Promise((resolve, reject) => {
                        HoteldashboardcalculationsHelper.GetHotelofRoom1(hotelId, enddate, (err, result) => {
    
                            if (result != null && result.length > 0) {
                                _.filter(result, function (data) {
                                    hotelofroom1 = data.NoOfRoomSold
                                })
                            } else {
                                hotelofroom1 = 0;
                            }
    
    
                            resolve();
                        })
                    })
                }

                if (period == "mtd") {
                    periodMtd = new Promise((resolve, reject) => {
                        HoteldashboardcalculationsHelper.NoOfRoomSoldMTD(hotelId, enddate, (err, result) => {
    
                            if (result != null && result.length > 0) {
                                _.filter(result, function (data) {
                                    hotelofroom2 = data.NoOfRoomSoldMTD
                                })
                            } else {
                                hotelofroom2 = 0;
                            }
                            resolve();
                        })
                    })
                }

                if (period == "ytd") {
                    periodYtd = new Promise((resolve, reject) => {
                        HoteldashboardcalculationsHelper.NoOfRoomSoldYTD(hotelId, enddate, (err, result) => {
    
                            if (result != null && result.length > 0) {
                                _.filter(result, function (data) {
                                    hotelofroom3 = data.NoOfRoomSoldYTD
                                })
                            } else {
                                hotelofroom3 = 0;
                            }
                            resolve();
                        })
                    })
                }

                return Promise.all([periodCurrent, periodMtd, periodYtd]).then(resp => {
                    if (period == "mtd") {
                        hotelofroom1 = hotelofroom2;
                    }
                    else if (period == "ytd") {
                        hotelofroom1 = hotelofroom3;
                    }
                    if (PayrollActualvsPlanModelList != null && PayrollActualvsPlanModelList.length > 0) {
                        let payrollActualvsPlanModel = new PayrollActualvsPlanModelData();
                        payrollActualvsPlanModel.PlanHours = _.sumBy(PayrollActualvsPlanModelList, 'PlanHours');
                        payrollActualvsPlanModel.PlanPORHours = _.sumBy(PayrollActualvsPlanModelList, 'PlanPORHours');
                        payrollActualvsPlanModel.ActualHours = _.sumBy(PayrollActualvsPlanModelList, 'ActualHours');
                        payrollActualvsPlanModel.ActualPORHours = _.sumBy(PayrollActualvsPlanModelList, 'ActualHours') / hotelofroom1;
                        payrollActualvsPlanModel.PlanHoursWTD = _.sumBy(PayrollActualvsPlanModelList, 'PlanHoursWTD');
                        payrollActualvsPlanModel.PlanPORHoursWTD = _.sumBy(PayrollActualvsPlanModelList, 'PlanPORHoursWTD');
                        payrollActualvsPlanModel.ActualHoursWTD = _.sumBy(PayrollActualvsPlanModelList, 'ActualHoursWTD');
                        payrollActualvsPlanModel.ActualPORHoursWTD = _.sumBy(PayrollActualvsPlanModelList, 'ActualPORHoursWTD');
                        payrollActualvsPlanModel.PlanHoursMTD = _.sumBy(PayrollActualvsPlanModelList, 'PlanHoursMTD');
                        payrollActualvsPlanModel.PlanPORHoursMTD = _.sumBy(PayrollActualvsPlanModelList, 'PlanPORHoursMTD');
                        payrollActualvsPlanModel.ActualHoursMTD = _.sumBy(PayrollActualvsPlanModelList, 'ActualHoursMTD');
                        payrollActualvsPlanModel.ActualPORHoursMTD = _.sumBy(PayrollActualvsPlanModelList, 'ActualPORHoursMTD');
                        payrollActualvsPlanModel.Department = "Total";
                        PayrollActualvsPlanModelList.push(payrollActualvsPlanModel);
                    }

                    cd(null, PayrollActualvsPlanModelList);
                })

            })

        })
    }

    static GetHouseKeepingPerRoom(orgid,userid, hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, cd) {
        LaborHelper.GetHouseKeepingPerRoomCal(userid, hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, (err, result) => {
            let title = "House Keeping";
            let value = 0.00;
            let header = "House Keeping Per Room (Minutes)";
            let IsHotelEffectiveness = null;

                if (userid == 2436 || orgid == 2436) {
                    header = "Room Attendant Per Room (Minutes)";
                }

                if (result.PayrollActualvsPlanTableList != null && result.PayrollActualvsPlanTableList.length > 0) {

                    if (isFinite(result.PayrollActualvsPlanTableList[0].ActualPORHours)) {

                        value = (Math.round(result.PayrollActualvsPlanTableList[0].ActualPORHours * 100) / 100).toFixed(2);

                    }
                    if (result.PayrollActualvsPlanTableList[0].organizationCode == 2436) {

                        title = " Room Attendant";
                    }
                }

                let y = new Promise((resolve,reject)=>{
                    LaborHelper.GetActiveOrganisationList((err, result) => {

                        let users = result;

                        if (users != null && users.length > 0) {
                            
                            let matches = _.find(users, { OranizationId: orgid });
                          
                            if (matches != null) {

                                IsHotelEffectiveness = true;

                                resolve(IsHotelEffectiveness)

                            }else{
                                resolve(IsHotelEffectiveness)
                            }

                        }else{
                            resolve(IsHotelEffectiveness)
                        }
                    });
                })

                
                y.then(IsHotelEffectiveness=>{
                    cd(null, [{ "header": header, "value": value, "title": title,"IsHotelEffectiveness":IsHotelEffectiveness }])
                })                
                
         


            /*_.filter(result.PayrollActualvsPlanTableList,function(data){
                if(data.Department=="Total"){
                    let totalhousekeeping = _.sumBy([data],'ActualPORHours')
                    result.PayrollActualvsPlanTableList[0].ActualPORHours = (totalhousekeeping*60)
                }
            }) */



        });
    }
    static GetPayrollActualvsPlanBudgetCal(orgid, userid, hotelId, currentDate, laborsection1, laborsection2, laborwidgetday, cd) {
        let newModel = new PayrollActualvsPlanTableList();
        let yeasterday = new Date(currentDate);
        newModel.CurrentDate = yeasterday;
        let GetWeekDayresult;
        return new Promise((resolve, reject) => {
            DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                if (err) {
                    cd(err, null);
                }
                newModel.WeekStartDate = result;
                resolve();
            })
        }).then(resp => {
            let sdate = Utils.firstDayOfMonth(yeasterday);
            return Promise.all([
                new Promise((resolve, reject) => {
                    DashboardSettingsHelper.GetLaborSection1((err, result) => {
                        if (err) {
                            cd(err, null);
                        }

                        /*[result].forEach(element=>{
                            if(element.LaborSection1==null){
                                LaborSection1 = "Daily";
                            }
                            
                        })*/
                        LaborSection1 = laborsection1;
                        resolve();
                    })
                }),
                new Promise((resolve, reject) => {
                    DashboardSettingsHelper.GetLaborSection2((err, result) => {
                        if (err) {
                            cd(err, null);
                        }
                        /*[result].forEach(element=>{
                            if(element.LaborSection2==null){
                                LaborSection2 = "Weekly";
                            }
                            
                        })*/
                        LaborSection2 = laborsection2;
                        resolve();
                    })
                })
            ]).then(resp => {
                if (!LaborSection1 && !LaborSection2) {
                    newModel.CurrentDate = yeasterday;
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.WeekStartDate = result;
                            resolve();
                        });
                    })

                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Daily") {
                    newModel.CurrentDate = yeasterday;
                    newModel.WeekStartDate = yeasterday;
                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Weekly") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }

                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })
                    newModel.WeekStartDate = newModel.CurrentDate;
                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Monthly") {
                    newModel.CurrentDate = sdate;
                    newModel.WeekStartDate = sdate;
                }
                if (LaborSection1 == "Quarter" && LaborSection2 == "Quarter") {
                    newModel.CurrentDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);

                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Weekly") {
                    newModel.CurrentDate = yeasterday;
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.WeekStartDate = result;
                            resolve();
                        });
                    });

                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Monthly") {
                    newModel.CurrentDate = yeasterday;
                    newModel.WeekStartDate = sdate;
                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Quarter") {
                    newModel.CurrentDate = yeasterday;
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Daily") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })
                    newModel.WeekStartDate = yeasterday;

                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Monthly") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })
                    newModel.WeekStartDate = sdate;
                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Quarter") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Daily") {
                    newModel.CurrentDate = sdate;
                    newModel.WeekStartDate = yeasterday;
                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Weekly") {
                    newModel.CurrentDate = sdate;
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.WeekStartDate = result;
                            resolve();
                        });
                    });

                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Quarter") {
                    newModel.CurrentDate = sdate;
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                }

                if (!GetWeekDayresult) {
                    LaborHelper.GetPayrollActualvsPlanTableData1(hotelId, yeasterday, newModel.WeekStartDate, (err, result) => {
                        let temp = [];
                        result.forEach(element => {
                            temp.push(element)
                        })

                        newModel.PayrollActualvsPlanTableList = temp;
                        Hotelshelper.GetLaborHouseKeeping(hotelId, (err, result) => {
                            let hotel = result;
                            if (hotel != null) {

                                let users = new Hoteleffectivenessusermodeldata();
                                LaborHelper.GetActiveOrganisationList((err, result) => {
                                    users = result;
                                    if (users != null && users.length > 0) {
                                        let matches = _.find(users, { OranizationId: hotel[0].OrganizationID });
                                        if (matches != null) {
                                            newModel.IsHotelEffectiveness = true;
                                        }
                                    }
                                });

                            }

                        });

                        let IsHotelEffectiveness;
                        let DisplayMTDDate;
                        let DisplayCurrentDate;
                        let headertopic1;
                        let headertopic2;
                        let headersubtopic1;
                        let headersubtopicfrom2;
                        let headersubtopicto2;
                        let departmentlist = [];
                        let row = [];

                        if (newModel != null && newModel.PayrollActualvsPlanTableList != null && newModel.PayrollActualvsPlanTableList.length > 0) {
                            [newModel].forEach(element => {                                
                                if (userid == 402 && orgid == 402) {
                                    if (element.CurrentDate == Model.MonthStartDat) {
                                        DisplayMTDDate = element.MonthStartDate;
                                    } else {
                                        DisplayCurrentDate = element.CurrentDate;
                                    }
                                } else {
                                    if (LaborSection1 == null) {
                                        headertopic1 = "Daily Wages";
                                    } else {
                                        headertopic1 = LaborSection1 + " " + "Wages";
                                    }

                                    headersubtopic1 = element.CurrentDate;

                                    if (LaborSection2 == null) {
                                        headertopic2 = "Week to Date Wages"

                                    } else {
                                        headertopic2 = LaborSection2 + " " + "to Date Wages"
                                    }
                                    if (element.CurrentDate == element.WeekStartDate) {
                                        headersubtopicfrom2 = element.CurrentDate;
                                    }
                                    else {
                                        headersubtopicfrom2 = element.WeekStartDate
                                        headersubtopicto2 = element.CurrentDate
                                    }
                                }
                                newModel.PayrollActualvsPlanTableList.forEach(item => {

                                    [item].forEach(key => {
                                        key = JSON.parse(JSON.stringify(key));
                                        let totalclass = key.Department == "Total" ? "borderbottom" : "";
                                        if (key.Department == "Hourly") {
                                            key.Department = "FD Hourly";
                                        }
                                        departmentlist.push({ "Name": key.Department })

                                        if (userid == 402 && orgid == 402) {

                                            let planbudget = new PayrollActualvsBudgetModelData();

                                            planbudget.Actual = key.PlanWagesMTD;
                                            planbudget.Plan = key.PlanWagesMTD;
                                            planbudget.OT_Wages = key.OTWagesMTD;

                                            if (key.VarianceWagesMTD < 0) {

                                                planbudget.Variance = (key.VarianceWagesMTD * -1);

                                            } else if (key.VarianceWagesMTD > 0) {

                                                planbudget.Variance = key.VarianceWagesMTD;

                                            } else {
                                                planbudget.Variance = key.VarianceWagesMTD;
                                            }
                                            planbudget.POR_Actual = key.ActualPORWagesMTD;
                                            planbudget.POR_Plan = key.PlanPORWagesMTD;

                                            if (key.VariancePORWagesMTD < 0) {

                                                planbudget.POR_Variance = (key.VariancePORWagesMTD * -1);

                                            } else if (key.VariancePORWagesMTD > 0) {

                                                planbudget.POR_Variance = key.VariancePORWagesMTD;

                                            } else {
                                                planbudget.POR_Variance = key.VariancePORWagesMTD;
                                            }
                                            row.push(planbudget.setFormat(planbudget));

                                        } else {
                                            let planbudget = new PayrollActualvsBudgetModelData();
                                            planbudget.Actual = key.ActualWages;
                                            planbudget.Plan = key.PlanWages;
                                            planbudget.OT_Wages = key.OTWages;

                                            if (key.VarianceWages < 0) {
                                                planbudget.Variance = -(key.VarianceWages * -1);
                                            } else if (key.VarianceWages > 0) {

                                                planbudget.Variance = key.VarianceWages;

                                            } else {
                                                planbudget.Variance = key.VarianceWages;
                                            }

                                            if (!isFinite(key.ActualPORWages)) {
                                                planbudget.POR_Actual = 0;

                                            } else {
                                                planbudget.POR_Actual = key.ActualPORWages;
                                            }

                                            if (!isFinite(key.PlanPORWages)) {

                                                planbudget.POR_Plan = 0;

                                            } else {

                                                planbudget.POR_Plan = key.PlanPORWages;
                                            }
                                            if (!isFinite(key.VariancePORWages)) {

                                                planbudget.POR_Variance = 0;

                                            } else if (key.VariancePORWages < 0) {

                                                planbudget.POR_Variance = -(key.VariancePORWages * -1);

                                            } else if (key.VariancePORWages > 0) {

                                                planbudget.POR_Variance = key.VariancePORWages;

                                            } else {

                                                planbudget.POR_Variance = key.VariancePORWages;
                                            }

                                            if (key.ActualWagesWTD < 0) {
                                                planbudget.Actual1 = (key.ActualWagesWTD * -1);

                                            } else {

                                                planbudget.Actual1 = key.ActualWagesWTD;
                                            }

                                            if (key.PlanWagesWTD < 0) {

                                                planbudget.Plan1 = (key.PlanWagesWTD * -1);

                                            } else {

                                                planbudget.Plan1 = key.PlanWagesWTD;
                                            }

                                            if (key.OTWagesWTD < 0) {

                                                planbudget.OT_Wages1 = (key.OTWagesWTD * -1);
                                            } else {

                                                planbudget.OT_Wages1 = key.OTWagesWTD;
                                            }

                                            if (key.VariancWagesWTD < 0) {

                                                planbudget.Variance1 = -(key.VariancWagesWTD * -1);

                                            } else if (key.VariancWagesWTD > 0) {

                                                planbudget.Variance1 = key.VariancWagesWTD;

                                            } else {

                                                planbudget.Variance1 = key.VariancWagesWTD;
                                            }

                                            if (!isFinite(key.ActualPORWagesWTD)) {

                                                planbudget.POR_Actual1 = 0;

                                            } else if (key.ActualPORWagesWTD < 0) {

                                                planbudget.POR_Actual1 = (key.ActualPORWagesWTD * -1);

                                            } else {

                                                planbudget.POR_Actual1 = key.ActualPORWagesWTD;
                                            }

                                            if (!isFinite(key.PlanPORWagesWTD)) {

                                                planbudget.POR_Plan1 = 0;

                                            } else if (key.PlanPORWagesWTD < 0) {

                                                planbudget.POR_Plan1 = (key.PlanPORWagesWTD * -1);

                                            } else {

                                                planbudget.POR_Plan1 = key.PlanPORWagesWTD;
                                            }
                                            if (!isFinite(key.VariancPORWagesWTD)) {

                                                planbudget.POR_Variance1 = 0;

                                            } else if (key.VariancPORWagesWTD < 0) {

                                                planbudget.POR_Variance1 = -(key.VariancPORWagesWTD * -1);

                                            } else if (key.VariancPORWagesWTD > 0) {

                                                planbudget.POR_Variance1 = key.VariancPORWagesWTD;

                                            } else {
                                                planbudget.POR_Variance1 = key.VariancPORWagesWTD;
                                            }
                                            row.push(planbudget.setFormat(planbudget));


                                        }
                                    })

                                })
                            })
                        }
                        let y = new Promise((resolve,reject)=>{
                            LaborHelper.GetActiveOrganisationList((err, result) => {

                                let users = result;

                                if (users != null && users.length > 0) {
                                    
                                    let matches = _.find(users, { OranizationId: orgid });
                                  
                                    if (matches != null) {

                                        IsHotelEffectiveness = true;

                                        resolve(IsHotelEffectiveness)

                                    }else{
                                        resolve(IsHotelEffectiveness)
                                    }

                                }else{
                                    resolve(IsHotelEffectiveness)
                                }
                            });
                        })
                        y.then(IsHotelEffectiveness=>{
                            cd(null, [{
                                "IsHotelEffectiveness": IsHotelEffectiveness,
                                "MonthStartDate": DisplayMTDDate,
                                "CurrentDate": DisplayCurrentDate,
                                "headertopic1": headertopic1,
                                "headertopic2": headertopic2,
                                "headersubtopic1": Utils.getFormattedDate(headersubtopic1, 'MM/DD dddd'),
                                "headersubtopicfrom2": Utils.getFormattedDate(headersubtopicfrom2, 'MM/DD dddd'),
                                "headersubtopicto2": Utils.getFormattedDate(headersubtopicto2, 'MM/DD dddd'),
                                "departmentlist": departmentlist,
                                "payrollactualvsplanbudget": row
                            }])
                            })
                        })



                } else if (GetWeekDayresult.then != undefined && typeof GetWeekDayresult.then === 'function') {
                    LaborHelper.GetPayrollActualvsPlanTableData1(hotelId, yeasterday, newModel.WeekStartDate, (err, result) => {
                        let temp = [];
                        result.forEach(element => {
                            temp.push(element)
                        })

                        newModel.PayrollActualvsPlanTableList = temp;
                        Hotelshelper.GetLaborHouseKeeping(hotelId, (err, result) => {
                            let hotel = result;
                            if (hotel != null) {

                                let users = new Hoteleffectivenessusermodeldata();
                                LaborHelper.GetActiveOrganisationList((err, result) => {
                                    users = result;
                                    if (users != null && users.length > 0) {
                                        let matches = _.find(users, { OranizationId: hotel[0].OrganizationID });
                                        if (matches != null) {
                                            newModel.IsHotelEffectiveness = true;
                                        }
                                    }
                                });

                            }

                        });

                        let IsHotelEffectiveness;
                        let DisplayMTDDate;
                        let DisplayCurrentDate;
                        let headertopic1;
                        let headertopic2;
                        let headersubtopic1;
                        let headersubtopicfrom2;
                        let headersubtopicto2;
                        let departmentlist = [];
                        let row = [];
                        if (newModel != null && newModel.PayrollActualvsPlanTableList != null && newModel.PayrollActualvsPlanTableList.length > 0) {
                            [newModel].forEach(element => {
                                //IsHotelEffectiveness = element.IsHotelEffectiveness;
                                if (userid == 402 && orgid == 402) {
                                    if (element.CurrentDate == Model.MonthStartDat) {
                                        DisplayMTDDate = element.MonthStartDate;
                                    } else {
                                        DisplayCurrentDate = element.CurrentDate;
                                    }
                                } else {
                                    if (LaborSection1 == null) {
                                        headertopic1 = "Daily Wages";
                                    } else {
                                        headertopic1 = LaborSection1 + " " + "Wages";
                                    }

                                    headersubtopic1 = element.CurrentDate;

                                    if (LaborSection2 == null) {
                                        headertopic2 = "Week to Date Wages"

                                    } else {
                                        headertopic2 = LaborSection2 + " " + "to Date Wages"
                                    }
                                    if (element.CurrentDate == element.WeekStartDate) {
                                        headersubtopicfrom2 = element.CurrentDate;
                                    }
                                    else {
                                        headersubtopicfrom2 = element.WeekStartDate
                                        headersubtopicto2 = element.CurrentDate
                                    }
                                }
                                newModel.PayrollActualvsPlanTableList.forEach(item => {

                                    [item].forEach(key => {
                                        key = JSON.parse(JSON.stringify(key));
                                        let totalclass = key.Department == "Total" ? "borderbottom" : "";
                                        if (key.Department == "Hourly") {
                                            key.Department = "FD Hourly";
                                        }
                                        departmentlist.push({ "Name": key.Department })

                                        if (userid == 402 && orgid == 402) {

                                            let planbudget = new PayrollActualvsBudgetModelData();

                                            planbudget.Actual = key.PlanWagesMTD;
                                            planbudget.Plan = key.PlanWagesMTD;
                                            planbudget.OT_Wages = key.OTWagesMTD;

                                            if (key.VarianceWagesMTD < 0) {

                                                planbudget.Variance = (key.VarianceWagesMTD * -1);

                                            } else if (key.VarianceWagesMTD > 0) {

                                                planbudget.Variance = key.VarianceWagesMTD;

                                            } else {
                                                planbudget.Variance = key.VarianceWagesMTD;
                                            }
                                            planbudget.POR_Actual = key.ActualPORWagesMTD;
                                            planbudget.POR_Plan = key.PlanPORWagesMTD;

                                            if (key.VariancePORWagesMTD < 0) {

                                                planbudget.POR_Variance = (key.VariancePORWagesMTD * -1);

                                            } else if (key.VariancePORWagesMTD > 0) {

                                                planbudget.POR_Variance = key.VariancePORWagesMTD;

                                            } else {
                                                planbudget.POR_Variance = key.VariancePORWagesMTD;
                                            }
                                            row.push(planbudget.setFormat(planbudget));

                                        } else {
                                            let planbudget = new PayrollActualvsBudgetModelData();
                                            planbudget.Actual = key.ActualWages;
                                            planbudget.Plan = key.PlanWages;
                                            planbudget.OT_Wages = key.OTWages;

                                            if (key.VarianceWages < 0) {
                                                planbudget.Variance = -(key.VarianceWages * -1);
                                            } else if (key.VarianceWages > 0) {

                                                planbudget.Variance = key.VarianceWages;

                                            } else {
                                                planbudget.Variance = key.VarianceWages;
                                            }

                                            if (!isFinite(key.ActualPORWages)) {
                                                planbudget.POR_Actual = 0;

                                            } else {
                                                planbudget.POR_Actual = key.ActualPORWages;
                                            }

                                            if (!isFinite(key.PlanPORWages)) {

                                                planbudget.POR_Plan = 0;

                                            } else {

                                                planbudget.POR_Plan = key.PlanPORWages;
                                            }
                                            if (!isFinite(key.VariancePORWages)) {

                                                planbudget.POR_Variance = 0;

                                            } else if (key.VariancePORWages < 0) {

                                                planbudget.POR_Variance = -(key.VariancePORWages * -1);

                                            } else if (key.VariancePORWages > 0) {

                                                planbudget.POR_Variance = key.VariancePORWages;

                                            } else {

                                                planbudget.POR_Variance = key.VariancePORWages;
                                            }

                                            if (key.ActualWagesWTD < 0) {
                                                planbudget.Actual1 = (key.ActualWagesWTD * -1);

                                            } else {

                                                planbudget.Actual1 = key.ActualWagesWTD;
                                            }

                                            if (key.PlanWagesWTD < 0) {

                                                planbudget.Plan1 = (key.PlanWagesWTD * -1);

                                            } else {

                                                planbudget.Plan1 = key.PlanWagesWTD;
                                            }

                                            if (key.OTWagesWTD < 0) {

                                                planbudget.OT_Wages1 = (key.OTWagesWTD * -1);
                                            } else {

                                                planbudget.OT_Wages1 = key.OTWagesWTD;
                                            }

                                            if (key.VariancWagesWTD < 0) {

                                                planbudget.Variance1 = -(key.VariancWagesWTD * -1);

                                            } else if (key.VariancWagesWTD > 0) {

                                                planbudget.Variance1 = key.VariancWagesWTD;

                                            } else {

                                                planbudget.Variance1 = key.VariancWagesWTD;
                                            }

                                            if (!isFinite(key.ActualPORWagesWTD)) {

                                                planbudget.POR_Actual1 = 0;

                                            } else if (key.ActualPORWagesWTD < 0) {

                                                planbudget.POR_Actual1 = (key.ActualPORWagesWTD * -1);

                                            } else {

                                                planbudget.POR_Actual1 = key.ActualPORWagesWTD;
                                            }

                                            if (!isFinite(key.PlanPORWagesWTD)) {

                                                planbudget.POR_Plan1 = 0;

                                            } else if (key.PlanPORWagesWTD < 0) {

                                                planbudget.POR_Plan1 = (key.PlanPORWagesWTD * -1);

                                            } else {

                                                planbudget.POR_Plan1 = key.PlanPORWagesWTD;
                                            }
                                            if (!isFinite(key.VariancPORWagesWTD)) {

                                                planbudget.POR_Variance1 = 0;

                                            } else if (key.VariancPORWagesWTD < 0) {

                                                planbudget.POR_Variance1 = -(key.VariancPORWagesWTD * -1);

                                            } else if (key.VariancPORWagesWTD > 0) {

                                                planbudget.POR_Variance1 = key.VariancPORWagesWTD;

                                            } else {
                                                planbudget.POR_Variance1 = key.VariancPORWagesWTD;
                                            }
                                            row.push(planbudget.setFormat(planbudget));


                                        }
                                    })

                                })
                            })
                        }
                        let y = new Promise((resolve,reject)=>{
                            LaborHelper.GetActiveOrganisationList((err, result) => {
                                let users = result;
                                if (users != null && users.length > 0) {
                                    let matches = _.find(users, { OranizationId: orgid });
                                    if (matches != null) {
                                        IsHotelEffectiveness = true;
                                        resolve(IsHotelEffectiveness)
                                    }else{
                                        resolve(IsHotelEffectiveness)
                                    }

                                }else{
                                    resolve(IsHotelEffectiveness)
                                }
                            });
                        })
                        y.then(IsHotelEffectiveness=>{
                            cd(null, [{
                                "IsHotelEffectiveness": IsHotelEffectiveness,
                                "MonthStartDate": DisplayMTDDate,
                                "CurrentDate": DisplayCurrentDate,
                                "headertopic1": headertopic1,
                                "headertopic2": headertopic2,
                                "headersubtopic1": Utils.getFormattedDate(headersubtopic1, 'MM/DD dddd'),
                                "headersubtopicfrom2": Utils.getFormattedDate(headersubtopicfrom2, 'MM/DD dddd'),
                                "headersubtopicto2": Utils.getFormattedDate(headersubtopicto2, 'MM/DD dddd'),
                                "departmentlist": departmentlist,
                                "payrollactualvsplanbudget": row
                            }])
                        })

                    })
                }




            })
        })

    }
    static GetPayrollActualvsPlanTableData1(hotelId, date, WeekDay, cd) {
        let PayrollActualvsPlanModelList = [];
        let sdate = Utils.firstDayOfMonth(date);
        /*let temp = date;
        let enddate = new Date(date.setHours(date.getHours()+23));
        enddate = new Date(enddate.setMinutes(date.getMinutes()+59));
        enddate = new Date(enddate.setSeconds(date.getSeconds()+59));
        date = temp;*/
        let enddate = Utils.endofDay(date);
        let sweekdate = WeekDay;
        let roomRevenueList;
        let hotelofroom;
        let hotelBudgetroomsold;
        let roomRevenueListWeek;
        let noofroomsoldweek;
        let hotelBudgetroomsold1;
        return Promise.all([
            new Promise((resolve, reject) => {
                HoteleffectivenesscalculationsSchema.find(
                    {
                        [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                        [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: date, $lte: date }
                    }

                ).exec((err, result) => {
                    if (err) {
                        reject(err);
                    }

                    roomRevenueList = result;
                    resolve();
                })
            }), new Promise((resolve, reject) => {
                HoteldashboardcalculationsHelper.GetPayrollHouseKeepingData(hotelId, date, (err, result) => {
                    if (err) {
                        reject(err);
                    }
                    hotelofroom = result;
                    resolve();
                })
            }), new Promise((resolve, reject) => {
                HotelbudgetHelper.GetPayrollActualvsPlanTableData(hotelId, date, (err, result) => {
                    if (err) {
                        reject(err);
                    }
                    hotelBudgetroomsold = result;
                    resolve();
                })
            })
        ]).then(resp => {
            let days = Utils.getDaysinMonth(date.getFullYear(), date.getMonth());

            if (hotelBudgetroomsold.length > 0) {

                hotelBudgetroomsold.forEach(element => {
                    hotelBudgetroomsold = element.TotalNumberofBudgetedRoomsSold;
                });

            } else {
                hotelBudgetroomsold = 0;
            }

            if (hotelBudgetroomsold > 0) {
                hotelBudgetroomsold = hotelBudgetroomsold / days;
            }
            else {
                hotelBudgetroomsold = 0;
            }

            if (hotelofroom == null) {
                hotelofroom = 0;
            } else {
                _.filter(hotelofroom, function (data) {
                    hotelofroom = data.NoOfRoomSold
                })
            }
            roomRevenueList.forEach(element => {
                let payrollActualvsPlanModel = new PayrollActualvsPlanModelData();
                payrollActualvsPlanModel.PlanWages = element.PlanWages == null ? 0 : element.PlanWages;
                payrollActualvsPlanModel.ActualWages = element.Wages == null ? 0 : element.Wages;
                payrollActualvsPlanModel.OTWages = element.OTWages == null ? 0 : element.OTWages;
                payrollActualvsPlanModel.PlanPORWages = (element.PlanWages == null || hotelBudgetroomsold == 0) ? 0 : element.PlanWages / hotelBudgetroomsold;
                payrollActualvsPlanModel.ActualPORWages = (element.Wages == null || hotelofroom == 0) ? 0 : element.Wages / hotelofroom;

                payrollActualvsPlanModel.VarianceWages = payrollActualvsPlanModel.PlanWages - payrollActualvsPlanModel.ActualWages;
                payrollActualvsPlanModel.VariancePORWages = payrollActualvsPlanModel.PlanPORWages - payrollActualvsPlanModel.ActualPORWages;

                payrollActualvsPlanModel.Department = element.Department;
                payrollActualvsPlanModel.Date = element.Date;
                payrollActualvsPlanModel.HotelID = element.HotelID;
                PayrollActualvsPlanModelList.push(payrollActualvsPlanModel);
            })

            return Promise.all([
                new Promise((resolve, reject) => {
                    HoteleffectivenesscalculationsSchema.find(
                        {
                            [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                            [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: sweekdate, $lte: date }
                        }

                    ).exec((err, result) => {
                        if (err) {
                            reject(err);
                        }

                        roomRevenueListWeek = result;
                        resolve();
                    })
                }),
                new Promise((resolve, reject) => {
                    HoteldashboardcalculationsHelper.GetPayrollHouseKeepingDataSweekDate(hotelId, sweekdate, date, (err, result) => {
                        if (err) {
                            reject(err);
                        }

                        noofroomsoldweek = result;
                        resolve();
                    })
                }),
                new Promise((resolve, reject) => {
                    HotelbudgetHelper.GetPayrollActualvsPlanTableDataSweekDate(hotelId, sweekdate, date, (err, result) => {
                        if (err) {
                            reject(err);
                        }

                        hotelBudgetroomsold1 = result;
                        resolve();
                    })

                })
            ]).then(resp => {
                let totalnoroomsold = 0;
                let flag = false;
                _.filter(noofroomsoldweek, function (data) {
                    totalnoroomsold += data.NoOfRoomSold
                })

                if (hotelBudgetroomsold1.length > 0) {
                    _.filter(hotelBudgetroomsold1, function (data) {
                        hotelBudgetroomsold1 = data.TotalNumberofBudgetedRoomsSold
                    })
                    if (hotelBudgetroomsold1 > 0) {
                        hotelBudgetroomsold1 = hotelBudgetroomsold1 / days;
                    } else {
                        hotelBudgetroomsold1 = 0;
                    }
                } else {
                    hotelBudgetroomsold1 = 0;
                }

                let totaldays = Utils.dateDiffInDays(date, sweekdate) + 1;

                if (totaldays > 1 && hotelBudgetroomsold1 > 0) {
                    hotelBudgetroomsold1 = hotelBudgetroomsold1 * totaldays;
                }
                PayrollActualvsPlanModelList.forEach(element => {
                    let matches = _.find(roomRevenueListWeek, { Department: element.Department });

                    if (matches != null && [matches].length > 0) {

                        element.ActualWagesWTD = _.sumBy([matches], 'Wages');
                        element.PlanWagesWTD = _.sumBy([matches], 'PlanWages');
                        element.OTWagesWTD = _.sumBy([matches], 'OTWages');
                        element.ActualPORWagesWTD = totalnoroomsold == 0 ? 0 : _.sumBy([matches], 'Wages') / totalnoroomsold;
                        element.PlanPORWagesWTD = hotelBudgetroomsold1 == 0 ? 0 : _.sumBy([matches], 'PlanWages') / hotelBudgetroomsold1;

                        element.VariancWagesWTD = element.PlanWagesWTD - element.ActualWagesWTD;
                        element.VariancPORWagesWTD = element.PlanPORWagesWTD - element.ActualPORWagesWTD;






                    }
                })

                let roomRevenueListMonth;
                return new Promise((resolve, reject) => {
                    HoteleffectivenesscalculationsSchema.find(
                        {
                            [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                            [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: sdate, $lte: date }
                        }

                    ).exec((err, result) => {
                        if (err) {
                            reject(err);
                        }
                        roomRevenueListMonth = result;
                        resolve();
                    })
                }).then(resp => {
                    PayrollActualvsPlanModelList.forEach(element => {
                        let matches = _.find(roomRevenueListMonth, { Department: element.Department });

                        if (matches != null && [matches].length > 0) {
                            element.ActualWagesMTD = _.sumBy([matches], 'Wages');
                            element.PlanWagesMTD = _.sumBy([matches], 'PlanWages');
                            element.OTWagesMTD = _.sumBy([matches], 'OTWages');

                            element.ActualPORWagesMTD = _.sumBy([matches], 'Wages');
                            element.PlanPORWagesMTD = _.sumBy([matches], 'PlanWages');
                            element.VarianceWagesMTD = element.ActualWagesMTD - element.PlanWagesMTD;
                            element.VariancePORWagesMTD = element.ActualPORWagesMTD - element.PlanPORWagesMTD;
                        }

                    })

                    if (PayrollActualvsPlanModelList != null && PayrollActualvsPlanModelList.length > 0) {
                        let payrollActualvsPlanModel = new PayrollActualvsPlanModelData();
                        payrollActualvsPlanModel.PlanWages = _.sumBy(PayrollActualvsPlanModelList, 'PlanWages');
                        payrollActualvsPlanModel.PlanPORWages = _.sumBy(PayrollActualvsPlanModelList, 'PlanPORWages');
                        payrollActualvsPlanModel.ActualWages = _.sumBy(PayrollActualvsPlanModelList, 'ActualWages');
                        payrollActualvsPlanModel.OTWages = _.sumBy(PayrollActualvsPlanModelList, 'OTWages');
                        payrollActualvsPlanModel.ActualPORWages = _.sumBy(PayrollActualvsPlanModelList, 'ActualPORWages');
                        payrollActualvsPlanModel.PlanWagesWTD = _.sumBy(PayrollActualvsPlanModelList, 'PlanWagesWTD');
                        payrollActualvsPlanModel.PlanPORWagesWTD = _.sumBy(PayrollActualvsPlanModelList, 'PlanPORWagesWTD');
                        payrollActualvsPlanModel.ActualWagesWTD = _.sumBy(PayrollActualvsPlanModelList, 'ActualWagesWTD');
                        payrollActualvsPlanModel.OTWagesWTD = _.sumBy(PayrollActualvsPlanModelList, 'OTWagesWTD');
                        payrollActualvsPlanModel.ActualPORWagesWTD = _.sumBy(PayrollActualvsPlanModelList, 'ActualPORWagesWTD');
                        payrollActualvsPlanModel.PlanWagesMTD = _.sumBy(PayrollActualvsPlanModelList, 'PlanWagesMTD');
                        payrollActualvsPlanModel.PlanPORWagesMTD = _.sumBy(PayrollActualvsPlanModelList, 'PlanPORWagesMTD');
                        payrollActualvsPlanModel.ActualWagesMTD = _.sumBy(PayrollActualvsPlanModelList, 'ActualWagesMTD');
                        payrollActualvsPlanModel.OTWagesMTD = _.sumBy(PayrollActualvsPlanModelList, 'OTWagesMTD');
                        payrollActualvsPlanModel.ActualPORWagesMTD = _.sumBy(PayrollActualvsPlanModelList, 'ActualPORWagesMTD');

                        payrollActualvsPlanModel.VarianceWages = _.sumBy(PayrollActualvsPlanModelList, 'VarianceWages');
                        payrollActualvsPlanModel.VariancePORWages = _.sumBy(PayrollActualvsPlanModelList, 'VariancePORWages');
                        payrollActualvsPlanModel.VariancWagesWTD = _.sumBy(PayrollActualvsPlanModelList, 'VariancWagesWTD');
                        payrollActualvsPlanModel.VariancPORWagesWTD = _.sumBy(PayrollActualvsPlanModelList, 'VariancPORWagesWTD');
                        payrollActualvsPlanModel.VarianceWagesMTD = _.sumBy(PayrollActualvsPlanModelList, 'VarianceWagesMTD');
                        payrollActualvsPlanModel.VariancePORWagesMTD = _.sumBy(PayrollActualvsPlanModelList, 'VariancePORWagesMTD');

                        payrollActualvsPlanModel.Department = "Total";
                        PayrollActualvsPlanModelList.push(payrollActualvsPlanModel);
                    }

                    cd(null, PayrollActualvsPlanModelList);


                })



            })



        })


    }
    static GetPayrollActualvsPlanBudgetHoursCal(orgid, userid, hotelId, rptType, currentDate, laborsection1, laborsection2, laborwidgetday, cd) {

        if (rptType == "Hour") {
            chartTitle = "Hours";
        } else if (rptType == "Minute") {
            chartTitle = "Minutes";
        }
        let newModel = new PayrollActualvsPlanTableList();

        let yeasterday = new Date(currentDate);
        newModel.CurrentDate = yeasterday;

        let GetWeekDayresult;

        return new Promise((resolve, reject) => {
            DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                if (err) {
                    cd(err, null);
                }

                newModel.WeekStartDate = result;
                resolve();
            })
        }).then(resp => {

            let sdate = Utils.firstDayOfMonth(yeasterday);
            let LaborSection1 = '';
            let LaborSection2 = '';
            return Promise.all([
                new Promise((resolve, reject) => {
                    DashboardSettingsHelper.GetLaborSection1((err, result) => {
                        if (err) {
                            cd(err, null);
                        }
                        //TO DO
                        /*[result].forEach(element=>{
                            if(element.LaborSection1==null){
                                LaborSection1 = "Daily";
                            }else{
                                LaborSection1 = element.LaborSection1;
                            }
                            
                        })*/
                        LaborSection1 = laborsection1;
                        resolve();
                    })
                }),
                new Promise((resolve, reject) => {
                    DashboardSettingsHelper.GetLaborSection2((err, result) => {
                        if (err) {
                            cd(err, null);
                        }
                        //TO DO          
                        /*[result].forEach(element=>{
                            if(element.LaborSection2==null){
                                LaborSection2 = "Weekly";
                            }else{
                                LaborSection2 = element.LaborSection2;
                            }
                            
                        })*/
                        LaborSection2 = laborsection2;
                        resolve();
                    })
                })
            ]).then(resp => {
                if (!LaborSection1 && !LaborSection2) {
                    newModel.CurrentDate = yeasterday;
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.WeekStartDate = result;
                            resolve();
                        });
                    })

                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Daily") {
                    newModel.CurrentDate = yeasterday;
                    newModel.WeekStartDate = yeasterday;
                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Weekly") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })
                    newModel.WeekStartDate = newModel.CurrentDate;
                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Monthly") {
                    newModel.CurrentDate = sdate;
                    newModel.WeekStartDate = sdate;
                }
                if (LaborSection1 == "Quarter" && LaborSection2 == "Quarter") {
                    newModel.CurrentDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);

                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Weekly") {
                    newModel.CurrentDate = yeasterday;
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.WeekStartDate = result;
                            resolve();
                        });
                    });

                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Monthly") {
                    newModel.CurrentDate = yeasterday;
                    newModel.WeekStartDate = sdate;
                }
                if (LaborSection1 == "Daily" && LaborSection2 == "Quarter") {
                    newModel.CurrentDate = yeasterday;
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Daily") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })
                    newModel.WeekStartDate = yeasterday;

                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Monthly") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })
                    newModel.WeekStartDate = sdate;
                }
                if (LaborSection1 == "Weekly" && LaborSection2 == "Quarter") {
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }
                            newModel.CurrentDate = result;
                            resolve();
                        });
                    })
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Daily") {
                    newModel.CurrentDate = sdate;
                    newModel.WeekStartDate = yeasterday;
                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Weekly") {

                    newModel.CurrentDate = sdate;
                    GetWeekDayresult = new Promise((resolve, reject) => {
                        DashboardSettingsHelper.GetWeekDay(newModel.CurrentDate, laborwidgetday, (err, result) => {
                            if (err) {
                                reject(err);
                            }

                            newModel.WeekStartDate = result;
                            resolve();
                        });
                    });

                }
                if (LaborSection1 == "Monthly" && LaborSection2 == "Quarter") {
                    newModel.CurrentDate = sdate;
                    newModel.WeekStartDate = DashboardSettingsHelper.GetFirstDayOfQuarter(yeasterday);
                }


                if (!GetWeekDayresult) {
                    return new Promise((resolve, reject) => {
                        newModel.PayrollActualvsPlanTableList = LaborHelper.GetPayrollActualvsPlanTableData(hotelId, yeasterday, newModel.WeekStartDate, (err, result) => {
                            newModel.PayrollActualvsPlanTableList = result;
                            resolve();
                        });
                    }).then(resp => {
                        let hotel;
                        return new Promise((resolve, reject) => {
                            Hotelshelper.GetLaborHouseKeeping(hotelId, (err, result) => {
                                if (err) {
                                    reject(err);
                                }
                                hotel = result;
                                resolve();
                            })
                        }).then(resp => {
                            if (hotel.length > 0) {
                                let users = new Hoteleffectivenesscalculationsdata();
                                return new Promise((resolve, reject) => {
                                    LaborHelper.GetActiveOrganisationList((err, result) => {
                                        if (err) {
                                            reject(err);
                                        }
                                        users = result;
                                        resolve()
                                    })
                                }).then(resp => {
                                    if (users != null && users.length > 0) {

                                        let matches = _.find(users, { OranizationId: hotel[0]["OrganizationID"] });
                                        if (matches != null) {
                                            newModel.IsHotelEffectiveness = true;
                                        }


                                    }
                                    if (rptType == "Minute") {
                                        if (newModel.PayrollActualvsPlanTableList.length > 0) {
                                            newModel.PayrollActualvsPlanTableList.forEach((element, index) => {
                                                newModel.PayrollActualvsPlanTableList[index].ActualHours = element.ActualHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].OTHours = element.OTHours * 60;

                                                newModel.PayrollActualvsPlanTableList[index].ActualHoursMTD = element.ActualHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].OTHoursMTD = element.OTHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].ActualHoursWTD = element.ActualHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].OTHoursWTD = element.OTHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].ActualPORHours = element.ActualPORHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].ActualPORHoursMTD = element.ActualPORHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].ActualPORHoursWTD = element.ActualPORHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].PlanHours = element.PlanHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].PlanHoursMTD = element.PlanHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].PlanHoursWTD = element.PlanHoursWTD * 60;

                                                newModel.PayrollActualvsPlanTableList[index].VarianceHours = element.VarianceHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VariancePORHours = element.VariancePORHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VarianceHoursWTD = element.VarianceHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VariancePORHoursWTD = element.VariancePORHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VarianceHoursMTD = element.VarianceHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VariancePORHoursMTD = element.VariancePORHoursMTD * 60;
                                            })
                                        }
                                    }


                                    let IsHotelEffectiveness;
                                    let DisplayMTDDate;
                                    let DisplayCurrentDate;
                                    let headertopic1;
                                    let headertopic2;
                                    let headersubtopic1;
                                    let headersubtopic2;
                                    let headersubtopicfrom2;
                                    let headersubtopicto2;
                                    let departmentlist = [];
                                    let row = [];
                                    if (newModel["PayrollActualvsPlanTableList"].length > 0) {
                                        //IsHotelEffectiveness = newModel["IsHotelEffectiveness"];
                                        if (userid == 402 && orgid == 402) {
                                            if (newModel["CurrentDate"] == newModel["MonthStartDate"]) {
                                                DisplayMTDDate = newModel["MonthStartDate"];
                                            }
                                            else {
                                                DisplayCurrentDate = newModel["CurrentDate"];
                                            }
                                        } else {
                                            if (chartTitle == "Hours") {
                                                if (LaborSection1 == null) {
                                                    headertopic1 = "Daily Hours";
                                                } else {
                                                    headertopic1 = LaborSection1 + " " + "Hours";
                                                }
                                            } else if (chartTitle == "Minutes") {
                                                if (LaborSection1 == null) {
                                                    headertopic1 = "Daily Minutes";
                                                } else {
                                                    headertopic1 = LaborSection1 + " " + "Minutes";
                                                }

                                            }
                                            headersubtopic1 = newModel["CurrentDate"];
                                        }
                                        if (chartTitle == "Hours") {
                                            if (LaborSection2 == null) {
                                                headertopic2 = "Week to Date Hours";
                                            }
                                            else {
                                                headertopic2 = LaborSection2 + " " + "to Date Hours";

                                            }

                                        } else if (chartTitle == "Minutes") {
                                            if (LaborSection2 == null) {
                                                headertopic2 = "Week to Date Minutes";

                                            }
                                            else {
                                                headertopic2 = LaborSection2 + " " + "to Date Minutes";

                                            }
                                        } if (newModel["CurrentDate"] == newModel["WeekStartDate"]) {
                                            headersubtopic2 = newModel["CurrentDate"];
                                        }
                                        else {
                                            headersubtopicfrom2 = newModel["WeekStartDate"];
                                            headersubtopicto2 = newModel["CurrentDate"];
                                        }
                                        newModel["PayrollActualvsPlanTableList"].forEach(item => {

                                            if (item["Department"] == "Hourly") {
                                                item["Department"] = "FD Hourly";
                                            }

                                            departmentlist.push({ "Name": item["Department"] });

                                            if (userid == 402 && orgid == 402) {
                                                let payrollactualvsbudgethours = new PayrollActualvsBudgetHoursModelData();
                                                payrollactualvsbudgethours.ActualHoursMTD = item.ActualHoursMTD;
                                                payrollactualvsbudgethours.PlanHoursMTD = item.PlanHoursMTD;
                                                payrollactualvsbudgethours.OTHoursMTD = item.OTHoursMTD;
                                                if (item.VarianceHoursMTD < 0) {
                                                    payrollactualvsbudgethours.VarianceHoursMTD = (item.VarianceHoursMTD * -1);
                                                }
                                                else if (item.VarianceHoursMTD > 0) {

                                                    payrollactualvsbudgethours.VarianceHoursMTD = item.VarianceHoursMTD;

                                                }
                                                else {

                                                    payrollactualvsbudgethours.VarianceHoursMTD = item.VarianceHoursMTD;

                                                }
                                                payrollactualvsbudgethours.ActualPORHoursMTD = item.ActualPORHoursMTD;
                                                payrollactualvsbudgethours.PlanPORHoursMTD = item.PlanPORHoursMTD;
                                                if (item.VariancePORHoursMTD < 0) {
                                                    payrollactualvsbudgethours.VariancePORHoursMTD = (item.VariancePORHoursMTD * -1)
                                                }
                                                else if (item.VariancePORHoursMTD > 0) {

                                                    payrollactualvsbudgethours.VariancePORHoursMTD = item.VariancePORHoursMTD

                                                }
                                                else {

                                                    payrollactualvsbudgethours.VariancePORHoursMTD = item.VariancePORHoursMTD;
                                                }

                                                row.push(payrollactualvsbudgethours.setFormat(payrollactualvsbudgethours));




                                            } else {
                                                let payrollactualvsbudgethours = new PayrollActualvsBudgetHoursModelData();
                                                payrollactualvsbudgethours.ActualHours = item.ActualHours;
                                                payrollactualvsbudgethours.PlanHours = item.PlanHours;
                                                payrollactualvsbudgethours.OTHours = item.OTHours;

                                                if (item.VarianceHours < 0) {
                                                    payrollactualvsbudgethours.VarianceHours = -(item.VarianceHours * -1);
                                                }
                                                else if (item.VarianceHours > 0) {
                                                    payrollactualvsbudgethours.VarianceHours = item.VarianceHours;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.VarianceHours = item.VarianceHours;
                                                }

                                                if (isFinite(item.ActualPORHours)) {
                                                    payrollactualvsbudgethours.ActualPORHours = item.ActualPORHours;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.ActualPORHours = null;
                                                }

                                                if (isFinite(item.PlanPORHours)) {
                                                    payrollactualvsbudgethours.PlanPORHours = item.PlanPORHours;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.PlanPORHours = null;
                                                }

                                                if (!isFinite(item.VariancePORHours)) {
                                                    payrollactualvsbudgethours.VariancePORHours = null;
                                                }
                                                else if (item.VariancePORHours < 0) {
                                                    payrollactualvsbudgethours.VariancePORHours = -(item.VariancePORHours * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.VariancePORHours = item.VariancePORHours;
                                                }

                                                if (item.ActualHoursWTD < 0) {
                                                    payrollactualvsbudgethours.ActualHoursWTD = -(item.ActualHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.ActualHoursWTD = item.ActualHoursWTD;
                                                }

                                                if (item.PlanHoursWTD < 0) {
                                                    payrollactualvsbudgethours.PlanHoursWTD = -(item.PlanHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.PlanHoursWTD = item.PlanHoursWTD;
                                                }
                                                if (item.OTHoursWTD < 0) {
                                                    payrollactualvsbudgethours.OTHoursWTD = -(item.OTHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.OTHoursWTD = item.OTHoursWTD;
                                                }

                                                if (item.VarianceHoursWTD < 0) {
                                                    payrollactualvsbudgethours.VarianceHoursWTD = -(item.VarianceHoursWTD * -1);
                                                }
                                                else if (item.VarianceHoursWTD > 0) {
                                                    payrollactualvsbudgethours.VarianceHoursWTD = item.VarianceHoursWTD;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.VarianceHoursWTD = item.VarianceHoursWTD;
                                                }

                                                if (!isFinite(item.ActualPORHoursWTD)) {
                                                    payrollactualvsbudgethours.ActualPORHoursWTD = null;
                                                }
                                                else if (item.ActualPORHoursWTD < 0) {
                                                    payrollactualvsbudgethours.ActualPORHoursWTD = -(item.ActualPORHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.ActualPORHoursWTD = item.ActualPORHoursWTD;
                                                }


                                                if (!isFinite(item.PlanPORHoursWTD)) {
                                                    payrollactualvsbudgethours.PlanPORHoursWTD = null;
                                                }
                                                else if (item.PlanPORHoursWTD < 0) {
                                                    payrollactualvsbudgethours.PlanPORHoursWTD = -(item.PlanPORHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.PlanPORHoursWTD = item.PlanPORHoursWTD;
                                                }


                                                if (!isFinite(item.VariancePORHoursWTD)) {
                                                    payrollactualvsbudgethours.VariancePORHoursWTD = null;
                                                }
                                                else if (item.VariancePORHoursWTD < 0) {
                                                    payrollactualvsbudgethours.VariancePORHoursWTD = -(item.VariancePORHoursWTD * -1);
                                                }
                                                else if (item.VariancePORHoursWTD > 0) {
                                                    payrollactualvsbudgethours.VariancePORHoursWTD = item.VariancePORHoursWTD;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.VariancePORHoursWTD = item.VariancePORHoursWTD;
                                                }
                                                row.push(payrollactualvsbudgethours.setFormat(payrollactualvsbudgethours));
                                            }

                                        })

                                        let y = new Promise((resolve,reject)=>{
                                            LaborHelper.GetActiveOrganisationList((err, result) => {
                
                                                let users = result;
                
                                                if (users != null && users.length > 0) {
                                                    
                                                    let matches = _.find(users, { OranizationId: orgid });
                                                  
                                                    if (matches != null) {
                
                                                        IsHotelEffectiveness = true;
                
                                                        resolve(IsHotelEffectiveness)
                
                                                    }else{
                                                        resolve(IsHotelEffectiveness)
                                                    }
                
                                                }else{
                                                    resolve(IsHotelEffectiveness)
                                                }
                                            });
                                        })
                                        y.then(IsHotelEffectiveness=>{
                                            cd(null, [{
                                                "IsHotelEffectiveness": IsHotelEffectiveness,
                                                "MonthStartDate": DisplayMTDDate,
                                                "CurrentDate": DisplayCurrentDate,
                                                "headertopic1": headertopic1,
                                                "headertopic2": headertopic2,
                                                "headersubtopic1": Utils.getFormattedDate(headersubtopic1, 'MM/DD dddd'),
                                                "headersubtopicfrom2": Utils.getFormattedDate(headersubtopicfrom2, 'MM/DD dddd'),
                                                "headersubtopicto2": Utils.getFormattedDate(headersubtopicto2, 'MM/DD dddd'),
                                                "departmentlist": departmentlist,
                                                "payrollactualvsplanbudgethours": row
                                            }])
                                        })




                                    } else {
                                        let y = new Promise((resolve,reject)=>{
                                            LaborHelper.GetActiveOrganisationList((err, result) => {
                
                                                let users = result;
                
                                                if (users != null && users.length > 0) {
                                                    
                                                    let matches = _.find(users, { OranizationId: orgid });
                                                  
                                                    if (matches != null) {
                
                                                        IsHotelEffectiveness = true;
                
                                                        resolve(IsHotelEffectiveness)
                
                                                    }else{
                                                        resolve(IsHotelEffectiveness)
                                                    }
                
                                                }else{
                                                    resolve(IsHotelEffectiveness)
                                                }
                                            });
                                        })
                                        y.then(IsHotelEffectiveness=>{
                                            cd(null, [{
                                                "IsHotelEffectiveness": IsHotelEffectiveness,
                                                "MonthStartDate": DisplayMTDDate,
                                                "CurrentDate": DisplayCurrentDate,
                                                "headertopic1": headertopic1,
                                                "headertopic2": headertopic2,
                                                "headersubtopic1": Utils.getFormattedDate(headersubtopic1, 'MM/DD dddd'),
                                                "headersubtopicfrom2": Utils.getFormattedDate(headersubtopicfrom2, 'MM/DD dddd'),
                                                "headersubtopicto2": Utils.getFormattedDate(headersubtopicto2, 'MM/DD dddd'),
                                                "departmentlist": departmentlist,
                                                "payrollactualvsplanbudgethours": row
                                            }])
                                        })                                        

                                    }




                                })
                            }

                        })

                    })
                } else if (typeof GetWeekDayresult.then === 'function') {
                    return new Promise((resolve, reject) => {
                        newModel.PayrollActualvsPlanTableList = LaborHelper.GetPayrollActualvsPlanTableData(hotelId, yeasterday, newModel.WeekStartDate, (err, result) => {
                            newModel.PayrollActualvsPlanTableList = result;
                            resolve();
                        });
                    }).then(resp => {
                        let hotel;
                        return new Promise((resolve, reject) => {
                            Hotelshelper.GetLaborHouseKeeping(hotelId, (err, result) => {
                                hotel = result;
                                resolve();
                            })
                        }).then(resp => {
                            if (hotel.length > 0) {
                                let users = new Hoteleffectivenesscalculationsdata();
                                return new Promise((resolve, reject) => {
                                    LaborHelper.GetActiveOrganisationList((err, result) => {
                                        if (err) {
                                            reject(err);
                                        }
                                        users = result;
                                        resolve()
                                    })
                                }).then(resp => {
                                    if (users != null && users.length > 0) {

                                        let matches = _.find(users, { OranizationId: hotel[0]["OrganizationID"] });
                                        if (matches != null) {
                                            newModel.IsHotelEffectiveness = true;
                                        }


                                    }
                                    if (rptType == "Minute") {
                                        if (newModel.PayrollActualvsPlanTableList.length > 0) {
                                            newModel.PayrollActualvsPlanTableList.forEach((element, index) => {
                                                newModel.PayrollActualvsPlanTableList[index].ActualHours = element.ActualHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].OTHours = element.OTHours * 60;

                                                newModel.PayrollActualvsPlanTableList[index].ActualHoursMTD = element.ActualHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].OTHoursMTD = element.OTHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].ActualHoursWTD = element.ActualHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].OTHoursWTD = element.OTHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].ActualPORHours = element.ActualPORHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].ActualPORHoursMTD = element.ActualPORHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].ActualPORHoursWTD = element.ActualPORHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].PlanHours = element.PlanHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].PlanHoursMTD = element.PlanHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].PlanHoursWTD = element.PlanHoursWTD * 60;

                                                newModel.PayrollActualvsPlanTableList[index].VarianceHours = element.VarianceHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VariancePORHours = element.VariancePORHours * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VarianceHoursWTD = element.VarianceHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VariancePORHoursWTD = element.VariancePORHoursWTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VarianceHoursMTD = element.VarianceHoursMTD * 60;
                                                newModel.PayrollActualvsPlanTableList[index].VariancePORHoursMTD = element.VariancePORHoursMTD * 60;
                                            })
                                        }
                                    }


                                    let IsHotelEffectiveness;
                                    let DisplayMTDDate;
                                    let DisplayCurrentDate;
                                    let headertopic1;
                                    let headertopic2;
                                    let headersubtopic1;
                                    let headersubtopic2;
                                    let headersubtopicfrom2;
                                    let headersubtopicto2;
                                    let departmentlist = [];
                                    let row = [];
                                    if (newModel["PayrollActualvsPlanTableList"].length > 0) {
                                        //IsHotelEffectiveness = newModel["IsHotelEffectiveness"];
                                        if (userid == 402 && orgid == 402) {
                                            if (newModel["CurrentDate"] == newModel["MonthStartDate"]) {
                                                DisplayMTDDate = newModel["MonthStartDate"];
                                            }
                                            else {
                                                DisplayCurrentDate = newModel["CurrentDate"];
                                            }
                                        } else {
                                            if (chartTitle == "Hours") {
                                                if (LaborSection1 == null) {
                                                    headertopic1 = "Daily Hours";
                                                } else {
                                                    headertopic1 = LaborSection1 + " " + "Hours";
                                                }
                                            } else if (chartTitle == "Minutes") {
                                                if (LaborSection1 == null) {
                                                    headertopic1 = "Daily Minutes";
                                                } else {
                                                    headertopic1 = LaborSection1 + " " + "Minutes";
                                                }

                                            }
                                            headersubtopic1 = newModel["CurrentDate"];
                                        }
                                        if (chartTitle == "Hours") {
                                            if (LaborSection2 == null) {
                                                headertopic2 = "Week to Date Hours";
                                            }
                                            else {
                                                headertopic2 = LaborSection2 + " " + "to Date Hours";

                                            }

                                        } else if (chartTitle == "Minutes") {
                                            if (LaborSection2 == null) {
                                                headertopic2 = "Week to Date Minutes";

                                            }
                                            else {
                                                headertopic2 = LaborSection2 + " " + "to Date Minutes";

                                            }
                                        }
                                        if (newModel["CurrentDate"] == newModel["WeekStartDate"]) {
                                            headersubtopic2 = newModel["CurrentDate"];
                                        }
                                        else {
                                            headersubtopicfrom2 = newModel["WeekStartDate"];
                                            headersubtopicto2 = newModel["CurrentDate"];
                                        }
                                        newModel["PayrollActualvsPlanTableList"].forEach(item => {

                                            if (item["Department"] == "Hourly") {
                                                item["Department"] = "FD Hourly";
                                            }

                                            departmentlist.push({ "Name": item["Department"] });

                                            if (userid == 402 && orgid == 402) {
                                                let payrollactualvsbudgethours = new PayrollActualvsBudgetHoursModelData();
                                                payrollactualvsbudgethours.ActualHoursMTD = item.ActualHoursMTD;
                                                payrollactualvsbudgethours.PlanHoursMTD = item.PlanHoursMTD;
                                                payrollactualvsbudgethours.OTHoursMTD = item.OTHoursMTD;
                                                if (item.VarianceHoursMTD < 0) {
                                                    payrollactualvsbudgethours.VarianceHoursMTD = (item.VarianceHoursMTD * -1);
                                                }
                                                else if (item.VarianceHoursMTD > 0) {

                                                    payrollactualvsbudgethours.VarianceHoursMTD = item.VarianceHoursMTD;

                                                }
                                                else {

                                                    payrollactualvsbudgethours.VarianceHoursMTD = item.VarianceHoursMTD;

                                                }
                                                payrollactualvsbudgethours.ActualPORHoursMTD = item.ActualPORHoursMTD;
                                                payrollactualvsbudgethours.PlanPORHoursMTD = item.PlanPORHoursMTD;
                                                if (item.VariancePORHoursMTD < 0) {
                                                    payrollactualvsbudgethours.VariancePORHoursMTD = (item.VariancePORHoursMTD * -1)
                                                }
                                                else if (item.VariancePORHoursMTD > 0) {

                                                    payrollactualvsbudgethours.VariancePORHoursMTD = item.VariancePORHoursMTD

                                                }
                                                else {

                                                    payrollactualvsbudgethours.VariancePORHoursMTD = item.VariancePORHoursMTD;
                                                }

                                                row.push(payrollactualvsbudgethours.setFormat(payrollactualvsbudgethours));




                                            } else {
                                                let payrollactualvsbudgethours = new PayrollActualvsBudgetHoursModelData();
                                                payrollactualvsbudgethours.ActualHours = item.ActualHours;
                                                payrollactualvsbudgethours.PlanHours = item.PlanHours;
                                                payrollactualvsbudgethours.OTHours = item.OTHours;

                                                if (item.VarianceHours < 0) {
                                                    payrollactualvsbudgethours.VarianceHours = -(item.VarianceHours * -1);
                                                }
                                                else if (item.VarianceHours > 0) {
                                                    payrollactualvsbudgethours.VarianceHours = item.VarianceHours;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.VarianceHours = item.VarianceHours;
                                                }

                                                if (isFinite(item.ActualPORHours)) {
                                                    payrollactualvsbudgethours.ActualPORHours = item.ActualPORHours;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.ActualPORHours = null;
                                                }

                                                if (isFinite(item.PlanPORHours)) {
                                                    payrollactualvsbudgethours.PlanPORHours = item.PlanPORHours;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.PlanPORHours = null;
                                                }

                                                if (!isFinite(item.VariancePORHours)) {
                                                    payrollactualvsbudgethours.VariancePORHours = null;
                                                }
                                                else if (item.VariancePORHours < 0) {
                                                    payrollactualvsbudgethours.VariancePORHours = -(item.VariancePORHours * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.VariancePORHours = item.VariancePORHours;
                                                }

                                                if (item.ActualHoursWTD < 0) {
                                                    payrollactualvsbudgethours.ActualHoursWTD = -(item.ActualHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.ActualHoursWTD = item.ActualHoursWTD;
                                                }

                                                if (item.PlanHoursWTD < 0) {
                                                    payrollactualvsbudgethours.PlanHoursWTD = -(item.PlanHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.PlanHoursWTD = item.PlanHoursWTD;
                                                }
                                                if (item.OTHoursWTD < 0) {
                                                    payrollactualvsbudgethours.OTHoursWTD = -(item.OTHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.OTHoursWTD = item.OTHoursWTD;
                                                }

                                                if (item.VarianceHoursWTD < 0) {
                                                    payrollactualvsbudgethours.VarianceHoursWTD = -(item.VarianceHoursWTD * -1);
                                                }
                                                else if (item.VarianceHoursWTD > 0) {
                                                    payrollactualvsbudgethours.VarianceHoursWTD = item.VarianceHoursWTD;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.VarianceHoursWTD = item.VarianceHoursWTD;
                                                }

                                                if (!isFinite(item.ActualPORHoursWTD)) {
                                                    payrollactualvsbudgethours.ActualPORHoursWTD = null;
                                                }
                                                else if (item.ActualPORHoursWTD < 0) {
                                                    payrollactualvsbudgethours.ActualPORHoursWTD = -(item.ActualPORHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.ActualPORHoursWTD = item.ActualPORHoursWTD;
                                                }


                                                if (!isFinite(item.PlanPORHoursWTD)) {
                                                    payrollactualvsbudgethours.PlanPORHoursWTD = null;
                                                }
                                                else if (item.PlanPORHoursWTD < 0) {
                                                    payrollactualvsbudgethours.PlanPORHoursWTD = -(item.PlanPORHoursWTD * -1);
                                                }
                                                else {
                                                    payrollactualvsbudgethours.PlanPORHoursWTD = item.PlanPORHoursWTD;
                                                }


                                                if (!isFinite(item.VariancePORHoursWTD)) {
                                                    payrollactualvsbudgethours.VariancePORHoursWTD = null;
                                                }
                                                else if (item.VariancePORHoursWTD < 0) {
                                                    payrollactualvsbudgethours.VariancePORHoursWTD = -(item.VariancePORHoursWTD * -1);
                                                }
                                                else if (item.VariancePORHoursWTD > 0) {
                                                    payrollactualvsbudgethours.VariancePORHoursWTD = item.VariancePORHoursWTD;
                                                }
                                                else {
                                                    payrollactualvsbudgethours.VariancePORHoursWTD = item.VariancePORHoursWTD;
                                                }
                                                row.push(payrollactualvsbudgethours.setFormat(payrollactualvsbudgethours));
                                            }

                                        })
                                        let y = new Promise((resolve,reject)=>{
                                            LaborHelper.GetActiveOrganisationList((err, result) => {
                
                                                let users = result;
                
                                                if (users != null && users.length > 0) {
                                                    
                                                    let matches = _.find(users, { OranizationId: orgid });
                                                  
                                                    if (matches != null) {
                
                                                        IsHotelEffectiveness = true;
                
                                                        resolve(IsHotelEffectiveness)
                
                                                    }else{
                                                        resolve(IsHotelEffectiveness)
                                                    }
                
                                                }else{
                                                    resolve(IsHotelEffectiveness)
                                                }
                                            });
                                        })
                                        y.then(IsHotelEffectiveness=>{
                                            cd(null, [{
                                                "IsHotelEffectiveness": IsHotelEffectiveness,
                                                "MonthStartDate": DisplayMTDDate,
                                                "CurrentDate": DisplayCurrentDate,
                                                "headertopic1": headertopic1,
                                                "headertopic2": headertopic2,
                                                "headersubtopic1": Utils.getFormattedDate(headersubtopic1, 'MM/DD dddd'),
                                                "headersubtopicfrom2": Utils.getFormattedDate(headersubtopicfrom2, 'MM/DD dddd'),
                                                "headersubtopicto2": Utils.getFormattedDate(headersubtopicto2, 'MM/DD dddd'),
                                                "departmentlist": departmentlist,
                                                "payrollactualvsplanbudgethours": row
                                            }])
                                        })



                                    } else {
                                        let y = new Promise((resolve,reject)=>{
                                            LaborHelper.GetActiveOrganisationList((err, result) => {
                
                                                let users = result;
                
                                                if (users != null && users.length > 0) {
                                                    
                                                    let matches = _.find(users, { OranizationId: orgid });
                                                  
                                                    if (matches != null) {
                
                                                        IsHotelEffectiveness = true;
                
                                                        resolve(IsHotelEffectiveness)
                
                                                    }else{
                                                        resolve(IsHotelEffectiveness)
                                                    }
                
                                                }else{
                                                    resolve(IsHotelEffectiveness)
                                                }
                                            });
                                        })
                                        y.then(IsHotelEffectiveness=>{
                                            cd(null, [{
                                                "IsHotelEffectiveness": IsHotelEffectiveness,
                                                "MonthStartDate": DisplayMTDDate,
                                                "CurrentDate": DisplayCurrentDate,
                                                "headertopic1": headertopic1,
                                                "headertopic2": headertopic2,
                                                "headersubtopic1": Utils.getFormattedDate(headersubtopic1, 'MM/DD dddd'),
                                                "headersubtopicfrom2": Utils.getFormattedDate(headersubtopicfrom2, 'MM/DD dddd'),
                                                "headersubtopicto2": Utils.getFormattedDate(headersubtopicto2, 'MM/DD dddd'),
                                                "departmentlist": departmentlist,
                                                "payrollactualvsplanbudgethours": row
                                            }])
                                        })                                        

                                    }




                                })
                            }

                        })

                    })
                }

            })
        })

    }
    static GetPayrollActualvsPlanBudgetHours_GraphQL(userid, hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, cd) {
        Hotelshelper.getHotelDataByCMPID(hotelId, (err, hoteldata) => {
            if (err) {
                cd(err, null);
            }
            if (!hoteldata) {
                cd(Constants.HotelNotFound, null);
            }
            else {
                LaborHelper.GetPayrollActualvsPlanBudgetHours(userid, [hoteldata][0].ID, period, currentDate, laborsection1, laborsection2, laborwidgetday, (err, result) => {
                    if (err) {
                        cd(err, null)
                    }
                    cd(null, result)
                })
            }
        })

    }
    static GetPayrollActualvsPlanBudget_GraphQL(userid, hotelId, currentDate, laborsection1, laborsection2, laborwidgetday, cd) {
        //get myp hotelid from cmp_id
        Hotelshelper.getHotelDataByCMPID(hotelId, (err, hoteldata) => {
            if (err) {
                cd(err, null);
            }
            if (!hoteldata) {
                cd(Constants.HotelNotFound, null);
            }
            else {
                LaborHelper.GetPayrollActualvsPlanBudget(userid, [hoteldata][0].ID, currentDate, laborsection1, laborsection2, laborwidgetday, (err, result) => {
                    if (err) {
                        cd(err, null)
                    }
                    cd(null, result)
                })
            }
        });

    }
    static GetPayrollActualvsPlanBudget(userid, hotelId, currentDate, laborsection1, laborsection2, laborwidgetday, cd) {
       
        let y = new Promise((resolve, reject) => {
            HotelsSchema.find({ [HotelsSchemaFields.ID]: hotelId }, (err, hoteldata) => {
                resolve(hoteldata)           
            })
        })

        y.then(hoteldata => {

            LaborHelper.GetPayrollActualvsPlanBudgetCal(hoteldata[0]['OrganizationID'],userid, hotelId, currentDate, laborsection1, laborsection2, laborwidgetday, (err, result) => {
                cd(null, result)
            })
        })

    }

    static GetPayrollActualvsPlanBudgetHours(userid, hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, cd) {
        let y = new Promise((resolve, reject) => {
            HotelsSchema.find({ [HotelsSchemaFields.ID]: hotelId }, (err, hoteldata) => {
                resolve(hoteldata)           
            })
        })

        y.then(hoteldata => {
            LaborHelper.GetPayrollActualvsPlanBudgetHoursCal(hoteldata[0]['OrganizationID'], userid, hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, (err, result) => {
                cd(null, result)
            })
        })
    }

    static GetPayrollActualvsPlanTableData(hotelId, date, WeekStartDate, cd) {
        let PayrollActualvsPlanModelList = [];
        let roomRevenueList;
        let hotelofroom;
        let roomRevenueListWeek;
        let noofroomsoldweek;
        let hotelBudgetroomsold1;
        let sdate = Utils.firstDayOfMonth(date);
        let edate = Utils.lastDayOfMonth(date);
        let sweekdate = WeekStartDate;
        let hotelBudgetroomsold;
        let roomRevenueListMonth;


        return Promise.all([
            new Promise((resolve, reject) => {
                HoteleffectivenesscalculationsSchema.find(
                    {
                        [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                        [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: date, $lte: date }
                    }

                ).exec((err, result) => {
                    if (err) {
                        reject(err);
                    }

                    roomRevenueList = result;
                    resolve();
                })
            }), new Promise((resolve, reject) => {
                HoteldashboardcalculationsHelper.GetPayrollHouseKeepingData(hotelId, date, (err, result) => {
                    if (err) {
                        reject(err);
                    }

                    hotelofroom = result;
                    resolve();
                })
            }), new Promise((resolve, reject) => {
                HotelbudgetHelper.GetPayrollActualvsPlanTableData(hotelId, date, (err, result) => {
                    if (err) {
                        reject(err);
                    }

                    hotelBudgetroomsold = result;
                    resolve();
                })
            })
        ]).then(resp => {

            let days = Utils.getDaysinMonth(date.getFullYear(), date.getMonth());

            if (hotelBudgetroomsold.length > 0) {

                hotelBudgetroomsold.forEach(element => {
                    hotelBudgetroomsold = element.TotalNumberofBudgetedRoomsSold;
                });

            } else {
                hotelBudgetroomsold = 0;
            }

            if (hotelBudgetroomsold > 0) {
                hotelBudgetroomsold = hotelBudgetroomsold / days;
            }
            else {
                hotelBudgetroomsold = 0;
            }

            if (hotelofroom.length > 0) {
                hotelofroom.forEach(element => {
                    hotelofroom = element.NoOfRoomSold;
                })
            } else {
                hotelofroom = 0;
            }



            roomRevenueList.forEach(key => {
                let payrollActualvsPlanModel = new PayrollActualvsBudgetHoursModelData();
                payrollActualvsPlanModel.PlanHours = key.PlanHours == null ? 0 : key.PlanHours.toFixed(2);
                payrollActualvsPlanModel.ActualHours = key.Hours == null ? 0 : key.Hours.toFixed(2);


                payrollActualvsPlanModel.PlanPORHours = key.PlanHours == null || hotelBudgetroomsold == 0 ? 0 : key.PlanHours.Value / hotelBudgetroomsold;
                payrollActualvsPlanModel.ActualPORHours = key.Hours == null || hotelofroom == 0 ? 0 : key.Hours / hotelofroom;

                payrollActualvsPlanModel.VarianceHours = payrollActualvsPlanModel.PlanHours - payrollActualvsPlanModel.ActualHours;
                payrollActualvsPlanModel.VariancePORHours = payrollActualvsPlanModel.PlanPORHours - payrollActualvsPlanModel.ActualPORHours;

                payrollActualvsPlanModel.Department = key.Department;
                payrollActualvsPlanModel.Date = key.Date;
                payrollActualvsPlanModel.HotelID = key.HotelID;

                PayrollActualvsPlanModelList.push(payrollActualvsPlanModel);
            })
            return Promise.all([
                new Promise((resolve, reject) => {
                    HoteleffectivenesscalculationsSchema.find(
                        {
                            [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                            [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: sweekdate, $lte: date }
                        }

                    ).exec((err, result) => {
                        if (err) {
                            reject(err);
                        }

                        roomRevenueListWeek = result;
                        resolve();
                    })
                }),
                new Promise((resolve, reject) => {
                    HoteldashboardcalculationsHelper.GetPayrollHouseKeepingDataSweekDate(hotelId, sweekdate, date, (err, result) => {
                        if (err) {
                            reject(err);
                        }

                        noofroomsoldweek = result;
                        resolve();
                    })
                }),
                new Promise((resolve, reject) => {
                    HotelbudgetHelper.GetPayrollActualvsPlanTableDataSweekDate(hotelId, sweekdate, date, (err, result) => {
                        if (err) {
                            reject(err);
                        }

                        hotelBudgetroomsold1 = result;
                        resolve();
                    })

                })
            ]).then(resp => {
                let totalnoroomsold = 0;

                if (noofroomsoldweek != null && noofroomsoldweek.length > 0) {
                    totalnoroomsold = _.sumBy(noofroomsoldweek, 'NoOfRoomSold');
                }

                if (hotelBudgetroomsold1 != null && hotelBudgetroomsold1.length > 0) {
                    _.filter(hotelBudgetroomsold1, function (data) {
                        hotelBudgetroomsold1 = data.TotalNumberofBudgetedRoomsSold
                    })
                }

                if (hotelBudgetroomsold1 > 0) {
                    hotelBudgetroomsold1 = hotelBudgetroomsold1 / days;
                }
                else {
                    hotelBudgetroomsold1 = 0;
                }
                let totaldays = Utils.dateDiffInDays(date, sweekdate) + 1;

                if (totaldays > 1 && hotelBudgetroomsold1 > 0) {
                    hotelBudgetroomsold1 = hotelBudgetroomsold1 * totaldays;
                }
                PayrollActualvsPlanModelList.forEach(element => {
                    let matches = _.find(roomRevenueListWeek, { Department: element.Department });

                    if (matches != null && [matches].length > 0) {
                        element.ActualHoursWTD = _.sumBy([matches], 'Hours');
                        element.OTHoursWTD = _.sumBy([matches], 'OTHours');
                        element.PlanHoursWTD = _.sumBy([matches], 'PlanHours');
                        element.PlanPORHoursWTD = hotelBudgetroomsold1 == 0 ? 0 : _.sumBy([matches], 'PlanHours') / hotelBudgetroomsold1;
                        element.ActualPORHoursWTD = totalnoroomsold == 0 ? 0 : _.sumBy([matches], 'Hours') / totalnoroomsold;

                        element.VarianceHoursWTD = element.PlanHoursWTD - element.ActualHoursWTD;
                        element.VariancePORHoursWTD = element.PlanPORHoursWTD - element.ActualPORHoursWTD;
                    }
                })

                return new Promise((resolve, reject) => {
                    HoteleffectivenesscalculationsSchema.find(
                        {
                            [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelId,
                            [HoteleffectivenesscalculationsSchemaFields.Date]: { $gte: date, $lte: date }
                        }
                    ).exec((err, result) => {
                        if (err) {
                            reject(err);
                        }

                        roomRevenueListMonth = result;
                        resolve();
                    })
                }).then(resp => {
                    PayrollActualvsPlanModelList.forEach(element => {
                        let matches = _.find(roomRevenueListMonth, { Department: element.Department });
                        if (matches != null && [matches].length > 0) {
                            element.ActualHoursMTD = _.sumBy([matches], 'Hours');
                            element.OTHoursMTD = _.sumBy([matches], 'OTHours');
                            element.PlanHoursMTD = _.sumBy([matches], 'PlanHours');
                            element.ActualPORHoursMTD = _.sumBy([matches], 'Hours');
                            element.PlanPORHoursMTD = _.sumBy([matches], 'PlanHours');
                            element.VarianceHoursMTD = element.PlanHoursMTD - element.ActualHoursMTD;
                            element.VariancePORHoursMTD = element.PlanPORHoursMTD - element.ActualPORHoursMTD;
                        }
                    })

                    if (PayrollActualvsPlanModelList != null && PayrollActualvsPlanModelList.length > 0) {
                        let payrollActualvsPlanModel = new PayrollActualvsBudgetHoursModelData();

                        payrollActualvsPlanModel.PlanHours = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.PlanHours);
                        });
                        payrollActualvsPlanModel.PlanPORHours = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.PlanPORHours);
                        });
                        payrollActualvsPlanModel.ActualHours = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.ActualHours);
                        });

                        payrollActualvsPlanModel.OTHours = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.OTHours);
                        });
                        payrollActualvsPlanModel.ActualPORHours = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.ActualPORHours);
                        });
                        payrollActualvsPlanModel.PlanHoursWTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.PlanHoursWTD);
                        });
                        payrollActualvsPlanModel.PlanPORHoursWTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.PlanPORHoursWTD);
                        });
                        payrollActualvsPlanModel.ActualHoursWTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.ActualHoursWTD);
                        });
                        payrollActualvsPlanModel.OTHoursWTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.OTHoursWTD);
                        });

                        payrollActualvsPlanModel.ActualPORHoursWTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.ActualPORHoursWTD);
                        });
                        payrollActualvsPlanModel.PlanHoursMTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.PlanHoursMTD);
                        });
                        payrollActualvsPlanModel.PlanPORHoursMTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.PlanPORHoursMTD);
                        });
                        payrollActualvsPlanModel.ActualHoursMTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.ActualHoursMTD);
                        });
                        payrollActualvsPlanModel.ActualPORHoursMTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.ActualPORHoursMTD);
                        });
                        payrollActualvsPlanModel.OTHoursMTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.OTHoursMTD);
                        });

                        payrollActualvsPlanModel.VarianceHours = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.VarianceHours);
                        });
                        payrollActualvsPlanModel.VariancePORHours = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.VariancePORHours);
                        });
                        payrollActualvsPlanModel.VarianceHoursWTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.VarianceHoursWTD);
                        });
                        payrollActualvsPlanModel.VariancePORHoursWTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.VariancePORHoursWTD);
                        });
                        payrollActualvsPlanModel.VarianceHoursMTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.VarianceHoursMTD);
                        });
                        payrollActualvsPlanModel.VariancePORHoursMTD = _.sumBy(PayrollActualvsPlanModelList, function (data) {
                            return parseFloat(data.VariancePORHoursMTD);
                        });



                        payrollActualvsPlanModel.Department = "Total";

                        PayrollActualvsPlanModelList.push(payrollActualvsPlanModel);

                    }

                    cd(null, PayrollActualvsPlanModelList)

                })


            })

        })

    }



    static GetConfigs_GraphQL(userid, cd) {

        UserHelper.getUserConfigData(userid, (err, result) => {
            if (err) {
                cd(err, null);
            }
            var objLaborconfigdata = new Laborconfigdata();
            objLaborconfigdata.userid = userid;
            if (result) {
                if (result.LaborSection1 != null) {
                    objLaborconfigdata.laborsection1 = result.LaborSection1;
                }
                if (result.LaborSection2 != null) {
                    objLaborconfigdata.laborsection2 = result.LaborSection2;
                }
                objLaborconfigdata.payrolldepartmentwise = result.PayrollDepartmentWise;
                objLaborconfigdata.payrollvsrevenuevsocc = result.PayrollVsRevenueVsOcc;
                objLaborconfigdata.actualvspayrollchart = result.ActualVsPayrollChart;
                objLaborconfigdata.housekeepingwidget = result.HouseKeepingWidget;
                objLaborconfigdata.payrollactualvsplanhourswidget = result.PayrollActualvsPlanHoursWidget;
                objLaborconfigdata.payrollactualvsplanwageswidget = result.PayrollActualvsPlanWagesWidget;
                objLaborconfigdata.defaultweekday = result.DefaultWeekDay;
            }
            cd(null, objLaborconfigdata);
        });
    }
    static SaveConfigs_GraphQL(userid, laborsection1, laborsection2, payrolldepartmentwise, payrollvsrevenuevsocc,
        actualvspayrollchart, housekeepingwidget, payrollactualvsplanhourswidget,
        payrollactualvsplanwageswidget, defaultweekday, cd) {

        UserHelper.getUserConfigData(userid, (err, result) => {
            if (err) {
                cd(err, null);
            }
            var objLaborconfigdata = new Laborconfigdata();
            objLaborconfigdata.userid = userid;
            if (laborsection1 != null) {
                objLaborconfigdata.laborsection1 = laborsection1;
            }
            if (laborsection2 != null) {
                objLaborconfigdata.laborsection2 = laborsection2;
            }
            objLaborconfigdata.payrolldepartmentwise = payrolldepartmentwise;
            objLaborconfigdata.payrollvsrevenuevsocc = payrollvsrevenuevsocc;
            objLaborconfigdata.actualvspayrollchart = actualvspayrollchart;
            objLaborconfigdata.housekeepingwidget = housekeepingwidget;
            objLaborconfigdata.payrollactualvsplanhourswidget = payrollactualvsplanhourswidget;
            objLaborconfigdata.payrollactualvsplanwageswidget = payrollactualvsplanwageswidget;
            objLaborconfigdata.defaultweekday = defaultweekday;
            UserHelper.saveUserConfigData_Labor(objLaborconfigdata, (err, save_result) => {
                if (err) {
                    cd(err, null);
                }

                //move it to SQL server as well for sync
                if (config.appsettings.sync_to_SQLServer) {

                    //db write to SQL server and sync will handle the data in mangodb
                    var json_postdata = [];
                    json_postdata.userid = userid;
                    json_postdata.LaborSection1 = objLaborconfigdata.laborsection1;
                    json_postdata.LaborSection2 = objLaborconfigdata.laborsection2;
                    json_postdata.PayrollDepartmentWise = objLaborconfigdata.payrolldepartmentwise;
                    json_postdata.PayrollVsRevenueVsOcc = objLaborconfigdata.payrollvsrevenuevsocc;
                    json_postdata.ActualVsPayrollChart = objLaborconfigdata.actualvspayrollchart;
                    json_postdata.HouseKeepingWidget = objLaborconfigdata.housekeepingwidget;
                    json_postdata.PayrollActualvsPlanHoursWidget = objLaborconfigdata.payrollactualvsplanhourswidget;
                    json_postdata.PayrollActualvsPlanWagesWidget = objLaborconfigdata.payrollactualvsplanwageswidget;
                    json_postdata.DefaultWeekDay = objLaborconfigdata.defaultweekday;
                    //Config/UpdateLaborConfig in SQL server
                    RESTHelper.POST(Constants.Urls.UpdateLaborConfig, json_postdata, (api_err, sync_result) => {
                        if (api_err)
                            log.error(api_err);
                        log.debug(sync_result);
                    });
                }

                cd(null, objLaborconfigdata);
            });
        });
    }
}

module.exports = LaborHelper;    
