const { Missingdatesmaster: MissingdatesmasterSchema, SchemaField: MissingdatesmasterSchemaFields } = require('../models/missingdatesmaster');

const Constants = require('../common/constants');

const Utils = require('../common/utils');

let log = require('log4js').getLogger("exclamation_helper");

const _ = require('lodash');
const moment = require('moment');

const Hotelshelper = require('./hotels_helper');
const MissingDatesHelper = require('./missingdates_helper');

const UserHelper = require('./user_helper');

const { Hotels: HotelsSchema, SchemaField: HotelsSchemaFields } = require('../models/hotels');

const HotelMissingDatesLinkView = require('../exclamation/models/missingdateslinkview');

const MissingDatesContentModel = require('../exclamation/models/missingdatescontent');

const HotelMissingDatesViewModel = require('../exclamation/models/hotelmissingdatesview');
const HotelMissingDatesLineItem = require('../exclamation/models/missinddateslineitem');



const dbtable = require('../schema/db_table');



class ExclamationHelper {

    static GetMissingDatesProperty(userid, hotelId, currentDate, period, cd) {
        let startDate = new Date();
        let endDate = new Date();
        let yesterday = new Date(currentDate);

        period = period.toLowerCase();

        if (period == "current" || period == null) {
            startDate = new Date(Utils.getFormattedDate(yesterday, "YYYY-MM-DD"));
            endDate = yesterday;
        }
        else if (period == "mtd") {
            startDate = Utils.firstDayOfMonth(yesterday);
            endDate = yesterday;
        }
        else if (period == "ytd") {
            startDate = Utils.firstDayOfYear(yesterday);
            endDate = yesterday;

        }
        else if (period == "ttm") {
            startDate = Utils.firstDayOfMonth(yesterday);
            startDate = Utils.lastYearDate(startDate);
            endDate = Utils.firstDayOfMonth(yesterday);
            endDate.setDate(startDate.getDate() - 1);

        }

        ExclamationHelper.GetMissingDates(hotelId, startDate, endDate, (err, result) => {
            cd(null, [result]);
        });




    }

    static GetMissingDates(hotelId, startDate, endDate, cd) {
        let retValue = new MissingDatesContentModel()
        let x = MissingdatesmasterSchema.aggregate();

        x.match({
            [MissingdatesmasterSchemaFields.HotelID]: hotelId,
            [MissingdatesmasterSchemaFields.Date]: {
                $gte: startDate,
                $lte: endDate
            }
        })
        let y = new Promise((resolve, reject) => {
            x.exec((err, roomRevenueList) => {
                resolve(roomRevenueList)
            })
        })

        let hotel;
        y.then(roomRevenueList => {
            if (roomRevenueList != null && roomRevenueList.length > 0) {

                if (hotelId != null && [hotelId].length == 1) {

                    hotel = new Promise((resolve, reject) => {
                        Hotelshelper.GetLaborHouseKeeping(hotelId, (err, hoteldata) => {
                            resolve(hoteldata)
                        })
                    })
                    hotel.then(hoteldata => {
                        let roomrevenuecat = Constants.MissingDates.RoomRevenue;
                        let otherRevenuecat = Constants.MissingDates.OtherRevenue;

                        let roomRevenuedata = [];
                        let FBOtherdata = [];

                        _.filter(roomRevenueList, function (key) {

                            if (key.Category == roomrevenuecat) {
                                roomRevenuedata.push(key);
                            };
                            if (key.Category == otherRevenuecat) {
                                FBOtherdata.push(key);
                            };
                        });

                        let link1;
                        let link2;
                        if (roomRevenuedata != null && roomRevenuedata.length > 0) {
                            link1 = new Promise((resolve, reject) => {
                                ExclamationHelper.DatesToStringWithoutLinkNew(roomRevenuedata, hotelId, (err, linkdata) => {
                                    resolve(linkdata)
                                });
                            })
                        }

                        if (link1 == undefined) {
                            let flag = false;
                            if (hoteldata != null) {
                                _.filter(hoteldata, (data) => {
                                    flag = data.IsMissingDateOtherRevenueEnabled;
                                })

                                if (flag == true) {

                                    if (FBOtherdata != null && FBOtherdata.length > 0) {
                                        link2 = new Promise((resolve, reject) => {
                                            ExclamationHelper.DatesToStringWithoutLinkNew(FBOtherdata, hotelId, (err, linkdata) => {
                                                resolve(linkdata)
                                            });
                                        })

                                        link2.then(linkdata => {
                                            retValue.OtherFNBRevenue = "Other/F&B Revenue" + linkdata;
                                            
                                        })

                                    }
                                }
                            }

                        } 
                        else if (link1.then != undefined && typeof link1.then === 'function') {
                            link1.then(linkdata => {
                                retValue.RoomRevenue = "Room Revenue<br/>" + linkdata;

                                let flag = false;
                                if (hoteldata != null) {
                                    _.filter(hoteldata, (data) => {
                                        flag = data.IsMissingDateOtherRevenueEnabled;
                                    })

                                    if (flag == true) {

                                        if (FBOtherdata != null && FBOtherdata.length > 0) {
                                            link2 = new Promise((resolve, reject) => {
                                                ExclamationHelper.DatesToStringWithoutLinkNew(FBOtherdata, hotelId, (err, linkdata) => {
                                                    resolve(linkdata)
                                                });
                                            })

                                            link2.then(linkdata => {
                                                retValue.OtherFNBRevenue = "Other/F&B Revenue <br/>" + linkdata;
                                            })

                                        }
                                    }
                                }

                            })


                        }
                        cd(null, retValue)
                    })

                }

            } else {
                cd(null, retValue)
            }
        })
    }

    static DatesToStringWithoutLinkNew(roomRevenuedata, hotelId, cd) {

        let retValue = '';

        if (roomRevenuedata != null && roomRevenuedata.length > 0) {


            let temp = [];
            _.filter(roomRevenuedata, (key) => {
                if (typeof key['OriginalDate'] == "undefined") {
                    key['OriginalDate'] = key.Date;
                    key.Date = Utils.getFormattedDate(key.Date, "MMM");
                }
                temp.push(key)
            })

            temp = _.groupBy(temp, "Date")



            _.filter(temp, (element) => {

                retValue = retValue + element[0].Date + "-";
                _.filter(element, (key) => {
                    retValue = retValue + Utils.getFormattedDate(key.OriginalDate, "DD") + ",";
                })
            })
            cd(null, retValue)
        }
    }

    static getHotelMissingDates_GraphQL(userid, hotelIds, currentdate, period, startDate, cd) {
        UserHelper.getUserData(userid, (err, userconfigdata) => {
            if (err) {
                cd(err,null);
            }

            ExclamationHelper.getMissingDates(hotelIds, currentdate, userconfigdata, period, startDate, (err, result) => {
                cd(null, result)
            })
        })
    }

    static getHotelMissingDates_v2_GraphQL(userid, hotelIds, currentdate, period, startDate, cd) {
        UserHelper.getUserData(userid, (err, userconfigdata) => {
            if (err) {
                cd(err,null);
            }

            ExclamationHelper.getMissingDates_V2(hotelIds, currentdate, userconfigdata, period, startDate, (err, result) => {
                cd(null, result)
            })
        })
    }
    static getMissingDates(hotelid, currentdate, userconfigdata, period, startdate, cd) {

        let hotelidList = hotelid.split(',');
        let x = [];
        let array = [];

        ExclamationHelper.gethotelmissingdateslistwithlinks(hotelidList, currentdate, period, startdate, (err, result) => {
            cd(null, result)
        });
    }



    static gethotelmissingdateslistwithlinks(hotelid, currentdate, period, startdate, cd) {
        let HotelList = [];
        let strperiod = period;
        strperiod = (strperiod.toLowerCase() == "current" ? "MTD" : strperiod);

        period = period.toLowerCase();

        let customDate;
        if (startdate != null && period == "custom") {
            customDate = new Date(Utils.getFormattedDate(startdate, "YYYY-MM-DD"));
        }

        let cDate = new Date(Utils.getFormattedDate(currentdate, "YYYY-MM-DD"));


        let activeHotelList = [];
        _.filter(hotelid, (id) => {
            let y = new Promise((resolve, reject) => {
                HotelsSchema.find({
                    [HotelsSchemaFields.ID]: id,
                    [HotelsSchemaFields.IsActive]: true
                }, [HotelsSchemaFields.ID, HotelsSchemaFields.IsMissingDateOtherRevenueEnabled], (err, hotelid) => {
                    resolve(hotelid)
                })
            })
            activeHotelList.push(y)
        })
        Promise.all(activeHotelList).then(hotelid => {
            _.filter(hotelid, (key) => {
                _.filter(key, (i) => {
                    HotelList.push(i)
                })
            })

            let yesterday = currentdate;
            let startDate;
            let endDate;

            if (period == "mtd") {
                startDate = Utils.firstDayOfMonth(yesterday);
                endDate = yesterday;
            }
            else if (period == "ytd") {
                startDate = Utils.firstDayOfYear(yesterday);
                endDate = yesterday;

            }
            else if (period == "ttm") {
                startDate = Utils.firstDayOfMonth(yesterday);
                startDate = Utils.lastYearDate(startDate);
                endDate = Utils.firstDayOfMonth(yesterday);
                endDate.setDate(startDate.getDate() - 1);

            }
            else if (period == "current") {
                startDate = yesterday;
                endDate = yesterday;
            }
            else if (period == "custom") {
                startDate = Utils.firstDayOfMonth(customDate);
                endDate = yesterday;
            }

            startDate = new Date(Utils.getFormattedDate(startDate, "YYYY-MM-DD"));
            endDate = new Date(Utils.getFormattedDate(endDate, "YYYY-MM-DD"));

            let revenuedatalist = [];
            let otherfandbdata = [];
            let hotelmissingdatesList = [];
            let hotelIDList = [];

            _.filter(HotelList, (hoteldata, index) => {
                /*********************TO DO*******************************/
                if (index <= 100) {
                    /*********************TO DO*******************************/
                    hotelIDList.push(hoteldata.ID);
                    (hoteldata.IsMissingDateOtherRevenueEnabled ? otherfandbdata.push(true) : otherfandbdata.push(false))
                    let y = new Promise((resolve, reject) => {
                        MissingdatesmasterSchema.find({
                            [MissingdatesmasterSchemaFields.HotelID]: hoteldata.ID,
                            [MissingdatesmasterSchemaFields.Date]: {
                                $gte: startDate,
                                $lte: endDate
                            }
                        }, (err, revenuedata) => {
                            if (err) {
                                log.error(err);
                                reject(err)
                            }

                            resolve(revenuedata);
                        })
                    })
                    revenuedatalist.push(y)
                }
            })

            let color = 'orange';
            Promise.all(revenuedatalist).then(revenuedata => {

                let output = [];
                _.filter(revenuedata, (key, index) => {

                    if (key.length == 0) {
                        let hotelmissingdates = new HotelMissingDatesViewModel();
                        hotelmissingdates.StrMissingDates = [];
                        hotelmissingdates.Type = color;
                        hotelmissingdates.HotelID = (hotelIDList[index] == null ? 0 : hotelIDList[index]);
                        hotelmissingdatesList.push(hotelmissingdates)
                    } else {
                        output = [];

                        _.filter(key, (element) => {
                            if (element.Category == "Room Revenue") {

                                let datelink = new HotelMissingDatesLinkView();
                                datelink.Section = "Room Revenue";
                                let x = new Date(1900, element.Date.getMonth(), 1);
                                datelink.Month = Utils.getFormattedDate(Utils.convertLocalTimeCST(x), "MMM") + "-";
                                datelink.Link = element.Date.getDate();
                                output.push(datelink)
                            }

                            if (otherfandbdata[index]) {

                                if (element.Category == "Other/F&B Revenue") {

                                    let datelink = new HotelMissingDatesLinkView();
                                    datelink.Section = "Other/F&B Revenue";
                                    let x = new Date(1900, element.Date.getMonth(), 1)
                                    datelink.Month = Utils.getFormattedDate(Utils.convertLocalTimeCST(x), "MMM") + "-";
                                    datelink.Link = element.Date.getDate();
                                    output.push(datelink)

                                }
                            }
                        })

                        color = 'red';

                        let hotelmissingdates = new HotelMissingDatesViewModel();
                        hotelmissingdates.StrMissingDates = output;
                        hotelmissingdates.Type = color;
                        hotelmissingdates.HotelID = (hotelIDList[index] == null ? 0 : hotelIDList[index]);
                        hotelmissingdatesList.push(hotelmissingdates)
                    }
                })
                cd(null, hotelmissingdatesList)
            })

        })

    }

    static getMissingDates_V2(hotelid, currentdate, userconfigdata, period, startdate, cd) {

        let hotelidList = hotelid.split(',');
        let x = [];
        let array = [];

        ExclamationHelper.gethotelmissingdateslistwithlinks_V2(hotelidList, currentdate, period, startdate, (err, result) => {
            cd(null, result)
        });
    }


    static gethotelmissingdateslistwithlinks_V2(hotelids, currentdate, period, startdate, cd) {

        let hotelsData = [];
        let HotelMissingDatesData = [];
        let strperiod = period;
        //strperiod = (strperiod.toLowerCase() == "current" ? "mtd" : strperiod);

        let output = [];

        let customDate;
        if (startdate != null && period == "custom") {
            customDate = new Date(Utils.getFormattedDate(startdate, "YYYY-MM-DD"));
        }


        let yesterday = new Date(currentdate);
        let startDate = yesterday;
        let endDate = yesterday;

        if (strperiod == "mtd") {
            startDate = Utils.firstDayOfMonth(yesterday);
            endDate = yesterday;
        }
        else if (strperiod == "ytd") {
            startDate = Utils.firstDayOfYear(yesterday);
            endDate = yesterday;

        }
        else if (strperiod == "ttm") {
            startDate = Utils.firstDayOfMonth(yesterday);
            startDate = Utils.lastYearDate(startDate);
            endDate = Utils.firstDayOfMonth(yesterday);
            endDate.setDate(startDate.getDate() - 1);

        }
        else if (strperiod == "custom") {
            startDate = Utils.firstDayOfMonth(customDate);
            endDate = yesterday;
        }

        startDate = new Date(Utils.getFormattedDate(startDate, "YYYY-MM-DD"));
        endDate = new Date(Utils.getFormattedDate(endDate, "YYYY-MM-DD"));

        return Promise.all([
            new Promise((resolve, reject) => {
                // get missing dates data
                MissingDatesHelper.getMissingDates(hotelids, startDate, endDate, (err, result) => {
                    if (err) {
                        reject(err);
                    }
                    if (result) {
                        HotelMissingDatesData = result;
                    }
                    resolve();
                });
            }),
            new Promise((resolve, reject) => {
                // get hotels data
                Hotelshelper.GetHotelsData(hotelids, (err, hotels_result) => {
                    if (err) {
                        reject(err);
                    }
                    if (hotels_result) {
                        hotelsData = hotels_result;
                    }
                    resolve();
                });
            }),
        ]).then(resp => {

            hotelsData.forEach(function (item) {

                let filterhoteldata = HotelMissingDatesData.filter(d => {
                    return (d.HotelID == item.ID);
                });
                if (filterhoteldata) {

                    if (filterhoteldata.length > 0) {

                        let datelink = new HotelMissingDatesLineItem();
                        datelink.HotelID = item.ID;
                        var datesHTMLOutput = '';
                        let roomRevenuedata = filterhoteldata.filter(d => {
                            return (d.Category == "Room Revenue");
                        });
                        if (roomRevenuedata) {

                            if (roomRevenuedata.length > 0) {

                                var roomRevenuedataresult = _.chain(roomRevenuedata)
                                    .groupBy(function (data) {
                                        return moment(data.Date).startOf('month').format('YYYY/MM');
                                    })
                                    .map(function (group, month) {
                                        return {
                                            month: month,
                                            times: group
                                        }
                                    })
                                    .value();

                                if (roomRevenuedataresult && roomRevenuedataresult.length > 0) {


                                    datesHTMLOutput = 'Room Revenue <br/>';
                                    roomRevenuedataresult.forEach(function (element) {

                                        let x = new Date(element.month + "/01");
                                        datesHTMLOutput += Utils.getFormattedDate(Utils.convertLocalTimeCST(x), "MMM") + "-";

                                        var lstdays = Utils.sort(element.times, "Date");
                                        lstdays.forEach(function (elementinner) {
                                            datesHTMLOutput += elementinner.Date.getDate() + ",";
                                        });
                                        datesHTMLOutput = datesHTMLOutput.replace(/,$/, ''); // right trim
                                        datesHTMLOutput += " <br/>";
                                    });
                                    datelink.Type = Constants.Colors.Red;

                                }

                            }
                        }

                        if (item.IsMissingDateOtherRevenueEnabled) {

                            let otherRevenuedata = filterhoteldata.filter(d => {
                                return (d.Category == "Other/F&B Revenue");
                            });

                            if (otherRevenuedata) {

                                if (otherRevenuedata.length > 0) {

                                    var otherRevenuedataresult = _.chain(otherRevenuedata)
                                        .groupBy(function (data) {
                                            return moment(data.Date).startOf('month').format('YYYY/MM');
                                        })
                                        .map(function (group, month) {
                                            return {
                                                month: month,
                                                times: group
                                            }
                                        })
                                        .value();


                                    if (otherRevenuedataresult && otherRevenuedataresult.length > 0) {

                                        datesHTMLOutput += 'Other/F&B Revenue <br/>';
                                        otherRevenuedataresult.forEach(function (element) {

                                            let x = new Date(element.month + "/01");
                                            datesHTMLOutput += Utils.getFormattedDate(Utils.convertLocalTimeCST(x), "MMM") + "-";
                                            var lstdays = Utils.sort(element.times, "Date");
                                            lstdays.forEach(function (elementinner) {
                                                datesHTMLOutput += elementinner.Date.getDate() + ",";
                                            });
                                            datesHTMLOutput = datesHTMLOutput.replace(/,$/, ''); // right trim
                                            datesHTMLOutput += " <br/>";
                                        });
                                        if (datelink.Type != Constants.Colors.Red) {
                                            datelink.Type = Constants.Colors.Orange;
                                        };
                                    }

                                }
                            }
                        }

                        datelink.HTMLOutput = datesHTMLOutput;
                        output.push(datelink);
                    }
                }

            });
            cd(null, output);

        }, err => {
            return cd(err);
        })
    }

}

module.exports = ExclamationHelper;
