const Constants = require('../common/constants');
const Utils = require('../common/utils');
const HttpMsg = require('../common/constants');
const KPIData = require('../customkpi/models/kpidata')
const SequenceHelper = require('../helpers/sequence_helper')
const RESTHelper = require('../helpers/rest_helper')
const config = require('../../appsettings.js');

const { Createowntablemappingmaster: CreateowntablemappingmasterSchema, SchemaField: CreateowntablemappingmasterSchemaFields } = require('../models/createowntablemappingmaster');
const { Createowntablemapping: CreateowntablemappingSchema, SchemaField: CreateowntablemappingSchemaFields } = require('../models/createowntablemapping');

var log = require('log4js').getLogger("CustomKPIHelper");

class CustomKPIHelper {

    static IsExistKPI(id, kpiname, orgId, cb) {

        return CreateowntablemappingmasterSchema.findOne({ [CreateowntablemappingmasterSchemaFields.ID]: { $ne: id }, [CreateowntablemappingmasterSchemaFields.KPIKey]: kpiname, [CreateowntablemappingmasterSchemaFields.OrganizationId]: orgId }, (err, kpi) => {
            if (err) {
                log.error(err);
            }
            if (!kpi && kpi !== null) {
                return cb(HttpMsg.kpiAlreadyExist, null);
            }
            cb(null, kpi);
        });
    }

    static getKPILookups(cb) {
        var lstKPI = [];
        return CreateowntablemappingmasterSchema.aggregate(
            [{ $match: { [CreateowntablemappingmasterSchemaFields.TableName]: "Consolidated Report" } }]
        ).exec((err, kpi) => {
            if (err) {
                log.error(err);
            }
            if (kpi.length <= 0) {
                return cb('kpinotfound', null);
            }
            else {
                kpi.forEach((element, index) => {
                    lstKPI.push({ kpikey: element.KPIKey,columname: element.ColumName });
                });
                cb(null, lstKPI);
            }
        })
        //  CreateowntablemappingmasterSchema.distinct("ColumName", { "TableName": "Consolidated Report" }, (err, kpi) => {
        //     if (err) {
        //         log.error(err);
        //     }
        //     if (kpi.length <= 0) {
        //         return cb('kpinotfound', null);
        //     }
        //     else {
        //         kpi.forEach((element, index) => {
        //             lstKPI.push({ kpiname: element });
        //         });
        //         cb(null, lstKPI);
        //     }
        // });
    }
    static getCustomKPIByOrgId(orgId, cb) {
        var lstKPIData = [];
        return CreateowntablemappingmasterSchema.find({
            $and: [
                { [CreateowntablemappingmasterSchemaFields.TableName]: "Consolidated Report" },
                { [CreateowntablemappingmasterSchemaFields.OrganizationId]: orgId },
            ]
        }, (err, kpi) => {
            if (err) {
                log.error(err);
            }
            if (kpi.length <= 0) {
                return cb('kpinotfound', null);
            }
            else {
                kpi.forEach((element, index) => {
                    var kpiData = new KPIData();
                    kpiData.id = element.ID,
                        kpiData.tablename = element.TableName,
                        kpiData.columname = element.ColumName,
                        kpiData.displayorder = element.DisplayOrder,
                        kpiData.kpikey = element.KPIKey,
                        kpiData.parentkey = element.ParentKey,
                        kpiData.hassubkey = element.HasSubKey,
                        kpiData.kpiformula = element.KPIFormula,
                        kpiData.unit = element.Unit,
                        kpiData.organizationid = element.OrganizationId,
                        kpiData.iscustom = element.IsCustom
                    lstKPIData.push(kpiData);
                });
                cb(null, lstKPIData);
            }

        });
    }
    static getCustomKPIIncludingSuperAdmin(orgId, cb) {
        return CreateowntablemappingmasterSchema.find({
            $and: [
                { [CreateowntablemappingmasterSchemaFields.IsActive]: true },
                { [CreateowntablemappingmasterSchemaFields.KPIKey]: 'Consolidated Report' },
                {
                    $or:
                        [{ [CreateowntablemappingmasterSchemaFields.OrganizationId]: orgId },
                        { [CreateowntablemappingmasterSchemaFields.OrganizationId]: 2 }
                        ]
                }
            ]
        }, (err, kpi) => {
            if (err) {
                log.error(err);
            }
            if (kpi.length <= 0) {
                return cb('kpinotfound', null);
            }
            cb(null, kpi);
        });
    }

    static getCustomKPIById(kpiId, cb) {
        var kpiData = new KPIData();
        return CreateowntablemappingmasterSchema.findOne({ [CreateowntablemappingmasterSchemaFields.ID]: kpiId }, (err, kpi) => {
            if (err) {
                log.error(err);
            }
            if (!kpi) {
                kpiData.kpikey = 'kpi not found';
            }
            else {
                kpiData.id = kpi.ID,
                    kpiData.tablename = kpi.TableName,
                    kpiData.columname = kpi.ColumName,
                    kpiData.displayorder = kpi.DisplayOrder,
                    kpiData.kpikey = kpi.KPIKey,
                    kpiData.parentkey = kpi.ParentKey,
                    kpiData.hassubkey = kpi.HasSubKey,
                    kpiData.kpiformula = kpi.KPIFormula,
                    kpiData.unit = kpi.Unit,
                    kpiData.organizationid = kpi.OrganizationId,
                    kpiData.iscustom = kpi.IsCustom
            }
            cb(null, kpiData);
        });
    }
    static deleteKPI(id, cb) {
        CreateowntablemappingmasterSchema.deleteOne({ [CreateowntablemappingmasterSchemaFields.ID]: id }, (err, result) => {
            if (err) {
                log.error(err);
            }

            cb(null, result);
        })
    }

    static getCustomKPIByOrgId_GraphQL(organizationid, cb) {
        return CustomKPIHelper.getCustomKPIByOrgId(organizationid, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    static getKPILookups_GraphQL(cb) {
        return CustomKPIHelper.getKPILookups(cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }

    static insertCustomKPI_GraphQL(kpiname, kpiformula, unit, organizationid, cb) {

        //db write to SQL server and sync will handle the data in mangodb
        var json_postdata = [];
        json_postdata.columname = kpiname;
        json_postdata.kpikey = kpiname;
        json_postdata.kpiformula = kpiformula;
        json_postdata.unit = unit;
        json_postdata.organizationid = organizationid;

        //CustomKPI/Add in SQL server
        return RESTHelper.POST(HttpMsg.Urls.InsertCustomKPI, json_postdata, (err, post_result) => {
            if (err)
                return cb(err, null);

            //#region write it to mongodb with id returned by SQL
            let id = parseInt(post_result.data.longid);
            let createowntablemappingmasterSchema = new CreateowntablemappingmasterSchema();
            createowntablemappingmasterSchema.ID = id;
            createowntablemappingmasterSchema.ColumName = kpiname.toString();
            createowntablemappingmasterSchema.KPIKey = kpiname.toString().toLowerCase().replace(/\s/g, '_');
            createowntablemappingmasterSchema.KPIFormula = kpiformula.toString();
            createowntablemappingmasterSchema.Unit = unit.toString();
            createowntablemappingmasterSchema.OrganizationId = organizationid;
            createowntablemappingmasterSchema.TableName = 'Consolidated Report';
            createowntablemappingmasterSchema.IsCustom = true;
            // createowntablemappingmasterSchema.save((err, data) => {
            //     if (err)
            //         return cb(err, null);
            // })

            var kpiData = [];
            kpiData.id = createowntablemappingmasterSchema.ID;
            kpiData.tablename = createowntablemappingmasterSchema.TableName;
            kpiData.columname = createowntablemappingmasterSchema.ColumName;
            kpiData.displayorder = createowntablemappingmasterSchema.DisplayOrder;
            kpiData.kpikey = createowntablemappingmasterSchema.KPIKey;
            kpiData.parentkey = createowntablemappingmasterSchema.ParentKey;
            kpiData.hassubkey = createowntablemappingmasterSchema.HasSubKey;
            kpiData.kpiformula = createowntablemappingmasterSchema.KPIFormula;
            kpiData.unit = createowntablemappingmasterSchema.Unit;
            kpiData.organizationid = createowntablemappingmasterSchema.OrganizationId;
            kpiData.iscustom = createowntablemappingmasterSchema.IsCustom;
            cb(null, kpiData);
            //cb(null, json_postdata);

            //  #endregion
        });

    }

    static getCustomKPIForEdit_GraphQL(kpiid, cb) {
        return CustomKPIHelper.getCustomKPIById(kpiid, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }

    static updateCustomKPI_GraphQL(kpiId, kpiname, kpiformula, unit, organizationid, cb) {
        var kpiresult = new KPIData();
        return CreateowntablemappingmasterSchema.findOne({ [CreateowntablemappingmasterSchemaFields.ID]: kpiId }, (err, kpi) => {
            if (err) {
                log.error(err);
            }
            if (!kpi) {
                kpiresult.kpikey = HttpMsg.internalErrorMsg;
            }
            else {

                kpi.ColumName = kpiname.toString();
                kpi.KPIKey = kpiname.toString().toLowerCase().replace(/\s/g, '_');
                kpi.KPIFormula = kpiformula.toString();
                kpi.Unit = unit.toString();
                kpi.OrganizationId = organizationid;

                // kpi.save((err, data) => {
                //     if (err)
                //         return cb(err, null);
                // })

                kpiresult.id = kpi.ID;
                kpiresult.tablename = kpi.TableName;
                kpiresult.columname = kpi.ColumName;
                kpiresult.displayorder = kpi.DisplayOrder;
                kpiresult.kpikey = kpi.KPIKey;
                kpiresult.parentkey = kpi.ParentKey;
                kpiresult.hassubkey = kpi.HasSubKey;
                kpiresult.kpiformula = kpi.KPIFormula;
                kpiresult.unit = kpi.Unit;
                kpiresult.organizationid = kpi.OrganizationId;
                kpiresult.iscustom = kpi.IsCustom;

                //move it to SQL server as well for sync
                if (config.appsettings.sync_to_SQLServer) {

                    //db write to SQL server and sync will handle the data in mangodb
                    var json_postdata = [];
                    json_postdata.columname = kpiresult.columname;
                    json_postdata.kpikey = kpiresult.kpikey;
                    json_postdata.kpiformula = kpiresult.kpiformula;
                    json_postdata.unit = kpiresult.unit;
                    json_postdata.organizationid = kpiresult.organizationid;
                    json_postdata.id = kpiresult.id;

                    //CustomKPI/Update in SQL server
                    RESTHelper.POST(Constants.Urls.UpdateCustomKPI, json_postdata, (api_err, sync_result) => {
                        if (api_err)
                            log.error(api_err);
                        log.debug(sync_result);
                    });

                }


            }
            cb(null, kpiresult);
        });
    }

    static deleteCustomKPI_GraphQL(kpiId, cb) {
        var kpiresult = new KPIData();
        return CreateowntablemappingmasterSchema.deleteOne({ [CreateowntablemappingmasterSchemaFields.ID]: kpiId }, (err, result) => {
            if (err) {
                log.error(err);
            }
            kpiresult.kpikey = HttpMsg.recoredDeleted;
            kpiresult.id = kpiId;

            //delete from createowntablemappings as well if user has enabled the kpis 
            CreateowntablemappingSchema.deleteMany({ [CreateowntablemappingSchemaFields.CreateOwnTableMasterID]: kpiId }, (err, result) => {
            })

            //db write to SQL server and sync will handle the data in mangodb
            var json_postdata = [];
            json_postdata.id = kpiId;

            //CustomKPI/Delete in SQL server
            RESTHelper.DELETE(Constants.Urls.DeleteCustomKPI, json_postdata, (api_err, sync_result) => {
                if (api_err)
                    log.error(api_err);
                log.debug(sync_result);
            });

            cb(null, kpiresult);
        })
    }
}
module.exports = CustomKPIHelper;

