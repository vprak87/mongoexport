const { Hoteleffectivenesscalculations: HoteleffectivenesscalculationsSchema, SchemaField: HoteleffectivenesscalculationsSchemaFields } = require('../models/hoteleffectivenesscalculations');
var log = require('log4js').getLogger("hoteleffectivenesscalculations_helper");

class HoteleffectivenesscalculationsHelper {

    static GetDepartmentWiseData(hotelid, startdate, enddate, cb) {

        log.debug('Call GetDepartmentWiseData, hotelid:' + hotelid + "startdate:" + startdate + "enddate:" + enddate);

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        //#region check Date wise data 
        let hoteleffectivenesscalculationsAggregate_Date = HoteleffectivenesscalculationsSchema.aggregate();
        hoteleffectivenesscalculationsAggregate_Date.match({
            [HoteleffectivenesscalculationsSchemaFields.HotelID]: hotelid,
            [HoteleffectivenesscalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })

        hoteleffectivenesscalculationsAggregate_Date.group({
            [HoteleffectivenesscalculationsSchemaFields._id]: `$${HoteleffectivenesscalculationsSchemaFields.Department}`,
            [HoteleffectivenesscalculationsSchemaFields.Wages]: { $sum: `$${HoteleffectivenesscalculationsSchemaFields.Wages}` },
            [HoteleffectivenesscalculationsSchemaFields.Hours]: { $sum: `$${HoteleffectivenesscalculationsSchemaFields.Hours}` },
            [HoteleffectivenesscalculationsSchemaFields.PlanWages]: { $sum: `$${HoteleffectivenesscalculationsSchemaFields.PlanWages}` },
        })
        return hoteleffectivenesscalculationsAggregate_Date.exec((err, result) => {
            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("GetDepartmentWiseData hoteleffectivenesscalculationsAggregate_Date result not found");
                return cb(null, null);
            }
            return cb(null, result);
        });




    }

    static GetLatestPortfolioData(lsthotelids, startdate, enddate, cb) {

        log.debug('Call GetLatestPortfolioData,  startdate:' + startdate + "enddate:" + enddate);

        let start = new Date(startdate.getFullYear(), startdate.getMonth(), startdate.getDate());
        let end = new Date(enddate.getFullYear(), enddate.getMonth(), enddate.getDate() + 1);

        //#region check Date wise data 
        let hoteleffectivenesscalculationsAggregate_Date = HoteleffectivenesscalculationsSchema.aggregate();
        hoteleffectivenesscalculationsAggregate_Date.match({
            [HoteleffectivenesscalculationsSchemaFields.HotelID]: {
                $in: lsthotelids
            },
            [HoteleffectivenesscalculationsSchemaFields.Date]: {
                $gte: start,
                $lt: end
            }
        })

        hoteleffectivenesscalculationsAggregate_Date.group({
            [HoteleffectivenesscalculationsSchemaFields._id]: `$${HoteleffectivenesscalculationsSchemaFields.HotelID}`,
            [HoteleffectivenesscalculationsSchemaFields.PlanHours]: { $sum: `$${HoteleffectivenesscalculationsSchemaFields.PlanHours}` },
            [HoteleffectivenesscalculationsSchemaFields.Hours]: { $sum: `$${HoteleffectivenesscalculationsSchemaFields.Hours}` }
        })
        return hoteleffectivenesscalculationsAggregate_Date.exec((err, result) => {
            if (err) {
                log.error(err);
            }
            if (!result || result.length == 0) {
                log.debug("GetLatestPortfolioData hoteleffectivenesscalculationsAggregate_Date result not found");
                return cb(null, null);
            }
            return cb(null, result);
        });




    }

}

module.exports = HoteleffectivenesscalculationsHelper;
