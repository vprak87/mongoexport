const { Department : DepartmentSchema, SchemaField: DepartmentSchemaFields } = require('../models/department');
const dbtable = require('../schema/db_table');

var log = require('log4js').getLogger("hotels_helper");

class DepartmentHelper {
    static GetSelectedOrganizationData(OrganizationId,cd){
        
        log.debug('Call OrganizationData, OrganizationId:' + OrganizationId);

        return DepartmentSchema.findOne({$and:[

            {[DepartmentSchemaFields.OrganizationID]:OrganizationId},
            {[DepartmentSchemaFields.IsActive]:true}

            ]}).sort('Name').exec(function(err,result){
            
                if (err) {
                    log.error(err);
                }        
                if (!result) {
                    log.debug("GetOrganizationData result not found");
                }
               
                                    
               return cd(null,result);
                
        }) 

        
       
    }
   
}
module.exports = DepartmentHelper;


