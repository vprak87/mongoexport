const Utils = require('../common/utils');
const Constants = require('../common/constants');

var log = require('log4js').getLogger("strreport_helper");

const StarreportHelper = require('./starreport_helper');
const UserHelper = require('./user_helper');
const HotelsHelper = require('./hotels_helper');

const HoteldashboardcalculationsHelper = require('./hoteldashboardcalculations_helper');


const Strreportdata = require('../strreport/models/strreportdata');
const Strreportdefaultdata = require('../strreport/models/strreportdefaultdata');
const Strreportitemdatamodel = require('../strreport/models/strreportitemdatamodel');
const Strreportdefaultitemdatamodel = require('../strreport/models/strreportdefaultitemdatamodel');
const Strreportdefaultlineitemdatamodel = require('../strreport/models/strreportdefaultlineitemdatamodel');
const Strreportlineitemdatamodel = require('../strreport/models/strreportlineitemdatamodel');
const Strportfoliolineitemdatamodel = require('../strreport/models/strportfoliolineitemdatamodel');
const Strportfoliomonthitemdatamodel = require('../strreport/models/strportfoliomonthitemdatamodel');
const Strportfoliomonthlineitemdatamodel = require('../strreport/models/strportfoliomonthlineitemdatamodel');

const { Starreport: StarreportSchema, SchemaField: StarreportSchemaFields } = require('../models/starreport');

class StrreportHelper {

    static getSTRData(lstStrreportdata_temp, hotelid) {

        let lstStarreportchartdatamodel = [];
        var counter = lstStrreportdata_temp.length;
        return new Promise((resolve, reject) => {
            if (lstStrreportdata_temp != undefined && lstStrreportdata_temp.length > 0) {
                lstStrreportdata_temp.forEach(function (item) {
                    StarreportHelper.getWeekData(hotelid, item.startdate, item.enddate, (err, strweek_result) => {
                        if (!err) {
                            lstStarreportchartdatamodel.push(strweek_result);
                        }
                        counter = counter - 1;
                        if (counter == 0) {

                            resolve(lstStarreportchartdatamodel);
                        }
                    });
                });
            }
        });
    }

    static getSTRLYSamePeriodData(lstStrreportdata_temp, hotelid) {

        let lstStarreportchartdatamodel = [];
        var counter = lstStrreportdata_temp.length;
        return new Promise((resolve, reject) => {
            if (lstStrreportdata_temp != undefined && lstStrreportdata_temp.length > 0) {
                lstStrreportdata_temp.forEach(function (item) {
                    StarreportHelper.getLYSamePeriodData(hotelid, item.Date, item.startDateCompare, item.endDateCompare, (err, strLYSamePeriodData_result) => {
                        if (!err) {
                            lstStarreportchartdatamodel.push(strLYSamePeriodData_result);
                        }
                        counter = counter - 1;
                        if (counter == 0) {

                            resolve(lstStarreportchartdatamodel);
                        }
                    });
                });
            }
        });
    }




    static getSTRBudgetData(lstStrreportdata_temp, hotelid) {

        let lstStarreportchartdatamodel = [];
        var counter = lstStrreportdata_temp.length;
        return new Promise((resolve, reject) => {
            if (lstStrreportdata_temp != undefined && lstStrreportdata_temp.length > 0) {
                lstStrreportdata_temp.forEach(function (item) {

                    StarreportHelper.getSTRBudgetData(hotelid, item.DateForChart, item.startDateCompare, item.endDateCompare, (err, strBudgetData_result) => {
                        if (!err) {
                            lstStarreportchartdatamodel.push(strBudgetData_result);
                        }
                        counter = counter - 1;
                        if (counter == 0) {

                            resolve(lstStarreportchartdatamodel);
                        }
                    });
                });
            }
        });
    }

    static getSTRRunning28DaysData(lstStrreportdata_temp, hotelid) {

        let lstStarreportchartdatamodel = [];
        var counter = lstStrreportdata_temp.length;
        return new Promise((resolve, reject) => {
            if (lstStrreportdata_temp != undefined && lstStrreportdata_temp.length > 0) {
                lstStrreportdata_temp.forEach(function (item) {
                    StarreportHelper.getSTRRunning28DaysData(hotelid, item.DateForChart, item.startDateCompare, item.endDateCompare, (err, strLYSamePeriodData_result) => {
                        if (!err) {
                            lstStarreportchartdatamodel.push(strLYSamePeriodData_result);
                        }
                        counter = counter - 1;
                        if (counter == 0) {

                            resolve(lstStarreportchartdatamodel);
                        }
                    });
                });
            }
        });
    }


    static getStrReportDetailData(hotelid, year, weekormonthnumber, comparison, type, userconfigdata, cb) {

        comparison = comparison.toLowerCase();
        type = type.toLowerCase();

        var reportdate = new Date(year, 1, 1);
        var dtreportdate = new Date(reportdate);

        let lstStrreportdata = [];

        let dateComparetitle = 'LY Same Period';

        if (comparison == Constants.StarComparison.LastYear) {
            dateComparetitle = "LY Same Period";
        }
        else if (comparison == Constants.StarComparison.Last28Days) {
            dateComparetitle = "Running 28 Days";
        }
        else if (comparison == Constants.StarComparison.Budget) {
            dateComparetitle = "Budget";
        }

        //set date based on type
        if (type == Constants.StarType.Month) {

            reportdate = new Date(year, weekormonthnumber - 1, 1);
            dtreportdate = new Date(reportdate);
            var monthenddate = Utils.lastDayOfMonth(reportdate);
            let totaldays = Utils.dateDiffInDays(reportdate, monthenddate);
            while (totaldays > 0) {

                //#region for type = month
                var objStrreportdata = new Strreportdata();
                objStrreportdata.startdate = new Date(dtreportdate.getFullYear(), dtreportdate.getMonth(), dtreportdate.getDate());
                objStrreportdata.enddate = new Date(dtreportdate.getFullYear(), dtreportdate.getMonth(), dtreportdate.getDate());
                objStrreportdata.enddate.setDate(objStrreportdata.enddate.getDate());
                let weeknumber = Utils.getWeekNumber(objStrreportdata.enddate);
                objStrreportdata.weeknumber = weeknumber;
                objStrreportdata.title = dateComparetitle;
                objStrreportdata.enddate = objStrreportdata.enddate;
                objStrreportdata.weektitle = Utils.getFormattedDate(objStrreportdata.startdate, 'DD-MMM-YY');
                lstStrreportdata.push(objStrreportdata);
                dtreportdate.setDate(dtreportdate.getDate() + 1);
                //#endregion

                totaldays--;
            }

        }
        else {
            reportdate = Utils.getFirstDayOfWeek(reportdate, reportdate.getFullYear(), weekormonthnumber);
            dtreportdate = new Date(reportdate);
            var i = 1;
            while (i <= 7) {

                //#region for type = week
                var objStrreportdata = new Strreportdata();
                objStrreportdata.startdate = new Date(dtreportdate.getFullYear(), dtreportdate.getMonth(), dtreportdate.getDate());
                objStrreportdata.enddate = new Date(dtreportdate.getFullYear(), dtreportdate.getMonth(), dtreportdate.getDate());
                objStrreportdata.enddate.setDate(objStrreportdata.enddate.getDate());
                let weeknumber = Utils.getWeekNumber(objStrreportdata.enddate);
                objStrreportdata.weeknumber = weeknumber;
                objStrreportdata.title = dateComparetitle;
                objStrreportdata.enddate = objStrreportdata.enddate;
                objStrreportdata.weektitle = Utils.getFormattedDate(objStrreportdata.startdate, 'DD-MMM-YY');
                lstStrreportdata.push(objStrreportdata);
                dtreportdate.setDate(dtreportdate.getDate() + 1);
                //#endregion

                i++;
            }
        }

        let lstStarreportchartdatamodel = [];
        let lstStarreportchartdatamodel_LY = [];
        let lstStarreportchartdatamodel_Budget = [];

        let lstStrreportitemdatamodel = [];

        StrreportHelper.getSTRData(lstStrreportdata, hotelid).then(lstStarreportchartdatamodel_result => {

            if (lstStarreportchartdatamodel_result) {
                lstStarreportchartdatamodel = lstStarreportchartdatamodel_result;
            }
            lstStarreportchartdatamodel = Utils.sort(lstStarreportchartdatamodel, 'DateForChart');


            lstStarreportchartdatamodel.forEach(function (item) {

                let startDateLY = Utils.sameDayLastYear(item.DateForChart);
                let startDateCompare = item.StartDate;
                let endDateCompare = item.EndDate;

                if (comparison == Constants.StarComparison.LastYear) {
                    item.DateCompare = "LY Same Period";
                    if (type == Constants.StarType.Month) {
                        startDateCompare = Utils.lastYearDate(startDateCompare);
                    }
                    else {
                        startDateCompare = Utils.getFirstDayOfWeek(startDateLY, startDateLY.getFullYear(), item.WeekNumber + 1);
                    }
                    endDateCompare = new Date(startDateCompare);
                    endDateCompare.setDate(startDateCompare.getDate());
                }
                else if (comparison == Constants.StarComparison.Last28Days) {

                    item.DateCompare = "Running 28 Days";

                }
                else if (comparison == Constants.StarComparison.Budget) {
                    item.DateCompare = "Budget";
                }

                item.startDateCompare = startDateCompare;
                item.endDateCompare = endDateCompare;

            });


            let missingflag = false;
            return Promise.all([
                new Promise((resolve, reject) => {
                    if (comparison == Constants.StarComparison.LastYear) {

                        //#region  Last Year Comparision

                        StrreportHelper.getSTRLYSamePeriodData(lstStarreportchartdatamodel, hotelid).then(lstStarreportchartdatamodel_LY_result => {

                            if (lstStarreportchartdatamodel_LY_result) {
                                lstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY_result;
                            }

                            lstStarreportchartdatamodel.forEach(function (item) {
                                if (item.UpdatedBy != "sp_missingdates") {
                                    if (item.OccIndex == 0
                                        && item.OccChgIndex == 0
                                        && item.AdrIndex == 0
                                        && item.AdrChgIndex == 0
                                        && item.RevParIndex == 0
                                        && item.RevParChgIndex == 0) {
                                        missingflag = true;
                                    }
                                }
                                let objlstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY.filter(d => {
                                    return (d.Date == item.Date);
                                });

                                if (objlstStarreportchartdatamodel_LY.length > 0) {
                                    objlstStarreportchartdatamodel_LY = objlstStarreportchartdatamodel_LY[0];


                                    item.OccChgIndexCompare = objlstStarreportchartdatamodel_LY.OccChgIndex;
                                    item.OccChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccChgMyProperty;
                                    item.OccChgRankCompare = objlstStarreportchartdatamodel_LY.OccChgRank;
                                    item.OccIndexCompare = objlstStarreportchartdatamodel_LY.OccIndex;
                                    item.OccMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccMyProperty;
                                    item.OccRankCompare = objlstStarreportchartdatamodel_LY.OccRank;

                                    item.AdrChgIndexCompare = objlstStarreportchartdatamodel_LY.AdrChgIndex;
                                    item.AdrChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrChgMyProperty;
                                    item.AdrChgRankCompare = objlstStarreportchartdatamodel_LY.AdrChgRank;
                                    item.AdrIndexCompare = objlstStarreportchartdatamodel_LY.AdrIndex;
                                    item.AdrMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrMyProperty;
                                    item.AdrRankCompare = objlstStarreportchartdatamodel_LY.AdrRank;


                                    item.RevParChgIndexCompare = objlstStarreportchartdatamodel_LY.RevParChgIndex;
                                    item.RevParChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParChgMyProperty;
                                    item.RevParChgRankCompare = objlstStarreportchartdatamodel_LY.RevParChgRank;
                                    item.RevParIndexCompare = objlstStarreportchartdatamodel_LY.RevParIndex;
                                    item.RevParMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParMyProperty;
                                    item.RevParRankCompare = objlstStarreportchartdatamodel_LY.RevParRank;


                                    if (item.OccChgCompSet > item.OccChgCompSetCompare) {
                                        item.IsOccChgCompSetUp = true;
                                    }
                                    if (item.OccChgIndex > item.OccChgIndexCompare) {
                                        item.IsOccChgIndexUp = true;
                                    }
                                    if (item.OccChgMyProperty > item.OccChgMyPropertyCompare) {
                                        item.IsOccChgMyPropertyUp = true;
                                    }
                                    if (item.OccCompSet > item.OccCompSetCompare) {
                                        item.IsOccCompSetUp = true;
                                    }
                                    if (item.OccIndex > item.OccIndexCompare) {
                                        item.IsOccIndexUp = true;
                                    }
                                    if (item.OccMyProperty > item.OccMyPropertyCompare) {
                                        item.IsOccMyPropertyUp = true;
                                    }

                                    if (item.AdrChgCompSet > item.AdrChgCompSetCompare) {
                                        item.IsAdrChgCompSetUp = true;
                                    }
                                    if (item.AdrChgIndex > item.AdrChgIndexCompare) {
                                        item.IsAdrChgIndexUp = true;
                                    }
                                    if (item.AdrChgMyProperty > item.AdrChgMyPropertyCompare) {
                                        item.IsAdrChgMyPropertyUp = true;
                                    }
                                    if (item.AdrCompSet > item.AdrCompSetCompare) {
                                        item.IsAdrCompSetUp = true;
                                    }
                                    if (item.AdrIndex > item.AdrIndexCompare) {
                                        item.IsAdrIndexUp = true;
                                    }
                                    if (item.AdrMyProperty > item.AdrMyPropertyCompare) {
                                        item.IsAdrMyPropertyUp = true;
                                    }

                                    if (item.RevParChgCompSet > item.RevParChgCompSetCompare) {
                                        item.IsRevParChgCompSetUp = true;
                                    }
                                    if (item.RevParChgIndex > item.RevParChgIndexCompare) {
                                        item.IsRevParChgIndexUp = true;
                                    }
                                    if (item.RevParChgMyProperty > item.RevParChgMyPropertyCompare) {
                                        item.IsRevParChgMyPropertyUp = true;
                                    }
                                    if (item.RevParCompSet > item.RevParCompSetCompare) {
                                        item.IsRevParCompSetUp = true;
                                    }
                                    if (item.RevParIndex > item.RevParIndexCompare) {
                                        item.IsRevParIndexUp = true;
                                    }
                                    if (item.RevParMyProperty > item.RevParMyPropertyCompare) {
                                        item.IsRevParMyPropertyUp = true;
                                    }

                                }
                            });

                            resolve();

                        });

                        //#endregion
                    }
                    else if (comparison == Constants.StarComparison.Last28Days) {

                        //#region  Last28Days Comparision

                        StrreportHelper.getSTRRunning28DaysData(lstStarreportchartdatamodel, hotelid).then(lstStarreportchartdatamodel_LY_result => {

                            if (lstStarreportchartdatamodel_LY_result) {
                                lstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY_result;
                            }

                            lstStarreportchartdatamodel.forEach(function (item) {
                                if (item.UpdatedBy != "sp_missingdates") {
                                    if (item.OccIndex == 0
                                        && item.OccChgIndex == 0
                                        && item.AdrIndex == 0
                                        && item.AdrChgIndex == 0
                                        && item.RevParIndex == 0
                                        && item.RevParChgIndex == 0) {
                                        missingflag = true;
                                    }
                                }
                                let objlstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY.filter(d => {
                                    return (d.Date == item.Date);
                                });

                                if (objlstStarreportchartdatamodel_LY.length > 0) {
                                    objlstStarreportchartdatamodel_LY = objlstStarreportchartdatamodel_LY[0];


                                    item.OccChgIndexCompare = objlstStarreportchartdatamodel_LY.OccChgIndex;
                                    item.OccChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccChgMyProperty;
                                    item.OccChgRankCompare = objlstStarreportchartdatamodel_LY.OccChgRank;
                                    item.OccIndexCompare = objlstStarreportchartdatamodel_LY.OccIndex;
                                    item.OccMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccMyProperty;
                                    item.OccRankCompare = objlstStarreportchartdatamodel_LY.OccRank;

                                    item.AdrChgIndexCompare = objlstStarreportchartdatamodel_LY.AdrChgIndex;
                                    item.AdrChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrChgMyProperty;
                                    item.AdrChgRankCompare = objlstStarreportchartdatamodel_LY.AdrChgRank;
                                    item.AdrIndexCompare = objlstStarreportchartdatamodel_LY.AdrIndex;
                                    item.AdrMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrMyProperty;
                                    item.AdrRankCompare = objlstStarreportchartdatamodel_LY.AdrRank;


                                    item.RevParChgIndexCompare = objlstStarreportchartdatamodel_LY.RevParChgIndex;
                                    item.RevParChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParChgMyProperty;
                                    item.RevParChgRankCompare = objlstStarreportchartdatamodel_LY.RevParChgRank;
                                    item.RevParIndexCompare = objlstStarreportchartdatamodel_LY.RevParIndex;
                                    item.RevParMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParMyProperty;
                                    item.RevParRankCompare = objlstStarreportchartdatamodel_LY.RevParRank;


                                    if (item.OccChgCompSet > item.OccChgCompSetCompare) {
                                        item.IsOccChgCompSetUp = true;
                                    }
                                    if (item.OccChgIndex > item.OccChgIndexCompare) {
                                        item.IsOccChgIndexUp = true;
                                    }
                                    if (item.OccChgMyProperty > item.OccChgMyPropertyCompare) {
                                        item.IsOccChgMyPropertyUp = true;
                                    }
                                    if (item.OccCompSet > item.OccCompSetCompare) {
                                        item.IsOccCompSetUp = true;
                                    }
                                    if (item.OccIndex > item.OccIndexCompare) {
                                        item.IsOccIndexUp = true;
                                    }
                                    if (item.OccMyProperty > item.OccMyPropertyCompare) {
                                        item.IsOccMyPropertyUp = true;
                                    }

                                    if (item.AdrChgCompSet > item.AdrChgCompSetCompare) {
                                        item.IsAdrChgCompSetUp = true;
                                    }
                                    if (item.AdrChgIndex > item.AdrChgIndexCompare) {
                                        item.IsAdrChgIndexUp = true;
                                    }
                                    if (item.AdrChgMyProperty > item.AdrChgMyPropertyCompare) {
                                        item.IsAdrChgMyPropertyUp = true;
                                    }
                                    if (item.AdrCompSet > item.AdrCompSetCompare) {
                                        item.IsAdrCompSetUp = true;
                                    }
                                    if (item.AdrIndex > item.AdrIndexCompare) {
                                        item.IsAdrIndexUp = true;
                                    }
                                    if (item.AdrMyProperty > item.AdrMyPropertyCompare) {
                                        item.IsAdrMyPropertyUp = true;
                                    }

                                    if (item.RevParChgCompSet > item.RevParChgCompSetCompare) {
                                        item.IsRevParChgCompSetUp = true;
                                    }
                                    if (item.RevParChgIndex > item.RevParChgIndexCompare) {
                                        item.IsRevParChgIndexUp = true;
                                    }
                                    if (item.RevParChgMyProperty > item.RevParChgMyPropertyCompare) {
                                        item.IsRevParChgMyPropertyUp = true;
                                    }
                                    if (item.RevParCompSet > item.RevParCompSetCompare) {
                                        item.IsRevParCompSetUp = true;
                                    }
                                    if (item.RevParIndex > item.RevParIndexCompare) {
                                        item.IsRevParIndexUp = true;
                                    }
                                    if (item.RevParMyProperty > item.RevParMyPropertyCompare) {
                                        item.IsRevParMyPropertyUp = true;
                                    }

                                }


                            });


                            resolve();

                        });

                        //#endregion
                    }
                    else if (comparison == Constants.StarComparison.Budget) {

                        //#region Budget comparision

                        StrreportHelper.getSTRBudgetData(lstStarreportchartdatamodel, hotelid).then(lstStarreportchartdatamodel_Budget_result => {

                            if (lstStarreportchartdatamodel_Budget_result) {
                                lstStarreportchartdatamodel_Budget = lstStarreportchartdatamodel_Budget_result;
                            }

                            lstStarreportchartdatamodel.forEach(function (item) {
                                if (item.UpdatedBy != "sp_missingdates") {
                                    if (item.OccIndex == 0
                                        && item.OccChgIndex == 0
                                        && item.AdrIndex == 0
                                        && item.AdrChgIndex == 0
                                        && item.RevParIndex == 0
                                        && item.RevParChgIndex == 0) {
                                        missingflag = true;
                                    }
                                }
                                let objlstStarreportchartdatamodel_Budget = lstStarreportchartdatamodel_Budget.filter(d => {
                                    return (d.Date == item.Date);
                                });

                                if (objlstStarreportchartdatamodel_Budget.length > 0) {

                                    objlstStarreportchartdatamodel_Budget = objlstStarreportchartdatamodel_Budget[0];

                                    let totaldays = Utils.dateDiffInDays(item.StartDate, item.EndDate);

                                    if (objlstStarreportchartdatamodel_Budget.MPIBudget
                                        && objlstStarreportchartdatamodel_Budget.MPIBudget != 0
                                        && totaldays != 0) {
                                        item.OccIndexCompare = objlstStarreportchartdatamodel_Budget.MPIBudget / totalDays;
                                    }

                                    if (objlstStarreportchartdatamodel_Budget.ARIBudget
                                        && objlstStarreportchartdatamodel_Budget.ARIBudget != 0
                                        && totaldays != 0) {
                                        item.AdrIndexCompare = objlstStarreportchartdatamodel_Budget.ARIBudget / totalDays;
                                    }

                                    if (objlstStarreportchartdatamodel_Budget.RGIBudget
                                        && objlstStarreportchartdatamodel_Budget.RGIBudget != 0
                                        && totaldays != 0) {
                                        item.RevParIndexCompare = objlstStarreportchartdatamodel_Budget.RGIBudget / totalDays;
                                    }

                                    if (item.OccIndexCompare <= item.OccIndex) {
                                        item.IsOccIndexUp = true;
                                    }
                                    if (item.AdrIndexCompare <= item.AdrIndex) {
                                        item.IsAdrIndexUp = true;
                                    }
                                    if (item.RevParIndexCompare <= item.RevParIndex) {
                                        item.IsRevParIndexUp = true;
                                    }

                                }



                            });

                            resolve();

                        });

                        //#endregion
                    }
                })
            ]).then(resp => {


                var counter = 1;
                lstStrreportdata.forEach(function (item) {

                    var objStrreportitemdatamodel = new Strreportitemdatamodel();
                    var objStrreportlineitemdatamodel = new Strreportlineitemdatamodel();
                    var objStrreportlineitemdatamodel_comparision = new Strreportlineitemdatamodel();

                    objStrreportlineitemdatamodel.title = item.weektitle;
                    if (missingflag) {
                        objStrreportlineitemdatamodel.missingdates = item.weektitle;
                    }
                    objStrreportlineitemdatamodel_comparision.title = item.title;

                    let objStarreportchartdatamodel = lstStarreportchartdatamodel.filter(d => {
                        return (d.EndDate == item.enddate);
                    });

                    if (objStarreportchartdatamodel.length > 0) {
                        objStarreportchartdatamodel = objStarreportchartdatamodel[0];

                        objStrreportlineitemdatamodel.occact = objStarreportchartdatamodel.OccMyProperty;
                        objStrreportlineitemdatamodel.occactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccMyPropertyUp) {
                            objStrreportlineitemdatamodel.occactcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.occchg = objStarreportchartdatamodel.OccChgMyProperty;
                        objStrreportlineitemdatamodel.occchgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccChgMyPropertyUp) {
                            objStrreportlineitemdatamodel.occchgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.mpiact = objStarreportchartdatamodel.OccIndex;
                        objStrreportlineitemdatamodel.mpiactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccIndexUp) {
                            objStrreportlineitemdatamodel.mpiactcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.mpichg = objStarreportchartdatamodel.OccChgIndex;
                        objStrreportlineitemdatamodel.mpichgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccChgIndexUp) {
                            objStrreportlineitemdatamodel.mpichgcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.occrankact = objStarreportchartdatamodel.OccRank;
                        objStrreportlineitemdatamodel.occrankchg = objStarreportchartdatamodel.OccChgRank;

                        objStrreportlineitemdatamodel.adract = objStarreportchartdatamodel.AdrMyProperty;
                        objStrreportlineitemdatamodel.adractcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrMyPropertyUp) {
                            objStrreportlineitemdatamodel.adractcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.adrchg = objStarreportchartdatamodel.AdrChgMyProperty;
                        objStrreportlineitemdatamodel.adrchgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrChgMyPropertyUp) {
                            objStrreportlineitemdatamodel.adrchgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.ariact = objStarreportchartdatamodel.AdrIndex;
                        objStrreportlineitemdatamodel.ariactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrIndexUp) {
                            objStrreportlineitemdatamodel.ariactcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.arichg = objStarreportchartdatamodel.AdrChgIndex;
                        objStrreportlineitemdatamodel.arichgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrChgIndexUp) {
                            objStrreportlineitemdatamodel.arichgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.adrrankact = objStarreportchartdatamodel.AdrRank;
                        objStrreportlineitemdatamodel.adrrankchg = objStarreportchartdatamodel.AdrChgRank;


                        objStrreportlineitemdatamodel.revparact = objStarreportchartdatamodel.RevParMyProperty;
                        objStrreportlineitemdatamodel.revparactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParMyPropertyUp) {
                            objStrreportlineitemdatamodel.revparactcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.revparchg = objStarreportchartdatamodel.RevParChgMyProperty;
                        objStrreportlineitemdatamodel.revparchgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParChgMyPropertyUp) {
                            objStrreportlineitemdatamodel.revparchgcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.rgiact = objStarreportchartdatamodel.RevParIndex;
                        objStrreportlineitemdatamodel.rgiactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParIndexUp) {
                            objStrreportlineitemdatamodel.rgiactcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.rgichg = objStarreportchartdatamodel.RevParChgIndex;
                        objStrreportlineitemdatamodel.rgichgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParChgIndexUp) {
                            objStrreportlineitemdatamodel.rgichgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.revparrankact = objStarreportchartdatamodel.RevParRank;
                        objStrreportlineitemdatamodel.revparrankchg = objStarreportchartdatamodel.RevParChgRank;


                        objStrreportlineitemdatamodel_comparision.mpiact = objStarreportchartdatamodel.OccIndexCompare;
                        objStrreportlineitemdatamodel_comparision.occrankact = objStarreportchartdatamodel.OccRankCompare;
                        objStrreportlineitemdatamodel_comparision.occrankchg = objStarreportchartdatamodel.OccChgRankCompare;

                        objStrreportlineitemdatamodel_comparision.ariact = objStarreportchartdatamodel.AdrIndexCompare;
                        objStrreportlineitemdatamodel_comparision.adrrankact = objStarreportchartdatamodel.AdrRankCompare;
                        objStrreportlineitemdatamodel_comparision.adrrankchg = objStarreportchartdatamodel.AdrChgRankCompare;

                        objStrreportlineitemdatamodel_comparision.rgiact = objStarreportchartdatamodel.RevParIndexCompare;
                        objStrreportlineitemdatamodel_comparision.revparrankact = objStarreportchartdatamodel.RevParRankCompare;
                        objStrreportlineitemdatamodel_comparision.revparrankchg = objStarreportchartdatamodel.RevParChgRankCompare;


                        if (comparison == Constants.StarComparison.Budget) {

                            objStrreportlineitemdatamodel_comparision.occact = "NA";
                            objStrreportlineitemdatamodel_comparision.occchg = "NA";
                            objStrreportlineitemdatamodel_comparision.mpichg = "NA";
                            objStrreportlineitemdatamodel_comparision.adract = "NA";
                            objStrreportlineitemdatamodel_comparision.adrchg = "NA";
                            objStrreportlineitemdatamodel_comparision.arichg = "NA";
                            objStrreportlineitemdatamodel_comparision.revparact = "NA";
                            objStrreportlineitemdatamodel_comparision.revparchg = "NA";
                            objStrreportlineitemdatamodel_comparision.rgichg = "NA";

                        }
                        else {
                            objStrreportlineitemdatamodel_comparision.occact = objStarreportchartdatamodel.OccMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.occchg = objStarreportchartdatamodel.OccChgMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.mpichg = objStarreportchartdatamodel.OccChgIndexCompare;
                            objStrreportlineitemdatamodel_comparision.adract = objStarreportchartdatamodel.AdrMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.adrchg = objStarreportchartdatamodel.AdrChgMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.arichg = objStarreportchartdatamodel.AdrChgIndexCompare;
                            objStrreportlineitemdatamodel_comparision.revparact = objStarreportchartdatamodel.RevParMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.revparchg = objStarreportchartdatamodel.RevParChgMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.rgichg = objStarreportchartdatamodel.RevParChgIndexCompare;

                        }
                    }

                    objStrreportitemdatamodel.id = counter++;
                    objStrreportitemdatamodel.actualdata = objStrreportlineitemdatamodel.setFormat(objStrreportlineitemdatamodel);
                    objStrreportitemdatamodel.comparisiondata = objStrreportlineitemdatamodel_comparision.setFormat(objStrreportlineitemdatamodel_comparision);

                    lstStrreportitemdatamodel.push(objStrreportitemdatamodel);
                });

                cb(null, lstStrreportitemdatamodel);

            }, err => {
                return cb(err);
            })

        });
    }



    static getStrReportData(hotelid, year, month, comparison, type, userconfigdata, cb) {

        comparison = comparison.toLowerCase();
        type = type.toLowerCase();

        var monthnumber = Utils.getMonthByName(month);

        var reportdate = new Date(year, monthnumber - 1, 1);

        var dtreportdate = new Date(reportdate);

        let lstStrreportdata = [];

        var firstSundayOfMonth = Utils.firstSundayOfMonth(dtreportdate);

        let dateComparetitle = 'LY Same Period';

        if (comparison == Constants.StarComparison.LastYear) {
            dateComparetitle = "LY Same Period";
        }
        else if (comparison == Constants.StarComparison.Last28Days) {
            dateComparetitle = "Running 28 Days";
        }
        else if (comparison == Constants.StarComparison.Budget) {
            dateComparetitle = "Budget";
        }

        //get all weeks for this month
        var currentmonth = Utils.getMonthNumber(firstSundayOfMonth);
        while (monthnumber == currentmonth) {

            if (type == Constants.StarType.Month) {

                //#region for type = month
                var objStrreportdata = new Strreportdata();
                objStrreportdata.startdate = new Date(firstSundayOfMonth.getFullYear(), firstSundayOfMonth.getMonth(), 1);
                objStrreportdata.enddate = Utils.lastDayOfMonth(objStrreportdata.startdate);

                let weeknumber = Utils.getWeekNumber(firstSundayOfMonth) + 1;

                objStrreportdata.weektitle = "Month " + weeknumber;
                objStrreportdata.weeknumber = weeknumber;
                objStrreportdata.title = dateComparetitle;
                objStrreportdata.enddate = objStrreportdata.enddate;
                var scurrentmonth = Utils.getMonthNumber(objStrreportdata.startdate);
                var ecurrentmonth = Utils.getMonthNumber(objStrreportdata.enddate);

                if (scurrentmonth == ecurrentmonth) {

                    objStrreportdata.weektitle = objStrreportdata.weektitle + " (" + Utils.getFormattedDate(objStrreportdata.startdate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.startdate, 'DD')
                        + " to " + Utils.getFormattedDate(objStrreportdata.enddate, 'DD')
                        + ")";
                }
                else {
                    objStrreportdata.weektitle = objStrreportdata.weektitle + " (" + Utils.getFormattedDate(objStrreportdata.startdate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.startdate, 'DD')
                        + " to " + Utils.getFormattedDate(objStrreportdata.enddate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.enddate, 'DD')
                        + ")";
                }


                let totaldays = Utils.dateDiffInDays(objStrreportdata.startdate, objStrreportdata.enddate);

                lstStrreportdata.push(objStrreportdata);
                firstSundayOfMonth.setDate(firstSundayOfMonth.getDate() + totaldays);
                currentmonth = Utils.getMonthNumber(firstSundayOfMonth);
                //#endregion

            }
            else {

                //#region for type = week
                var objStrreportdata = new Strreportdata();
                objStrreportdata.startdate = new Date(firstSundayOfMonth.getFullYear(), firstSundayOfMonth.getMonth(), firstSundayOfMonth.getDate());
                objStrreportdata.enddate = new Date(firstSundayOfMonth.getFullYear(), firstSundayOfMonth.getMonth(), firstSundayOfMonth.getDate());
                objStrreportdata.enddate.setDate(objStrreportdata.enddate.getDate() + 6);

                let weeknumber = Utils.getWeekNumber(objStrreportdata.startdate) + 1;
                objStrreportdata.weektitle = "Week " + weeknumber;
                objStrreportdata.weeknumber = weeknumber;
                objStrreportdata.title = dateComparetitle;
                objStrreportdata.enddate = objStrreportdata.enddate;


                var scurrentmonth = Utils.getMonthNumber(objStrreportdata.startdate);
                var ecurrentmonth = Utils.getMonthNumber(objStrreportdata.enddate);

                if (scurrentmonth == ecurrentmonth) {

                    objStrreportdata.weektitle = objStrreportdata.weektitle + " (" + Utils.getFormattedDate(objStrreportdata.startdate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.startdate, 'DD')
                        + " to " + Utils.getFormattedDate(objStrreportdata.enddate, 'DD')
                        + ")";
                }
                else {
                    objStrreportdata.weektitle = objStrreportdata.weektitle + " (" + Utils.getFormattedDate(objStrreportdata.startdate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.startdate, 'DD')
                        + " to " + Utils.getFormattedDate(objStrreportdata.enddate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.enddate, 'DD')
                        + ")";
                }

                lstStrreportdata.push(objStrreportdata);
                firstSundayOfMonth.setDate(firstSundayOfMonth.getDate() + 7);
                currentmonth = Utils.getMonthNumber(firstSundayOfMonth);
                //#endregion

            }

        }

        let lstStarreportchartdatamodel = [];
        let lstStarreportchartdatamodel_LY = [];
        let lstStarreportchartdatamodel_Budget = [];

        let lstStrreportitemdatamodel = [];

        StrreportHelper.getSTRData(lstStrreportdata, hotelid).then(lstStarreportchartdatamodel_result => {

            if (lstStarreportchartdatamodel_result) {
                lstStarreportchartdatamodel = lstStarreportchartdatamodel_result;
            }
            lstStarreportchartdatamodel = Utils.sort(lstStarreportchartdatamodel, 'DateForChart');


            lstStarreportchartdatamodel.forEach(function (item) {

                let startDateLY = Utils.lastYearDate(item.DateForChart);
                let startDateCompare = item.StartDate;
                let endDateCompare = item.EndDate;

                if (comparison == Constants.StarComparison.LastYear) {
                    item.DateCompare = "LY Same Period";
                    if (type == Constants.StarType.Month) {
                        startDateCompare = Utils.getFirstDayOfWeek(startDateLY, startDateLY.getFullYear(), item.WeekNumber);
                    }
                    else {
                        startDateCompare = Utils.getFirstDayOfWeek(startDateLY, startDateLY.getFullYear(), item.WeekNumber + 1);
                    }
                    endDateCompare = new Date(startDateCompare);
                    endDateCompare.setDate(startDateCompare.getDate() + 6);
                }
                else if (comparison == Constants.StarComparison.Last28Days) {

                    item.DateCompare = "Running 28 Days";

                }
                else if (comparison == Constants.StarComparison.Budget) {
                    item.DateCompare = "Budget";
                }

                item.startDateCompare = startDateCompare;
                item.endDateCompare = endDateCompare;

            });


            let missingflag = false;
            return Promise.all([
                new Promise((resolve, reject) => {
                    if (comparison == Constants.StarComparison.LastYear) {

                        //#region  Last Year Comparision

                        StrreportHelper.getSTRLYSamePeriodData(lstStarreportchartdatamodel, hotelid).then(lstStarreportchartdatamodel_LY_result => {

                            if (lstStarreportchartdatamodel_LY_result) {
                                lstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY_result;
                            }

                            lstStarreportchartdatamodel.forEach(function (item, index) {

                                if (item.UpdatedBy != "sp_missingdates") {
                                    if (item.OccIndex == 0
                                        && item.OccChgIndex == 0
                                        && item.AdrIndex == 0
                                        && item.AdrChgIndex == 0
                                        && item.RevParIndex == 0
                                        && item.RevParChgIndex == 0) {
                                        missingflag = true;
                                    }
                                }
                                let objlstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY.filter(d => {
                                    return (d.Date == item.Date);
                                });

                                if (objlstStarreportchartdatamodel_LY.length > 0) {
                                    objlstStarreportchartdatamodel_LY = objlstStarreportchartdatamodel_LY[0];


                                    item.OccChgIndexCompare = objlstStarreportchartdatamodel_LY.OccChgIndex;
                                    item.OccChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccChgMyProperty;
                                    item.OccChgRankCompare = objlstStarreportchartdatamodel_LY.OccChgRank;
                                    item.OccIndexCompare = objlstStarreportchartdatamodel_LY.OccIndex;
                                    item.OccMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccMyProperty;
                                    item.OccRankCompare = objlstStarreportchartdatamodel_LY.OccRank;

                                    item.AdrChgIndexCompare = objlstStarreportchartdatamodel_LY.AdrChgIndex;
                                    item.AdrChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrChgMyProperty;
                                    item.AdrChgRankCompare = objlstStarreportchartdatamodel_LY.AdrChgRank;
                                    item.AdrIndexCompare = objlstStarreportchartdatamodel_LY.AdrIndex;
                                    item.AdrMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrMyProperty;
                                    item.AdrRankCompare = objlstStarreportchartdatamodel_LY.AdrRank;


                                    item.RevParChgIndexCompare = objlstStarreportchartdatamodel_LY.RevParChgIndex;
                                    item.RevParChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParChgMyProperty;
                                    item.RevParChgRankCompare = objlstStarreportchartdatamodel_LY.RevParChgRank;
                                    item.RevParIndexCompare = objlstStarreportchartdatamodel_LY.RevParIndex;
                                    item.RevParMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParMyProperty;
                                    item.RevParRankCompare = objlstStarreportchartdatamodel_LY.RevParRank;


                                    if (item.OccChgCompSet > item.OccChgCompSetCompare) {
                                        item.IsOccChgCompSetUp = true;
                                    }
                                    if (item.OccChgIndex > item.OccChgIndexCompare || item.OccChgIndexCompare == "NA") {
                                        item.IsOccChgIndexUp = true;
                                    }
                                    if (item.OccChgMyProperty > item.OccChgMyPropertyCompare || item.OccChgMyPropertyCompare == "NA") {
                                        item.IsOccChgMyPropertyUp = true;
                                    }
                                    if (item.OccCompSet > item.OccCompSetCompare) {
                                        item.IsOccCompSetUp = true;
                                    }
                                    if (item.OccIndex > item.OccIndexCompare || item.OccIndexCompare == "NA") {
                                        item.IsOccIndexUp = true;
                                    }
                                    if (item.OccMyProperty > item.OccMyPropertyCompare || item.OccMyPropertyCompare == "NA") {
                                        item.IsOccMyPropertyUp = true;
                                    }

                                    if (item.AdrChgCompSet > item.AdrChgCompSetCompare) {
                                        item.IsAdrChgCompSetUp = true;
                                    }
                                    if (item.AdrChgIndex > item.AdrChgIndexCompare || item.AdrChgIndexCompare == "NA") {
                                        item.IsAdrChgIndexUp = true;
                                    }
                                    if (item.AdrChgMyProperty > item.AdrChgMyPropertyCompare || item.AdrChgMyPropertyCompare == "NA") {
                                        item.IsAdrChgMyPropertyUp = true;
                                    }
                                    if (item.AdrCompSet > item.AdrCompSetCompare) {
                                        item.IsAdrCompSetUp = true;
                                    }
                                    if (item.AdrIndex > item.AdrIndexCompare || item.AdrIndexCompare == "NA") {
                                        item.IsAdrIndexUp = true;
                                    }
                                    if (item.AdrMyProperty > item.AdrMyPropertyCompare || item.AdrMyPropertyCompare == "NA") {
                                        item.IsAdrMyPropertyUp = true;
                                    }

                                    if (item.RevParChgCompSet > item.RevParChgCompSetCompare) {
                                        item.IsRevParChgCompSetUp = true;
                                    }
                                    if (item.RevParChgIndex > item.RevParChgIndexCompare || item.RevParChgIndexCompare == "NA") {
                                        item.IsRevParChgIndexUp = true;
                                    }
                                    if (item.RevParChgMyProperty > item.RevParChgMyPropertyCompare || item.RevParChgMyPropertyCompare == "NA") {
                                        item.IsRevParChgMyPropertyUp = true;
                                    }
                                    if (item.RevParCompSet > item.RevParCompSetCompare) {
                                        item.IsRevParCompSetUp = true;
                                    }
                                    if (item.RevParIndex > item.RevParIndexCompare || item.RevParIndexCompare == "NA") {
                                        item.IsRevParIndexUp = true;
                                    }
                                    if (item.RevParMyProperty > item.RevParMyPropertyCompare || item.RevParMyPropertyCompare == "NA") {
                                        item.IsRevParMyPropertyUp = true;
                                    }

                                }
                                else //no LY data to compare
                                {
                                    item.IsOccMyPropertyUp = true;
                                    item.IsOccIndexUp = true;
                                    item.IsAdrMyPropertyUp = true;
                                    item.IsAdrIndexUp = true;
                                    item.IsRevParMyPropertyUp = true;
                                    item.IsRevParIndexUp = true;

                                }
                            });

                            resolve();

                        });

                        //#endregion
                    }
                    else if (comparison == Constants.StarComparison.Last28Days) {

                        //#region  Last28Days Comparision

                        StrreportHelper.getSTRRunning28DaysData(lstStarreportchartdatamodel, hotelid).then(lstStarreportchartdatamodel_LY_result => {

                            if (lstStarreportchartdatamodel_LY_result) {
                                lstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY_result;
                            }

                            lstStarreportchartdatamodel.forEach(function (item) {
                                if (item.UpdatedBy != "sp_missingdates") {
                                    if (item.OccIndex == 0
                                        && item.OccChgIndex == 0
                                        && item.AdrIndex == 0
                                        && item.AdrChgIndex == 0
                                        && item.RevParIndex == 0
                                        && item.RevParChgIndex == 0) {
                                        missingflag = true;
                                    }
                                }
                                let objlstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY.filter(d => {
                                    return (d.Date == item.Date);
                                });

                                if (objlstStarreportchartdatamodel_LY.length > 0) {
                                    objlstStarreportchartdatamodel_LY = objlstStarreportchartdatamodel_LY[0];


                                    item.OccChgIndexCompare = objlstStarreportchartdatamodel_LY.OccChgIndex;
                                    item.OccChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccChgMyProperty;
                                    item.OccChgRankCompare = objlstStarreportchartdatamodel_LY.OccChgRank;
                                    item.OccIndexCompare = objlstStarreportchartdatamodel_LY.OccIndex;
                                    item.OccMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccMyProperty;
                                    item.OccRankCompare = objlstStarreportchartdatamodel_LY.OccRank;

                                    item.AdrChgIndexCompare = objlstStarreportchartdatamodel_LY.AdrChgIndex;
                                    item.AdrChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrChgMyProperty;
                                    item.AdrChgRankCompare = objlstStarreportchartdatamodel_LY.AdrChgRank;
                                    item.AdrIndexCompare = objlstStarreportchartdatamodel_LY.AdrIndex;
                                    item.AdrMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrMyProperty;
                                    item.AdrRankCompare = objlstStarreportchartdatamodel_LY.AdrRank;


                                    item.RevParChgIndexCompare = objlstStarreportchartdatamodel_LY.RevParChgIndex;
                                    item.RevParChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParChgMyProperty;
                                    item.RevParChgRankCompare = objlstStarreportchartdatamodel_LY.RevParChgRank;
                                    item.RevParIndexCompare = objlstStarreportchartdatamodel_LY.RevParIndex;
                                    item.RevParMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParMyProperty;
                                    item.RevParRankCompare = objlstStarreportchartdatamodel_LY.RevParRank;


                                    if (item.OccChgCompSet > item.OccChgCompSetCompare) {
                                        item.IsOccChgCompSetUp = true;
                                    }
                                    if (item.OccChgIndex > item.OccChgIndexCompare) {
                                        item.IsOccChgIndexUp = true;
                                    }
                                    if (item.OccChgMyProperty > item.OccChgMyPropertyCompare) {
                                        item.IsOccChgMyPropertyUp = true;
                                    }
                                    if (item.OccCompSet > item.OccCompSetCompare) {
                                        item.IsOccCompSetUp = true;
                                    }
                                    if (item.OccIndex > item.OccIndexCompare) {
                                        item.IsOccIndexUp = true;
                                    }
                                    if (item.OccMyProperty > item.OccMyPropertyCompare) {
                                        item.IsOccMyPropertyUp = true;
                                    }

                                    if (item.AdrChgCompSet > item.AdrChgCompSetCompare) {
                                        item.IsAdrChgCompSetUp = true;
                                    }
                                    if (item.AdrChgIndex > item.AdrChgIndexCompare) {
                                        item.IsAdrChgIndexUp = true;
                                    }
                                    if (item.AdrChgMyProperty > item.AdrChgMyPropertyCompare) {
                                        item.IsAdrChgMyPropertyUp = true;
                                    }
                                    if (item.AdrCompSet > item.AdrCompSetCompare) {
                                        item.IsAdrCompSetUp = true;
                                    }
                                    if (item.AdrIndex > item.AdrIndexCompare) {
                                        item.IsAdrIndexUp = true;
                                    }
                                    if (item.AdrMyProperty > item.AdrMyPropertyCompare) {
                                        item.IsAdrMyPropertyUp = true;
                                    }

                                    if (item.RevParChgCompSet > item.RevParChgCompSetCompare) {
                                        item.IsRevParChgCompSetUp = true;
                                    }
                                    if (item.RevParChgIndex > item.RevParChgIndexCompare) {
                                        item.IsRevParChgIndexUp = true;
                                    }
                                    if (item.RevParChgMyProperty > item.RevParChgMyPropertyCompare) {
                                        item.IsRevParChgMyPropertyUp = true;
                                    }
                                    if (item.RevParCompSet > item.RevParCompSetCompare) {
                                        item.IsRevParCompSetUp = true;
                                    }
                                    if (item.RevParIndex > item.RevParIndexCompare) {
                                        item.IsRevParIndexUp = true;
                                    }
                                    if (item.RevParMyProperty > item.RevParMyPropertyCompare) {
                                        item.IsRevParMyPropertyUp = true;
                                    }

                                }


                            });


                            resolve();

                        });

                        //#endregion
                    }
                    else if (comparison == Constants.StarComparison.Budget) {

                        //#region Budget comparision

                        StrreportHelper.getSTRBudgetData(lstStarreportchartdatamodel, hotelid).then(lstStarreportchartdatamodel_Budget_result => {

                            if (lstStarreportchartdatamodel_Budget_result) {
                                lstStarreportchartdatamodel_Budget = lstStarreportchartdatamodel_Budget_result;
                            }

                            lstStarreportchartdatamodel.forEach(function (item) {
                                if (item.UpdatedBy != "sp_missingdates") {
                                    if (item.OccIndex == 0
                                        && item.OccChgIndex == 0
                                        && item.AdrIndex == 0
                                        && item.AdrChgIndex == 0
                                        && item.RevParIndex == 0
                                        && item.RevParChgIndex == 0) {
                                        missingflag = true;
                                    }
                                }
                                let objlstStarreportchartdatamodel_Budget = lstStarreportchartdatamodel_Budget.filter(d => {
                                    return (d.Date == item.Date);
                                });

                                if (objlstStarreportchartdatamodel_Budget.length > 0) {

                                    objlstStarreportchartdatamodel_Budget = objlstStarreportchartdatamodel_Budget[0];

                                    let totaldays = Utils.dateDiffInDays(item.StartDate, item.EndDate);

                                    if (objlstStarreportchartdatamodel_Budget.MPIBudget
                                        && objlstStarreportchartdatamodel_Budget.MPIBudget != 0
                                        && totaldays != 0) {
                                        item.OccIndexCompare = objlstStarreportchartdatamodel_Budget.MPIBudget / totalDays;
                                    }

                                    if (objlstStarreportchartdatamodel_Budget.ARIBudget
                                        && objlstStarreportchartdatamodel_Budget.ARIBudget != 0
                                        && totaldays != 0) {
                                        item.AdrIndexCompare = objlstStarreportchartdatamodel_Budget.ARIBudget / totalDays;
                                    }

                                    if (objlstStarreportchartdatamodel_Budget.RGIBudget
                                        && objlstStarreportchartdatamodel_Budget.RGIBudget != 0
                                        && totaldays != 0) {
                                        item.RevParIndexCompare = objlstStarreportchartdatamodel_Budget.RGIBudget / totalDays;
                                    }

                                    if (item.OccIndexCompare <= item.OccIndex) {
                                        item.IsOccIndexUp = true;
                                    }
                                    if (item.AdrIndexCompare <= item.AdrIndex) {
                                        item.IsAdrIndexUp = true;
                                    }
                                    if (item.RevParIndexCompare <= item.RevParIndex) {
                                        item.IsRevParIndexUp = true;
                                    }

                                }



                            });

                            resolve();

                        });

                        //#endregion
                    }
                })
            ]).then(resp => {



                lstStrreportdata.forEach(function (item) {

                    var objStrreportitemdatamodel = new Strreportitemdatamodel();
                    var objStrreportlineitemdatamodel = new Strreportlineitemdatamodel();
                    var objStrreportlineitemdatamodel_comparision = new Strreportlineitemdatamodel();

                    objStrreportlineitemdatamodel.title = item.weektitle;
                    if (missingflag) {
                        objStrreportlineitemdatamodel.missingdates = item.weektitle;
                    }

                    objStrreportlineitemdatamodel_comparision.title = item.title;

                    let objStarreportchartdatamodel = lstStarreportchartdatamodel.filter(d => {
                        return (d.EndDate == item.enddate);
                    });

                    if (objStarreportchartdatamodel.length > 0) {
                        objStarreportchartdatamodel = objStarreportchartdatamodel[0];

                        objStrreportlineitemdatamodel.occact = objStarreportchartdatamodel.OccMyProperty;
                        objStrreportlineitemdatamodel.occactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccMyPropertyUp) {
                            objStrreportlineitemdatamodel.occactcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.occchg = objStarreportchartdatamodel.OccChgMyProperty;
                        objStrreportlineitemdatamodel.occchgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccChgMyPropertyUp) {
                            objStrreportlineitemdatamodel.occchgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.mpiact = objStarreportchartdatamodel.OccIndex;
                        objStrreportlineitemdatamodel.mpiactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccIndexUp) {
                            objStrreportlineitemdatamodel.mpiactcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.mpichg = objStarreportchartdatamodel.OccChgIndex;
                        objStrreportlineitemdatamodel.mpichgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccChgIndexUp) {
                            objStrreportlineitemdatamodel.mpichgcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.occrankact = objStarreportchartdatamodel.OccRank;
                        objStrreportlineitemdatamodel.occrankchg = objStarreportchartdatamodel.OccChgRank;

                        objStrreportlineitemdatamodel.adract = objStarreportchartdatamodel.AdrMyProperty;
                        objStrreportlineitemdatamodel.adractcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrMyPropertyUp) {
                            objStrreportlineitemdatamodel.adractcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.adrchg = objStarreportchartdatamodel.AdrChgMyProperty;
                        objStrreportlineitemdatamodel.adrchgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrChgMyPropertyUp) {
                            objStrreportlineitemdatamodel.adrchgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.ariact = objStarreportchartdatamodel.AdrIndex;
                        objStrreportlineitemdatamodel.ariactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrIndexUp) {
                            objStrreportlineitemdatamodel.ariactcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.arichg = objStarreportchartdatamodel.AdrChgIndex;
                        objStrreportlineitemdatamodel.arichgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrChgIndexUp) {
                            objStrreportlineitemdatamodel.arichgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.adrrankact = objStarreportchartdatamodel.AdrRank;
                        objStrreportlineitemdatamodel.adrrankchg = objStarreportchartdatamodel.AdrChgRank;


                        objStrreportlineitemdatamodel.revparact = objStarreportchartdatamodel.RevParMyProperty;
                        objStrreportlineitemdatamodel.revparactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParMyPropertyUp) {
                            objStrreportlineitemdatamodel.revparactcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.revparchg = objStarreportchartdatamodel.RevParChgMyProperty;
                        objStrreportlineitemdatamodel.revparchgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParChgMyPropertyUp) {
                            objStrreportlineitemdatamodel.revparchgcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.rgiact = objStarreportchartdatamodel.RevParIndex;
                        objStrreportlineitemdatamodel.rgiactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParIndexUp) {
                            objStrreportlineitemdatamodel.rgiactcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.rgichg = objStarreportchartdatamodel.RevParChgIndex;
                        objStrreportlineitemdatamodel.rgichgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParChgIndexUp) {
                            objStrreportlineitemdatamodel.rgichgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.revparrankact = objStarreportchartdatamodel.RevParRank;
                        objStrreportlineitemdatamodel.revparrankchg = objStarreportchartdatamodel.RevParChgRank;


                        objStrreportlineitemdatamodel_comparision.mpiact = objStarreportchartdatamodel.OccIndexCompare;
                        objStrreportlineitemdatamodel_comparision.occrankact = objStarreportchartdatamodel.OccRankCompare;
                        objStrreportlineitemdatamodel_comparision.occrankchg = objStarreportchartdatamodel.OccChgRankCompare;

                        objStrreportlineitemdatamodel_comparision.ariact = objStarreportchartdatamodel.AdrIndexCompare;
                        objStrreportlineitemdatamodel_comparision.adrrankact = objStarreportchartdatamodel.AdrRankCompare;
                        objStrreportlineitemdatamodel_comparision.adrrankchg = objStarreportchartdatamodel.AdrChgRankCompare;

                        objStrreportlineitemdatamodel_comparision.rgiact = objStarreportchartdatamodel.RevParIndexCompare;
                        objStrreportlineitemdatamodel_comparision.revparrankact = objStarreportchartdatamodel.RevParRankCompare;
                        objStrreportlineitemdatamodel_comparision.revparrankchg = objStarreportchartdatamodel.RevParChgRankCompare;


                        if (comparison == Constants.StarComparison.Budget) {

                            objStrreportlineitemdatamodel_comparision.occact = "NA";
                            objStrreportlineitemdatamodel_comparision.occchg = "NA";
                            objStrreportlineitemdatamodel_comparision.mpichg = "NA";
                            objStrreportlineitemdatamodel_comparision.adract = "NA";
                            objStrreportlineitemdatamodel_comparision.adrchg = "NA";
                            objStrreportlineitemdatamodel_comparision.arichg = "NA";
                            objStrreportlineitemdatamodel_comparision.revparact = "NA";
                            objStrreportlineitemdatamodel_comparision.revparchg = "NA";
                            objStrreportlineitemdatamodel_comparision.rgichg = "NA";

                        }
                        else {
                            objStrreportlineitemdatamodel_comparision.occact = objStarreportchartdatamodel.OccMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.occchg = objStarreportchartdatamodel.OccChgMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.mpichg = objStarreportchartdatamodel.OccChgIndexCompare;
                            objStrreportlineitemdatamodel_comparision.adract = objStarreportchartdatamodel.AdrMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.adrchg = objStarreportchartdatamodel.AdrChgMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.arichg = objStarreportchartdatamodel.AdrChgIndexCompare;
                            objStrreportlineitemdatamodel_comparision.revparact = objStarreportchartdatamodel.RevParMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.revparchg = objStarreportchartdatamodel.RevParChgMyPropertyCompare;
                            objStrreportlineitemdatamodel_comparision.rgichg = objStarreportchartdatamodel.RevParChgIndexCompare;

                        }
                    }
                    objStrreportitemdatamodel.id = item.weeknumber;
                    objStrreportitemdatamodel.actualdata = objStrreportlineitemdatamodel.setFormat(objStrreportlineitemdatamodel);
                    objStrreportitemdatamodel.comparisiondata = objStrreportlineitemdatamodel_comparision.setFormat(objStrreportlineitemdatamodel_comparision);

                    lstStrreportitemdatamodel.push(objStrreportitemdatamodel);
                });

                // cb(null, lstStarreportchartdatamodel);
                cb(null, lstStrreportitemdatamodel);

            }, err => {
                return cb(err);
            })

        });
    }
    static getStrReportDefaultData(hotelid, year, month, userconfigdata, cb) {


        var monthnumber = Utils.getMonthByName(month);

        var reportdate = new Date(year, monthnumber - 1, 1);

        var dtreportdate = new Date(reportdate);

        let hotelsData = [];
        let lstStrreportdata = [];

        var firstDayOfMonth = Utils.firstDayOfMonth(dtreportdate);


        //get all days for this month
        var currentmonth = Utils.getMonthNumber(firstDayOfMonth);

        var week = 0;
        var i = 0;
        var currentyear = firstDayOfMonth.getFullYear();

        while (monthnumber == currentmonth) {

            //#region  get all month days
            if (i % 7 == 0) {
                week = week + 1;
            }

            var objStrreportdata = new Strreportdefaultdata();
            var startdate = new Date(firstDayOfMonth.getFullYear(), firstDayOfMonth.getMonth(), firstDayOfMonth.getDate());
            objStrreportdata.month = Utils.getFormattedDate(startdate, 'MMM');
            objStrreportdata.day = Utils.getFormattedDate(startdate, 'dddd');
            objStrreportdata.date = startdate;
            objStrreportdata.displaydate = Utils.getFormattedDate(startdate, 'Do') + " " + objStrreportdata.month + " " + currentyear;
            objStrreportdata.week = "Week " + week;
            lstStrreportdata.push(objStrreportdata);
            firstDayOfMonth.setDate(firstDayOfMonth.getDate() + 1);
            currentmonth = Utils.getMonthNumber(firstDayOfMonth);

            i = i + 1;
            //#endregion

        }

        let lstStrreportitemdatamodel = [];
        let lstStrreportdefaultdatamodel = [];

        StarreportHelper.GetMonthData(hotelid, dtreportdate, (err, lstStrreportdefaultdatamodel_result) => {

            if (err) {
                log.error(err);
            }

            if (lstStrreportdefaultdatamodel_result) {
                lstStrreportdefaultdatamodel = lstStrreportdefaultdatamodel_result;
            }
            lstStrreportdefaultdatamodel = Utils.sort(lstStrreportdefaultdatamodel, 'Date');
            lstStrreportdata.forEach(function (item) {

                var objStrreportitemdatamodel = new Strreportdefaultitemdatamodel();
                var objStrreportdefaultlineitemdatamodel_occ = new Strreportdefaultlineitemdatamodel();
                var objStrreportdefaultlineitemdatamodel_adr = new Strreportdefaultlineitemdatamodel();
                var objStrreportdefaultlineitemdatamodel_revpar = new Strreportdefaultlineitemdatamodel();

                objStrreportitemdatamodel.month = item.month;
                objStrreportitemdatamodel.week = item.week;
                objStrreportitemdatamodel.day = item.day;
                objStrreportitemdatamodel.date = item.date;
                objStrreportitemdatamodel.displaydate = item.displaydate;

                var dt = item.date;
                let objStrreportdefaultdatamodel = lstStrreportdefaultdatamodel.filter(d => {
                    var time = new Date(d.Date);
                    time.setHours(0, 0, 0, 0);
                    return (time >= dt && time <= dt);
                });

                if (objStrreportdefaultdatamodel.length > 0) {

                    objStrreportdefaultdatamodel = objStrreportdefaultdatamodel[0];
                    objStrreportdefaultlineitemdatamodel_occ.myproperty = objStrreportdefaultdatamodel.OccMyProperty;
                    objStrreportdefaultlineitemdatamodel_occ.mypropertychange = objStrreportdefaultdatamodel.OccChgMyProperty;
                    objStrreportdefaultlineitemdatamodel_occ.index = objStrreportdefaultdatamodel.OccIndex;
                    objStrreportdefaultlineitemdatamodel_occ.indexchange = objStrreportdefaultdatamodel.OccChgIndex;

                    objStrreportdefaultlineitemdatamodel_adr.myproperty = objStrreportdefaultdatamodel.AdrMyProperty;
                    objStrreportdefaultlineitemdatamodel_adr.mypropertychange = objStrreportdefaultdatamodel.AdrChgMyProperty;
                    objStrreportdefaultlineitemdatamodel_adr.index = objStrreportdefaultdatamodel.AdrIndex;
                    objStrreportdefaultlineitemdatamodel_adr.indexchange = objStrreportdefaultdatamodel.AdrChgIndex;

                    objStrreportdefaultlineitemdatamodel_revpar.myproperty = objStrreportdefaultdatamodel.RevParMyProperty;
                    objStrreportdefaultlineitemdatamodel_revpar.mypropertychange = objStrreportdefaultdatamodel.RevParChgMyProperty;
                    objStrreportdefaultlineitemdatamodel_revpar.index = objStrreportdefaultdatamodel.RevParIndex;
                    objStrreportdefaultlineitemdatamodel_revpar.indexchange = objStrreportdefaultdatamodel.RevParChgIndex;

                }
                objStrreportitemdatamodel.occupancy = objStrreportdefaultlineitemdatamodel_occ.setFormat(objStrreportdefaultlineitemdatamodel_occ);
                objStrreportitemdatamodel.adr = objStrreportdefaultlineitemdatamodel_adr.setFormat(objStrreportdefaultlineitemdatamodel_adr);
                objStrreportitemdatamodel.revpar = objStrreportdefaultlineitemdatamodel_revpar.setFormat(objStrreportdefaultlineitemdatamodel_revpar);
                lstStrreportitemdatamodel.push(objStrreportitemdatamodel);
            });

            cb(null, lstStrreportitemdatamodel);

        });


    }


    static getYTDRoomRevenueData(lstStrreportdata_temp, dtlastDayOfMonth) {

        let lstStarreportchartdatamodel = [];
        var counter = lstStrreportdata_temp.length;
        return new Promise((resolve, reject) => {
            if (lstStrreportdata_temp != undefined && lstStrreportdata_temp.length > 0) {
                lstStrreportdata_temp.forEach(function (item) {
                    //get YTD Room Revenue 
                    HoteldashboardcalculationsHelper.GetData(item.hotelid, dtlastDayOfMonth, (err, hoteldashboardcalculations_result) => {
                        if (!err) {
                            lstStarreportchartdatamodel.push(hoteldashboardcalculations_result);
                        }
                        counter = counter - 1;
                        if (counter == 0) {
                            resolve(lstStarreportchartdatamodel);
                        }
                    });
                });
            }
        });
    }


    static getSTRPortfolioItemsData(lstStrreportdata_temp, dtfirstDayOfMonth, dtlastDayOfMonth, frommonthtable) {

        let lstStarreportchartdatamodel = [];
        var counter = lstStrreportdata_temp.length;
        return new Promise((resolve, reject) => {
            if (lstStrreportdata_temp != undefined && lstStrreportdata_temp.length > 0) {
                lstStrreportdata_temp.forEach(function (item) {

                    //get STRPortfolioData
                    StarreportHelper.getSTRPortfolioData(item.hotelid, dtfirstDayOfMonth, dtlastDayOfMonth, frommonthtable, (err, result) => {
                        if (!err) {
                            lstStarreportchartdatamodel.push(result);
                        }
                        counter = counter - 1;
                        if (counter == 0) {
                            resolve(lstStarreportchartdatamodel);
                        }
                    });
                });
            }
        });
    }

    static getSTRPortfolioData(userid, orgid, year, month, userconfigdata, cb) {


        var monthnumber = Utils.getMonthByName(month);

        var reportdate = new Date(year, monthnumber - 1, 1);

        var dtreportdate = new Date(reportdate);

        var dtlastDayOfMonth = Utils.lastDayOfMonth(dtreportdate);
        var dtfirstDayOfMonth = Utils.firstDayOfMonth(dtreportdate);

        var dtlastDayOfMonth_YTD = Utils.firstDayOfMonth(dtreportdate);
        dtlastDayOfMonth_YTD.setMonth(dtlastDayOfMonth_YTD.getMonth() - 13);

        let lstStrportfoliolineitemdatamodel = [];
        let lstStrportfoliolineitemdatamodel_YTD = [];
        let lstStrportfoliolineitemdatamodel_STR = [];
        let lstStrportfoliolineitemdatamodel_STR_YTD = [];
        let lstStrportfoliolineitemdatamodel_actual = [];

        var monthname = Utils.getFormattedDate(reportdate, 'MMM - YYYY');

        //get user info from id
        UserHelper.getUserData(userid, (err, userinfo) => {

            if (err) {
                log.error(err);
            }
            if (!userinfo) {
                cb(null, null);
            }
            else {
                let secondaryOrganizationId = -1;
                if (userinfo.SecondaryOrganizationId) {
                    secondaryOrganizationId = userinfo.SecondaryOrganizationId;
                }


                //get all hotels from orgid 
                //   HotelsHelper.GetHotelsByOrganizationIdandRoleID(userid, orgid, secondaryOrganizationId, userinfo.RoleID, (err, orghotels) => {
                HotelsHelper.GetHotelsByGroupId(userid, orgid, (err, orghotels) => {
                    if (err) {
                        log.error(err);
                    }
                    if (orghotels && orghotels.length > 0) {

                        orghotels = Utils.sort(orghotels, 'HotelName');
                        orghotels.forEach(function (item) {

                            var objStrportfoliolineitemdatamodel = new Strportfoliolineitemdatamodel();
                            objStrportfoliolineitemdatamodel.name = item.HotelName;
                            objStrportfoliolineitemdatamodel.hotelid = item.ID;
                            objStrportfoliolineitemdatamodel.month = monthname;
                            lstStrportfoliolineitemdatamodel.push(objStrportfoliolineitemdatamodel);
                        });

                        return Promise.all([
                            new Promise((resolve, reject) => {

                                //get YTD Room Revenue 
                                StrreportHelper.getYTDRoomRevenueData(lstStrportfoliolineitemdatamodel, dtlastDayOfMonth).then(lstStrportfoliolineitemdatamodel_YTD_result => {
                                    if (lstStrportfoliolineitemdatamodel_YTD_result && lstStrportfoliolineitemdatamodel_YTD_result.length > 0) {
                                        lstStrportfoliolineitemdatamodel_YTD = lstStrportfoliolineitemdatamodel_YTD_result;
                                    }
                                    resolve();
                                });

                            }),
                            new Promise((resolve, reject) => {

                                //get StarReport data
                                StrreportHelper.getSTRPortfolioItemsData(lstStrportfoliolineitemdatamodel, dtfirstDayOfMonth, dtlastDayOfMonth, false).then(lstStrportfoliolineitemdatamodel_STR_result => {
                                    if (lstStrportfoliolineitemdatamodel_STR_result && lstStrportfoliolineitemdatamodel_STR_result.length > 0) {
                                        lstStrportfoliolineitemdatamodel_STR = lstStrportfoliolineitemdatamodel_STR_result;
                                    }
                                    resolve();
                                });

                            }),
                            new Promise((resolve, reject) => {

                                //get StarReport data YTD
                                StrreportHelper.getSTRPortfolioItemsData(lstStrportfoliolineitemdatamodel, dtlastDayOfMonth_YTD, dtfirstDayOfMonth, true).then(lstStrportfoliolineitemdatamodel_STR_YTD_result => {
                                    if (lstStrportfoliolineitemdatamodel_STR_YTD_result && lstStrportfoliolineitemdatamodel_STR_YTD_result.length > 0) {
                                        lstStrportfoliolineitemdatamodel_STR_YTD = lstStrportfoliolineitemdatamodel_STR_YTD_result;
                                    }
                                    resolve();
                                });

                            })

                        ]).then(resp => {

                            lstStrportfoliolineitemdatamodel.forEach(function (item) {

                                let isdatavailable = false;

                                var objStrportfoliolineitemdatamodel_YTD = lstStrportfoliolineitemdatamodel_YTD.filter(d => {
                                    return (d != null && d.HotelID == item.hotelid);
                                });

                                if (objStrportfoliolineitemdatamodel_YTD.length > 0) {

                                    objStrportfoliolineitemdatamodel_YTD = objStrportfoliolineitemdatamodel_YTD[0];
                                    item.ytdroomrevenue = objStrportfoliolineitemdatamodel_YTD.TotalRevenueYTD;

                                    //#region Current Month

                                    var objStrportfoliolineitemdatamodel_STR = lstStrportfoliolineitemdatamodel_STR.filter(d => {
                                        return (d != null && d._id == item.hotelid);
                                    });


                                    var objStrportfoliomonthlineitemdatamodel_current_revpar = new Strportfoliomonthlineitemdatamodel();
                                    var objStrportfoliomonthlineitemdatamodel_current_adr = new Strportfoliomonthlineitemdatamodel();
                                    var objStrportfoliomonthlineitemdatamodel_current_occ = new Strportfoliomonthlineitemdatamodel();

                                    if (objStrportfoliolineitemdatamodel_STR.length > 0) {
                                        isdatavailable = true;

                                        objStrportfoliolineitemdatamodel_STR = objStrportfoliolineitemdatamodel_STR[0];

                                        objStrportfoliomonthlineitemdatamodel_current_revpar.hotelvalue = objStrportfoliolineitemdatamodel_STR.RevParMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_current_revpar.hotelvaluechange = objStrportfoliolineitemdatamodel_STR.RevParChgMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_current_revpar.compsetvalue = objStrportfoliolineitemdatamodel_STR.RevParCompSet;
                                        objStrportfoliomonthlineitemdatamodel_current_revpar.compsetvaluechange = objStrportfoliolineitemdatamodel_STR.RevParChgCompSet;

                                        objStrportfoliomonthlineitemdatamodel_current_adr.hotelvalue = objStrportfoliolineitemdatamodel_STR.AdrMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_current_adr.hotelvaluechange = objStrportfoliolineitemdatamodel_STR.AdrChgMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_current_adr.compsetvalue = objStrportfoliolineitemdatamodel_STR.AdrCompSet;
                                        objStrportfoliomonthlineitemdatamodel_current_adr.compsetvaluechange = objStrportfoliolineitemdatamodel_STR.AdrChgCompSet;

                                        objStrportfoliomonthlineitemdatamodel_current_occ.hotelvalue = objStrportfoliolineitemdatamodel_STR.OccMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_current_occ.hotelvaluechange = objStrportfoliolineitemdatamodel_STR.OccChgMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_current_occ.compsetvalue = objStrportfoliolineitemdatamodel_STR.OccCompSet;
                                        objStrportfoliomonthlineitemdatamodel_current_occ.compsetvaluechange = objStrportfoliolineitemdatamodel_STR.OccChgCompSet;

                                    }

                                    var objStrportfoliomonthitemdatamodel_current = new Strportfoliomonthitemdatamodel();
                                    objStrportfoliomonthitemdatamodel_current.revpar = objStrportfoliomonthlineitemdatamodel_current_revpar.setFormat(objStrportfoliomonthlineitemdatamodel_current_revpar);
                                    objStrportfoliomonthitemdatamodel_current.adr = objStrportfoliomonthlineitemdatamodel_current_adr.setFormat(objStrportfoliomonthlineitemdatamodel_current_adr);
                                    objStrportfoliomonthitemdatamodel_current.occ = objStrportfoliomonthlineitemdatamodel_current_occ.setFormat(objStrportfoliomonthlineitemdatamodel_current_occ);

                                    //#endregion

                                    //#region Running 12 month

                                    var objStrportfoliolineitemdatamodel_STR_YTD = lstStrportfoliolineitemdatamodel_STR_YTD.filter(d => {
                                        return (d != null && d._id == item.hotelid);
                                    });

                                    var objStrportfoliomonthlineitemdatamodel_running12month_revpar = new Strportfoliomonthlineitemdatamodel();
                                    var objStrportfoliomonthlineitemdatamodel_running12month_adr = new Strportfoliomonthlineitemdatamodel();
                                    var objStrportfoliomonthlineitemdatamodel_running12month_occ = new Strportfoliomonthlineitemdatamodel();

                                    if (objStrportfoliolineitemdatamodel_STR_YTD.length > 0) {
                                        objStrportfoliolineitemdatamodel_STR_YTD = objStrportfoliolineitemdatamodel_STR_YTD[0];


                                        objStrportfoliomonthlineitemdatamodel_running12month_revpar.hotelvalue = objStrportfoliolineitemdatamodel_STR_YTD.RevParMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_running12month_revpar.hotelvaluechange = objStrportfoliolineitemdatamodel_STR_YTD.RevParChgMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_running12month_revpar.compsetvalue = objStrportfoliolineitemdatamodel_STR_YTD.RevParCompSet;
                                        objStrportfoliomonthlineitemdatamodel_running12month_revpar.compsetvaluechange = objStrportfoliolineitemdatamodel_STR_YTD.RevParChgCompSet;

                                        objStrportfoliomonthlineitemdatamodel_running12month_adr.hotelvalue = objStrportfoliolineitemdatamodel_STR_YTD.AdrMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_running12month_adr.hotelvaluechange = objStrportfoliolineitemdatamodel_STR_YTD.AdrChgMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_running12month_adr.compsetvalue = objStrportfoliolineitemdatamodel_STR_YTD.AdrCompSet;
                                        objStrportfoliomonthlineitemdatamodel_running12month_adr.compsetvaluechange = objStrportfoliolineitemdatamodel_STR_YTD.AdrChgCompSet;

                                        objStrportfoliomonthlineitemdatamodel_running12month_occ.hotelvalue = objStrportfoliolineitemdatamodel_STR_YTD.OccMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_running12month_occ.hotelvaluechange = objStrportfoliolineitemdatamodel_STR_YTD.OccChgMyProperty;
                                        objStrportfoliomonthlineitemdatamodel_running12month_occ.compsetvalue = objStrportfoliolineitemdatamodel_STR_YTD.OccCompSet;
                                        objStrportfoliomonthlineitemdatamodel_running12month_occ.compsetvaluechange = objStrportfoliolineitemdatamodel_STR_YTD.OccChgCompSet;


                                    }

                                    var objStrportfoliomonthitemdatamodel_running12month = new Strportfoliomonthitemdatamodel();
                                    objStrportfoliomonthitemdatamodel_running12month.revpar = objStrportfoliomonthlineitemdatamodel_running12month_revpar.setFormat(objStrportfoliomonthlineitemdatamodel_running12month_revpar);
                                    objStrportfoliomonthitemdatamodel_running12month.adr = objStrportfoliomonthlineitemdatamodel_running12month_adr.setFormat(objStrportfoliomonthlineitemdatamodel_running12month_adr);
                                    objStrportfoliomonthitemdatamodel_running12month.occ = objStrportfoliomonthlineitemdatamodel_running12month_occ.setFormat(objStrportfoliomonthlineitemdatamodel_running12month_occ);


                                    //#endregion

                                    item.currentmonth = objStrportfoliomonthitemdatamodel_current;
                                    item.running12month = objStrportfoliomonthitemdatamodel_running12month;


                                    item = item.setFormat(item);

                                    //if (isdatavailable) {
                                    lstStrportfoliolineitemdatamodel_actual.push(item);
                                    // }
                                }

                            });




                            cb(null, lstStrportfoliolineitemdatamodel_actual);

                        }, err => {
                            return cb(err);
                        })
                    }
                    else {
                        cb(null, lstStrportfoliolineitemdatamodel_actual);
                    }
                });
            }
        });

    }

    static getStrReportWidgetData(hotelid, currentdate, comparison, type, userconfigdata, cb) {

        comparison = comparison.toLowerCase();
        type = type.toLowerCase();
        currentdate = new Date(currentdate);
        let repdate = new Date(currentdate.getFullYear(), currentdate.getMonth(), currentdate.getDate() + 8);
        repdate = Utils.getFirstDayOfWeek(repdate, currentdate.getFullYear(), Utils.getWeekNumber(repdate));
        var monthnumber = repdate.getMonth(); //Utils.getMonthByName(month);
        var year = repdate.getFullYear();
        var reportdate = new Date(year, monthnumber - 1, repdate.getDate() + 8);

        var dtreportdate = new Date(reportdate);

        let lstStrreportdata = [];

        var firstSundayOfMonth = Utils.getFirstDayOfWeek(dtreportdate, dtreportdate.getFullYear(), Utils.getWeekNumber(dtreportdate));

        let dateComparetitle = 'LY Same Period';

        if (comparison == Constants.StarComparison.LastYear) {
            dateComparetitle = "LY Same Period";
        }
        else if (comparison == Constants.StarComparison.Last28Days) {
            dateComparetitle = "Running 28 Days";
        }
        else if (comparison == Constants.StarComparison.Budget) {
            dateComparetitle = "Budget";
        }
        //get all weeks for this month
        var currentmonth = Utils.getMonthNumber(firstSundayOfMonth);
        var i = 4;
        while (i > 0) {

            if (type == Constants.StarType.Month) {

                //#region for type = month
                var objStrreportdata = new Strreportdata();
                objStrreportdata.startdate = new Date(firstSundayOfMonth.getFullYear(), firstSundayOfMonth.getMonth(), 1);
                objStrreportdata.enddate = Utils.lastDayOfMonth(objStrreportdata.startdate);

                let weeknumber = Utils.getWeekNumber(firstSundayOfMonth) + 1;

                objStrreportdata.weektitle = "Month " + weeknumber;
                objStrreportdata.weeknumber = weeknumber;
                objStrreportdata.title = dateComparetitle;
                objStrreportdata.enddate = objStrreportdata.enddate;
                var scurrentmonth = Utils.getMonthNumber(objStrreportdata.startdate);
                var ecurrentmonth = Utils.getMonthNumber(objStrreportdata.enddate);

                if (scurrentmonth == ecurrentmonth) {

                    objStrreportdata.weektitle = objStrreportdata.weektitle + " (" + Utils.getFormattedDate(objStrreportdata.startdate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.startdate, 'DD')
                        + " to " + Utils.getFormattedDate(objStrreportdata.enddate, 'DD')
                        + ")";
                }
                else {
                    objStrreportdata.weektitle = objStrreportdata.weektitle + " (" + Utils.getFormattedDate(objStrreportdata.startdate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.startdate, 'DD')
                        + " to " + Utils.getFormattedDate(objStrreportdata.enddate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.enddate, 'DD')
                        + ")";
                }


                let totaldays = Utils.dateDiffInDays(objStrreportdata.startdate, objStrreportdata.enddate);

                lstStrreportdata.push(objStrreportdata);
                firstSundayOfMonth.setDate(firstSundayOfMonth.getDate() + totaldays);
                currentmonth = Utils.getMonthNumber(firstSundayOfMonth);
                //#endregion

            }
            else {

                //#region for type = week
                var objStrreportdata = new Strreportdata();
                objStrreportdata.startdate = new Date(firstSundayOfMonth.getFullYear(), firstSundayOfMonth.getMonth(), firstSundayOfMonth.getDate());
                objStrreportdata.enddate = new Date(firstSundayOfMonth.getFullYear(), firstSundayOfMonth.getMonth(), firstSundayOfMonth.getDate());
                objStrreportdata.enddate.setDate(objStrreportdata.enddate.getDate() + 6);

                let weeknumber = Utils.getWeekNumber(objStrreportdata.startdate) + 1;
                objStrreportdata.weektitle = "Week " + weeknumber;
                objStrreportdata.weeknumber = weeknumber;
                objStrreportdata.title = dateComparetitle;
                objStrreportdata.enddate = objStrreportdata.enddate;


                var scurrentmonth = Utils.getMonthNumber(objStrreportdata.startdate);
                var ecurrentmonth = Utils.getMonthNumber(objStrreportdata.enddate);

                if (scurrentmonth == ecurrentmonth) {

                    objStrreportdata.weektitle = objStrreportdata.weektitle + " (" + Utils.getFormattedDate(objStrreportdata.startdate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.startdate, 'DD')
                        + " to " + Utils.getFormattedDate(objStrreportdata.enddate, 'DD')
                        + ")";
                }
                else {
                    objStrreportdata.weektitle = objStrreportdata.weektitle + " (" + Utils.getFormattedDate(objStrreportdata.startdate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.startdate, 'DD')
                        + " to " + Utils.getFormattedDate(objStrreportdata.enddate, 'MMM')
                        + " " + Utils.getFormattedDate(objStrreportdata.enddate, 'DD')
                        + ")";
                }

                lstStrreportdata.push(objStrreportdata);
                firstSundayOfMonth.setDate(firstSundayOfMonth.getDate() + 7);
                currentmonth = Utils.getMonthNumber(firstSundayOfMonth);
                //#endregion

            }
            i = i - 1;
        }

        let lstStarreportchartdatamodel = [];
        let lstStarreportchartdatamodel_LY = [];
        let lstStrreportitemdatamodel = [];

        StrreportHelper.getSTRData(lstStrreportdata, hotelid).then(lstStarreportchartdatamodel_result => {

            if (lstStarreportchartdatamodel_result) {
                lstStarreportchartdatamodel = lstStarreportchartdatamodel_result;
            }
            lstStarreportchartdatamodel = Utils.sort(lstStarreportchartdatamodel, 'DateForChart');

            lstStarreportchartdatamodel.forEach(function (item) {

                let startDateLY = Utils.lastYearDate(item.DateForChart);
                let startDateCompare = item.StartDate;
                let endDateCompare = item.EndDate;

                if (comparison == Constants.StarComparison.LastYear) {
                    item.DateCompare = "LY Same Period";
                    if (type == Constants.StarType.Month) {
                        startDateCompare = Utils.getFirstDayOfWeek(startDateLY, startDateLY.getFullYear(), item.WeekNumber);
                    }
                    else {
                        startDateCompare = Utils.getFirstDayOfWeek(startDateLY, startDateLY.getFullYear(), item.WeekNumber + 1);
                    }
                    endDateCompare = new Date(startDateCompare);
                    endDateCompare.setDate(startDateCompare.getDate() + 6);
                }                
                else if (comparison == Constants.StarComparison.Last28Days) {

                    item.DateCompare = "Running 28 Days";

                }
                else if (comparison == Constants.StarComparison.Budget) {
                    item.DateCompare = "Budget";
                }

                item.startDateCompare = startDateCompare;
                item.endDateCompare = endDateCompare;

            });
            let missingflag = false;
            return Promise.all([
                new Promise((resolve, reject) => {
                    if (comparison == Constants.StarComparison.LastYear) {
                        //#region  Last Year Comparision
                        StrreportHelper.getSTRLYSamePeriodData(lstStarreportchartdatamodel, hotelid).then(lstStarreportchartdatamodel_LY_result => {

                            if (lstStarreportchartdatamodel_LY_result) {
                                lstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY_result;
                            }

                            lstStarreportchartdatamodel.forEach(function (item) {

                                let objlstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY.filter(d => {
                                    return (d.Date == item.Date);
                                });

                                if (objlstStarreportchartdatamodel_LY.length > 0) {
                                    objlstStarreportchartdatamodel_LY = objlstStarreportchartdatamodel_LY[0];


                                    item.OccChgIndexCompare = objlstStarreportchartdatamodel_LY.OccChgIndex;
                                    item.OccChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccChgMyProperty;
                                    item.OccChgRankCompare = objlstStarreportchartdatamodel_LY.OccChgRank;
                                    item.OccIndexCompare = objlstStarreportchartdatamodel_LY.OccIndex;
                                    item.OccMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccMyProperty;
                                    item.OccRankCompare = objlstStarreportchartdatamodel_LY.OccRank;

                                    item.AdrChgIndexCompare = objlstStarreportchartdatamodel_LY.AdrChgIndex;
                                    item.AdrChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrChgMyProperty;
                                    item.AdrChgRankCompare = objlstStarreportchartdatamodel_LY.AdrChgRank;
                                    item.AdrIndexCompare = objlstStarreportchartdatamodel_LY.AdrIndex;
                                    item.AdrMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrMyProperty;
                                    item.AdrRankCompare = objlstStarreportchartdatamodel_LY.AdrRank;


                                    item.RevParChgIndexCompare = objlstStarreportchartdatamodel_LY.RevParChgIndex;
                                    item.RevParChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParChgMyProperty;
                                    item.RevParChgRankCompare = objlstStarreportchartdatamodel_LY.RevParChgRank;
                                    item.RevParIndexCompare = objlstStarreportchartdatamodel_LY.RevParIndex;
                                    item.RevParMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParMyProperty;
                                    item.RevParRankCompare = objlstStarreportchartdatamodel_LY.RevParRank;


                                    if (item.OccChgCompSet > item.OccChgCompSetCompare) {
                                        item.IsOccChgCompSetUp = true;
                                    }
                                    if (item.OccChgIndex > item.OccChgIndexCompare || item.OccChgIndexCompare == "NA") {
                                        item.IsOccChgIndexUp = true;
                                    }
                                    if (item.OccChgMyProperty > item.OccChgMyPropertyCompare || item.OccChgMyPropertyCompare == "NA") {
                                        item.IsOccChgMyPropertyUp = true;
                                    }
                                    if (item.OccCompSet > item.OccCompSetCompare) {
                                        item.IsOccCompSetUp = true;
                                    }
                                    if (item.OccIndex > item.OccIndexCompare || item.OccIndexCompare == "NA") {
                                        item.IsOccIndexUp = true;
                                    }
                                    if (item.OccMyProperty > item.OccMyPropertyCompare || item.OccMyPropertyCompare == "NA") {
                                        item.IsOccMyPropertyUp = true;
                                    }

                                    if (item.AdrChgCompSet > item.AdrChgCompSetCompare) {
                                        item.IsAdrChgCompSetUp = true;
                                    }
                                    if (item.AdrChgIndex > item.AdrChgIndexCompare || item.AdrChgIndexCompare == "NA") {
                                        item.IsAdrChgIndexUp = true;
                                    }
                                    if (item.AdrChgMyProperty > item.AdrChgMyPropertyCompare || item.AdrChgMyPropertyCompare == "NA") {
                                        item.IsAdrChgMyPropertyUp = true;
                                    }
                                    if (item.AdrCompSet > item.AdrCompSetCompare) {
                                        item.IsAdrCompSetUp = true;
                                    }
                                    if (item.AdrIndex > item.AdrIndexCompare || item.AdrIndexCompare == "NA") {
                                        item.IsAdrIndexUp = true;
                                    }
                                    if (item.AdrMyProperty > item.AdrMyPropertyCompare || item.AdrMyPropertyCompare == "NA") {
                                        item.IsAdrMyPropertyUp = true;
                                    }

                                    if (item.RevParChgCompSet > item.RevParChgCompSetCompare) {
                                        item.IsRevParChgCompSetUp = true;
                                    }
                                    if (item.RevParChgIndex > item.RevParChgIndexCompare || item.RevParChgIndexCompare == "NA") {
                                        item.IsRevParChgIndexUp = true;
                                    }
                                    if (item.RevParChgMyProperty > item.RevParChgMyPropertyCompare || item.RevParChgMyPropertyCompare == "NA") {
                                        item.IsRevParChgMyPropertyUp = true;
                                    }
                                    if (item.RevParCompSet > item.RevParCompSetCompare) {
                                        item.IsRevParCompSetUp = true;
                                    }
                                    if (item.RevParIndex > item.RevParIndexCompare || item.RevParIndexCompare == "NA") {
                                        item.IsRevParIndexUp = true;
                                    }
                                    if (item.RevParMyProperty > item.RevParMyPropertyCompare || item.RevParMyPropertyCompare == "NA") {
                                        item.IsRevParMyPropertyUp = true;
                                    }

                                }
                                else //no LY data to compare
                                {
                                    item.IsOccMyPropertyUp = true;
                                    item.IsOccIndexUp = true;
                                    item.IsAdrMyPropertyUp = true;
                                    item.IsAdrIndexUp = true;
                                    item.IsRevParMyPropertyUp = true;
                                    item.IsRevParIndexUp = true;

                                }
                            });

                            resolve();

                        });
                        //#endregion
                    }
                    else if (comparison == Constants.StarComparison.Last28Days) {

                        //#region  Last28Days Comparision

                        StrreportHelper.getSTRRunning28DaysData(lstStarreportchartdatamodel, hotelid).then(lstStarreportchartdatamodel_LY_result => {

                            if (lstStarreportchartdatamodel_LY_result) {
                                lstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY_result;
                            }

                            lstStarreportchartdatamodel.forEach(function (item) {
                                if (item.UpdatedBy != "sp_missingdates") {
                                    if (item.OccIndex == 0
                                        && item.OccChgIndex == 0
                                        && item.AdrIndex == 0
                                        && item.AdrChgIndex == 0
                                        && item.RevParIndex == 0
                                        && item.RevParChgIndex == 0) {
                                        missingflag = true;
                                    }
                                }
                                let objlstStarreportchartdatamodel_LY = lstStarreportchartdatamodel_LY.filter(d => {
                                    return (d.Date == item.Date);
                                });

                                if (objlstStarreportchartdatamodel_LY.length > 0) {
                                    objlstStarreportchartdatamodel_LY = objlstStarreportchartdatamodel_LY[0];


                                    item.OccChgIndexCompare = objlstStarreportchartdatamodel_LY.OccChgIndex;
                                    item.OccChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccChgMyProperty;
                                    item.OccChgRankCompare = objlstStarreportchartdatamodel_LY.OccChgRank;
                                    item.OccIndexCompare = objlstStarreportchartdatamodel_LY.OccIndex;
                                    item.OccMyPropertyCompare = objlstStarreportchartdatamodel_LY.OccMyProperty;
                                    item.OccRankCompare = objlstStarreportchartdatamodel_LY.OccRank;

                                    item.AdrChgIndexCompare = objlstStarreportchartdatamodel_LY.AdrChgIndex;
                                    item.AdrChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrChgMyProperty;
                                    item.AdrChgRankCompare = objlstStarreportchartdatamodel_LY.AdrChgRank;
                                    item.AdrIndexCompare = objlstStarreportchartdatamodel_LY.AdrIndex;
                                    item.AdrMyPropertyCompare = objlstStarreportchartdatamodel_LY.AdrMyProperty;
                                    item.AdrRankCompare = objlstStarreportchartdatamodel_LY.AdrRank;


                                    item.RevParChgIndexCompare = objlstStarreportchartdatamodel_LY.RevParChgIndex;
                                    item.RevParChgMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParChgMyProperty;
                                    item.RevParChgRankCompare = objlstStarreportchartdatamodel_LY.RevParChgRank;
                                    item.RevParIndexCompare = objlstStarreportchartdatamodel_LY.RevParIndex;
                                    item.RevParMyPropertyCompare = objlstStarreportchartdatamodel_LY.RevParMyProperty;
                                    item.RevParRankCompare = objlstStarreportchartdatamodel_LY.RevParRank;


                                    if (item.OccChgCompSet > item.OccChgCompSetCompare) {
                                        item.IsOccChgCompSetUp = true;
                                    }
                                    if (item.OccChgIndex > item.OccChgIndexCompare) {
                                        item.IsOccChgIndexUp = true;
                                    }
                                    if (item.OccChgMyProperty > item.OccChgMyPropertyCompare) {
                                        item.IsOccChgMyPropertyUp = true;
                                    }
                                    if (item.OccCompSet > item.OccCompSetCompare) {
                                        item.IsOccCompSetUp = true;
                                    }
                                    if (item.OccIndex > item.OccIndexCompare) {
                                        item.IsOccIndexUp = true;
                                    }
                                    if (item.OccMyProperty > item.OccMyPropertyCompare) {
                                        item.IsOccMyPropertyUp = true;
                                    }

                                    if (item.AdrChgCompSet > item.AdrChgCompSetCompare) {
                                        item.IsAdrChgCompSetUp = true;
                                    }
                                    if (item.AdrChgIndex > item.AdrChgIndexCompare) {
                                        item.IsAdrChgIndexUp = true;
                                    }
                                    if (item.AdrChgMyProperty > item.AdrChgMyPropertyCompare) {
                                        item.IsAdrChgMyPropertyUp = true;
                                    }
                                    if (item.AdrCompSet > item.AdrCompSetCompare) {
                                        item.IsAdrCompSetUp = true;
                                    }
                                    if (item.AdrIndex > item.AdrIndexCompare) {
                                        item.IsAdrIndexUp = true;
                                    }
                                    if (item.AdrMyProperty > item.AdrMyPropertyCompare) {
                                        item.IsAdrMyPropertyUp = true;
                                    }

                                    if (item.RevParChgCompSet > item.RevParChgCompSetCompare) {
                                        item.IsRevParChgCompSetUp = true;
                                    }
                                    if (item.RevParChgIndex > item.RevParChgIndexCompare) {
                                        item.IsRevParChgIndexUp = true;
                                    }
                                    if (item.RevParChgMyProperty > item.RevParChgMyPropertyCompare) {
                                        item.IsRevParChgMyPropertyUp = true;
                                    }
                                    if (item.RevParCompSet > item.RevParCompSetCompare) {
                                        item.IsRevParCompSetUp = true;
                                    }
                                    if (item.RevParIndex > item.RevParIndexCompare) {
                                        item.IsRevParIndexUp = true;
                                    }
                                    if (item.RevParMyProperty > item.RevParMyPropertyCompare) {
                                        item.IsRevParMyPropertyUp = true;
                                    }

                                }


                            });


                            resolve();

                        });

                        //#endregion
                    }
                    else if (comparison == Constants.StarComparison.Budget) {

                        //#region Budget comparision

                        StrreportHelper.getSTRBudgetData(lstStarreportchartdatamodel, hotelid).then(lstStarreportchartdatamodel_Budget_result => {

                            if (lstStarreportchartdatamodel_Budget_result) {
                                lstStarreportchartdatamodel_Budget = lstStarreportchartdatamodel_Budget_result;
                            }

                            lstStarreportchartdatamodel.forEach(function (item) {
                                if (item.UpdatedBy != "sp_missingdates") {
                                    if (item.OccIndex == 0
                                        && item.OccChgIndex == 0
                                        && item.AdrIndex == 0
                                        && item.AdrChgIndex == 0
                                        && item.RevParIndex == 0
                                        && item.RevParChgIndex == 0) {
                                        missingflag = true;
                                    }
                                }
                                let objlstStarreportchartdatamodel_Budget = lstStarreportchartdatamodel_Budget.filter(d => {
                                    return (d.Date == item.Date);
                                });

                                if (objlstStarreportchartdatamodel_Budget.length > 0) {

                                    objlstStarreportchartdatamodel_Budget = objlstStarreportchartdatamodel_Budget[0];

                                    let totaldays = Utils.dateDiffInDays(item.StartDate, item.EndDate);

                                    if (objlstStarreportchartdatamodel_Budget.MPIBudget
                                        && objlstStarreportchartdatamodel_Budget.MPIBudget != 0
                                        && totaldays != 0) {
                                        item.OccIndexCompare = objlstStarreportchartdatamodel_Budget.MPIBudget / totalDays;
                                    }

                                    if (objlstStarreportchartdatamodel_Budget.ARIBudget
                                        && objlstStarreportchartdatamodel_Budget.ARIBudget != 0
                                        && totaldays != 0) {
                                        item.AdrIndexCompare = objlstStarreportchartdatamodel_Budget.ARIBudget / totalDays;
                                    }

                                    if (objlstStarreportchartdatamodel_Budget.RGIBudget
                                        && objlstStarreportchartdatamodel_Budget.RGIBudget != 0
                                        && totaldays != 0) {
                                        item.RevParIndexCompare = objlstStarreportchartdatamodel_Budget.RGIBudget / totalDays;
                                    }

                                    if (item.OccIndexCompare <= item.OccIndex) {
                                        item.IsOccIndexUp = true;
                                    }
                                    if (item.AdrIndexCompare <= item.AdrIndex) {
                                        item.IsAdrIndexUp = true;
                                    }
                                    if (item.RevParIndexCompare <= item.RevParIndex) {
                                        item.IsRevParIndexUp = true;
                                    }

                                }



                            });

                            resolve();

                        });

                        //#endregion
                    }
                })
            ]).then(resp => {
                lstStrreportdata.forEach(function (item) {

                    var objStrreportitemdatamodel = new Strreportitemdatamodel();
                    var objStrreportlineitemdatamodel = new Strreportlineitemdatamodel();
                    var objStrreportlineitemdatamodel_comparision = new Strreportlineitemdatamodel();

                    objStrreportlineitemdatamodel.title = item.weektitle;
                    objStrreportlineitemdatamodel_comparision.title = item.title;
                    
                    let objStarreportchartdatamodel = lstStarreportchartdatamodel.filter(d => {
                        return (d.EndDate == item.enddate);
                    });

                    if (objStarreportchartdatamodel.length > 0) {
                        
                        objStarreportchartdatamodel = objStarreportchartdatamodel[0];
                        if (objStarreportchartdatamodel.UpdatedBy != "sp_missingdates") {
                            if (objStarreportchartdatamodel.OccIndex == 0 && objStarreportchartdatamodel.OccChgIndex == 0
                                && objStarreportchartdatamodel.AdrIndex == 0 && objStarreportchartdatamodel.AdrChgIndex == 0
                                && objStarreportchartdatamodel.RevParIndex == 0 && objStarreportchartdatamodel.RevParChgIndex == 0) {
                                    objStrreportlineitemdatamodel.missingdates = item.weektitle;
                            }
                        }
                        objStrreportlineitemdatamodel.occact = objStarreportchartdatamodel.OccMyProperty;
                        objStrreportlineitemdatamodel.occactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccMyPropertyUp) {
                            objStrreportlineitemdatamodel.occactcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.occchg = objStarreportchartdatamodel.OccChgMyProperty;
                        objStrreportlineitemdatamodel.occchgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccChgMyPropertyUp) {
                            objStrreportlineitemdatamodel.occchgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.mpiact = objStarreportchartdatamodel.OccIndex;
                        objStrreportlineitemdatamodel.mpiactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccIndexUp) {
                            objStrreportlineitemdatamodel.mpiactcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.mpichg = objStarreportchartdatamodel.OccChgIndex;
                        objStrreportlineitemdatamodel.mpichgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsOccChgIndexUp) {
                            objStrreportlineitemdatamodel.mpichgcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.occrankact = objStarreportchartdatamodel.OccRank;
                        objStrreportlineitemdatamodel.occrankchg = objStarreportchartdatamodel.OccChgRank;

                        objStrreportlineitemdatamodel.adract = objStarreportchartdatamodel.AdrMyProperty;
                        objStrreportlineitemdatamodel.adractcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrMyPropertyUp) {
                            objStrreportlineitemdatamodel.adractcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.adrchg = objStarreportchartdatamodel.AdrChgMyProperty;
                        objStrreportlineitemdatamodel.adrchgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrChgMyPropertyUp) {
                            objStrreportlineitemdatamodel.adrchgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.ariact = objStarreportchartdatamodel.AdrIndex;
                        objStrreportlineitemdatamodel.ariactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrIndexUp) {
                            objStrreportlineitemdatamodel.ariactcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.arichg = objStarreportchartdatamodel.AdrChgIndex;
                        objStrreportlineitemdatamodel.arichgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsAdrChgIndexUp) {
                            objStrreportlineitemdatamodel.arichgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.adrrankact = objStarreportchartdatamodel.AdrRank;
                        objStrreportlineitemdatamodel.adrrankchg = objStarreportchartdatamodel.AdrChgRank;


                        objStrreportlineitemdatamodel.revparact = objStarreportchartdatamodel.RevParMyProperty;
                        objStrreportlineitemdatamodel.revparactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParMyPropertyUp) {
                            objStrreportlineitemdatamodel.revparactcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.revparchg = objStarreportchartdatamodel.RevParChgMyProperty;
                        objStrreportlineitemdatamodel.revparchgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParChgMyPropertyUp) {
                            objStrreportlineitemdatamodel.revparchgcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.rgiact = objStarreportchartdatamodel.RevParIndex;
                        objStrreportlineitemdatamodel.rgiactcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParIndexUp) {
                            objStrreportlineitemdatamodel.rgiactcolor = Constants.Colors.Green;
                        }

                        objStrreportlineitemdatamodel.rgichg = objStarreportchartdatamodel.RevParChgIndex;
                        objStrreportlineitemdatamodel.rgichgcolor = Constants.Colors.Red;
                        if (objStarreportchartdatamodel.IsRevParChgIndexUp) {
                            objStrreportlineitemdatamodel.rgichgcolor = Constants.Colors.Green;
                        }
                        objStrreportlineitemdatamodel.revparrankact = objStarreportchartdatamodel.RevParRank;
                        objStrreportlineitemdatamodel.revparrankchg = objStarreportchartdatamodel.RevParChgRank;


                        objStrreportlineitemdatamodel_comparision.mpiact = objStarreportchartdatamodel.OccIndexCompare;
                        objStrreportlineitemdatamodel_comparision.occrankact = objStarreportchartdatamodel.OccRankCompare;
                        objStrreportlineitemdatamodel_comparision.occrankchg = objStarreportchartdatamodel.OccChgRankCompare;

                        objStrreportlineitemdatamodel_comparision.ariact = objStarreportchartdatamodel.AdrIndexCompare;
                        objStrreportlineitemdatamodel_comparision.adrrankact = objStarreportchartdatamodel.AdrRankCompare;
                        objStrreportlineitemdatamodel_comparision.adrrankchg = objStarreportchartdatamodel.AdrChgRankCompare;

                        objStrreportlineitemdatamodel_comparision.rgiact = objStarreportchartdatamodel.RevParIndexCompare;
                        objStrreportlineitemdatamodel_comparision.revparrankact = objStarreportchartdatamodel.RevParRankCompare;
                        objStrreportlineitemdatamodel_comparision.revparrankchg = objStarreportchartdatamodel.RevParChgRankCompare;

                        objStrreportlineitemdatamodel_comparision.occact = objStarreportchartdatamodel.OccMyPropertyCompare;
                        objStrreportlineitemdatamodel_comparision.occchg = objStarreportchartdatamodel.OccChgMyPropertyCompare;
                        objStrreportlineitemdatamodel_comparision.mpichg = objStarreportchartdatamodel.OccChgIndexCompare;
                        objStrreportlineitemdatamodel_comparision.adract = objStarreportchartdatamodel.AdrMyPropertyCompare;
                        objStrreportlineitemdatamodel_comparision.adrchg = objStarreportchartdatamodel.AdrChgMyPropertyCompare;
                        objStrreportlineitemdatamodel_comparision.arichg = objStarreportchartdatamodel.AdrChgIndexCompare;
                        objStrreportlineitemdatamodel_comparision.revparact = objStarreportchartdatamodel.RevParMyPropertyCompare;
                        objStrreportlineitemdatamodel_comparision.revparchg = objStarreportchartdatamodel.RevParChgMyPropertyCompare;
                        objStrreportlineitemdatamodel_comparision.rgichg = objStarreportchartdatamodel.RevParChgIndexCompare;

                    }

                    objStrreportitemdatamodel.id = item.weeknumber;
                    objStrreportitemdatamodel.actualdata = objStrreportlineitemdatamodel.setFormat(objStrreportlineitemdatamodel);
                    objStrreportitemdatamodel.comparisiondata = objStrreportlineitemdatamodel_comparision.setFormat(objStrreportlineitemdatamodel_comparision);
                    
                    lstStrreportitemdatamodel.push(objStrreportitemdatamodel);
                });

                // cb(null, lstStarreportchartdatamodel);
                cb(null, lstStrreportitemdatamodel);

            }, err => {
                return cb(err);
            })
        });
    }

    static getStrReportWidgetData_GraphQL(userid, hotelid, currentdate, comparison, type, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    StrreportHelper.getStrReportWidgetData(hoteldata.ID, currentdate, comparison, type, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }
    static getSTRPortfolioData_GraphQL(userid, orgid, year, month, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            StrreportHelper.getSTRPortfolioData(userid, orgid, year, month, userconfigdata, cb, (err, result) => {
                if (err) {
                    cb(err, null);
                }
                cb(null, result);
            });

        });
    }


    static getStrReportData_GraphQL(userid, hotelid, year, month, comparison, type, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    StrreportHelper.getStrReportData(hoteldata.ID, year, month, comparison, type, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }

    static getStrReportDetailData_GraphQL(userid, hotelid, year, weekormonthnumber, comparison, type, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    StrreportHelper.getStrReportDetailData(hoteldata.ID, year, weekormonthnumber, comparison, type, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }

    static getStrReportDefaultData_GraphQL(userid, hotelid, year, month, cb) {

        return UserHelper.getUserConfigData(userid, (err, userconfigdata) => {
            if (err) {
                cb(err, null);
            }
            //get myp hotelid from cmp_id
            HotelsHelper.getHotelDataByCMPID(hotelid, (err, hoteldata) => {
                if (err) {
                    cb(err, null);
                }
                if (!hoteldata) {
                    cb(Constants.HotelNotFound, null);
                }
                else {
                    StrreportHelper.getStrReportDefaultData(hoteldata.ID, year, month, userconfigdata, cb, (err, result) => {
                        if (err) {
                            cb(err, null);
                        }
                        cb(null, result);
                    });
                }
            });

        });
    }

    static GetDataBetweenDate(id, start, end, cb) {
        StarreportSchema.find({
            [StarreportSchemaFields.HotelID]: id,
            [StarreportSchemaFields.Date]: { $gte: start, $lte: end }
        }).exec((err, result) => {
            if (err) {
                cb(err, null);
            }
            if (!result) {
                log.debug("StrReport Data result not found");
                return cb("data not found", null);
            }
            else {
                cb(null, result);
            }

        })
    }

    static GetData(hotelid, date, cb) {
        log.debug('Call GetDataBetweenDate, hotelid:' + hotelid + "startdate:" + date + "enddate:" + date);

        let start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        let end = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
        return StarreportSchema.find({

            [StarreportSchemaFields.HotelID]: id,
            [StarreportSchemaFields.Date]: {
                $gte: start, $lte: end
            }
        }).exec(function (err, result) {
            if (err) {
                log.error(err);
            }
            if (!result) {
                log.debug("Star report result not found");
                return cb("data not found", null);
            }
            else {
                return cb(null, result);
            }
        })

    }

}

module.exports = StrreportHelper;

