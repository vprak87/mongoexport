
const { Userhotelxref: UserhotelxrefSchema, SchemaField: UserhotelxrefSchemaFields } = require('../models/userhotelxref');
const dbtable = require('../schema/db_table');

var log = require('log4js').getLogger("userhotelxref_helper");

class UserHotelXrefHelper {
    static getUserHotelList(cd) {
       
        UserhotelxrefSchema.find({},[UserhotelxrefSchemaFields.HotelID]).exec(function (err, result) {
            cd(null,result)
        })
        
    }
    static getUserHoteData(userid, hotelid, cd) {
        UserhotelxrefSchema.find({$and:[
            {[UserhotelxrefSchemaFields.UserID]:userid},
            {[UserhotelxrefSchemaFields.HotelID]:hotelid}]}
        ).exec((err,result)=>{
            if(err){
                cd(err,null)
                log.debug('user hotel groups result not found!');
            }
            cd(null,result);
        })
    }
    
    static getDatabyUserID(userid,cd){
        UserhotelxrefSchema.find({[UserhotelxrefSchemaFields.UserID]:userid}).exec((err,result)=>{            
            cd(null,result);
        })        
    }

}
module.exports = UserHotelXrefHelper;
 




