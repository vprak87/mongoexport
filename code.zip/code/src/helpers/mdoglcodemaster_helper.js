const { MDOGLCodeMaster: MDOGLCodeMasterSchema, SchemaField: MDOGLCodeMasterSchemaFields } = require('../models/mdoglcodemaster');
const { HMGGLCodeMaster: HMGGLCodeMasterSchema, SchemaField: HMGGLCodeMasterSchemaFields } = require('../models/hmgglcodemaster');
const { MDOGLCodeHMGMapping: MDOGLCodeHMGMappingSchema, SchemaField: MDOGLCodeHMGMappingSchemaFields } = require('../models/mdoglcodehmgmapping');

const dbtable = require('../schema/db_table');
const SequenceHelper = require('./sequence_helper')
const MDOGLCodeMasterData = require('../viewModel/mdoglcodemasterdata'); 
const HMGGLCodeMasterData = require('../viewModel/hmgglcodemasterdata'); 
const MDOGLCodeHMGMappingData = require('../viewModel/mdoglcodehmgmappingdata'); 
const MDOGLCodeMappingData = require('../viewModel/mdoglcodemappingtable')
const _ = require('lodash');
const log = require('log4js').getLogger("MDOGLCodeMaster_helper");

class MDOGLCodeMasterHelper {
    
    //#region MDOCOdeMaster
    static createOrUpdateMDOGLCodeMaster(id,glcode, description, displaydescription, parentid,isactive, cb) {

        MDOGLCodeMasterSchema.findOne({ [MDOGLCodeMasterSchemaFields.ID]: id }, (err, scheduler) => {
            if (err) {
                log.error(err);
            }
            if (!scheduler) {
               //#region  
                log.debug('Call Create MDOGLCodeMasterSchema , glcode:' + glcode + ' description:' + description + 'parentid:' + parentid);
                SequenceHelper.getValueForNextSequence(dbtable.MDOGLCODEMASTER, (err, seq_result) => {
                    if (seq_result) {
                        let id = parseInt(seq_result);

                        var mdoglcodemaster = {
                            [MDOGLCodeMasterSchemaFields.ID]: id,
                            [MDOGLCodeMasterSchemaFields.GLCode]: glcode,
                            [MDOGLCodeMasterSchemaFields.Description]: description,
                            [MDOGLCodeMasterSchemaFields.DisplayDescription]: displaydescription,
                            [MDOGLCodeMasterSchemaFields.ParentId]: parentid,
                            [MDOGLCodeMasterSchemaFields.IsActive]: isactive
                        };

                        let mdoglcodemasterSchema = new MDOGLCodeMasterSchema(mdoglcodemaster);
                        mdoglcodemasterSchema.save((err, result) => {
                            if (err)
                                return cb(err, null);
                            else {
                                return cb(null, [result]);
                            }
                        })
                    }
                    else {
                        return cb(new Error(HttpMsg.internalErrorMsg), null);
                    }
                });
               //#endregion
            }
            else {
                log.debug('Call update mdoglcodemasterSchema, GLCode:' + glcode + ' Description:' + description + 'parentid:' + parentid);
       
                MDOGLCodeMasterSchema.findOneAndUpdate(                    
                    {
                        [MDOGLCodeMasterSchemaFields.ID]: id,
                    },
                    {
                        [MDOGLCodeMasterSchemaFields.GLCode]: glcode,
                        [MDOGLCodeMasterSchemaFields.Description]: description,
                        [MDOGLCodeMasterSchemaFields.DisplayDescription]: displaydescription,
                        [MDOGLCodeMasterSchemaFields.ParentId]: parentid,
                        [MDOGLCodeMasterSchemaFields.IsActive]:isactive,
                    },
                    {
                        new: true
                    }
                ).exec((err, result) => {           
                    if (err) {
                        log.error(err);
                    }
                    
                    if(result){                        
                        return cb(null, [result]);
                    }
                })
            }
        });
    }
    static getMDOGLCodeMaster(cb) {
        var lstMDOGLCodeMasterData = [];
        return MDOGLCodeMasterSchema.find((err, result) => {
            if (err) {
                log.error(err);
            }
            if (result.length <= 0) {
                return cb('MDOGLCodeMasternotfound', null);
            }
            else {
                result.forEach((element, index) => {
                    var MDOGLCodeMaster = new MDOGLCodeMasterData();
                    MDOGLCodeMaster._id = element._id,
                    MDOGLCodeMaster.ID = element.ID,
                    MDOGLCodeMaster.GLCode = element.GLCode,
                    MDOGLCodeMaster.Description = element.Description,
                    MDOGLCodeMaster.DisplayDescription = element.DisplayDescription,                                
                    MDOGLCodeMaster.ParentId = element.ParentId,
                    MDOGLCodeMaster.IsActive = element.IsActive
                    lstMDOGLCodeMasterData.push(MDOGLCodeMaster);
                });
                cb(null, lstMDOGLCodeMasterData);
            }

        });
    }
    static getMDOGLCodeMasterByParentId(parentId, cb) {
        var lstMDOGLCodeMasterData = [];
        return MDOGLCodeMasterSchema.find({
            $and: [{ [MDOGLCodeMasterSchemaFields.ParentId]: parentId },]
        }, (err, result) => {
            if (err) {
                log.error(err);
            }
            if (result.length <= 0) {
                return cb('MDOGLCodeMasternotfound', null);
            }
            else {
                result.forEach((element, index) => {
                    var MDOGLCodeMaster = new MDOGLCodeMasterData();
                    MDOGLCodeMaster._id = element._id,
                    MDOGLCodeMaster.ID = element.ID,
                    MDOGLCodeMaster.GLCode = element.GLCode,
                    MDOGLCodeMaster.Description = element.Description,
                    MDOGLCodeMaster.DisplayDescription = element.DisplayDescription,                                
                    MDOGLCodeMaster.ParentId = element.ParentId,
                    MDOGLCodeMaster.IsActive = element.IsActive
                    lstMDOGLCodeMasterData.push(MDOGLCodeMaster);
                });
                cb(null, lstMDOGLCodeMasterData);
            }

        });
    }
    static deleteMDOGLCodeMaster(id, cb) {
        MDOGLCodeMasterSchema.deleteOne({ [MDOGLCodeMasterSchemaFields.ID]: id }, (err, result) => {
            if (err) {
                log.error(err);
            }

            cb(null, result);
        })
    }
    static getMDOGLCodeMaster_GraphQL(cb) {
        return MDOGLCodeMasterHelper.getMDOGLCodeMaster(cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static getMDOGLCodeMasterByParentId_GraphQL(parentId, cb) {
        return MDOGLCodeMasterHelper.getMDOGLCodeMasterByParentId(parentId, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static deleteMDOGLCodeMaster_GraphQL(id, cb) {
        MDOGLCodeMasterHelper.deleteMDOGLCodeMaster(id, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static createOrUpdateMDOGLCodeMaster_GraphQL(id,glcode, description, displaydescription, parentid,isactive, cb) {
        MDOGLCodeMasterHelper.createOrUpdateMDOGLCodeMaster(id,glcode, description, displaydescription, parentid,isactive, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    //#endregion

     //#region HMGGLCodeMaster
     static createOrUpdateHMGGLCodeMaster(id,glcode, description, organizationid,isactive, cb) {

        HMGGLCodeMasterSchema.findOne({ [HMGGLCodeMasterSchemaFields._id]: id }, (err, scheduler) => {
            if (err) {
                log.error(err);
            }
            if (!scheduler) {
               //#region  
                log.debug('Call Create HMGGLCodeMasterSchema , glcode:' + glcode + ' description:' + description + 'organizationid:' + organizationid);
                var hmgglcodemaster = {
                    [HMGGLCodeMasterSchemaFields.GLCode]: glcode,
                    [HMGGLCodeMasterSchemaFields.Description]: description,
                    [HMGGLCodeMasterSchemaFields.OrganizationID]: organizationid,
                    [HMGGLCodeMasterSchemaFields.IsActive]: isactive
                };

                let hmgglcodemasterSchema = new HMGGLCodeMasterSchema(hmgglcodemaster);
                hmgglcodemasterSchema.save((err, result) => {
                    if (err)
                        return cb(err, null);
                    else {
                        return cb(null, [result]);
                    }
                })
               //#endregion
            }
            else {
                log.debug('Call update HMGGLCodeMasterSchema, GLCode:' + glcode + ' Description:' + description + 'parentid:' + organizationid);
       
                HMGGLCodeMasterSchema.findOneAndUpdate(                    
                    {
                        [HMGGLCodeMasterSchemaFields._id]: id,
                    },
                    {
                        [HMGGLCodeMasterSchemaFields.GLCode]: glcode,
                        [HMGGLCodeMasterSchemaFields.Description]: description,
                        [HMGGLCodeMasterSchemaFields.OrganizationID]: organizationid,
                        [HMGGLCodeMasterSchemaFields.IsActive]: isactive
                    },
                    {
                        new: true
                    }
                ).exec((err, result) => {           
                    if (err) {
                        log.error(err);
                    }
                    
                    if(result){                        
                        return cb(null, [result]);
                    }
                })
            }
        });
    }
    static getHMGGLCodeMasterByOrganizationID(organizationid, cb) {
        var lstHMGGLCodeMasterData = [];
        return HMGGLCodeMasterSchema.find({
            $and: [{ [HMGGLCodeMasterSchemaFields.OrganizationID]: organizationid },]
        }, (err, result) => {
            if (err) {
                log.error(err);
            }
            if (result.length <= 0) {
                return cb('HMGGLCodeMasternotfound', null);
            }
            else {
                result.forEach((element, index) => {
                    var HMGGLCodeMaster = new HMGGLCodeMasterData();
                    HMGGLCodeMaster._id = element._id,
                    HMGGLCodeMaster.GLCode = element.GLCode,
                    HMGGLCodeMaster.Description = element.Description,                             
                    HMGGLCodeMaster.OrganizationID = element.OrganizationID,
                    HMGGLCodeMaster.IsActive = element.IsActive
                    lstHMGGLCodeMasterData.push(HMGGLCodeMaster);
                });
                cb(null, lstHMGGLCodeMasterData);
            }

        });
    }
    static deleteHMGGLCodeMaster(id, cb) {
        HMGGLCodeMasterSchema.deleteOne({ [HMGGLCodeMasterSchemaFields._id]: id }, (err, result) => {
            if (err) {
                log.error(err);
            }

            cb(null, result);
        })
    }
    
    static getHMGGLCodeMasterByOrganizationID_GraphQL(organizationid, cb) {
        return MDOGLCodeMasterHelper.getHMGGLCodeMasterByOrganizationID(organizationid, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static deleteHMGGLCodeMaster_GraphQL(id, cb) {
        MDOGLCodeMasterHelper.deleteHMGGLCodeMaster(id, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static createOrUpdateHMGGLCodeMaster_GraphQL(id,glcode, description, organizationid,isactive, cb) {
        MDOGLCodeMasterHelper.createOrUpdateHMGGLCodeMaster(id,glcode, description, organizationid,isactive, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    //#endregion

    //#region MDOGLCodeHMGMapping
    static createOrUpdateMDOGLCodeHMGMapping(mapping, cb) {
       // console.log("in helper method query" + mapping.length);
        mapping.forEach((element, index) => {

        MDOGLCodeHMGMappingSchema.findOne({ [MDOGLCodeHMGMappingSchemaFields._id]:element._id }, (err, scheduler) => {
            if (err) {
                log.error(err);
            }
            if (!scheduler) {
               //#region  
                log.debug('Call Create MDOGLCodeHMGMappingSchema , hmgglcode:' + element.HMGGLCode + ' description:' + element.Description + 'organizationid:' + element.OrganizationID);
                var MDOGLCodeHMGMapping = {
                    [MDOGLCodeHMGMappingSchemaFields.HMGGLCode]:element.HMGGLCode,
                    [MDOGLCodeHMGMappingSchemaFields.MDOGLCode]: element.MDOGLCode,
                    [MDOGLCodeHMGMappingSchemaFields.Description]: element.Description,
                    [MDOGLCodeHMGMappingSchemaFields.Status]:element.Status,
                    [MDOGLCodeHMGMappingSchemaFields.OrganizationID]: element.OrganizationID
                };

                let mdoGLCodeHMGMappingSchema = new MDOGLCodeHMGMappingSchema(MDOGLCodeHMGMapping);
                mdoGLCodeHMGMappingSchema.save((err, result) => {
                    if (err)
                        return cb(err, null);
                    else {
                        return cb(null, [result]);
                    }
                })
               //#endregion
            }
            else {
                log.debug('Call update MDOGLCodeHMGMappingSchema, mdoglcode:' + element.MDOGLCode + ' Description:' + element.Description + 'parentid:' + element.OrganizationID);
       
                MDOGLCodeHMGMappingSchema.findOneAndUpdate(                    
                    {
                        [MDOGLCodeHMGMappingSchemaFields._id]: element._id,
                    },
                    {
                        [MDOGLCodeHMGMappingSchemaFields.HMGGLCode]: element.HMGGLCode,
                        [MDOGLCodeHMGMappingSchemaFields.MDOGLCode]: element.MDOGLCode,
                        [MDOGLCodeHMGMappingSchemaFields.Description]: element.Description,
                        [MDOGLCodeHMGMappingSchemaFields.Status]: element.Status,
                        [MDOGLCodeHMGMappingSchemaFields.OrganizationID]: element.OrganizationID
                    },
                    {
                        new: true
                    }
                ).exec((err, result) => {           
                    if (err) {
                        log.error(err);
                    }
                    
                    if(result){                        
                        return cb(null, [result]);
                    }
                })
            }
        });
    });
    }

    

    static getMDOGLCodeHMGMappingByOrganizationID(organizationid, cb) {
        var lstMDOGLCodeHMGMappingData = [];
        return MDOGLCodeHMGMappingSchema.find({
            $and: [{ [MDOGLCodeHMGMappingSchemaFields.OrganizationID]: organizationid },]
        }, (err, result) => {
            if (err) {
                log.error(err);
            }
            if (result.length > 0) {
                
                result.forEach((element, index) => {
                    var MDOGLCodeHMGMapping = new MDOGLCodeHMGMappingData();
                    MDOGLCodeHMGMapping._id = element._id,
                    MDOGLCodeHMGMapping.HMGGLCode = element.HMGGLCode,
                    MDOGLCodeHMGMapping.MDOGLCode = element.MDOGLCode,
                    MDOGLCodeHMGMapping.Description = element.Description,
                    MDOGLCodeHMGMapping.Status = element.Status,                             
                    MDOGLCodeHMGMapping.OrganizationID = element.OrganizationID
                    lstMDOGLCodeHMGMappingData.push(MDOGLCodeHMGMapping);
                });
            }
            cb(null, lstMDOGLCodeHMGMappingData);

        });
    }
    static deleteMDOGLCodeHMGMapping(id, cb) {
        MDOGLCodeHMGMappingSchema.deleteOne({ [MDOGLCodeHMGMappingSchemaFields._id]: id }, (err, result) => {
            if (err) {
                log.error(err);
            }

            cb(null, result);
        })
    }
    
    static getMDOGLCodeHMGMappingByOrganizationID_GraphQL(organizationid, cb) {
        return MDOGLCodeMasterHelper.getMDOGLCodeHMGMappingByOrganizationID(organizationid, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static deleteMDOGLCodeHMGMapping_GraphQL(id, cb) {
        MDOGLCodeMasterHelper.deleteMDOGLCodeHMGMapping(id, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    
    static createOrUpdateMDOGLCodeHMGMapping_GraphQL(mapping, cb) {
        //console.log("in graphql helper");
        MDOGLCodeMasterHelper.createOrUpdateMDOGLCodeHMGMapping(mapping, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }

    //Fetch only active  HMG mapping reords
    static getMDOGLCodeMasterMappingOnlyActives(organizationid,cb) {
        
            var lstMDOGLCodeMasterData = [];
            let mdohmgMappingAggregate = MDOGLCodeHMGMappingSchema.aggregate();
            
            mdohmgMappingAggregate.match({
                 [MDOGLCodeHMGMappingSchemaFields.OrganizationID]: organizationid ,
                [MDOGLCodeHMGMappingSchemaFields.Status]: true 
                
            })
    
            mdohmgMappingAggregate.lookup({
                from: dbtable.MDOGLCODEMASTERS,
                let: { glcode: `$${MDOGLCodeHMGMappingSchemaFields.MDOGLCode}` },
                pipeline: [
                    {
                        $match:
                        {
                            $expr: { $eq: ["$$glcode", `$${MDOGLCodeMasterSchemaFields.GLCode}`] }
                        }
    
                    },
                    {
                        $project: {
                            "_id": 1,
                            [MDOGLCodeMasterSchemaFields.GLCode]: 1,
                            [MDOGLCodeMasterSchemaFields.ID]: 1,
                            [MDOGLCodeMasterSchemaFields.ParentId]: 1,
                            [MDOGLCodeMasterSchemaFields.IsActive]: 1,
                            [MDOGLCodeMasterSchemaFields.Description]: 1,
                            [MDOGLCodeMasterSchemaFields.DisplayDescription]: 1,
                       }
                    }
                ],
                as: "mdoglmaster"
            })
    
            return mdohmgMappingAggregate.exec((err, result) => {
                if (err) {
                    log.error(err);
                }
                if (!result || result.length == 0) {
                    log.debug("MDOGL and HMG GL mapping result not found");
                    return cb(null, null);
                }
                else {
                    result.forEach((element, index) => {
                        var MDOGLCodeMappingMaster = new MDOGLCodeMappingData();
                        MDOGLCodeMappingMaster._id = element.mdoglmaster[0]._id,
                        MDOGLCodeMappingMaster.ID = element.mdoglmaster[0].ID,
                        MDOGLCodeMappingMaster.GLCode = element.MDOGLCode,
                        MDOGLCodeMappingMaster.Description = element.mdoglmaster[0].Description,
                        MDOGLCodeMappingMaster.DisplayDescription = element.mdoglmaster[0].DisplayDescription,                                
                        MDOGLCodeMappingMaster.ParentId = element.mdoglmaster[0].ParentId,
                        MDOGLCodeMappingMaster.IsActive = element.mdoglmaster[0].IsActive
                        MDOGLCodeMappingMaster.MappingID=element._id,
                        MDOGLCodeMappingMaster.MappingStatus=element.Status,       
                        MDOGLCodeMappingMaster.CustomDescription=element.CustomDescription,
                        MDOGLCodeMappingMaster.HMGGLCode=element.HMGGLCode
                        lstMDOGLCodeMasterData.push(MDOGLCodeMappingMaster);
                    });
                    return cb(null, lstMDOGLCodeMasterData);
                }
            });
        }
        
    static getMDOGLCodeMasterMapping(organizationid,cb) {
        var lstMDOGLCodeMasterData = [];
        var MDOGLCodeMaster = [];
        var HMGMapping = [];
        return Promise.all([     
            new Promise((resolve, reject) => {
                MDOGLCodeMasterSchema.find((err, result) => {
                    if (err) {
                        log.error(err);
                    }
                    MDOGLCodeMaster = result;
                    resolve();
                });
            }),       
            new Promise((resolve, reject) => {
                MDOGLCodeMasterHelper.getMDOGLCodeHMGMappingByOrganizationID(organizationid, (err, result_HMG) => {
                    if (err) {
                        cb(err, null);
                    }
                    if (err) {
                        reject(err);
                    }
                    if (result_HMG) {
                        HMGMapping = result_HMG;
                    }
                    resolve();
                });
            })
        ]).then(resp => {

            if(MDOGLCodeMaster.length > 0){
                MDOGLCodeMaster.forEach((element, index) => {
                    var custDesc = '';
                    var hmgGLCode = '';
                    var mapid = '';
                    var mapstatus = '';
                    _.filter(HMGMapping,(item)=>{
                        if(item.MDOGLCode==element.GLCode){
                            custDesc = item.Description;
                            hmgGLCode = item.HMGGLCode;
                            mapid = item._id;
                            mapstatus = item.Status;
                        }
                    });
                    var MDOGLCodeMappingMaster = new MDOGLCodeMappingData();
                    MDOGLCodeMappingMaster._id = element._id,
                    MDOGLCodeMappingMaster.ID = element.ID,
                    MDOGLCodeMappingMaster.GLCode = element.GLCode,
                    MDOGLCodeMappingMaster.Description = element.Description,
                    MDOGLCodeMappingMaster.DisplayDescription = element.DisplayDescription,                                
                    MDOGLCodeMappingMaster.ParentId = element.ParentId,
                    MDOGLCodeMappingMaster.IsActive = element.IsActive
                    MDOGLCodeMappingMaster.MappingID=mapid,
                    MDOGLCodeMappingMaster.MappingStatus=mapstatus,
                    MDOGLCodeMappingMaster.CustomDescription=custDesc,
                    MDOGLCodeMappingMaster.HMGGLCode=hmgGLCode
                    lstMDOGLCodeMasterData.push(MDOGLCodeMappingMaster);

                    if (MDOGLCodeMaster.length == lstMDOGLCodeMasterData.length)
                        return cb(null, lstMDOGLCodeMasterData);
                });
            }
            else{
                return cb(null, lstMDOGLCodeMasterData);
            }
        }, err => {
            return cb(err);
        })
    }

    static getMDOGLCodeMasterMapping_GraphQL(organizationid, cb) {
        return MDOGLCodeMasterHelper.getMDOGLCodeMasterMapping(organizationid, cb, (err, result) => {
            if (err) {
                cb(err, null);
            }
            cb(null, result);
        });
    }
    //#endregion

}

module.exports = MDOGLCodeMasterHelper;