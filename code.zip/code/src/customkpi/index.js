const express = require('express');
const router = express.Router(),
    Controller = require('./controller/customkpi');


router.post("/insertkpi", Controller.InsertKPI);
router.get("/getkpibyorgid", Controller.GetKPIByOrgId);
router.get("/getkpilookups", Controller.GetKPILookups);
router.get("/getkpibyid", Controller.GetKPIById);
router.get("/removekpi", Controller.RemoveKPI);
router.post("/updatekpi", Controller.UpdateKPI);

module.exports = router