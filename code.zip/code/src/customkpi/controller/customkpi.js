const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const Checkit = require('checkit');
const { Createowntablemappingmaster: CreateowntablemappingmasterSchema, SchemaField: CreateowntablemappingmasterSchemaFields } = require('../../models/createowntablemappingmaster');
const SequenceHelper = require('../../helpers/sequence_helper')
const CustomKPIHelper = require('../../helpers/customkpi_helper');
const RESTHelper = require('../../helpers/rest_helper');
var log = require('log4js').getLogger("customkpi");

let GetKPILookupsFn = (req, res, next) => {
    CustomKPIHelper.getKPILookups((err, result) => {
        if (err) {
            if (err === 'kpinotfound') {
                let response = new Response(true, 200).setMessage(HttpMsg.recordedNotfound).setResultData(result).build();
                res.status(200).send(response);
            }
            else
                return next(err);
        }
        else {
            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        }
    });

}

let GetKPIByOrgIdFn = (req, res, next) => {
    var checkit = new Checkit({
        organizationid: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    CustomKPIHelper.getCustomKPIByOrgId(data.organizationid, (err, result) => {
        if (err) {
            if (err === 'kpinotfound') {
                let response = new Response(true, 200).setMessage(HttpMsg.recordedNotfound).setResultData(result).build();
                res.status(200).send(response);
            }
            else
                return next(err);
        }
        else {
            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        }
    });

}
let GetKPIByIdFn = (req, res, next) => {

    var checkit = new Checkit({
        kpiid: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    CustomKPIHelper.getCustomKPIById(data.kpiid, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });
}

let RemoveKPIFn = (req, res, next) => {
    var checkit = new Checkit({
        kpiid: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    CustomKPIHelper.deleteKPI(data.kpiid, (err, kpi_result) => {
        if (err) {
            log.error(err.toJSON());
            return res.status(400).send(err.toJSON());
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredDeleted).build();
        res.status(200),
            res.send(response)
    })
}
let InsertKPIFn = (req, res, next) => {

    var checkit = new Checkit({
        kpiname: 'required',
        kpiformula: 'required',
        unit: 'required',
        organizationid: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    CustomKPIHelper.IsExistKPI(null, data.kpiname, data.organizationid, (err, kpi_result) => {
        if (err) {
            return next(err);
        }

        if (kpi_result) {
            return next(new Error(HttpMsg.kpiAlreadyExist))
        }
        else {

            //db write to SQL server and sync will handle the data in mangodb
            var json_postdata = [];
            json_postdata.columname = data.kpiname;
            json_postdata.kpikey = data.kpiname;
            json_postdata.kpiformula = data.kpiformula;
            json_postdata.unit = data.unit;
            json_postdata.organizationid = data.organizationid;

            //CustomKPI/Add in SQL server
            RESTHelper.POST(HttpMsg.Urls.InsertCustomKPI, json_postdata, (err, result) => {
                if (err)
                    return next(err);

                //#region write it to mongodb with id returned by SQL
                let id = parseInt(post_result.data.longid);

                let createowntablemappingmasterSchema = new CreateowntablemappingmasterSchema();
                createowntablemappingmasterSchema.ID = id;
                createowntablemappingmasterSchema.ColumName = data.kpiname.toString();
                createowntablemappingmasterSchema.KPIKey = data.kpiname.toString().toLowerCase().replace(/\s/g, '_');
                createowntablemappingmasterSchema.KPIFormula = data.kpiformula.toString();
                createowntablemappingmasterSchema.Unit = data.unit.toString();
                createowntablemappingmasterSchema.OrganizationId = data.organizationid;
                createowntablemappingmasterSchema.TableName = 'Consolidated Report';
                createowntablemappingmasterSchema.IsCustom = true;
                createowntablemappingmasterSchema.save((err, data) => {
                    if (err)
                        return next(err)

                    let response = new Response(true, 200).setMessage(HttpMsg.recordedAdded).setResultData(data).build();
                    res.status(200)
                    res.send(response)
                })
                //  #endregion
            });

        }

    });
}

let UpdateKPIFn = (req, res, next) => {

    var checkit = new Checkit({
        id: 'required',
        kpiname: 'required',
        kpiformula: 'required',
        unit: 'required',
        organizationid: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    CustomKPIHelper.IsExistKPI(data.id, data.kpiname, data.organizationid, (err, kpi_result) => {
        if (err) {
            return next(err);
        }

        if (kpi_result) {
            return next(new Error(HttpMsg.kpiAlreadyExist))
        }
        else {
            CustomKPIHelper.getCustomKPIById(data.id, (err, createowntablemappingmasterSchema) => {
                if (createowntablemappingmasterSchema) {
                    createowntablemappingmasterSchema.ColumName = data.kpiname.toString();
                    createowntablemappingmasterSchema.KPIKey = data.kpiname.toString().toLowerCase().replace(/\s/g, '_');
                    createowntablemappingmasterSchema.KPIFormula = data.kpiformula.toString();
                    createowntablemappingmasterSchema.Unit = data.unit.toString();

                    createowntablemappingmasterSchema.save((err, data) => {
                        if (err)
                            return next(err)

                        let response = new Response(true, 200).setMessage(HttpMsg.recoredUpdateed).setResultData(data).build();
                        res.status(200)
                        res.send(response)
                    })
                }
                else {
                    return next(new Error(HttpMsg.internalErrorMsg))
                }
            });
        }

    });
}
module.exports = {
    InsertKPI: InsertKPIFn,
    GetKPIById: GetKPIByIdFn,
    GetKPIByOrgId: GetKPIByOrgIdFn,
    GetKPILookups: GetKPILookupsFn,
    RemoveKPI: RemoveKPIFn,
    UpdateKPI: UpdateKPIFn,
}