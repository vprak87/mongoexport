const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const Checkit = require('checkit');

var log = require('log4js').getLogger("hotelList");

const HotelListHelper = require('../../helpers/hotellist_helper');

let hotelListFn = (req, res, next) => {
  var checkit = new Checkit({
    userEmail: 'required',
  });

  var [err, data] = checkit.validateSync(req.body);
  if (err) {
    log.error(err.toJSON());
    return res.status(400).send(err.toJSON());
  }

  HotelListHelper.getHotelList(data.userEmail, (err, result) => {
    if (err) {
      return next(err, 'error2');
    }
    // let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
    res.status(200).send(result);
  });

}

module.exports = {
  HotelListData: hotelListFn
}