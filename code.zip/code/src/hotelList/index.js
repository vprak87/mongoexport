const express = require('express');
const router = express.Router(),
    Controller = require('./controller/hotelList');


router.post("/hotellist", Controller.HotelListData);



module.exports = router