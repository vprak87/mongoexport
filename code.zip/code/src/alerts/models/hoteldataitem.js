const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class Hoteldataitem {

    constructor(options) {

        // Default values
        const defaults = {
            id: 0,
            name: ''
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }

    // setFormat(data) {
    //     const defaultzero = 0;
    //     this.occupancy = data.occupancy == null || data.occupancy == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.occupancy, Constants.NumeralFormats.NoComma2DecimalNegativeBrackets);
    //     this.occupancyly = data.occupancyly== null || data.occupancyly == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.occupancyly, Constants.NumeralFormats.NoComma2DecimalNegativeBrackets);
    //     this.adr = data.adr == null || data.adr == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.adr, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
    //     this.adrly = data.adrly == null || data.adrly == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.adrly, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
    //     this.revpar = data.revpar == null ||  data.revpar == '0'  ? defaultzero.toFixed(2) : Utils.formatValue(data.revpar, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
    //     this.revparly = data.revparly == null ||  data.revparly == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.revparly, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
    //     return this
    // }
}
module.exports = Hoteldataitem
