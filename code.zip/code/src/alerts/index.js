const express = require('express');
const router = express.Router(),
    Controller = require('./controller/alerts');

router.get("/propertydata", Controller.PropertyData)
router.get("/portfoliodata", Controller.PortfolioData)



module.exports = router