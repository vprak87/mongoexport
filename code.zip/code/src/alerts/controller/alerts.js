const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const Checkit = require('checkit');
const UserHelper = require('../../helpers/user_helper');
const HotelsHelper = require('../../helpers/hotels_helper');
const AlertsHelper = require('../../helpers/alerts_helper');

var log = require('log4js').getLogger("alerts");

let PortfolioDataFn = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
        reportdate: 'required',
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        //get myp hotelid from cmp_id
        HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
            if (err) {
                return next(err);
            }
            if (!hoteldata) {
                return next(HttpMsg.HotelNotFound);
            }
            else {
                AlertsHelper.getPortfolioData(data.userid, data.reportdate, userconfigdata, (err, result) => {
                    if (err) {
                        return next(err);
                    }

                    let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                    res.status(200).send(response);
                });
            }
        });

    });

}



let PropertyDataFn = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        reportdate: 'required',
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        //get myp hotelid from cmp_id
        HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
            if (err) {
                return next(err);
            }
            if (!hoteldata) {
                return next(HttpMsg.HotelNotFound);
            }
            else {
                AlertsHelper.getPropertyData(data.userid, hoteldata.ID, data.reportdate, userconfigdata, (err, result) => {
                    if (err) {
                        return next(err);
                    }

                    let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                    res.status(200).send(response);
                });
            }
        });

    });

}

module.exports = {
    PropertyData: PropertyDataFn,
    PortfolioData: PortfolioDataFn,
}
