const Utils = require('../../common/utils');
const Constants = require('../../common/constants');
class Occupancy {

    constructor(options) {

        // Default values
        const defaults = {
            Max:"100",
            Chart:"0",
            Actual:"0",
            OccupancyForLastYear:"0",
            BudgetOccupancy:"0",
            ForecastedOccupancy:"0"
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }
    setFormat(data) {
        const defaultzero = "0";
        this.Max = data.Max == null ? "100" : data.Max;
        this.Chart = data.Chart == null ? defaultzero : data.Chart;
        this.Actual = data.Actual == null ? defaultzero : data.Actual;
        this.OccupancyForLastYear == null? defaultzero : data.OccupancyForLastYear;
        this.BudgetOccupancy == null? defaultzero : data.BudgetOccupancy;
        this.ForecastedOccupancy == null? defaultzero : data.ForecastedOccupancy;
        return this;
    }
}
module.exports = Occupancy