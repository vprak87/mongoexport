const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class GetActualVsPayrollChartData {
    constructor(options) {

        // Default values
        const defaults = {
            Type: '',
            Category: '',
            PayrollActual: 0,
            PayrollBudget: 0

        };       


        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }


}
module.exports = GetActualVsPayrollChartData