class PayrollActualvsBudgetModelData {
    constructor(options) {
        // Default values
        const defaults = {
            Actual:0,
            Plan: 0,
            OT_Wages:0 ,
            Variance:0 ,
            POR_Actual:0,
            POR_Plan:0,
            POR_Variance:0,      
            Actual1:0,
            Plan1:0,
            OT_Wages1:0,
            Variance1:0,
            POR_Actual1:0,
            POR_Plan1:0,
            POR_Variance1:0                    
        }; 
        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });        
    }
    setFormat(data) {
        const defaultzero = 0;
        this.Actual = !data.Actual? defaultzero.toFixed(2) :(Math.round(data.Actual * 100) / 100).toFixed(2);
        this.Plan = !data.Plan? defaultzero.toFixed(2) :(Math.round(data.Plan * 100) / 100).toFixed(2);
        this.OT_Wages = !data.OT_Wages? defaultzero.toFixed(2) :(Math.round(data.OT_Wages * 100) / 100).toFixed(2);
        this.Variance =  !data.Variance? defaultzero.toFixed(2) :(Math.round(data.Variance * 100) / 100).toFixed(2);
        this.POR_Actual =  data.POR_Actual==0? "0.00" :(Math.round(data.POR_Actual * 100) / 100).toFixed(2);
        this.POR_Plan =  data.POR_Plan ==0? "0.00" :(Math.round(data.POR_Plan * 100) / 100).toFixed(2);
        this.POR_Variance=  data.POR_Variance==0? "0.00" :(Math.round(data.POR_Variance * 100) / 100).toFixed(2);    
        this.Actual1=  !data.Actual1? defaultzero.toFixed(2) :(Math.round(data.Actual1 * 100) / 100).toFixed(2);
        this.Plan1=  !data.Plan1? defaultzero.toFixed(2) :(Math.round(data.Plan1 * 100) / 100).toFixed(2);
        this.OT_Wages1=  !data.OT_Wages1? defaultzero.toFixed(2) :(Math.round(data.OT_Wages1 * 100) / 100).toFixed(2);
        this.Variance1=  !data.Variance1? defaultzero.toFixed(2) :(Math.round(data.Variance1 * 100) / 100).toFixed(2);
        this.POR_Actual1=  data.POR_Actual1==0? "0.00" :(Math.round(data.POR_Actual1 * 100) / 100).toFixed(2);
        this.POR_Plan1=  data.POR_Plan1==0? "0.00" :(Math.round(data.POR_Plan1 * 100) / 100).toFixed(2);
        this.POR_Variance1=  data.POR_Variance1==0? "0.00" :(Math.round(data.POR_Variance1 * 100) / 100).toFixed(2);  
        return this;
    }


}
module.exports = PayrollActualvsBudgetModelData;