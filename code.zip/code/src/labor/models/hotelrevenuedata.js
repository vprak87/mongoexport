const Utils = require('../../common/utils');
const Constants = require('../../common/constants');
class HotelRevenueData {

    constructor(options) {

        // Default values
        const defaults = {
            ID:'',
            HotelID:'',
            Date:'',
            Category:'',
            Description:'',
            NoOfReference:'',
            Amount:'',
            NumberofAvailableRooms:'',
            UpdatedBy:'',
            UpdatedDateTime:'',
            IsDelete:'',
            ReportedDateTime:'',
            TransientRoomsSold:'',
            TransientRoomRevenue:'',
            GroupRoomsSold:'',
            GroupRoomRevenue:'',
            GroupBlock: '',
            AmountMTD: '',
            AmountYTD: '',
            PMSCode: '',
            PMSType: '',
            ReportName:''
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }
}
module.exports = HotelRevenueData