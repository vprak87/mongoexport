class PayrollActualvsBudgetHoursModelData {
    constructor(options) {
        // Default values
        const defaults = {
            ActualHoursMTD:0,
            PlanHoursMTD: 0,
            OTHoursMTD:0,
            VarianceHoursMTD:0 ,
            ActualPORHoursMTD:0,
            PlanPORHoursMTD:0,
            VariancePORHoursMTD:0, 
            ActualHours:0,
            PlanHours:0,
            OTHours:0,
            VarianceHours:0,
            ActualPORHours:0,
            PlanPORHours:0,
            VariancePORHours:0,
            ActualHoursWTD:0,
            PlanHoursWTD:0,
            OTHoursWTD:0,
            VarianceHoursWTD:0,
            ActualPORHoursWTD:0,
            PlanPORHoursWTD:0,
            VariancePORHoursWTD:0                   
        }; 
        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });        
    }
    setFormat(data) {
        const defaultzero = 0;
        this.ActualHoursMTD = !data.ActualHoursMTD? defaultzero.toFixed(2) :(Math.round(data.ActualHoursMTD * 100) / 100).toFixed(2);
        this.PlanHoursMTD = !data.PlanHoursMTD? defaultzero.toFixed(2) :(Math.round(data.PlanHoursMTD * 100) / 100).toFixed(2);
        this.OTHoursMTD = !data.OTHoursMTD? defaultzero.toFixed(2) :(Math.round(data.OTHoursMTD * 100) / 100).toFixed(2);
        this.VarianceHoursMTD =  !data.VarianceHoursMTD? defaultzero.toFixed(2) :(Math.round(data.VarianceHoursMTD * 100) / 100).toFixed(2);
        this.ActualPORHoursMTD =  !data.ActualPORHoursMTD? defaultzero.toFixed(2) :(Math.round(data.ActualPORHoursMTD * 100) / 100).toFixed(2);
        this.PlanPORHoursMTD =  !data.PlanPORHoursMTD? defaultzero.toFixed(2) :(Math.round(data.PlanPORHoursMTD * 100) / 100).toFixed(2);
        this.VariancePORHoursMTD=  !data.VariancePORHoursMTD? defaultzero.toFixed(2) :(Math.round(data.VariancePORHoursMTD * 100) / 100).toFixed(2);    
        this.ActualHours=!data.ActualHours? defaultzero.toFixed(2) :(Math.round(data.ActualHours * 100) / 100).toFixed(2);
        this.PlanHours=!data.PlanHours? defaultzero.toFixed(2) :(Math.round(data.PlanHours * 100) / 100).toFixed(2);
        this.OTHours=!data.OTHours? defaultzero.toFixed(2) :(Math.round(data.OTHours * 100) / 100).toFixed(2);
        this.VarianceHours=!data.VarianceHours? defaultzero.toFixed(2) :(Math.round(data.VarianceHours * 100) / 100).toFixed(2);
        this.ActualPORHours=!data.ActualPORHours? "0.00" : (Math.round(data.ActualPORHours * 100) / 100).toFixed(2);
        this.PlanPORHours=!data.PlanPORHours? "0.00" : (Math.round(data.PlanPORHours * 100) / 100).toFixed(2);
        this.VariancePORHours=!data.VariancePORHours? "0.00" :(Math.round(data.VariancePORHours * 100) / 100).toFixed(2);
        this.ActualHoursWTD=  !data.ActualHoursWTD? defaultzero.toFixed(2) :(Math.round(data.ActualHoursWTD * 100) / 100).toFixed(2);
        this.PlanHoursWTD=  !data.PlanHoursWTD? defaultzero.toFixed(2) :(Math.round(data.PlanHoursWTD * 100) / 100).toFixed(2);
        this.OTHoursWTD=  !data.OTHoursWTD? defaultzero.toFixed(2) :(Math.round(data.OTHoursWTD * 100) / 100).toFixed(2);
        this.VarianceHoursWTD=  !data.VarianceHoursWTD? defaultzero.toFixed(2) :(Math.round(data.VarianceHoursWTD * 100) / 100).toFixed(2);
        this.ActualPORHoursWTD=  !data.ActualPORHoursWTD? "0.00" :(Math.round(data.ActualPORHoursWTD * 100) / 100).toFixed(2);
        this.PlanPORHoursWTD=  !data.PlanPORHoursWTD? "0.00" :(Math.round(data.PlanPORHoursWTD * 100) / 100).toFixed(2);
        this.VariancePORHoursWTD=  !data.VariancePORHoursWTD? "0.00" :(Math.round(data.VariancePORHoursWTD * 100) / 100).toFixed(2); 
        return this;
    
    }


}
module.exports = PayrollActualvsBudgetHoursModelData;