const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class Hoteleffectivenesscalculationsdata {

    constructor(options) {

        // Default values
        const defaults = {
            ID:0,
            HotelID:0,
            Date:'',
            Department:'',
            Wages:0,
            Hours:'',
            UpdatedBy:'',
            UpdatedDateTime:'',
            Category:'',
            FromDate:'',
            ToDate:'',
            PlanWages:null,
            PlanHours:null,
            ReportName:null            
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }
}
module.exports = Hoteleffectivenesscalculationsdata