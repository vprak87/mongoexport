class PayrollActualvsPlanModelData {
    constructor(options) {
        // Default values
        const defaults = {
            HotelID: '',
            Date: '',
            Department: '',
            ActualHours:'',
            PlanHours: '',
            VarianceHours:'',
            ActualPORHours:'',
            PlanPORHours:'',
            VariancePORHours:'',
            ActualHoursWTD:'',
            PlanHoursWTD:'',
            VarianceHoursWTD:'',
            ActualPORHoursWTD:'',
            PlanPORHoursWTD:'',
            VariancePORHoursWTD:'',
            ActualHoursMTD:'',
            PlanHoursMTD:'',
            VarianceHoursMTD:'',
            groupName:'',
            ActualWages:'',
            PlanWages:'',
            VarianceWages:'',
            ActualPORWages:'',
            PlanPORWages:'',
            VariancePORWages:'',
            ActualWagesWTD:'',
            PlanWagesWTD:'',
            VariancWagesWTD:'',
            ActualPORWagesWTD:'',
            PlanPORWagesWTD:'',
            VariancPORWagesWTD:'',
            ActualWagesMTD:'',
            PlanWagesMTD:'',
            VarianceWagesMTD:'',
            ActualPORWagesMTD:'',
            PlanPORWagesMTD:'',
            VariancePORWagesMTD:'',
            organizationCode:''                        
        }; 
        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });        
    }
    setFormat(data) {;      
        this.VarianceHours= data.PlanHours-data.ActualHours; 
        this.VariancePORHours = data.PlanPORHours-data.ActualPORHours;     
        this.VarianceHoursWTD = data.PlanHoursWTD-data.ActualHoursWTD;
        this.VariancePORHoursWTD = data.PlanPORHoursWTD-data.ActualPORHoursWTD;
        this.VarianceHoursMTD=data.PlanHoursMTD-data.ActualHoursMTD;
        this.VarianceWages = data.PlanWages-data.ActualWages;
        this.VariancePORWages = data.PlanPORWages-data.ActualPORWages;
        this.VariancWagesWTD = data.PlanWagesWTD-data.ActualWagesWTD;
        this.VariancPORWagesWTD = data.ActualPORWagesWTD-data.PlanPORWagesWTD;
        this.VarianceWagesMTD = data.ActualWagesMTD-data.PlanWagesMTD;
        this.VariancePORWagesMTD = data.ActualPORWagesMTD-data.PlanPORWagesMTD;
    }


}
module.exports = PayrollActualvsPlanModelData;