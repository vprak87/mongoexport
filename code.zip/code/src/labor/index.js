const express = require('express');
const router = express.Router(),
    Controller = require('./controller/labor');


router.get("/payrolldepartmentwise", Controller.GetPayrollDepartmentWiseData);
router.get("/payrollvsrevenuevsocc", Controller.GetPayrollVsRevenueVsOcc);
router.get("/actualvspayroll", Controller.GetActualVsPayroll);
router.get("/housekeepingperroom", Controller.GetHouseKeepingPerRoom);
router.get("/payrollactualvsplanbudget", Controller.GetPayrollActualvsPlanBudget);
router.get("/payrollactualvsplanbudgethourse", Controller.GetPayrollActualvsPlanBudgetHours);
router.get("/getconfigs", Controller.GetConfigs);
router.post("/saveconfigs", Controller.SaveConfigs);




module.exports = router