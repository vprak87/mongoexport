const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const PayrollDepartmentWise = require('../../helpers/labor_helper');
const HotelsHelper = require('../../helpers/hotels_helper');
const UserHelper = require('../../helpers/user_helper');

const { Userhotelxref: UserhotelxrefSchema, SchemaField: UserhotelxrefSchemaField }
    = require('../../models/userhotelxref');
const Checkit = require('checkit');

const GetActualVsPayrollChartData = require('../models/actualvspayrollchartdata');
const Laborconfigdata = require('../models/laborconfigdata');

let hotelIdList = [1];
const UserID = 2;

let GetPayrollDepartmentWise = (req, res, next) => {

    var checkit = new Checkit({
        hotelId: 'required',
        period: 'required',
        currentDate: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    //get myp hotelid from cmp_id
    HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
        if (err) {
            return next(err);
        }
        if (!hoteldata) {
            return next(HttpMsg.HotelNotFound);
        }
        else {
            PayrollDepartmentWise.GetPayrollDepartmentWiseData(hoteldata.ID, data.period, data.currentDate, (err, result) => {
                if (err) {
                    return next(err);
                }

                let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                res.status(200).send(result);
            });
        }
    });

}

GetPayrollVsRevenueVsOcc = (req, res, next) => {
    var checkit = new Checkit({
        hotelId: 'required',
        period: 'required',
        currentDate: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }
    //get myp hotelid from cmp_id
    HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
        if (err) {
            return next(err);
        }
        if (!hoteldata) {
            return next(HttpMsg.HotelNotFound);
        }
        else {
            PayrollDepartmentWise.GetPayrollVsRevenueVsOcc(hoteldata.ID, data.period, data.currentDate, (err, result) => {
                if (err) {
                    return next(err);
                }
                let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                res.status(200).send(response);
            });
        }
    });


}
GetActualVsPayroll = (req, res, next) => {
    var checkit = new Checkit({
        hotelId: 'required',
        period: 'required',
        currentDate: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        //return res.status(400).send(err.toJSON());
    }

    //get myp hotelid from cmp_id
    HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
        if (err) {
            return next(err);
        }
        if (!hoteldata) {
            return next(HttpMsg.HotelNotFound);
        }
        else {
            PayrollDepartmentWise.GetActualVsPayroll(hoteldata.ID, data.period, data.currentDate, (err, result) => {
                let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                res.status(200).send(response);
            });
        }
    });
}
let GetHouseKeepingPerRoom = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelId: 'required',
        period: 'required',
        currentDate: 'required',
        laborsection1: 'required',
        laborsection2: 'required',
        laborwidgetday: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }
    //get myp hotelid from cmp_id
    HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
        if (err) {
            return next(err);
        }
        if (!hoteldata) {
            return next(HttpMsg.HotelNotFound);
        }
        else {
            PayrollDepartmentWise.GetHouseKeepingPerRoom(data.userid,hoteldata.ID, data.period, data.currentDate, data.laborsection1, data.laborsection2, data.laborwidgetday, (err, result) => {
                let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                res.status(200).send(response);
            });
        }
    });

}
let GetPayrollActualvsPlanBudget = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelId: 'required',
        currentDate: 'required',
        laborsection1: 'required',
        laborsection2: 'required',
        laborwidgetday: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }
    //get myp hotelid from cmp_id
    HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
        if (err) {
            return next(err);
        }
        if (!hoteldata) {
            return next(HttpMsg.HotelNotFound);
        }
        else {
            PayrollDepartmentWise.GetPayrollActualvsPlanBudget(data.userid,hoteldata.ID, data.currentDate, data.laborsection1, data.laborsection2, data.laborwidgetday, (err, result) => {
                let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                res.status(200).send(response);
            });
        }
    });

}
let GetPayrollActualvsPlanBudgetHours = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelId: 'required',
        period: 'required',
        currentDate: 'required',
        laborsection1: 'required',
        laborsection2: 'required',
        laborwidgetday: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }
    //get myp hotelid from cmp_id
    HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
        if (err) {
            return next(err);
        }
        if (!hoteldata) {
            return next(HttpMsg.HotelNotFound);
        }
        else {
            PayrollDepartmentWise.GetPayrollActualvsPlanBudgetHours(data.userid.hoteldata.ID, data.period, data.currentDate, data.laborsection1, data.laborsection2, data.laborwidgetday, (err, result) => {
                let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                res.status(200).send(response);
            });
        }
    });

}


let SaveConfigs = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        laborsection1: 'required',
        laborsection2: 'required',
        payrolldepartmentwise: 'required',
        payrollvsrevenuevsocc: 'required',
        actualvspayrollchart: 'required',
        housekeepingwidget: 'required',
        payrollactualvsplanhourswidget: 'required',
        payrollactualvsplanwageswidget: 'required',
        defaultweekday: 'required'

    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserConfigData(data.userid, (err, result) => {
        if (err) {
            return next(err);
        }
        var objLaborconfigdata = new Laborconfigdata();
        objLaborconfigdata.userid = data.userid;
        if (result.LaborSection1 != null) {
            objLaborconfigdata.laborsection1 = data.laborsection1;
        }
        if (result.LaborSection2 != null) {
            objLaborconfigdata.laborsection2 = data.laborsection2;
        }
        objLaborconfigdata.payrolldepartmentwise = data.payrolldepartmentwise;
        objLaborconfigdata.payrollvsrevenuevsocc = data.payrollvsrevenuevsocc;
        objLaborconfigdata.actualvspayrollchart = data.actualvspayrollchart;
        objLaborconfigdata.housekeepingwidget = data.housekeepingwidget;
        objLaborconfigdata.payrollactualvsplanhourswidget = data.payrollactualvsplanhourswidget;
        objLaborconfigdata.payrollactualvsplanwageswidget = data.payrollactualvsplanwageswidget;
        objLaborconfigdata.defaultweekday = data.defaultweekday;
        UserHelper.saveUserConfigData_Labor(objLaborconfigdata, (err, save_result) => {
            if (err) {
                return next(err);
            }
            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(objLaborconfigdata).build();
            res.status(200).send(response);
        });
    });

}
let GetConfigs = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }
    UserHelper.getUserConfigData(data.userid, (err, result) => {
        if (err) {
            return next(err);
        }
        var objLaborconfigdata = new Laborconfigdata();
        objLaborconfigdata.userid = data.userid;
        if (result) {
            if (result.LaborSection1 != null) {
                objLaborconfigdata.laborsection1 = result.LaborSection1;
            }
            if (result.LaborSection2 != null) {
                objLaborconfigdata.laborsection2 = result.LaborSection2;
            }
            objLaborconfigdata.payrolldepartmentwise = result.PayrollDepartmentWise;
            objLaborconfigdata.payrollvsrevenuevsocc = result.PayrollVsRevenueVsOcc;
            objLaborconfigdata.actualvspayrollchart = result.ActualVsPayrollChart;
            objLaborconfigdata.housekeepingwidget = result.HouseKeepingWidget;
            objLaborconfigdata.payrollactualvsplanhourswidget = result.PayrollActualvsPlanHoursWidget;
            objLaborconfigdata.payrollactualvsplanwageswidget = result.PayrollActualvsPlanWagesWidget;
            objLaborconfigdata.defaultweekday = result.DefaultWeekDay;

        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(objLaborconfigdata).build();
        res.status(200).send(response);
    });

}

module.exports = {
    GetPayrollDepartmentWiseData: GetPayrollDepartmentWise,
    GetPayrollVsRevenueVsOcc: GetPayrollVsRevenueVsOcc,
    GetActualVsPayroll: GetActualVsPayroll,
    GetHouseKeepingPerRoom: GetHouseKeepingPerRoom,
    GetPayrollActualvsPlanBudget: GetPayrollActualvsPlanBudget,
    GetPayrollActualvsPlanBudgetHours: GetPayrollActualvsPlanBudgetHours,
    GetConfigs: GetConfigs,
    SaveConfigs: SaveConfigs,
}