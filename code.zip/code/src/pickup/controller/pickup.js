const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const Checkit = require('checkit');
const UserHelper = require('../../helpers/user_helper');
const PickupHelper = require('../../helpers/pickup_helper');
const MonthlyPickupHelper = require('../../helpers/monthlypickup_helper');
const PickupSummeryHelper = require('../../helpers/pickupsummery_helper');
const HotelsHelper = require('../../helpers/hotels_helper');

var log = require('log4js').getLogger("pickup");

let pickupDataFn = (req, res, next) => {

  var checkit = new Checkit({
    userid: 'required',
    hotelid: 'required',
    today: 'required',
    days: 'required',
    startDate: 'required'
  });

  var [err, data] = checkit.validateSync(req.body);
  if (err) {
    log.error(err.toJSON());
    return res.status(400).send(err.toJSON());
  }

  UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
    if (err) {
      return next(err);
    }
    //get myp hotelid from cmp_id
    HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
      if (err) {
        return next(err);
      }
      if (!hoteldata) {
        return next(HttpMsg.HotelNotFound);
      }
      else {
        PickupHelper.getPickupData(hoteldata.ID, data.today, data.days, data.startDate, userconfigdata, (err, result) => {
          if (err) {
            return next(err);
          }
          let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
          res.status(200).send(response);
        });
      }
    });
  });
}

let monthlyPickupDataFn = (req, res, next) => {

  var checkit = new Checkit({
    userid: 'required',
    hotelid: 'required',
    month: 'required',
    currentdate: 'required'
  });

  var [err, data] = checkit.validateSync(req.body);
  if (err) {
    log.error(err.toJSON());
    return res.status(400).send(err.toJSON());
  }
  UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
    if (err) {
      return next(err);
    }
    //get myp hotelid from cmp_id
    HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
      if (err) {
        return next(err);
      }
      if (!hoteldata) {
        return next(HttpMsg.HotelNotFound);
      }
      else {
        MonthlyPickupHelper.getMonthlyPickupData(hoteldata.ID, data.month, data.currentdate, userconfigdata, (err, result) => {
          if (err) {
            return next(err);
          }
          let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
          res.status(200).send(response);
        });
      }
    });

  });
}

let summeryPickupDataFn = (req, res, next) => {

  var checkit = new Checkit({
    userid: 'required',
    hotelid: 'required',
    date: 'required',
  });

  var [err, data] = checkit.validateSync(req.body);
  if (err) {
    log.error(err.toJSON());
    return res.status(400).send(err.toJSON());
  }
  UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
    if (err) {
      return next(err);
    }
    //get myp hotelid from cmp_id
    HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
      if (err) {
        return next(err);
      }
      if (!hoteldata) {
        return next(HttpMsg.HotelNotFound);
      }
      else {
        PickupSummeryHelper.getSummeryPickupData(hoteldata.ID, data.date, userconfigdata, (err, result) => {
          if (err) {
            return next(err);
          }
          let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
          res.status(200).send(response);
        });
      }
    });

  });

}
let pickupDataMissingDates = (req, res, next) => {
  var checkit = new Checkit({
    userid: 'required',
    hotelid: 'required',
    today: 'required',
    days:'required'
  });

  var [err, data] = checkit.validateSync(req.body);
  if (err) {
    log.error(err.toJSON());
    return res.status(400).send(err.toJSON());
  }
    //get myp hotelid from cmp_id
    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
      if (err) {
        return next(err);
      }
      //get myp hotelid from cmp_id
      HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
        if (err) {
          return next(err);
        }
        if (!hoteldata) {
          return next(HttpMsg.HotelNotFound);
        }
        else {
          PickupSummeryHelper.getMissingPickupDates(hoteldata.ID, data.today,data.days, userconfigdata, (err, result) => {
            if (err) {
              return next(err);
            }
            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
          });
        }
      });
  
    });
}
module.exports = {
  PickupData: pickupDataFn,
  MonthlyPickupData: monthlyPickupDataFn,
  SummeryPickupData: summeryPickupDataFn,
  PickupDataMissingDates: pickupDataMissingDates
}
