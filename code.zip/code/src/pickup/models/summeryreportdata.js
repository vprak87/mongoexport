class Summeryreportdata {

  constructor(options) {
    const defaults = {
      MonthYear: '',
      PickUpRoomNight: 0,
      PickUpRevenue: 0,
      PickUpADR: 0,
      MTDBudgetRoomNight: 0,
      MTDBudgetRevenue: 0,
      MTDForcastRoomNight: 0,
      MTDForcastRevenue: 0,

      OTBBudgetRoomNight: 0,
      OTBBudgetRevenue: 0,
      OTBForcastRoomNight: 0,
      OTBForcastRevenue: 0
    }
    
    let opts = Object.assign({}, defaults, options);

    // assign options to instance data (using only property names contained
    //  in defaults object to avoid copying properties we don't want)
    Object.keys(defaults).forEach(prop => {
        this[prop] = opts[prop];
    });
  }
}

module.exports = Summeryreportdata;