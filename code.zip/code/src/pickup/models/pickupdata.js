const Utils = require('../../common/utils');

class Pickupdata {

  constructor(options) {
    const defaults = {
      Date: '',
      DailyActivityDate: '',
      Occupancy: '',
      TotalRevenue: '',
      NoOfRoomSold: '',
      NoOfRoomAvailable: '',
      Pickup1Amount: 0,
      Pickup3Amount: 0,
      Pickup7Amount: 0,
      PickupSDLYAmount: 0,
      Pickup1RoomSold: 0,
      Pickup3RoomSold: 0,
      Pickup7RoomSold: 0,
      PickupSDLYRoomSold: 0,
      DeltaForcast: 0,
      TodayDate: '',
      IsFriORSat: false,
      GroupBlock: 0,
      GroupNotPickedUp: 0,
      TransientDelta7: 0,
      TransientDeltaSDLY: 0,
      TransientDelta3: 0,
      TransientDelta1: 0,
      TransientRoomSold: 0
    }
  
    let opts = Object.assign({}, defaults, options);

    // assign options to instance data (using only property names contained
    //  in defaults object to avoid copying properties we don't want)
    Object.keys(defaults).forEach(prop => {
        this[prop] = opts[prop];
    });
  }

  setFormat(data) {
      this.IsFriORSat = Utils.IsFriORSat(this.DailyActivityDate);
      return this;
  }

}

module.exports = Pickupdata;
