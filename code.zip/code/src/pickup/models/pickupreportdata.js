class Pickupreportdata {

  constructor(options) {
    const defaults = {
      Day: '',
      Date: '',
      AvailRoom: 0,
      TotalAvailRoom: 0,

      RoomsActual: 0,
      TotalRoomsActual: 0,

      RoomsBudget: 0,
      TotalRoomsBudget: 0,

      RoomsBudgetVariance: 0,
      TotalRoomsBudgetVariance: 0,

      RoomsForcastBudget: 0,
      TotalRoomsForcastBudget: 0,
      
      RoomsForcastVariance: 0,
      TotalRoomsForcastVariance: 0,

      ReveneActual: 0,
      TotalReveneActual: 0,

      ReveneBudget: 0,
      TotalReveneBudget: 0,

      ReveneBudgetVariance: 0,
      TotalReveneBudgetVariance: 0,

      RevenueForcastBudget: 0,
      TotalRevenueForcastBudget: 0,

      RevenueForcastVariance: 0,
      TotalRevenueForcastVariance: 0,

      ADTActual: 0,
      TotalADTActual: 0,

      ADTBudget: 0,
      TotalADTBudget: 0,

      ADTBudgetVariance: 0,
      TotalADTBudgetVariance: 0,

      ADTForcastBudget: 0,
      TotalADTForcastBudget: 0,

      ADTForcastVariance: 0,
      TotalADTForcastVariance: 0,

      OccuActual: 0,
      TotalOccuActual: 0,

      OccuBudget: 0,
      TotalOccuBudget: 0,

      OccuBudgetVariance: 0,
      TotalOccuBudgetVariance: 0,

      OccuForcastBudget: 0,
      TotalOccuForcastBudget: 0,

      OccuForcastVariance: 0,
      TotalOccuForcastVariance: 0,

      pickupToday: 0,
      TotalpickupToday: 0,

      pickupMTD: 0,
      TotalpickupMTD: 0,

      RevparActual: 0,
      TotalRevparActual: 0,

      RevparBudget: 0,
      TotalRevparBudget: 0,

      RevparBudgetVariance: 0,
      TotalRevparBudgetVariance: 0,

      RevparForcastBudget: 0,
      TotalRevparForcastBudget: 0,

      RevparForcastVariance: 0,
      TotalRevparForcastVariance: 0

    }
    let opts = Object.assign({}, defaults, options);

    // assign options to instance data (using only property names contained
    //  in defaults object to avoid copying properties we don't want)
    Object.keys(defaults).forEach(prop => {
        this[prop] = opts[prop];
    });

  }
}

module.exports = Pickupreportdata;