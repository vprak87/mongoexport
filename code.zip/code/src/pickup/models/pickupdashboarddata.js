
class Pickupdashboarddata {

  constructor(options) {
    const defaults = {
      PickupDataModelList: [],
      DailyActivityDateDelta1: '',
      DailyActivityDateDelta3: '',
      DailyActivityDateDelta7: '',
      DailyActivityDateDeltaSDLY: '',
      CurrentDate: '',
    }

    let opts = Object.assign({}, defaults, options);

    // assign options to instance data (using only property names contained
    //  in defaults object to avoid copying properties we don't want)
    Object.keys(defaults).forEach(prop => {
        this[prop] = opts[prop];
    });
  
  }
}

module.exports = Pickupdashboarddata