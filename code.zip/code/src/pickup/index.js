const express = require('express');
const router = express.Router(),
    Controller = require('./controller/pickup');


router.get("/pickupdata", Controller.PickupData);
router.get("/monthlypickupdata", Controller.MonthlyPickupData);
router.get("/summerypickupdata", Controller.SummeryPickupData);
router.get("/getpickupdatamissingdates", Controller.PickupDataMissingDates);




module.exports = router