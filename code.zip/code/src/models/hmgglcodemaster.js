const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hmgglcodemasterSchema'),
    DBTable = require('../schema/db_table');

const HMGGLCodeMasterSchema = new Schema({ 
    [SchemaField.GLCode]: { type: String, required: [true, "GLCode required"] },
    [SchemaField.Description]: { type: String, required: [true, "Description required"] },
    [SchemaField.OrganizationID]: { type: Number, required: [true, "OrganizationID required"] },
    [SchemaField.IsActive]:{ type: Boolean, default: true, required: [true, "IsActive required"] },
})


HMGGLCodeMasterSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const HMGGLCodeMaster = mongoose.model(DBTable.HMGGLCODEMASTER, HMGGLCodeMasterSchema);

module.exports = { HMGGLCodeMaster, SchemaField };  