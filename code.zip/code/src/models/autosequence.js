const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/autosequenceSchema'),
    DBTable = require('../schema/db_table');



const AutosequenceSchema = new Schema({
    [SchemaField.TableName]: { type: String, required: [true, "TableName required"] },
    [SchemaField.SequenceValue]: { type: Number, required: [true, "SequenceValue required"] }
})


AutosequenceSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Autosequence = mongoose.model(DBTable.AUTOSEQUENCE, AutosequenceSchema);

module.exports = { Autosequence, SchemaField };  