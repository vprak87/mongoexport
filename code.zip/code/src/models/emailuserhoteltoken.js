const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/emailuserhoteltokenSchema'),
    DBTable = require('../schema/db_table');



const EmailuserhoteltokenSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.HotelID]: { type: Number },
    [SchemaField.HotelGroupID]: { type: Number },
    [SchemaField.Token]: { type: String }

})


EmailuserhoteltokenSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Emailuserhoteltoken = mongoose.model(DBTable.EMAILUSERHOTELTOKEN, EmailuserhoteltokenSchema);

module.exports = { Emailuserhoteltoken, SchemaField };  