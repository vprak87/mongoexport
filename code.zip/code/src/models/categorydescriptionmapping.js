const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/categorydescriptionmappingSchema'),
    DBTable = require('../schema/db_table');



const CategorydescriptionmappingSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.Category]: { type: String },
    [SchemaField.OldCategory]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.OrganisationID]: { type: Number },
    [SchemaField.PMS]: { type: String },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },

})


CategorydescriptionmappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Categorydescriptionmapping = mongoose.model(DBTable.CATEGORYDESCRIPTIONMAPPING, CategorydescriptionmappingSchema);

module.exports = { Categorydescriptionmapping, SchemaField };  