const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/accountingtoolemailogsSchema'),
    DBTable = require('../schema/db_table');



const AccountingtoolemailogsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.TransID]: { type: String, required: [true, "TransID required"] },
    [SchemaField.EmailSentOn]: { type: Date },
    [SchemaField.Category]: { type: String }
})


AccountingtoolemailogsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Accountingtoolemailogs = mongoose.model(DBTable.ACCOUNTINGTOOLEMAILOGS, AccountingtoolemailogsSchema);

module.exports = { Accountingtoolemailogs, SchemaField };  