const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/userhotelgroupxrefSchema'),
    DBTable = require('../schema/db_table');



const UserhotelgroupxrefSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.UserId]: { type: Number, required: [true, "UserId required"] },
    [SchemaField.HotelGroupId]: { type: Number, required: [true, "HotelGroupId required"] }

})


UserhotelgroupxrefSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Userhotelgroupxref = mongoose.model(DBTable.USERHOTELGROUPXREF, UserhotelgroupxrefSchema);

module.exports = { Userhotelgroupxref, SchemaField };  