const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/strrevparmonthreportSchema'),
    DBTable = require('../schema/db_table');



const StrrevparmonthreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.RevParMyPropRun28]: { type: Number },
    [SchemaField.RevParCompRun28]: { type: Number },
    [SchemaField.RevParMyPropRunMTD]: { type: Number },
    [SchemaField.RevParCompRunMTD]: { type: Number },
    [SchemaField.RevParChgMyPropRun28]: { type: Number },
    [SchemaField.RevParChgCompRun28]: { type: Number },
    [SchemaField.RevParChgMyPropRunMTD]: { type: Number },
    [SchemaField.RevParChgCompRunMTD]: { type: Number },
    [SchemaField.RevParIndexRun28]: { type: Number },
    [SchemaField.RevParIndexRunMTD]: { type: Number },
    [SchemaField.RevParIndexChgRun28]: { type: Number },
    [SchemaField.RevParIndexChgRunMTD]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedOn]: { type: Date, default: Date.now },
    [SchemaField.IsDeleted]: { type: Boolean }

})


StrrevparmonthreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Strrevparmonthreport = mongoose.model(DBTable.STRREVPARMONTHREPORT, StrrevparmonthreportSchema);

module.exports = { Strrevparmonthreport, SchemaField };  