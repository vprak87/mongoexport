const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/strcompsetSchema'),
    DBTable = require('../schema/db_table');



const StrcompsetSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.County]: { type: String },
    [SchemaField.Zip]: { type: Number },
    [SchemaField.Phone]: { type: String },
    [SchemaField.Rooms]: { type: Number },
    [SchemaField.Date]: { type: Date },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedOn]: { type: Date, default: Date.now },
    [SchemaField.IsDeleted]: { type: Boolean },
    [SchemaField.City]: { type: String },
    [SchemaField.State]: { type: String },
    [SchemaField.HotelName]: { type: String },
    [SchemaField.HotelId]: { type: Number },
    [SchemaField.ToDate]: { type: Date },
    [SchemaField.Address]: { type: String },
    [SchemaField.ZipCode]: { type: String }

})


StrcompsetSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Strcompset = mongoose.model(DBTable.STRCOMPSET, StrcompsetSchema);

module.exports = { Strcompset, SchemaField };  