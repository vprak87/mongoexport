const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/accountingtoolmasterpropertiesSchema'),
    DBTable = require('../schema/db_table');



const AccountingtoolmasterpropertiesSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.Property]: { type: String, required: [true, "Property required"] }
})


AccountingtoolmasterpropertiesSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Accountingtoolmasterproperties = mongoose.model(DBTable.ACCOUNTINGTOOLMASTERPROPERTIES, AccountingtoolmasterpropertiesSchema);

module.exports = { Accountingtoolmasterproperties, SchemaField };  