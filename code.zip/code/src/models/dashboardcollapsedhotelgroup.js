const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/dashboardcollapsedhotelgroupSchema'),
    DBTable = require('../schema/db_table');



const DashboardcollapsedhotelgroupSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.HotelGroups]: { type: String },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now }
})


DashboardcollapsedhotelgroupSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Dashboardcollapsedhotelgroup = mongoose.model(DBTable.DASHBOARDCOLLAPSEDHOTELGROUP, DashboardcollapsedhotelgroupSchema);

module.exports = { Dashboardcollapsedhotelgroup, SchemaField };  