const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/pnlmonthlycolorderSchema'),
    DBTable = require('../schema/db_table');

const SchemaField1 = require('../schema/fields/pnlmothlycolSchema');
const SchemaField2 = require('../schema/fields/pnlmonthlycolgroupSchema');

const PnlcolSchema = new Schema({
  [SchemaField1.Type]: { type: String},
  [SchemaField1.Id]: { type: Number},
  [SchemaField1.Title]: { type: String},
  [SchemaField1.DataKey]: { type: String}
})


const PnlgroupSchema = new Schema({
  [SchemaField2.Type]: { type: String},
  [SchemaField2.Id]: { type: Number},
  [SchemaField2.Title]: { type: String},
  [SchemaField2.DataKey]: { type: String},
  [SchemaField2.Color]: { type: String},
  [SchemaField2.Cols]: [{type: PnlcolSchema}]
})


const PnlmonthlycolorderSchema = new Schema({
  [SchemaField.User_ID]: { type: Number, required: [true, "User ID required"] },
  [SchemaField.Hotel_ID]: { type: Number, required: [true, "Hotel ID required"] },
  [SchemaField.Created_at]: { type: Date, default: Date.now },
  [SchemaField.Data] : [{type: PnlgroupSchema}]
})


PnlmonthlycolorderSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});

const Pnlmonthlycolorder = mongoose.model(DBTable.PNLMONTHLYCOLORDER, PnlmonthlycolorderSchema);

module.exports = { Pnlmonthlycolorder, SchemaField };  