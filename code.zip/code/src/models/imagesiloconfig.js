const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/imagesiloconfigSchema'),
    DBTable = require('../schema/db_table');



const ImagesiloconfigSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.UserId]: { type: Number, required: [true, "UserId required"] },
    [SchemaField.Username]: { type: String, required: [true, "Username required"] },
    [SchemaField.Password]: { type: String, required: [true, "Password required"] },
    [SchemaField.EntityId]: { type: String, required: [true, "EntityId required"] },
    [SchemaField.ProjectId]: { type: String, required: [true, "ProjectId required"] }
})


ImagesiloconfigSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Imagesiloconfig = mongoose.model(DBTable.IMAGESILOCONFIG, ImagesiloconfigSchema);

module.exports = { Imagesiloconfig, SchemaField };  