const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/auditlogSchema'),
    DBTable = require('../schema/db_table');



const AuditlogSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.AuditId]: { type: String },
    [SchemaField.IPAddress]: { type: String },
    [SchemaField.UserName]: { type: String },
    [SchemaField.URLAccessed]: { type: String },
    [SchemaField.TimeAccessed]: { type: Date, default: Date.now },
    [SchemaField.PostedData]: { type: String }
})

AuditlogSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Auditlog = mongoose.model(DBTable.AUDITLOG, AuditlogSchema);

module.exports = { Auditlog, SchemaField };  