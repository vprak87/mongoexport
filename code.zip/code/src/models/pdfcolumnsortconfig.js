const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/pdfcolumnsortconfigSchema'),
    DBTable = require('../schema/db_table');



const PdfcolumnsortconfigSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.UserId]: { type: Number, required: [true, "UserId required"] },
    [SchemaField.ConfigName]: { type: String },
    [SchemaField.DisplayName]: { type: String },
    [SchemaField.DisplayOrder]: { type: Number },
    [SchemaField.Type]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now }
})


PdfcolumnsortconfigSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Pdfcolumnsortconfig = mongoose.model(DBTable.PDFCOLUMNSORTCONFIG, PdfcolumnsortconfigSchema);

module.exports = { Pdfcolumnsortconfig, SchemaField };  