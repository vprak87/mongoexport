const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelqcreportglcodeSchema'),
    DBTable = require('../schema/db_table');



const HotelqcreportglcodeSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.TotalRevenue]: { type: Boolean },
    [SchemaField.TotalRevenueMTD]: { type: Boolean },
    [SchemaField.TotalRevenueYTD]: { type: Boolean },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now }

})


HotelqcreportglcodeSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelqcreportglcode = mongoose.model(DBTable.HOTELQCREPORTGLCODE, HotelqcreportglcodeSchema);

module.exports = { Hotelqcreportglcode, SchemaField };  