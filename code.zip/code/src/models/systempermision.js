const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/systempermisionSchema'),
    DBTable = require('../schema/db_table');



const SystempermisionSchema = new Schema({
    [SchemaField.PermissionId]: { type: String, required: [true, "PermissionId required"] },
    [SchemaField.ControllerName]: { type: String, required: [true, "PermissionId required"] },
    [SchemaField.Action]: { type: String, required: [true, "PermissionId required"] }

})


SystempermisionSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Systempermision = mongoose.model(DBTable.SYSTEMPERMISION, SystempermisionSchema);

module.exports = { Systempermision, SchemaField };  