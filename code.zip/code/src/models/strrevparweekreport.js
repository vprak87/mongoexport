const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/strrevparweekreportSchema'),
    DBTable = require('../schema/db_table');



const StrrevparweekreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.RevParMyPropCurrentWeek]: { type: Number },
    [SchemaField.RevParCompCurrentWeek]: { type: Number },
    [SchemaField.RevParMyPropRun28]: { type: Number },
    [SchemaField.RevParCompRun28]: { type: Number },
    [SchemaField.RevParMyPropRunMTD]: { type: Number },
    [SchemaField.RevParCompRunMTD]: { type: Number },
    [SchemaField.RevParChgMyPropCurrentWeek]: { type: Number },
    [SchemaField.RevParChgCompCurrentWeek]: { type: Number },
    [SchemaField.RevParChgMyPropRun28]: { type: Number },
    [SchemaField.RevParChgCompRun28]: { type: Number },
    [SchemaField.RevParChgMyPropRunMTD]: { type: Number },
    [SchemaField.RevParChgCompRunMTD]: { type: Number },
    [SchemaField.RevParIndexCurrentWeek]: { type: Number },
    [SchemaField.RevParIndexRun28]: { type: Number },
    [SchemaField.RevParIndexRunMTD]: { type: Number },
    [SchemaField.RevParIndexChgCurrentWeek]: { type: Number },
    [SchemaField.RevParIndexChgRun28]: { type: Number },
    [SchemaField.RevParIndexChgRunMTD]: { type: Number },
    [SchemaField.RevParRankCurrentWeek]: { type: String },
    [SchemaField.RevParRankRun28]: { type: String },
    [SchemaField.RevParRankRunMTD]: { type: String },
    [SchemaField.RevParRankChgCurrentWeek]: { type: String },
    [SchemaField.RevParRankChgRun28]: { type: String },
    [SchemaField.RevParRankChgRunMTD]: { type: String },
    [SchemaField.RevParRankChgRunMTD]: { type: String },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.IsDelete]: { type: Boolean },

})


StrrevparweekreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Strrevparweekreport = mongoose.model(DBTable.STRREVPARWEEKREPORT, StrrevparweekreportSchema);

module.exports = { Strrevparweekreport, SchemaField };  