const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/boardcastmessageSchema'),
    DBTable = require('../schema/db_table');



const BoardcastmessageSchema = new Schema({
    [SchemaField.BoardcastMessageID]: { type: Number, required: [true, "BoardcastMessageID required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.OrgID]: { type: Number },
    [SchemaField.Message]: { type: String },
    [SchemaField.StartDate]: { type: Date, required: [true, "StartDate required"] },
    [SchemaField.EndDate]: { type: Date, required: [true, "EndDate required"] },
    [SchemaField.IsActive]: { type: Boolean },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String }

})


BoardcastmessageSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Boardcastmessage = mongoose.model(DBTable.BOARDCASTMESSAGE, BoardcastmessageSchema);

module.exports = { Boardcastmessage, SchemaField };  