const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/googleplacehotelmappingSchema'),
    DBTable = require('../schema/db_table');



const GoogleplacehotelmappingSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.PlaceID]: { type: String, required: [true, "PlaceID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] }


})


GoogleplacehotelmappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Googleplacehotelmapping = mongoose.model(DBTable.GOOGLEPLACEHOTELMAPPING, GoogleplacehotelmappingSchema);

module.exports = { Googleplacehotelmapping, SchemaField };  