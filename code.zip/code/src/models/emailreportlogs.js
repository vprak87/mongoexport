const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/emailreportlogsSchema'),
    DBTable = require('../schema/db_table');



const EmailreportlogsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.ReportDate]: { type: Date, required: [true, "ReportDate required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.EmailAddress]: { type: String },
    [SchemaField.HotelID]: { type: Number },
    [SchemaField.EmailSent]: { type: Boolean },
    [SchemaField.NoDataFound]: { type: Boolean },
    [SchemaField.ActionType]: { type: String },
    [SchemaField.IsManager]: { type: Boolean },
    [SchemaField.IsAdmin]: { type: Boolean },
    [SchemaField.InsertedDateTime]: { type: Date },
    [SchemaField.UpdatedDateTime]: { type: Date },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.ScheduledDateTime]: { type: Date },
    [SchemaField.Category]: { type: String },
    [SchemaField.EmailConfigurationScheduleID]: { type: Number }

})


EmailreportlogsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Emailreportlogs = mongoose.model(DBTable.EMAILREPORTLOGS, EmailreportlogsSchema);

module.exports = { Emailreportlogs, SchemaField };  