const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelavendraalertnonmfddetaildataSchema'),
    DBTable = require('../schema/db_table');



const HotelavendraalertnonmfddetaildataSchema = new Schema({
    [SchemaField.AvendraAlertNonMFDDetailDataId]: { type: Number, required: [true, "AvendraAlertNonMFDDetailDataId required"] },
    [SchemaField.AvendraAlertInsightid]: { type: Number },
    [SchemaField.ERM_Parent]: { type: String },
    [SchemaField.CUST_ID]: { type: String },
    [SchemaField.BP_CATEGORY_NM]: { type: String },
    [SchemaField.BP_DIST_CATEGORY]: { type: String },
    [SchemaField.DIST_NM]: { type: String },
    [SchemaField.SPEND]: { type: Number }

})


HotelavendraalertnonmfddetaildataSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelavendraalertnonmfddetaildata = mongoose.model(DBTable.HOTELAVENDRAALERTNONMFDDETAILDATA, HotelavendraalertnonmfddetaildataSchema);

module.exports = { Hotelavendraalertnonmfddetaildata, SchemaField };  