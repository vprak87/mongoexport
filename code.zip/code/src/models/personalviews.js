const mongoose = require('mongoose');
const Schema = mongoose.Schema,ObjectId = Schema.ObjectId;
const SchemaField = require('../schema/fields/personalviewsSchema'),
    DBTable = require('../schema/db_table');


     

const PersonalviewsSchema = new Schema({
    [SchemaField.userid]: { type: Number, required: [true, "User Id required"] },
    [SchemaField.name]: { type: String, required: [true, "Name required"] },
    [SchemaField.nameforsort]: { type: String},    
    [SchemaField.description]: { type: String},
    [SchemaField.templateid]: { type: ObjectId, required: [true, "Template Id required"] }

})

PersonalviewsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const PersonalViews = mongoose.model(DBTable.PERSONALVIEWS, PersonalviewsSchema);

module.exports = { PersonalViews, SchemaField };  