const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelavendraalertinsightlevelSchema'),
    DBTable = require('../schema/db_table');



const HotelavendraalertinsightlevelSchema = new Schema({
    [SchemaField.AvendraAlertInsightLevelId]: { type: Number, required: [true, "AvendraAlertInsightLevelId required"] },
    [SchemaField.AvendraAlertInsightLevelName]: { type: String }

})


HotelavendraalertinsightlevelSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelavendraalertinsightlevel = mongoose.model(DBTable.HOTELAVENDRAALERTINSIGHTLEVEL, HotelavendraalertinsightlevelSchema);

module.exports = { Hotelavendraalertinsightlevel, SchemaField };  