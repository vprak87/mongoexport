const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/glcodehotelrevenueSchema'),
    DBTable = require('../schema/db_table');



const GlcodehotelrevenueSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelName]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.DisplayDescription]: { type: String },
    [SchemaField.GLCode]: { type: String },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.OrganizationID]: { type: Number, required: [true, "OrganizationID required"] },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.IsActive]: { type: Boolean },
    [SchemaField.Category]: { type: String },
    [SchemaField.DepartmentID]: { type: String },
    [SchemaField.DisplayPMSCode]: { type: String },
    [SchemaField.GLDescription]: { type: String }
})


GlcodehotelrevenueSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Glcodehotelrevenue = mongoose.model(DBTable.GLCODEHOTELREVENUE, GlcodehotelrevenueSchema);

module.exports = { Glcodehotelrevenue, SchemaField };  