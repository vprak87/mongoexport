const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelrevenueSchema'),
    DBTable = require('../schema/db_table');



const HotelrevenueSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.Category]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.NoOfReference]: { type: Number },
    [SchemaField.Amount]: { type: Number },
    [SchemaField.NumberofAvailableRooms]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.IsDelete]: { type: Boolean },
    [SchemaField.ReportedDateTime]: { type: Date },
    [SchemaField.TransientRoomsSold]: { type: Number },
    [SchemaField.TransientRoomRevenue]: { type: Number },
    [SchemaField.GroupRoomsSold]: { type: Number },
    [SchemaField.GroupRoomRevenue]: { type: Number },
    [SchemaField.GroupBlock]: { type: Number },
    [SchemaField.AmountMTD]: { type: Number },
    [SchemaField.AmountYTD]: { type: Number },
    [SchemaField.PMSCode]: { type: String },
    [SchemaField.PMSType]: { type: String },
    [SchemaField.ReportName]: { type: String }


})


HotelrevenueSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelrevenue = mongoose.model(DBTable.HOTELREVENUE, HotelrevenueSchema);

module.exports = { Hotelrevenue, SchemaField };  