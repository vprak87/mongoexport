const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/webapitokenSchema'),
    DBTable = require('../schema/db_table');

const WebAPITokensSchema = new Schema({
    [SchemaField.TokenId]: { type: Number, required: [true, "TokenId required"] },
    [SchemaField.UserId]: { type: Number, required: [true, "UserId required"] },
    [SchemaField.AuthToken]: { type: String, required: [true, "AuthToken required"] },
    [SchemaField.IssuedOn]: { type: Date, default: Date.now },
    [SchemaField.ExpiresOn]: { type: Date },
    [SchemaField.Type]: { type: String }
})



const WebAPITokens = mongoose.model(DBTable.WEBAPITOKENS, WebAPITokensSchema);

module.exports = { WebAPITokens, SchemaField };  
