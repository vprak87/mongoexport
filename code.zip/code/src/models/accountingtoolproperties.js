const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/accountingtoolpropertiesSchema'),
    DBTable = require('../schema/db_table');



const AccountingtoolpropertiesSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.AccountingTool]: { type: String },
    [SchemaField.Property]: { type: String }
})

AccountingtoolpropertiesSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Accountingtoolproperties = mongoose.model(DBTable.ACCOUNTINGTOOLPROPERTIES, AccountingtoolpropertiesSchema);

module.exports = { Accountingtoolproperties, SchemaField };  