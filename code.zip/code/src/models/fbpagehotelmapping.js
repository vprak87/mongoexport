const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/fbpagehotelmappingSchema'),
    DBTable = require('../schema/db_table');



const FbpagehotelmappingSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.FBPageURL]: { type: String, required: [true, "FBPageURL required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] }


})


FbpagehotelmappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Fbpagehotelmapping = mongoose.model(DBTable.FBPAGEHOTELMAPPING, FbpagehotelmappingSchema);

module.exports = { Fbpagehotelmapping, SchemaField };  