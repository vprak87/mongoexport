const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/revenuemasterSchema'),
    DBTable = require('../schema/db_table');



const RevenuemasterSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.ImportDate]: { type: Date, required: [true, "ImportDate required"] },
    [SchemaField.ImportBy]: { type: Number, required: [true, "ImportBy required"] },
    [SchemaField.SyncOn]: { type: Date },
    [SchemaField.SyncStatus]: { type: Number },
    [SchemaField.SyncResponse]: { type: String },
    [SchemaField.HotelId]: { type: Number, required: [true, "HotelId required"] }

})


RevenuemasterSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Revenuemaster = mongoose.model(DBTable.REVENUEMASTER, RevenuemasterSchema);

module.exports = { Revenuemaster, SchemaField };  