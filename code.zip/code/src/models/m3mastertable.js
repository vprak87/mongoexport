const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/m3mastertableSchema'),
    DBTable = require('../schema/db_table');



const M3mastertableSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.Name]: { type: String },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] }
})


M3mastertableSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const M3mastertable = mongoose.model(DBTable.M3MASTERTABLE, M3mastertableSchema);

module.exports = { M3mastertable, SchemaField };  