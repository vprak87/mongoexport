const mongoose = require('mongoose');
const Schema = mongoose.Schema,ObjectId = Schema.ObjectId;
const SchemaField = require('../schema/fields/kpimarstersSchema'),
    DBTable = require('../schema/db_table');
    
const KpimarstersSchema = new Schema({
    [SchemaField.Name]: { type: String, required: [true, "Chart name required"] },
    [SchemaField.Text]: { type: String, required: [true, "Chart title required"] }
    

})

KpimarstersSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const KpiMarsters = mongoose.model(DBTable.KPIMARSTERS, KpimarstersSchema);

module.exports = { KpiMarsters, SchemaField };  