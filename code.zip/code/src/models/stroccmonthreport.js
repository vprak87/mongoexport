const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/stroccmonthreportSchema'),
    DBTable = require('../schema/db_table');



const StroccmonthreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.OccMyPropRun28]: { type: Number },
    [SchemaField.OccCompRun28]: { type: Number },
    [SchemaField.OccMyPropRunMTD]: { type: Number },
    [SchemaField.OccCompRunMTD]: { type: Number },
    [SchemaField.OccChgMyPropRun28]: { type: Number },
    [SchemaField.OccChgCompRun28]: { type: Number },
    [SchemaField.OccChgMyPropRunMTD]: { type: Number },
    [SchemaField.OccChgCompRunMTD]: { type: Number },
    [SchemaField.OccIndexRun28]: { type: Number },
    [SchemaField.OccIndexRunMTD]: { type: Number },
    [SchemaField.OccIndexChgRun28]: { type: Number },
    [SchemaField.OccIndexChgRunMTD]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedOn]: { type: Date, default: Date.now },
    [SchemaField.IsDeleted]: { type: Boolean }

})


StroccmonthreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Stroccmonthreport = mongoose.model(DBTable.STROCCMONTHREPORT, StroccmonthreportSchema);

module.exports = { Stroccmonthreport, SchemaField };  