const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/userroleaccessSchema'),
    DBTable = require('../schema/db_table');



const UserroleaccessSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserId required"] },
    [SchemaField.DashboardDayButton]: { type: Boolean },
    [SchemaField.DashboardMonthButton]: { type: Boolean },
    [SchemaField.DashboardYearButton]: { type: Boolean },
    [SchemaField.AddComment]: { type: Boolean },
    [SchemaField.AddEvent]: { type: Boolean },
    [SchemaField.StatsByDateRange]: { type: Boolean },
    [SchemaField.STRReport]: { type: Boolean },
    [SchemaField.PickupReport]: { type: Boolean },
    [SchemaField.SessionReport]: { type: Boolean },
    [SchemaField.ImportLogReport]: { type: Boolean },
    [SchemaField.QCLogReport]: { type: Boolean },
    [SchemaField.HotelDashboardCalculation]: { type: Boolean },
    [SchemaField.Organization]: { type: Boolean },
    [SchemaField.PayRoll]: { type: Boolean },
    [SchemaField.HotelReview]: { type: Boolean },
    [SchemaField.AddHotel]: { type: Boolean },
    [SchemaField.AddHotelGroup]: { type: Boolean },
    [SchemaField.ImportHotel]: { type: Boolean },
    [SchemaField.UserList]: { type: Boolean },
    [SchemaField.AddUser]: { type: Boolean },
    [SchemaField.UserHotelMapping]: { type: Boolean },
    [SchemaField.UserHotelMappingList]: { type: Boolean },
    [SchemaField.ImportUser]: { type: Boolean },
    [SchemaField.Department]: { type: Boolean },
    [SchemaField.ExpenseFormVendorList]: { type: Boolean },
    [SchemaField.AddExpenseFormVendor]: { type: Boolean },
    [SchemaField.ImportExpenseFormVendor]: { type: Boolean },
    [SchemaField.RoomRevenue]: { type: Boolean },
    [SchemaField.FoodBeverageRevenue]: { type: Boolean },
    [SchemaField.OtherIncome]: { type: Boolean },
    [SchemaField.HotelBudgetForecast]: { type: Boolean },
    [SchemaField.HotelRevenueGLCode]: { type: Boolean },
    [SchemaField.SetRevenueSourceTitle]: { type: Boolean },
    [SchemaField.ImportReport]: { type: Boolean },
    [SchemaField.ExportReport]: { type: Boolean },
    [SchemaField.Configuration]: { type: Boolean },
    [SchemaField.EmailConfigurationList]: { type: Boolean },
    [SchemaField.AddEmailConfiguration]: { type: Boolean },
    [SchemaField.ContactSupport]: { type: Boolean },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date },
    [SchemaField.IsActive]: { type: Boolean },
    [SchemaField.AddOrganization]: { type: Boolean },
    [SchemaField.EmailEscalationConfigurationList]: { type: Boolean },
    [SchemaField.AddEmailEscalationConfiguration]: { type: Boolean },
    [SchemaField.Labor]: { type: Boolean }


})


UserroleaccessSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Userroleaccess = mongoose.model(DBTable.USERROLEACCESS, UserroleaccessSchema);

module.exports = { Userroleaccess, SchemaField };  