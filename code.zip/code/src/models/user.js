const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/userSchema'),
    DBTable = require('../schema/db_table');

const UserSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"], unique: true },
    [SchemaField.UserName]: { type: String, required: [true, "UserName required"] },
    [SchemaField.Password]: { type: String, required: [true, "Password required"] },
    [SchemaField.FirstName]: { type: String, required: [true, "FirstName required"] },
    [SchemaField.LastName]: { type: String, required: [true, "LastName required"] },
    [SchemaField.Gender]: { type: String },
    [SchemaField.CompanyName]: { type: String },
    [SchemaField.Country]: { type: String },
    [SchemaField.Address1]: { type: String },
    [SchemaField.Address2]: { type: String },
    [SchemaField.City]: { type: String },
    [SchemaField.State]: { type: String },
    [SchemaField.BusineePhoneNumber]: { type: String },
    [SchemaField.AltPhoneNumber]: { type: String },
    [SchemaField.FaxNumber]: { type: String },
    [SchemaField.SecretQuestion]: { type: String },
    [SchemaField.SecreAnswer]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.RoleID]: { type: Number },
    [SchemaField.IsActive]: { type: Boolean },
    [SchemaField.IsRegisterForPoForm]: { type: Boolean },
    [SchemaField.PasswordRecoveryToken]: { type: String },
    [SchemaField.OrganizationId]: { type: Number },
    [SchemaField.IsRegisterForExpenseForm]: { type: Boolean },
    [SchemaField.IsFirstTimeLogin]: { type: Boolean, default: false },
    [SchemaField.SecondaryOrganizationId]: { type: Number },
    [SchemaField.AccessFailedCount]: { type: Number },
    [SchemaField.IsLockout]: { type: Boolean, default: false },
    [SchemaField.Cmp_Id]: { type: Number },
    [SchemaField.Cmp_OrgUser_Id]: { type: Number }
})

UserSchema.path(SchemaField.UserName).validate(function (v) {
    var emailRegex = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    return emailRegex.test(v); // Assuming email has a text attribute

}, "Invalid UserName")



UserSchema.pre('save', function (next) {
    var user = this;
    User.count({ $or: [{ email: user.email }, { mobile: user.mobile }, { username: user.username }] }, (err, result) => {
        if (err)
            return next(err)

        if (result > 0)
            return next(new Error("User Already exists"))

        next()
    })

});

UserSchema.post('save', function (error, doc, next) {

    if (error.name === 'MongoError' && error.code === 11000) {
        next(new Error("User already register with us"));
    } else if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const User = mongoose.model(DBTable.USER, UserSchema);

module.exports = { User, SchemaField };  