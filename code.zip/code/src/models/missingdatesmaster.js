const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/missingdatesmasterSchema'),
    DBTable = require('../schema/db_table');



const MissingdatesmasterSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.Category]: { type: String }
})


MissingdatesmasterSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Missingdatesmaster = mongoose.model(DBTable.MISSINGDATESMASTER, MissingdatesmasterSchema);

module.exports = { Missingdatesmaster, SchemaField };  