const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;
const SchemaField = require('../schema/fields/templatemastermappingsSchema'),
    DBTable = require('../schema/db_table');



const TemplateMasterMappingsSchema = new Schema({
    [SchemaField.userid]: { type: String, required: [true, "UserId required"] },
    [SchemaField.templateid]: { type: String, required: [true, "TemplateId required"] },
    [SchemaField.graphid]: { type: String, required: [true, "Template required"] },
    [SchemaField.updated]: {   type: Date , required: [true, "Updated time required"] }

})

TemplateMasterMappingsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const TemplatemasterMappings = mongoose.model(DBTable.TEMPLATEMASTERMAPPINGS, TemplateMasterMappingsSchema);

module.exports = { TemplatemasterMappings, SchemaField };  