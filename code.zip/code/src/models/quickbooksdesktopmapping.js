const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/quickbooksdesktopmappingSchema'),
    DBTable = require('../schema/db_table');



const QuickbooksdesktopmappingSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.RefNo]: { type: String },
    [SchemaField.DocType]: { type: String }

})


QuickbooksdesktopmappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Quickbooksdesktopmapping = mongoose.model(DBTable.QUICKBOOKSDESKTOPMAPPING, QuickbooksdesktopmappingSchema);

module.exports = { Quickbooksdesktopmapping, SchemaField };  