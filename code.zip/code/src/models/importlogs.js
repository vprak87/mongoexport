const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/importlogsSchema'),
    DBTable = require('../schema/db_table');



const ImportlogsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number },
    [SchemaField.ImportType]: { type: String },
    [SchemaField.PMS]: { type: String },
    [SchemaField.FileCategory]: { type: String },
    [SchemaField.ErrorType]: { type: String },
    [SchemaField.Message]: { type: String },
    [SchemaField.FileName]: { type: String },
    [SchemaField.UpdatedB]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.FileDateTime]: { type: Date }
})


ImportlogsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Importlogs = mongoose.model(DBTable.IMPORTLOGS, ImportlogsSchema);

module.exports = { Importlogs, SchemaField };  