const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/emailescalationnotificationlogsSchema'),
    DBTable = require('../schema/db_table');



const EmailescalationnotificationlogsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.ReportDate]: { type: Date, required: [true, "ReportDate required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.EmailSent]: { type: Boolean, required: [true, "Type required"] },
    [SchemaField.InsertedDateTime]: { type: Date, default: Date.now },
    [SchemaField.InsertedBy]: { type: String, required: [true, "InsertedBy required"] },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String, required: [true, "UpdatedBy required"] }
})


EmailescalationnotificationlogsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Emailescalationnotificationlogs = mongoose.model(DBTable.EMAILESCALATIONNOTIFICATIONLOGS, EmailescalationnotificationlogsSchema);

module.exports = { Emailescalationnotificationlogs, SchemaField };  