const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelavendraalertsubgroupSchema'),
    DBTable = require('../schema/db_table');



const HotelavendraalertsubgroupSchema = new Schema({
    [SchemaField.AvendraAlertSubGroupId]: { type: Number, required: [true, "AvendraAlertSubGroupId required"] },
    [SchemaField.AvendraAlertSubGroupName]: { type: String }

})


HotelavendraalertsubgroupSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelavendraalertsubgroup = mongoose.model(DBTable.HOTELAVENDRAALERTSUBGROUP, HotelavendraalertsubgroupSchema);

module.exports = { Hotelavendraalertsubgroup, SchemaField };  