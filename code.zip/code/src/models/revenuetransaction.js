const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/revenuetransactionSchema'),
    DBTable = require('../schema/db_table');



const RevenuetransactionSchema = new Schema({
    [SchemaField.Id]: { type: Number, required: [true, "ID required"] },
    [SchemaField.RevenueMasterId]: { type: Number, required: [true, "RevenueMasterId required"] },
    [SchemaField.Type]: { type: String, required: [true, "Type required"] },
    [SchemaField.Date]: { type: Date, required: [true, "Date required"] },
    [SchemaField.Source]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.Debit]: { type: Number },
    [SchemaField.Credit]: { type: Number },
    [SchemaField.Total]: { type: Number }

})


RevenuetransactionSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Revenuetransaction = mongoose.model(DBTable.REVENUETRANSACTION, RevenuetransactionSchema);

module.exports = { Revenuetransaction, SchemaField };  