const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/contactsupportlogsSchema'),
    DBTable = require('../schema/db_table');



const ContactsupportlogsSchema = new Schema({
    [SchemaField.LogId]: { type: Number, required: [true, "LogId required"] },
    [SchemaField.QuestionId]: { type: Number },
    [SchemaField.Subject]: { type: String },
    [SchemaField.Message]: { type: String },
    [SchemaField.Rating]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now }

})


ContactsupportlogsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Contactsupportlogs = mongoose.model(DBTable.CONTACTSUPPORTLOGS, ContactsupportlogsSchema);

module.exports = { Contactsupportlogs, SchemaField };  