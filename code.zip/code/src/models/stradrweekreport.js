const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/stradrweekreportSchema'),
    DBTable = require('../schema/db_table');



const StradrweekreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.AdrMyPropCurrentWeek]: { type: Number },
    [SchemaField.AdrCompCurrentWeek]: { type: Number },
    [SchemaField.AdrMyPropRun28]: { type: Number },
    [SchemaField.AdrCompRun28]: { type: Number },
    [SchemaField.AdrMyPropRunMTD]: { type: Number },
    [SchemaField.AdrCompRunMTD]: { type: Number },
    [SchemaField.AdrChgMyPropCurrentWeek]: { type: Number },
    [SchemaField.AdrChgCompCurrentWeek]: { type: Number },
    [SchemaField.AdrChgMyPropRun28]: { type: Number },
    [SchemaField.AdrChgCompRun28]: { type: Number },
    [SchemaField.AdrChgMyPropRunMTD]: { type: Number },
    [SchemaField.AdrChgCompRunMTD]: { type: Number },
    [SchemaField.AdrIndexCurrentWeek]: { type: Number },
    [SchemaField.AdrIndexRun28]: { type: Number },
    [SchemaField.AdrIndexRunMTD]: { type: Number },
    [SchemaField.AdrIndexChgCurrentWeek]: { type: Number },
    [SchemaField.AdrIndexChgRun28]: { type: Number },
    [SchemaField.AdrIndexChgRunMTD]: { type: Number },
    [SchemaField.AdrRankCurrentWeek]: { type: String },
    [SchemaField.AdrRankRun28]: { type: String },
    [SchemaField.AdrRankRunMTD]: { type: String },
    [SchemaField.AdrRankChgCurrentWeek]: { type: String },
    [SchemaField.AdrRankChgRun28]: { type: String },
    [SchemaField.AdrRankChgRunMTD]: { type: String },
    [SchemaField.AdrRankChgRunMTD]: { type: String },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.IsDelete]: { type: Boolean },

})


StradrweekreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Stradrweekreport = mongoose.model(DBTable.STRADRWEEKREPORT, StradrweekreportSchema);

module.exports = { Stradrweekreport, SchemaField };  