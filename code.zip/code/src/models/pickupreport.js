const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/pickupreportSchema'),
    DBTable = require('../schema/db_table');



const PickupreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date, required: [true, "Date required"] },
    [SchemaField.ReportedDateTime]: { type: Date, required: [true, "ReportedDateTime required"] },
    [SchemaField.Occupancy]: { type: Number },
    [SchemaField.NoOfRoomSold]: { type: Number },
    [SchemaField.NumberofAvailableRooms]: { type: Number },
    [SchemaField.TotalRevenue]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.TransientRoomsSold]: { type: Number },
    [SchemaField.TransientRoomRevenue]: { type: Number },
    [SchemaField.GroupRoomsSold]: { type: Number },
    [SchemaField.GroupRoomRevenue]: { type: Number },
    [SchemaField.GroupBlock]: { type: Number }

})


PickupreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Pickupreport = mongoose.model(DBTable.PICKUPREPORT, PickupreportSchema);

module.exports = { Pickupreport, SchemaField };  