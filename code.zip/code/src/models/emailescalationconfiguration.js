const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/emailescalationconfigurationSchema'),
    DBTable = require('../schema/db_table');



const EmailescalationconfigurationSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Type]: { type: String, required: [true, "Type required"] },
    [SchemaField.UpdatedBy]: { type: String, required: [true, "UpdatedBy required"] },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.ScheduleTime]: { type: Date },
    [SchemaField.TimeZone]: { type: String }
})


EmailescalationconfigurationSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Emailescalationconfiguration = mongoose.model(DBTable.EMAILESCALATIONCONFIGURATION, EmailescalationconfigurationSchema);

module.exports = { Emailescalationconfiguration, SchemaField };  