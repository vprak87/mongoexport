const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelaccountingtoolpropertymappingsSchema'),
    DBTable = require('../schema/db_table');



const HotelaccountingtoolpropertymappingsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelId]: { type: Number, required: [true, "HotelId required"] },
    [SchemaField.MasterProperty]: { type: String },
    [SchemaField.AccountingProperty]: { type: String },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },

})


HotelaccountingtoolpropertymappingsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelaccountingtoolpropertymappings = mongoose.model(DBTable.HOTELACCOUNTINGTOOLPROPERTYMAPPINGS, HotelaccountingtoolpropertymappingsSchema);

module.exports = { Hotelaccountingtoolpropertymappings, SchemaField };  