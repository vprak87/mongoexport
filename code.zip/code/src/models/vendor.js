const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/vendorSchema'),
    DBTable = require('../schema/db_table');



const VendorSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.Name]: { type: String, required: [true, "Name required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.OrganizationID]: { type: Number, required: [true, "OrganizationID required"] },
    [SchemaField.UpdateDateTime]: { type: Date, required: [true, "UpdateDateTime required"] },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.IsActive]: { type: Boolean }

})


VendorSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Vendor = mongoose.model(DBTable.VENDOR, VendorSchema);

module.exports = { Vendor, SchemaField };  