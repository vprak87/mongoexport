const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/createowntablemappingsgroupSchema'),
    DBTable = require('../schema/db_table');

const SchemaField1 = require('../schema/fields/createowntablemappingsgroupdetailSchema');

const CreateowntablemappingsgroupdetailSchema = new Schema({
    [SchemaField1.KPIKey]: { type: String, required: [true, "KPIKey required"] },
    [SchemaField1.DisplayOrder]: { type: Number, default: 0 },
    [SchemaField1.UpdatedBy]: { type: String },
    [SchemaField1.UpdateDateTime]: { type: Date, default: Date.now }
})

const CreateowntablemappingsgroupSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"], unique: true },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.GroupName]: { type: String, required: [true, "GroupName required"] },
    [SchemaField.GroupColor]: { type: String },
    [SchemaField.DisplayOrder]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.kpilist]: [{ type: CreateowntablemappingsgroupdetailSchema }],

})


CreateowntablemappingsgroupSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Createowntablemappingsgroup = mongoose.model(DBTable.CREATEOWNTABLEMAPPINGGROUP, CreateowntablemappingsgroupSchema);

module.exports = { Createowntablemappingsgroup, SchemaField };  