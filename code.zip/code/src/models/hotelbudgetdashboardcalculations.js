const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelbudgetdashboardcalculationsSchema'),
    DBTable = require('../schema/db_table');



const HotelbudgetdashboardcalculationsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date, required: [true, "Date required"] },
    [SchemaField.MTDBudget]: { type: Number },
    [SchemaField.MTDBudgetBOB]: { type: Number },
    [SchemaField.MTDBudgetBOBNextMonth]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date },
    [SchemaField.YTDBudget]: { type: Number },
    [SchemaField.MonthHotelBudget]: { type: Number },
    [SchemaField.MonthHotelForecast]: { type: Number },
    [SchemaField.TTMBudget]: { type: Number },
    [SchemaField.MTDBudgetRooms]: { type: Number },
    [SchemaField.YTDBudgetRooms]: { type: Number },
    [SchemaField.BudgetOccupancy]: { type: Number },
    [SchemaField.ForecastOccupancy]: { type: Number },
    [SchemaField.BudgetOccupancyMTD]: { type: Number },
    [SchemaField.BudgetOccupancyYTD]: { type: Number },
    [SchemaField.BudgetADR]: { type: Number },
    [SchemaField.ForecastADR]: { type: Number },
    [SchemaField.BudgetADRMTD]: { type: Number },
    [SchemaField.BudgetADRYTD]: { type: Number },
    [SchemaField.BudgetRoomRevenue]: { type: Number },
    [SchemaField.BudgetFANDBRevenue]: { type: Number },
    [SchemaField.BudgetOtherRevenue]: { type: Number },
    [SchemaField.BudgetTotalRevenue]: { type: Number },
    [SchemaField.BudgetRoomSold]: { type: Number },
    [SchemaField.BudgetNumberofAvailableRooms]: { type: Number },
    [SchemaField.ForecastRoomSold]: { type: Number },
    [SchemaField.ForecastRoomRevenue]: { type: Number },
    [SchemaField.ForecastFANDBRevenue]: { type: Number },
    [SchemaField.ForecastOtherRevenue]: { type: Number },
    [SchemaField.ForecastTotalRevenue]: { type: Number },
    [SchemaField.MTDFANDBRevenue]: { type: Number },
    [SchemaField.MTDOtherRevenue]: { type: Number },
    [SchemaField.MTDTotalRevenue]: { type: Number },
    [SchemaField.YTDFANDBRevenue]: { type: Number },
    [SchemaField.YTDOtherRevenue]: { type: Number },
    [SchemaField.YTDTotalRevenue]: { type: Number },
    [SchemaField.MTDForecastRoomRevenue]: { type: Number },
    [SchemaField.MTDForecastFANDBRevenue]: { type: Number },
    [SchemaField.MTDForecastOtherRevenue]: { type: Number },
    [SchemaField.MTDForecastTotalRevenue]: { type: Number },
    [SchemaField.YTDForecastRoomRevenue]: { type: Number },
    [SchemaField.YTDForecastFANDBRevenue]: { type: Number },
    [SchemaField.YTDForecastOtherRevenue]: { type: Number },
    [SchemaField.YTDForecastTotalRevenue]: { type: Number },
    [SchemaField.ForecastOccupancyMTD]: { type: Number },
    [SchemaField.ForecastOccupancyYTD]: { type: Number },
    [SchemaField.ForecastADRMTD]: { type: Number },
    [SchemaField.ForecastADRYTD]: { type: Number },
    [SchemaField.BudgetOccupancyTTM]: { type: Number },
    [SchemaField.BudgetADRTTM]: { type: Number },
    [SchemaField.TTMFANDBRevenue]: { type: Number },
    [SchemaField.TTMOtherRevenue]: { type: Number },
    [SchemaField.TTMTotalRevenue]: { type: Number },
    [SchemaField.TTMForecastRoomRevenue]: { type: Number },
    [SchemaField.TTMForecastFANDBRevenue]: { type: Number },
    [SchemaField.TTMForecastOtherRevenue]: { type: Number },
    [SchemaField.TTMForecastTotalRevenue]: { type: Number },
    [SchemaField.ForecastOccupancyTTM]: { type: Number },
    [SchemaField.ForecastADRTTM]: { type: Number },
    [SchemaField.TTMBudgetRooms]: { type: Number },
    [SchemaField.OtherMonthHotelBudget]: { type: Number },
    [SchemaField.OtherMonthHotelForecast]: { type: Number },
    [SchemaField.FNBMonthHotelBudget]: { type: Number },
    [SchemaField.FNBMonthHotelForecast]: { type: Number },
    [SchemaField.RoomRevenueMonthHotelBudget]: { type: Number },
    [SchemaField.RoomRevenueMonthHotelForecast]: { type: Number }

})


HotelbudgetdashboardcalculationsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelbudgetdashboardcalculations = mongoose.model(DBTable.HOTELBUDGETDASHBOARDCALCULATIONS, HotelbudgetdashboardcalculationsSchema);

module.exports = { Hotelbudgetdashboardcalculations, SchemaField };  