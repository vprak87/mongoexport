const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelavendraalertSchema'),
    DBTable = require('../schema/db_table');



const HotelavendraalertSchema = new Schema({
    [SchemaField.AlertID]: { type: Number, required: [true, "AlertID required"] },
    [SchemaField.ClientId]: { type: String },
    [SchemaField.CustomerId]: { type: String },
    [SchemaField.ContactId]: { type: String },
    [SchemaField.TopicCode]: { type: String },
    [SchemaField.SubtopicCode]: { type: String },
    [SchemaField.RankValue]: { type: Number },
    [SchemaField.Attribute1]: { type: String },
    [SchemaField.Attribute2]: { type: String },
    [SchemaField.Attribute3]: { type: String },
    [SchemaField.Attribute4]: { type: String },
    [SchemaField.Attribute5]: { type: String },
    [SchemaField.CreatedOn]: { type: Date, default: Date.now },
    [SchemaField.CreatedBy]: { type: Number },
    [SchemaField.UpdatedOn]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: Number },
    [SchemaField.HotelID]: { type: Number },
    [SchemaField.Alert_Number]: { type: Number }


})


HotelavendraalertSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelavendraalert = mongoose.model(DBTable.HOTELAVENDRAALERT, HotelavendraalertSchema);

module.exports = { Hotelavendraalert, SchemaField };  