const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/roleaccessSchema'),
    DBTable = require('../schema/db_table');



const RoleaccessSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]:{ type: Number},
    [SchemaField.RevinateHotelName]: { type: String },
    [SchemaField.RevinateHotelID]: { type: Number }

})


RoleaccessSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Roleaccess = mongoose.model(DBTable.ROLEACCESS, RoleaccessSchema);

module.exports = { Roleaccess, SchemaField };  