const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelguestledgerSchema'),
    DBTable = require('../schema/db_table');



const HotelGuestLedgerSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.Description]: { type: String },
    [SchemaField.BeginingBalance]: { type: Number },
    [SchemaField.Debit]: { type: Number },
    [SchemaField.Credit]: { type: Number },
    [SchemaField.EndingBalance]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now }

})


HotelGuestLedgerSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const HotelGuestLedger = mongoose.model(DBTable.HOTELGUESTLEDGER, HotelGuestLedgerSchema);

module.exports = { HotelGuestLedger, SchemaField };  