const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/glcodemasterSchema'),
    DBTable = require('../schema/db_table');



const GlcodemasterSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.GLCode]: { type: String },
    [SchemaField.GLDescripton]: { type: String },
    [SchemaField.DepartmentID]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
})


GlcodemasterSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Glcodemaster = mongoose.model(DBTable.GLCODEMASTER, GlcodemasterSchema);

module.exports = { Glcodemaster, SchemaField };  