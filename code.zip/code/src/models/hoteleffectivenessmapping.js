const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hoteleffectivenessmappingSchema'),
    DBTable = require('../schema/db_table');



const HotelEffectivenessMappingSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.OrganisationID]: { type: Number, required: [true, "OrganisationID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.LocationID]: { type: String, required: [true, "LocationID required"] }
})


HotelEffectivenessMappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const HotelEffectivenessMapping = mongoose.model(DBTable.HOTELEFFECTIVENESSMAPPING, HotelEffectivenessMappingSchema);

module.exports = { HotelEffectivenessMapping, SchemaField };  