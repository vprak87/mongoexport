const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/emailconfigurationscheduleSchema'),
    DBTable = require('../schema/db_table');



const EmailconfigurationscheduleSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.EmailConfigurationID]: { type: Number },
    [SchemaField.EmailConfigurationReportID]: { type: Number },
    [SchemaField.ScheduleTime]: { type: Date },
    [SchemaField.TimeZone]: { type: String },
    [SchemaField.EmailNotificationRequest]: { type: Boolean },
    [SchemaField.ScheduleType]: { type: String },
    [SchemaField.OtherRecipients]: { type: Boolean },
    [SchemaField.BlackAndWhiteColor]: { type: Boolean },
    [SchemaField.IsScheduleActive]: { type: Boolean },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedOn]: { type: Date }


})


EmailconfigurationscheduleSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Emailconfigurationschedule = mongoose.model(DBTable.EMAILCONFIGURATIONSCHEDULE, EmailconfigurationscheduleSchema);

module.exports = { Emailconfigurationschedule, SchemaField };  