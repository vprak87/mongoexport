const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelavendraalertdetailSchema'),
    DBTable = require('../schema/db_table');



const HotelavendraalertdetailSchema = new Schema({
    [SchemaField.AvendraAlertDetailid]: { type: Number, required: [true, "AvendraAlertDetailid required"] },
    [SchemaField.AvendraAlertInsightid]: { type: Number },
    [SchemaField.UnitNumber]: { type: Number },
    [SchemaField.RankValue]: { type: Number },
    [SchemaField.Attributes]: { type: String },
    [SchemaField.AvendraAlertGroupId]: { type: Number },
    [SchemaField.AvendraAlertSubGroupId]: { type: Number }


})


HotelavendraalertdetailSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelavendraalertdetail = mongoose.model(DBTable.HOTELAVENDRAALERTDETAIL, HotelavendraalertdetailSchema);

module.exports = { Hotelavendraalertdetail, SchemaField };  