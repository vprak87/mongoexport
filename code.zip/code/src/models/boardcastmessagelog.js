const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/boardcastmessagelogSchema'),
    DBTable = require('../schema/db_table');



const BoardcastmessagelogSchema = new Schema({
    [SchemaField.BoardcastMessageLogID]: { type: Number, required: [true, "BoardcastMessageLogID required"] },
    [SchemaField.BoardcastMessageID]: { type: Number, required: [true, "BoardcastMessageID required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String }

})


BoardcastmessagelogSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Boardcastmessagelog = mongoose.model(DBTable.BOARDCASTMESSAGELOG, BoardcastmessagelogSchema);

module.exports = { Boardcastmessagelog, SchemaField };  