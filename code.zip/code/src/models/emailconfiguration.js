const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/emailconfigurationSchema'),
    DBTable = require('../schema/db_table');



const EmailconfigurationSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.EmailRequest]: { type: Boolean, default: true },
    [SchemaField.ErrorRequest]: { type: Boolean, default: false },
    [SchemaField.RoomRevenueRequest]: { type: Boolean, default: false },
    [SchemaField.RoomRevenueTableRequest]: { type: Boolean, default: false },
    [SchemaField.IsDelete]: { type: Boolean, default: false },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.ScheduleTime]: { type: Date, default: Date.now },
    [SchemaField.TimeZone]: { type: String },
    [SchemaField.EmailNotificationRequest]: { type: Boolean },
    [SchemaField.PDFReportRequest]: { type: Boolean },
    [SchemaField.MissingDatesPDFReportRequest]: { type: Boolean },
    [SchemaField.BlackAndWhiteColor]: { type: Boolean },
    [SchemaField.ScheduleType]: { type: String },
    [SchemaField.OtherRecipients]: { type: Boolean },
    [SchemaField.ARAgingPDFReportRequest]: { type: Boolean },
    [SchemaField.IsEmailActive]: { type: Boolean }

})


EmailconfigurationSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Emailconfiguration = mongoose.model(DBTable.EMAILCONFIGURATION, EmailconfigurationSchema);

module.exports = { Emailconfiguration, SchemaField };  