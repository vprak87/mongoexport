const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelcommentSchema'),
    DBTable = require('../schema/db_table');



const HotelcommentSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.UserID]: { type: Number },
    [SchemaField.Tags]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.ParentID]: { type: Number },
    [SchemaField.UserTags]: { type: String }
})


HotelcommentSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelcomment = mongoose.model(DBTable.HOTELCOMMENT, HotelcommentSchema);

module.exports = { Hotelcomment, SchemaField };  