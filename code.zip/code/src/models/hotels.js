const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelsSchema'),
    DBTable = require('../schema/db_table');



const HotelsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"], unique: true },
    [SchemaField.HotelName]: { type: String, required: [true, "HotelName required"] },
    [SchemaField.NumberofAvailableRooms]: { type: Number },
    [SchemaField.OrganizationID]: { type: Number, required: [true, "OrganizationID required"] },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.IsActive]: { type: Boolean, default: true, required: [true, "IsActive required"] },
    [SchemaField.HotelCode]: { type: String },
    [SchemaField.AddressLine1]: { type: String },
    [SchemaField.AddressLine2]: { type: String },
    [SchemaField.City]: { type: String },
    [SchemaField.StateISO2]: { type: String },
    [SchemaField.CountryISO2]: { type: String },
    [SchemaField.Zip]: { type: String },
    [SchemaField.Attention]: { type: String },
    [SchemaField.PMS]: { type: String },
    [SchemaField.AccountingTool]: { type: String },
    [SchemaField.PMSPropertyID]: { type: String },
    [SchemaField.PMSPropertyName]: { type: String },
    [SchemaField.TimeZone]: { type: String },
    [SchemaField.IsMissingDateOtherRevenueEnabled]: { type: Boolean },
    [SchemaField.Property]: { type: String },
    [SchemaField.PropertyCode]: { type: String },
    [SchemaField.STRID]: { type: String },
    [SchemaField.Cmp_Id]: { type: Number },
    [SchemaField.JoinedDate]: { type: Date },
    [SchemaField.DefaultCurrency]: { type: String }

})


HotelsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotels = mongoose.model(DBTable.HOTELS, HotelsSchema);

module.exports = { Hotels, SchemaField };  