const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/pdfgroupcategoriesSchema'),
    DBTable = require('../schema/db_table');



const PdfgroupcategoriesSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.Name]: { type: String, required: [true, "Name required"] }
})


PdfgroupcategoriesSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Pdfgroupcategories = mongoose.model(DBTable.PDFGROUPCATEGORIES, PdfgroupcategoriesSchema);

module.exports = { Pdfgroupcategories, SchemaField };  