const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/revinateapidataorganisationSchema'),
    DBTable = require('../schema/db_table');



const RevinateapidataorganisationSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.RevinateUsername]: { type: String },
    [SchemaField.RevinateApiKey]: { type: String },
    [SchemaField.RevinateSecretKey]: { type: String },
    [SchemaField.OrganisationID]: { type: Number, required: [true, "OrganisationID required"] }

})


RevinateapidataorganisationSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Revinateapidataorganisation = mongoose.model(DBTable.REVINATEAPIDATAORGANISATION, RevinateapidataorganisationSchema);

module.exports = { Revinateapidataorganisation, SchemaField };  