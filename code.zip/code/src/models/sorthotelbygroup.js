const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/sorthotelbygroupSchema'),
    DBTable = require('../schema/db_table');



const SorthotelbygroupSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.GroupID]: { type: Number, required: [true, "GroupID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.DisplayOrder]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now }

})


SorthotelbygroupSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Sorthotelbygroup = mongoose.model(DBTable.SORTHOTELBYGROUP, SorthotelbygroupSchema);

module.exports = { Sorthotelbygroup, SchemaField };  