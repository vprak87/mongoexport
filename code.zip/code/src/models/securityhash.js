const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/securityhashSchema'),
    DBTable = require('../schema/db_table');



const SecurityhashSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.Hash]: { type: String, required: [true, "Hash required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.UpdatedDatetime]: { type: Date, default: Date.now }

})


SecurityhashSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Securityhash = mongoose.model(DBTable.SECURITYHASH, SecurityhashSchema);

module.exports = { Securityhash, SchemaField };  