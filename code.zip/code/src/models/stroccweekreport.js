const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/stroccweekreportSchema'),
    DBTable = require('../schema/db_table');



const StroccweekreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.OccMyPropCurrentWeek]: { type: Number },
    [SchemaField.OccCompCurrentWeek]: { type: Number },
    [SchemaField.OccMyPropRun28]: { type: Number },
    [SchemaField.OccCompRun28]: { type: Number },
    [SchemaField.OccMyPropRunMTD]: { type: Number },
    [SchemaField.OccCompRunMTD]: { type: Number },
    [SchemaField.OccChgMyPropCurrentWeek]: { type: Number },
    [SchemaField.OccChgCompCurrentWeek]: { type: Number },
    [SchemaField.OccChgMyPropRun28]: { type: Number },
    [SchemaField.OccChgCompRun28]: { type: Number },
    [SchemaField.OccChgMyPropRunMTD]: { type: Number },
    [SchemaField.OccChgCompRunMTD]: { type: Number },
    [SchemaField.OccIndexCurrentWeek]: { type: Number },
    [SchemaField.OccIndexRun28]: { type: Number },
    [SchemaField.OccIndexRunMTD]: { type: Number },
    [SchemaField.OccIndexChgCurrentWeek]: { type: Number },
    [SchemaField.OccIndexChgRun28]: { type: Number },
    [SchemaField.OccIndexChgRunMTD]: { type: Number },
    [SchemaField.OccRankCurrentWeek]: { type: String },
    [SchemaField.OccRankRun28]: { type: String },
    [SchemaField.OccRankRunMTD]: { type: String },
    [SchemaField.OccRankChgCurrentWeek]: { type: String },
    [SchemaField.OccRankChgRun28]: { type: String },
    [SchemaField.OccRankChgRunMTD]: { type: String },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.IsDelete]: { type: Boolean },

})


StroccweekreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Stroccweekreport = mongoose.model(DBTable.STROCCWEEKREPORT, StroccweekreportSchema);

module.exports = { Stroccweekreport, SchemaField };  