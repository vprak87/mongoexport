const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/HotelroomstatusdashboardcalculationsSchema'),
    DBTable = require('../schema/db_table');



const HotelroomstatusdashboardcalculationsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date, required: [true, "Date required"] },
    [SchemaField.OutOfOrderRooms]: { type: Number },
    [SchemaField.OutOfOrderRoomsMTD]: { type: Number },
    [SchemaField.OutOfOrderRoomsYTD]: { type: Number },
    [SchemaField.OutOfOrderRoomsTTM]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date },
    [SchemaField.CompRooms]: { type: Number },
    [SchemaField.CompRoomsMTD]: { type: Number },
    [SchemaField.CompRoomsYTD]: { type: Number },
    [SchemaField.CompRoomsTTM]: { type: Number },
    [SchemaField.OutOfOrderRooms_NoCalc]: { type: Number },
    [SchemaField.OutOfOrderRoomsMTD_NoCalc]: { type: Number },
    [SchemaField.OutOfOrderRoomsYTD_NoCalc]: { type: Number },
    [SchemaField.OutOfOrderRoomsTTM_NoCalc]: { type: Number },
    [SchemaField.GuestRoom]: { type: Number },
    [SchemaField.GuestRoomMTD]: { type: Number },
    [SchemaField.GuestRoomYTD]: { type: Number },
    [SchemaField.GuestRoomTTM]: { type: Number }

})


HotelroomstatusdashboardcalculationsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelroomstatusdashboardcalculations = mongoose.model(DBTable.HOTELROOMSTATUSDASHBOARDCALCULATIONS, HotelroomstatusdashboardcalculationsSchema);

module.exports = { Hotelroomstatusdashboardcalculations, SchemaField };  