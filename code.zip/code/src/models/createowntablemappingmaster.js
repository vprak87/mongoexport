const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/createowntablemappingmasterSchema'),
    DBTable = require('../schema/db_table');



const CreateowntablemappingmasterSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.TableName]: { type: String },
    [SchemaField.ColumName]: { type: String },
    [SchemaField.DisplayOrder]: { type: Number },
    [SchemaField.KPIKey]: { type: String },
    [SchemaField.ParentKey]: { type: Boolean },
    [SchemaField.HasSubKey]: { type: Boolean },
    [SchemaField.KPIFormula]: { type: String},
    [SchemaField.Unit]: { type: String },
    [SchemaField.OrganizationId]: { type: Number},   
    [SchemaField.IsCustom]: { type: Boolean }, 
})


CreateowntablemappingmasterSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Createowntablemappingmaster = mongoose.model(DBTable.CREATEOWNTABLEMAPPINGMASTER, CreateowntablemappingmasterSchema);

module.exports = { Createowntablemappingmaster, SchemaField };  