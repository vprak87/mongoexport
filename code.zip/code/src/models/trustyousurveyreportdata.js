const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/trustyousurveyreportdataSchema'),
    DBTable = require('../schema/db_table');



const TrustyousurveyreportdataSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.OrganisationID]: { type: Number, required: [true, "OrganisationID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.Category]: { type: String },
    [SchemaField.SubCategory]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.CategoryValue]: { type: Number },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.HotelID]: { type: Number },

})


TrustyousurveyreportdataSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Trustyousurveyreportdata = mongoose.model(DBTable.TRUSTYOUSURVEYREPORTDATA, TrustyousurveyreportdataSchema);

module.exports = { Trustyousurveyreportdata, SchemaField };  