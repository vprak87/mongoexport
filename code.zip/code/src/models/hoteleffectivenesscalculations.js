const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hoteleffectivenesscalculationsSchema'),
    DBTable = require('../schema/db_table');



const HoteleffectivenesscalculationsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.Department]: { type: String },
    [SchemaField.Wages]: { type: Number },
    [SchemaField.Hours]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date },
    [SchemaField.Category]: { type: String },
    [SchemaField.FromDate]: { type: Date },
    [SchemaField.ToDate]: { type: Date },
    [SchemaField.PlanWages]: { type: Number },
    [SchemaField.PlanHours]: { type: Number },
    [SchemaField.ReportName]: { type: String },
    [SchemaField.OTHours]: { type: Number },
    [SchemaField.OTWages]: { type: Number },
     [SchemaField.SalaryGratuity]: { type: Number },
    [SchemaField.PayrollTaxes]: { type: Number },
    [SchemaField.PTOWages]: { type: Number },
    [SchemaField.PTOHours]: { type: Number },
    [SchemaField.ForecastWages]: { type: Number },
    [SchemaField.ForecastHours]: { type: Number },
    [SchemaField.ContractWages]: { type: Number },
    [SchemaField.ContractHours]: { type: Number }
})


HoteleffectivenesscalculationsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hoteleffectivenesscalculations = mongoose.model(DBTable.HOTELEFFECTIVENESSCALCULATIONS, HoteleffectivenesscalculationsSchema);

module.exports = { Hoteleffectivenesscalculations, SchemaField };  