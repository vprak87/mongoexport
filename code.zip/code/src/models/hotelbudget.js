const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelbudgetSchema'),
    DBTable = require('../schema/db_table');



const HotelbudgetSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.HotelName]: { type: String },
    [SchemaField.DateFrom]: { type: Date },
    [SchemaField.DateTo]: { type: Date },
    [SchemaField.NumberofAvailableRooms]: { type: Number },
    [SchemaField.TotalNumberofBudgetedRoomsSold]: { type: Number },
    [SchemaField.RoomRevenueBudget]: { type: Number },
    [SchemaField.TotalNumberofForcastedRoomsSold]: { type: Number },
    [SchemaField.RoomRevenueForcast]: { type: Number },
    [SchemaField.FoodAndBeveragesBudget]: { type: Number },
    [SchemaField.FoodAndBeveragesForcast]: { type: Number },
    [SchemaField.OtherIncomeBudget]: { type: Number },
    [SchemaField.OtherIncomeForcast]: { type: Number },
    [SchemaField.TotalHotelBudget]: { type: Number },
    [SchemaField.TotalHotelForcast]: { type: Number },
    [SchemaField.StrMPIBgt]: { type: Number },
    [SchemaField.StrARIBgt]: { type: Number },
    [SchemaField.StrRGIBgt]: { type: Number },
    [SchemaField.StrOccRank]: { type: Number },
    [SchemaField.StrOccOutOfRank]: { type: Number },
    [SchemaField.StrAdrRank]: { type: Number },
    [SchemaField.StrAdrOutOfRank]: { type: Number },
    [SchemaField.StrRevParRank]: { type: Number },
    [SchemaField.StrRevParOutOfRank]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.IsDelete]: { type: Boolean },
})


HotelbudgetSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelbudget = mongoose.model(DBTable.HOTELBUDGET, HotelbudgetSchema);

module.exports = { Hotelbudget, SchemaField };  