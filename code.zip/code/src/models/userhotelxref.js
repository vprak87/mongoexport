const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/userhotelxrefSchema'),
    DBTable = require('../schema/db_table');



const UserhotelxrefSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserId required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.DisplayFor]: { type: Number }

})


UserhotelxrefSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Userhotelxref = mongoose.model(DBTable.USERHOTELXREF, UserhotelxrefSchema);

module.exports = { Userhotelxref, SchemaField };  