const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/operaoutoforderbyreasonreportSchema'),
    DBTable = require('../schema/db_table');



const OperaoutoforderbyreasonreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number },
    [SchemaField.DateFrom]: { type: Date },
    [SchemaField.DateTo]: { type: Date },  
    [SchemaField.ReportedDate]: { type: Date },
    [SchemaField.NoOfRooms]: { type: Number },
    [SchemaField.ReasonCode]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.RoomType]: { type: String },
    [SchemaField.Status]: { type: String },
    [SchemaField.ReturnStatus]: { type: String },
    [SchemaField.Remarks]: { type: String },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.IsDelete]: { type: Boolean }

})


OperaoutoforderbyreasonreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Operaoutoforderbyreasonreport = mongoose.model(DBTable.OPERAOUTOFORDERBYREASONREPORT, OperaoutoforderbyreasonreportSchema);

module.exports = { Operaoutoforderbyreasonreport, SchemaField };  