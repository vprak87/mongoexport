const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/countrySchema'),
    DBTable = require('../schema/db_table');



const CountrySchema = new Schema({
    [SchemaField.CountryId]: { type: Number, required: [true, "CountryId required"] },
    [SchemaField.Name]: { type: String, required: [true, "Name required"] },
    [SchemaField.CountryISO]: { type: String, required: [true, "CountryISO required"] }
})


CountrySchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Country = mongoose.model(DBTable.COUNTRY, CountrySchema);

module.exports = { Country, SchemaField };  