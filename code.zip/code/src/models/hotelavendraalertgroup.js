const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelavendraalertgroupSchema'),
    DBTable = require('../schema/db_table');



const HotelavendraalertgroupSchema = new Schema({
    [SchemaField.AvendraAlertGroupId]: { type: Number, required: [true, "AvendraAlertGroupId required"] },
    [SchemaField.AvendraAlertGroupName]: { type: String }


})


HotelavendraalertgroupSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelavendraalertgroup = mongoose.model(DBTable.HOTELAVENDRAALERTGROUP, HotelavendraalertgroupSchema);

module.exports = { Hotelavendraalertgroup, SchemaField };  