const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/foodnbeveragerevenueSchema'),
    DBTable = require('../schema/db_table');



const FoodnbeveragerevenueSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number },
    [SchemaField.HotelName]: { type: String },
    [SchemaField.Date]: { type: Date },
    [SchemaField.FoodBeverageRevenueSource1]: { type: Number },
    [SchemaField.NumberofCoversSoldSource1]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource2]: { type: Number },
    [SchemaField.NumberofCoversSoldSource2]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource3]: { type: Number },
    [SchemaField.NumberofCoversSoldSource3]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource4]: { type: Number },
    [SchemaField.NumberofCoversSoldSource4]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource5]: { type: Number },
    [SchemaField.NumberofCoversSoldSource5]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource6]: { type: Number },
    [SchemaField.NumberofCoversSoldSource6]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource7]: { type: Number },
    [SchemaField.NumberofCoversSoldSource7]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource8]: { type: Number },
    [SchemaField.NumberofCoversSoldSource8]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource9]: { type: Number },
    [SchemaField.NumberofCoversSoldSource9]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource10]: { type: Number },
    [SchemaField.NumberofCoversSoldSource10]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource11]: { type: Number },
    [SchemaField.NumberofCoversSoldSource11]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource12]: { type: Number },
    [SchemaField.NumberofCoversSoldSource12]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource13]: { type: Number },
    [SchemaField.NumberofCoversSoldSource13]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource14]: { type: Number },
    [SchemaField.NumberofCoversSoldSource14]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource15]: { type: Number },
    [SchemaField.NumberofCoversSoldSource15]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource16]: { type: Number },
    [SchemaField.NumberofCoversSoldSource16]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource17]: { type: Number },
    [SchemaField.NumberofCoversSoldSource17]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource18]: { type: Number },
    [SchemaField.NumberofCoversSoldSource18]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource19]: { type: Number },
    [SchemaField.NumberofCoversSoldSource19]: { type: Number },
    [SchemaField.FoodBeverageRevenueSource20]: { type: Number },
    [SchemaField.NumberofCoversSoldSource20]: { type: Number },
    [SchemaField.TotalFoodAndBaverage]: { type: Number },
    [SchemaField.TotalNumberOfCovers]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.IsDelete]: { type: Boolean }



})


FoodnbeveragerevenueSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Foodnbeveragerevenue = mongoose.model(DBTable.FOODNBEVERAGEREVENUE, FoodnbeveragerevenueSchema);

module.exports = { Foodnbeveragerevenue, SchemaField };  