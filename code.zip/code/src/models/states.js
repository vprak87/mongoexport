const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/statesSchema'),
    DBTable = require('../schema/db_table');



const StatesSchema = new Schema({
    [SchemaField.StateId]: { type: Number, required: [true, "StateId required"] },
    [SchemaField.Name]: { type: String, required: [true, "Name required"] },
    [SchemaField.StateISO]: { type: String, required: [true, "StateISO required"] },
    [SchemaField.CountryISO]: { type: String, required: [true, "CountryISO required"] }

})


StatesSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const States = mongoose.model(DBTable.STATES, StatesSchema);

module.exports = { States, SchemaField };  