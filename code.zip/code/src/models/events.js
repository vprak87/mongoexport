const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/eventsSchema'),
    DBTable = require('../schema/db_table');



const EventsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.EventName]: { type: String, required: [true, "EventName required"] },
    [SchemaField.Description]: { type: String },
    [SchemaField.StartDate]: { type: Date, default: Date.now },
    [SchemaField.TimeZone]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.IsActive]: { type: Boolean },
    [SchemaField.IsRepeat]: { type: Boolean },
    [SchemaField.Repeats]: { type: String },
    [SchemaField.RepeatEvery]: { type: Number },
    [SchemaField.RepeatEvRepeatOnery]: { type: String },
    [SchemaField.EndDate]: { type: Date, default: Date.now }

})


EventsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Events = mongoose.model(DBTable.EVENTS, EventsSchema);

module.exports = { Events, SchemaField };  