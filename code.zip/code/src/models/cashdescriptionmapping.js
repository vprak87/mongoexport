const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/cashdescriptionmappingSchema'),
    DBTable = require('../schema/db_table');



const CashdescriptionmappingSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.OrganizationID]: { type: Number, required: [true, "OrganizationID required"] },
    [SchemaField.Description]: { type: String },
    [SchemaField.Category]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.IsActive]: { type: Boolean }


})


CashdescriptionmappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Cashdescriptionmapping = mongoose.model(DBTable.CASHDESCRIPTIONMAPPING, CashdescriptionmappingSchema);

module.exports = { Cashdescriptionmapping, SchemaField };  