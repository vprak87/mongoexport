const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelgssSchema'),
    DBTable = require('../schema/db_table');



const HotelgssSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.Category]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.LastYear_Jan]: { type: Number },
    [SchemaField.LastYear_Feb]: { type: Number },
    [SchemaField.LastYear_Mar]: { type: Number },
    [SchemaField.LastYear_Apr]: { type: Number },
    [SchemaField.LastYear_May]: { type: Number },
    [SchemaField.LastYear_Jun]: { type: Number },
    [SchemaField.LastYear_Jul]: { type: Number },
    [SchemaField.LastYear_Aug]: { type: Number },
    [SchemaField.LastYear_Sep]: { type: Number },
    [SchemaField.LastYear_Oct]: { type: Number },
    [SchemaField.LastYear_Nov]: { type: Number },
    [SchemaField.LastYear_Dec]: { type: Number },
    [SchemaField.Current_Jan]: { type: Number },
    [SchemaField.Current_Feb]: { type: Number },
    [SchemaField.Current_Mar]: { type: Number },
    [SchemaField.Current_Apr]: { type: Number },
    [SchemaField.Current_May]: { type: Number },
    [SchemaField.Current_Jun]: { type: Number },
    [SchemaField.Current_Jul]: { type: Number },
    [SchemaField.Current_Aug]: { type: Number },
    [SchemaField.Current_Sep]: { type: Number },
    [SchemaField.Current_Oct]: { type: Number },
    [SchemaField.Current_Nov]: { type: Number },
    [SchemaField.Current_Dec]: { type: Number },
    [SchemaField.Total]: { type: Number },
    [SchemaField.Benchmark]: { type: Number },
    [SchemaField.Benchmark_Variance]: { type: Number },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.SetPriority]: { type: Number },
    [SchemaField.Current_YTD_Jan]: { type: Number },
    [SchemaField.Current_YTD_Feb]: { type: Number },
    [SchemaField.Current_YTD_Mar]: { type: Number },
    [SchemaField.Current_YTD_Apr]: { type: Number },
    [SchemaField.Current_YTD_May]: { type: Number },
    [SchemaField.Current_YTD_Jun]: { type: Number },
    [SchemaField.Current_YTD_Jul]: { type: Number },
    [SchemaField.Current_YTD_Aug]: { type: Number },
    [SchemaField.Current_YTD_Sep]: { type: Number },
    [SchemaField.Current_YTD_Oct]: { type: Number },
    [SchemaField.Current_YTD_Nov]: { type: Number },
    [SchemaField.Current_YTD_Dec]: { type: Number }

})


HotelgssSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelgss = mongoose.model(DBTable.HOTELGSS, HotelgssSchema);

module.exports = { Hotelgss, SchemaField };  