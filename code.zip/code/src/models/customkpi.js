const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/customkpischema'),
    DBTable = require('../schema/db_table');



const CustomKPISchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"], unique: true },
    [SchemaField.KPIName]: { type: String, required: [true, "KPIName required"] },
    [SchemaField.Unit]: { type: String, required: [true, "Unit required"] },
    [SchemaField.OrganizationId]: { type: Number, required: [true, "OrganizationId required"] },
    [SchemaField.KPIFormula]: { type: String, required: [true, "KPIFormula required"] },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.IsActive]: { type: Boolean, default: true, required: [true, "IsActive required"] }

})


CustomKPISchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const CustomKPI = mongoose.model(DBTable.CUSTOMKPI, CustomKPISchema);

module.exports = { CustomKPI, SchemaField };  