const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/rolebasedpermissionSchema'),
    DBTable = require('../schema/db_table');



const RolebasedpermissionSchema = new Schema({
    [SchemaField.ID]: { type: String, required: [true, "ID required"] },
    [SchemaField.PermissionId]: { type: String, required: [true, "ID required"] },
    [SchemaField.RoleId]: { type: Number, required: [true, "RoleId required"] }

})


RolebasedpermissionSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Rolebasedpermission = mongoose.model(DBTable.ROLEBASEDPERMISSION, RolebasedpermissionSchema);

module.exports = { Rolebasedpermission, SchemaField };  