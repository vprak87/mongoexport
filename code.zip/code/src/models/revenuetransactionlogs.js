const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/revenuetransactionlogsSchema'),
    DBTable = require('../schema/db_table');



const RevenuetransactionlogsSchema = new Schema({
    [SchemaField.LogId]: { type: Number, required: [true, "LogId required"] },
    [SchemaField.RevenueMasterId]: { type: Number, required: [true, "RevenueMasterId required"] },
    [SchemaField.Type]: { type: String, required: [true, "Type required"] },
    [SchemaField.Date]: { type: Date, required: [true, "Date required"] },
    [SchemaField.Source]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.Debit]: { type: Number },
    [SchemaField.Credit]: { type: Number },
    [SchemaField.Total]: { type: Number }

})


RevenuetransactionlogsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Revenuetransactionlogs = mongoose.model(DBTable.REVENUETRANSACTIONLOGS, RevenuetransactionlogsSchema);

module.exports = { Revenuetransactionlogs, SchemaField };  