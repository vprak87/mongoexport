const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelservicesSchema'),
    DBTable = require('../schema/db_table');



const HotelservicesSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Month]: { type: Number },
    [SchemaField.Year]: { type: Number },
    [SchemaField.BrandAverage]: { type: Number },
    [SchemaField.HotelGSSRate]: { type: Number },
    [SchemaField.CHIHotelRanking]: { type: Number },
    [SchemaField.CHIHotelRankingOutof]: { type: Number },
    [SchemaField.Score]: { type: Number },
    [SchemaField.TripAdvisorExcellent]: { type: Number },
    [SchemaField.TripAdvisorVeryGood]: { type: Number },
    [SchemaField.TripAdvisorAverage]: { type: Number },
    [SchemaField.TripAdvisorPoor]: { type: Number },
    [SchemaField.TripAdvisorTerrible]: { type: Number },
    [SchemaField.Date]: { type: Date },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String }

})


HotelservicesSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelservices = mongoose.model(DBTable.HOTELSERVICES, HotelservicesSchema);

module.exports = { Hotelservices, SchemaField };  