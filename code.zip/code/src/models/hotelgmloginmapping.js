const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelgmloginmappingSchema'),
    DBTable = require('../schema/db_table');



const HotelgmloginmappingSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.LastGMLoginDateTime]: { type: Date },
    [SchemaField.UpdatedBy]: { type: String },

})


HotelgmloginmappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelgmloginmapping = mongoose.model(DBTable.HOTELGMLOGINMAPPING, HotelgmloginmappingSchema);

module.exports = { Hotelgmloginmapping, SchemaField };  