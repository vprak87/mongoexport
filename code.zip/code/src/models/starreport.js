const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/starreportSchema'),
    DBTable = require('../schema/db_table');



const StarreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.OccMyProperty]: { type: Number },
    [SchemaField.OccCompSet]: { type: Number },
    [SchemaField.OccIndex]: { type: Number },
    [SchemaField.OccChgMyProperty]: { type: Number },
    [SchemaField.OccChgCompSet]: { type: Number },
    [SchemaField.OccChgIndex]: { type: Number },
    [SchemaField.OccRank]: { type: String },
    [SchemaField.OccChgRank]: { type: Number },
    [SchemaField.AdrMyProperty]: { type: Number },
    [SchemaField.AdrCompSet]: { type: Number },
    [SchemaField.AdrIndex]: { type: Number },
    [SchemaField.AdrChgMyProperty]: { type: Number },
    [SchemaField.AdrChgCompSet]: { type: Number },
    [SchemaField.AdrChgIndex]: { type: Number },
    [SchemaField.AdrRank]: { type: String },
    [SchemaField.AdrchgRank]: { type: Number },
    [SchemaField.RevParMyProperty]: { type: Number },
    [SchemaField.RevParCompSet]: { type: Number },
    [SchemaField.RevParIndex]: { type: Number },
    [SchemaField.RevParChgMyProperty]: { type: Number },
    [SchemaField.RevParChgCompSet]: { type: Number },
    [SchemaField.RevParChgIndex]: { type: Number },
    [SchemaField.RevParRank]: { type: String },
    [SchemaField.RevParChgRank]: { type: Number },
    [SchemaField.OccId]: { type: Number },
    [SchemaField.AdrId]: { type: Number },
    [SchemaField.RevParId]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.IsDelete]: { type: Boolean },

})


StarreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Starreport = mongoose.model(DBTable.STARREPORT, StarreportSchema);

module.exports = { Starreport, SchemaField };  