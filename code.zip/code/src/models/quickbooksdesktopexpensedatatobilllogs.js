const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/quickbooksdesktopexpensedatatobilllogsSchema'),
    DBTable = require('../schema/db_table');



const QuickbooksdesktopexpensedatatobillLogsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.TransID]: { type: String },
    [SchemaField.SyncStatus]: { type: Number },
    [SchemaField.SyncResponse]: { type: String },
    [SchemaField.SyncOn]: { type: Date },
    [SchemaField.HotelId]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.ExpenseNumber]: { type: String }

})


QuickbooksdesktopexpensedatatobillLogsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const QuickbooksdesktopexpensedatatobillLogs = mongoose.model(DBTable.QUICKBOOKSDESKTOPEXPENSEDATATOBILLLOGS, QuickbooksdesktopexpensedatatobillLogsSchema);

module.exports = { QuickbooksdesktopexpensedatatobillLogs, SchemaField };  