const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/pnlcustomizeviewSchema'),
    DBTable = require('../schema/db_table');

const SchemaField1 = require('../schema/fields/pnlcustomizeitemSchema');
const SchemaField2 = require('../schema/fields/pnlcustomizegroupSchema');


const PnlitemSchema = new Schema({
  [SchemaField1.Raw_Name]: { type: String},
  [SchemaField1.Order_ID]: { type: Number },
  [SchemaField1.Enable]: { type: Boolean },
  [SchemaField1.Highlighted]: { type: Boolean },
  [SchemaField1.Merged]: { type: Boolean }
})

const PnlgroupSchema = new Schema({
  [SchemaField2.Group_Name]: { type: String},
  [SchemaField2.Group_Title]: { type: String},
  [SchemaField2.Order_ID]: { type: Number},
  [SchemaField2.Items]: [{ type: PnlitemSchema }],
})

const PnlcustomizeRawSchema = new Schema({
  [SchemaField.User_ID]: { type: Number, required: [true, "User ID required"] },
  [SchemaField.Hotel_ID]: { type: Number, required: [true, "Hotel ID required"] },
  [SchemaField.Created_at]: { type: Date, default: Date.now },
  [SchemaField.Pnl_view]: { type: String },
  [SchemaField.Groups] : [{type: PnlgroupSchema}]
})


PnlcustomizeRawSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});

const PnlcustomRaw = mongoose.model(DBTable.PNLCUSTOMIZERAW, PnlcustomizeRawSchema);

module.exports = { PnlcustomRaw, SchemaField };  