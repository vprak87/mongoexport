const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/revenuemasterlogsSchema'),
    DBTable = require('../schema/db_table');



const RevenuemasterlogsSchema = new Schema({
    [SchemaField.LogId]: { type: Number, required: [true, "LogId required"] },
    [SchemaField.Id]: { type: Number, required: [true, "ID required"] },
    [SchemaField.ImportDate]: { type: Date, required: [true, "ImportDate required"] },
    [SchemaField.ImportBy]: { type: Number, required: [true, "ImportBy required"] },
    [SchemaField.SyncOn]: { type: Date },
    [SchemaField.SyncStatus]: { type: Number },
    [SchemaField.SyncResponse]: { type: String },
    [SchemaField.HotelId]: { type: Number, required: [true, "HotelId required"] }

})


RevenuemasterlogsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Revenuemasterlogs = mongoose.model(DBTable.REVENUEMASTERLOGS, RevenuemasterlogsSchema);

module.exports = { Revenuemasterlogs, SchemaField };  