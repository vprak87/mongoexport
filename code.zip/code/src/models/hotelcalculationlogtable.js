const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelcalculationlogtableSchema'),
    DBTable = require('../schema/db_table');



const HotelcalculationlogtableSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date },
    [SchemaField.CreatedAt]: { type: Date },
    [SchemaField.CreatedBy]: { type: String },
    [SchemaField.UpdatedAt]: { type: Date },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.Status]: { type: Number },
    [SchemaField.Remarks]: { type: String },
    [SchemaField.LastCalculatedDate]: { type: Date }
})


HotelcalculationlogtableSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelcalculationlogtable = mongoose.model(DBTable.HOTELCALCULATIONLOGTABLE, HotelcalculationlogtableSchema);

module.exports = { Hotelcalculationlogtable, SchemaField };  