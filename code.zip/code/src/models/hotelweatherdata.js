const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelweatherdataSchema'),
    DBTable = require('../schema/db_table');



const HotelweatherdataSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.City]: { type: String, required: [true, "City required"] },
    [SchemaField.StateISO]: { type: String, required: [true, "StateISO required"] },
    [SchemaField.CountryCode]: { type: String, required: [true, "CountryCode required"] },
    [SchemaField.Period]: { type: Number, required: [true, "Period required"] },
    [SchemaField.Date]: { type: Date, required: [true, "Date required"] },
    [SchemaField.TemperatureCMin]: { type: String },
    [SchemaField.TemperatureFMin]: { type: String },
    [SchemaField.TemperatureCMax]: { type: String },
    [SchemaField.TemperatureFMax]: { type: String },
    [SchemaField.WindDirection]: { type: String },
    [SchemaField.WindSpeedKMH]: { type: String },
    [SchemaField.WindSpeedMPH]: { type: String },
    [SchemaField.POPPercentDay]: { type: String },
    [SchemaField.FxIconDay]: { type: String },
    [SchemaField.FxConditionDay]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String }

})


HotelweatherdataSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelweatherdata = mongoose.model(DBTable.HOTELWEATHERDATA, HotelweatherdataSchema);

module.exports = { Hotelweatherdata, SchemaField };  