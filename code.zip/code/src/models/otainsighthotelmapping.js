const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/otainsighthotelmappingSchema'),
    DBTable = require('../schema/db_table');



const OtainsighthotelmappingSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number },
    [SchemaField.OTAInsightHotelName]: { type: String },
    [SchemaField.OTAInsightHotelID]: { type: Number },
    [SchemaField.OTASubscriptionID]: { type: Number }
})


OtainsighthotelmappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Otainsighthotelmapping = mongoose.model(DBTable.OTAINSIGHTHOTELMAPPING, OtainsighthotelmappingSchema);

module.exports = { Otainsighthotelmapping, SchemaField };  