const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelqcreportSchema'),
    DBTable = require('../schema/db_table');



const HotelqcreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Category]: { type: String },
    [SchemaField.Date]: { type: Date },
    [SchemaField.NoOfRoomSold]: { type: Boolean },
    [SchemaField.NoOfRoomSoldMTD]: { type: Boolean },
    [SchemaField.NoOfRoomSoldYTD]: { type: Boolean },
    [SchemaField.TotalRevenue]: { type: Boolean },
    [SchemaField.TotalRevenueMTD]: { type: Boolean },
    [SchemaField.TotalRevenueYTD]: { type: Boolean },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.NoOfRoomSoldFileValue]: { type: Number },
    [SchemaField.NoOfRoomSoldMTDFileValue]: { type: Number },
    [SchemaField.NoOfRoomSoldYTDFileValue]: { type: Number },
    [SchemaField.TotalRevenueFileValue]: { type: Number },
    [SchemaField.TotalRevenueMTDFileValue]: { type: Number },
    [SchemaField.TotalRevenueYTDFileValue]: { type: Number },
    [SchemaField.ReportName]: { type: String }

})


HotelqcreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelqcreport = mongoose.model(DBTable.HOTELQCREPORT, HotelqcreportSchema);

module.exports = { Hotelqcreport, SchemaField };  