const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/mdoglcodemasterSchema'),
    DBTable = require('../schema/db_table');



const MDOGLCodeMasterSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.GLCode]: { type: String, required: [true, "GLCode required"] },
    [SchemaField.Description]: { type: String, required: [true, "Description required"] },
    [SchemaField.DisplayDescription]: { type: String },
    [SchemaField.ParentId]: { type: Number },
    [SchemaField.IsActive]:{ type: Boolean, default: true, required: [true, "IsActive required"] },
})


MDOGLCodeMasterSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const MDOGLCodeMaster = mongoose.model(DBTable.MDOGLCODEMASTER, MDOGLCodeMasterSchema);

module.exports = { MDOGLCodeMaster, SchemaField };  