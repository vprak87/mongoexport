const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/emailnotificationSchema'),
    DBTable = require('../schema/db_table');



const EmailnotificationSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.ReportDate]: { type: Date, required: [true, "ReportDate required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.SendEmailToUserID]: { type: Number, required: [true, "SendEmailToUserID required"] },
    [SchemaField.NoDataFound]: { type: Boolean },
    [SchemaField.EmailSent]: { type: Boolean },
    [SchemaField.InsertedDateTime]: { type: Date, default: Date.now },
    [SchemaField.InsertedBy]: { type: String, required: [true, "InsertedBy required"] },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now },
    [SchemaField.UpdatedBy]: { type: String, required: [true, "UpdatedBy required"] }
})


EmailnotificationSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Emailnotification = mongoose.model(DBTable.EMAILNOTIFICATION, EmailnotificationSchema);

module.exports = { Emailnotification, SchemaField };  