const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelavendraalertinsightSchema'),
    DBTable = require('../schema/db_table');



const HotelavendraalertinsightSchema = new Schema({
    [SchemaField.AvendraAlertInsightid]: { type: Number, required: [true, "AvendraAlertInsightid required"] },
    [SchemaField.AlertID]: { type: Number },
    [SchemaField.AvendraAlertGroupId]: { type: Number },
    [SchemaField.AvendraAlertSubGroupId]: { type: Number },
    [SchemaField.UnitNumber]: { type: Number },
    [SchemaField.AvendraAlertInsightTypeId]: { type: Number },
    [SchemaField.InsightDescription]: { type: String },
    [SchemaField.InsightNumber]: { type: Number },
    [SchemaField.AvendraAlertInsightLevelId]: { type: Number }


})


HotelavendraalertinsightSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelavendraalertinsight = mongoose.model(DBTable.HOTELAVENDRAALERTINSIGHT, HotelavendraalertinsightSchema);

module.exports = { Hotelavendraalertinsight, SchemaField };  