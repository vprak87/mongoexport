const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/emailconfigurationreportSchema'),
    DBTable = require('../schema/db_table');



const EmailconfigurationreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.EmailConfigurationReportName]: { type: String }

})


EmailconfigurationreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Emailconfigurationreport = mongoose.model(DBTable.EMAILCONFIGURATIONREPORT, EmailconfigurationreportSchema);

module.exports = { Emailconfigurationreport, SchemaField };  