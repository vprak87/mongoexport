const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/createpnltablemappingSchema'),
    DBTable = require('../schema/db_table');



const CreatePnlTableMappingSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"], unique: true  },
    [SchemaField.ColumName]: { type: String, required: [true, "ColumName required"] },
    [SchemaField.ColumPeriod]: { type: String, required: [true, "ColumPeriod required"] },
    [SchemaField.DisplayOrder]: { type: Number, required: [true, "DisplayOrder required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.PNLType]: { type: String, required: [true, "PNLType required"] },
})


CreatePnlTableMappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const CreatePnlTableMapping = mongoose.model(DBTable.CREATEPNLTABLEMAPPINGS, CreatePnlTableMappingSchema);

module.exports = { CreatePnlTableMapping, SchemaField };  