const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/stradrmonthreportSchema'),
    DBTable = require('../schema/db_table');



const StradrmonthreportSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.RevParMyPropCurrentWeek]: { type: Number },
    [SchemaField.RevParCompCurrentWeek]: { type: Number },
    [SchemaField.RevParMyPropRun28]: { type: Number },
    [SchemaField.RevParCompRun28]: { type: Number },
    [SchemaField.RevParMyPropRunMTD]: { type: Number },
    [SchemaField.RevParCompRunMTD]: { type: Number },
    [SchemaField.RevParChgMyPropCurrentWeek]: { type: Number },
    [SchemaField.RevParChgCompCurrentWeek]: { type: Number },
    [SchemaField.RevParChgMyPropRun28]: { type: Number },
    [SchemaField.RevParChgCompRun28]: { type: Number },
    [SchemaField.RevParChgMyPropRunMTD]: { type: Number },
    [SchemaField.RevParChgCompRunMTD]: { type: Number },
    [SchemaField.RevParIndexCurrentWeek]: { type: Number },
    [SchemaField.RevParIndexRun28]: { type: Number },
    [SchemaField.RevParIndexRunMTD]: { type: Number },
    [SchemaField.RevParIndexChgCurrentWeek]: { type: Number },
    [SchemaField.RevParIndexChgRun28]: { type: Number },
    [SchemaField.RevParIndexChgRunMTD]: { type: Number },
    [SchemaField.RevParRankCurrentWeek]: { type: Number },
    [SchemaField.RevParRankRun28]: { type: Number },
    [SchemaField.RevParRankRunMTD]: { type: Number },
    [SchemaField.RevParRankChgCurrentWeek]: { type: Number },
    [SchemaField.RevParRankChgRun28]: { type: Number },
    [SchemaField.RevParRankChgRunMTD]: { type: Number },
    [SchemaField.RevParRankChgRunMTD]: { type: Number },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdateDateTime]: { type: Date, default: Date.now },
    [SchemaField.IsDelete]: { type: Boolean },

})


StradrmonthreportSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Stradrmonthreport = mongoose.model(DBTable.STRADRMONTHREPORT, StradrmonthreportSchema);

module.exports = { Stradrmonthreport, SchemaField };  