const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/emailpdfreportcolumnmasterSchema'),
    DBTable = require('../schema/db_table');



const EmailpdfreportcolumnmasterSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.Name]: { type: String },
    [SchemaField.DisplayName]: { type: String },
    [SchemaField.Type]: { type: String },
    [SchemaField.DisplayOrder]: { type: Number }
})


EmailpdfreportcolumnmasterSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Emailpdfreportcolumnmaster = mongoose.model(DBTable.EMAILPDFREPORTCOLUMNMASTER, EmailpdfreportcolumnmasterSchema);

module.exports = { Emailpdfreportcolumnmaster, SchemaField };  