const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/hotelexpensedashboardcalculationsSchema'),
    DBTable = require('../schema/db_table');



const HotelexpensedashboardcalculationsSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.HotelID]: { type: Number, required: [true, "HotelID required"] },
    [SchemaField.Date]: { type: Date, required: [true, "Date required"] },
    [SchemaField.Category]: { type: String },
    [SchemaField.Description]: { type: String },
    [SchemaField.Expense]: { type: Number },
    [SchemaField.MTDExpense]: { type: Number },
    [SchemaField.YTDExpense]: { type: Number },
    [SchemaField.MTDBudget]: { type: Number },
    [SchemaField.YTDBudget]: { type: Number },
    [SchemaField.MTDForecast]: { type: Number },
    [SchemaField.YTDforecast]: { type: Number },
    [SchemaField.DisplayDescription]: { type: String },
    [SchemaField.GLCode]: { type: String },
    [SchemaField.UpdatedBy]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date }

})


HotelexpensedashboardcalculationsSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Hotelexpensedashboardcalculations = mongoose.model(DBTable.HOTELEXPENSEDASHBOARDCALCULATION, HotelexpensedashboardcalculationsSchema);

module.exports = { Hotelexpensedashboardcalculations, SchemaField };  