const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/citySchema'),
    DBTable = require('../schema/db_table');



const CitySchema = new Schema({
    [SchemaField.CityId]: { type: Number, required: [true, "CityId required"] },
    [SchemaField.Name]: { type: String, required: [true, "Name required"] },
    [SchemaField.StateISO]: { type: String, required: [true, "StateISO required"] },
    [SchemaField.ZipCode]: { type: String },
})


CitySchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const City = mongoose.model(DBTable.CITY, CitySchema);

module.exports = { City, SchemaField };  