const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/failedemaillistSchema'),
    DBTable = require('../schema/db_table');



const FailedemaillistSchema = new Schema({
    [SchemaField.ID]: { type: Number, required: [true, "ID required"] },
    [SchemaField.EmailAddress]: { type: String },
    [SchemaField.UserId]: { type: Number },
    [SchemaField.ReportedDate]: { type: Date },
    [SchemaField.Status]: { type: String },
    [SchemaField.Remarks]: { type: String },
    [SchemaField.UpdatedDateTime]: { type: Date, default: Date.now }


})


FailedemaillistSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Failedemaillist = mongoose.model(DBTable.FAILEDEMAILLIST, FailedemaillistSchema);

module.exports = { Failedemaillist, SchemaField };  