const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/mdoglcodehmgmappingSchema'),
    DBTable = require('../schema/db_table');

const MDOGLCodeHMGMappingSchema = new Schema({ 
    [SchemaField.HMGGLCode]: { type: String, required: [true, "HMGGLCode required"] },
    [SchemaField.MDOGLCode]: { type: String, required: [true, "MDOGLCode required"] },
    [SchemaField.Description]: { type: String, required: [true, "Description required"] },
    [SchemaField.Status]:{ type: Boolean, default: true, required: [true, "Status required"] },
    [SchemaField.OrganizationID]: { type: Number, required: [true, "OrganizationID required"] },
})


MDOGLCodeHMGMappingSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const MDOGLCodeHMGMapping = mongoose.model(DBTable.MDOGLCODEHMGMAPPING, MDOGLCodeHMGMappingSchema);

module.exports = { MDOGLCodeHMGMapping, SchemaField };  