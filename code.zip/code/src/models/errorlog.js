const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const SchemaField = require('../schema/fields/errorlogSchema'),
    DBTable = require('../schema/db_table');



const ErrorlogSchema = new Schema({
    [SchemaField.ErrorId]: { type: String, required: [true, "ErrorId required"] },
    [SchemaField.UserID]: { type: Number, required: [true, "UserID required"] },
    [SchemaField.TimeUtc]: { type: Date, default: Date.now },
    [SchemaField.ErrorMessage]: { type: String },
    [SchemaField.Exception]: { type: String }

})


ErrorlogSchema.post('save', function (error, doc, next) {

    if (error.name === 'ValidationError' && error.errors) {
        let keys = Object.keys(error.errors);
        next(error.errors[keys[0]]);
    } else {
        next(error);
    }
});


const Errorlog = mongoose.model(DBTable.ERRORLOG, ErrorlogSchema);

module.exports = { Errorlog, SchemaField };  