const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const UserHelper = require('../../helpers/user_helper');
const HotelsHelper = require('../../helpers/hotels_helper');
const Checkit = require('checkit');
const ExclamationHelper = require('../../helpers/exclamation_helper');
var log = require('log4js').getLogger("missingdates");

let GetMissingDatesProperty = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelId: 'required',
        currentDate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);

    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    ExclamationHelper.GetMissingDatesProperty(data.userid, data.hotelId, data.currentDate, data.period, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}

let GetMissingDates = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
        hotelIds: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);

    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        //get myp hotelid from cmp_id
        /*HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
            if (err) {
                return next(err);
            }
            if (!hoteldata) {
                return next(HttpMsg.HotelNotFound);
            }
            else {*/

        ExclamationHelper.getMissingDates(data.hotelIds, data.currentdate, userconfigdata, data.period, req.body.startDate, (err, result) => {
            if (err) {
                return next(err);
            }

            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        });
        //}
        //});

    });

}


let GetMissingDatesv2 = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
        hotelIds: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);

    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        //get myp hotelid from cmp_id
        /*HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
            if (err) {
                return next(err);
            }
            if (!hoteldata) {
                return next(HttpMsg.HotelNotFound);
            }
            else {*/

        ExclamationHelper.getMissingDates_V2(data.hotelIds, data.currentdate, userconfigdata, data.period, req.body.startDate, (err, result) => {
            if (err) {
                return next(err);
            }

            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        });
        //}
        //});

    });

}
module.exports = {
    GetMissingDates: GetMissingDates,
    GetMissingDatesv2: GetMissingDatesv2,
    GetMissingDatesProperty: GetMissingDatesProperty
}