const express = require('express');
const router = express.Router(),
    Controller = require('./controller/hotelmissingdateswithlinks');



router.get("/missingdates", Controller.GetMissingDates);
router.get("/missingdatesv2", Controller.GetMissingDatesv2);
router.get("/propertymissingdates", Controller.GetMissingDatesProperty);

module.exports = router