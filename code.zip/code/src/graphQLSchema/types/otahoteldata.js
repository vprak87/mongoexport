const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const otahoteldata = new GraphQLObjectType({
    name: 'otahoteldata',
    description: 'ota hotel item data',
    fields: {
        date: { type: GraphQLString },
        demand:{ type: GraphQLString },
        hotelrate: { type: GraphQLString },
        avgcompsetrates:{ type: GraphQLString }        
    }
});

module.exports = otahoteldata;
