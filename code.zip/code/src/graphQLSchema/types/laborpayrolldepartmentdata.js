const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLFloat} = graphql

const laborpayrolldepartmentdataType = new GraphQLObjectType({
    name: 'LaborPayrollDepartmentData',
    description: 'Labor Data - Payroll vs Department',
    fields: {
        label: { type: GraphQLString },
        categoryvalue: { type: GraphQLString },
        value: { type: GraphQLFloat },
        color: { type: GraphQLString },
    }
});

module.exports = laborpayrolldepartmentdataType;