const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt } = graphql

const pnltablecolumndataitem = new GraphQLObjectType({
    name: 'pnltablecolumndataitem',
    description: 'Add KPI Column data Item',
    fields: { 
        id: { type: GraphQLInt },
        displayorder: { type: GraphQLInt },
        columname: { type: GraphQLString },
        columperiod: { type: GraphQLString },
        userid: { type: GraphQLInt },
        pnltype:{ type: GraphQLString }

    }
});

module.exports = pnltablecolumndataitem;
