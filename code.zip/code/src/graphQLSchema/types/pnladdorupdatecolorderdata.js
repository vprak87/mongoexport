const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat, GraphQLInputObjectType } = graphql;

const pnlcolItemDataModelListType = new GraphQLInputObjectType({
  name: 'PnLcolItemDataModelList',
  description: 'PnL col Item Model List Data',
  fields: {
    Id: { type: GraphQLInt },
    Type: { type: GraphQLString },
    Title: { type: GraphQLString },
    DataKey: { type: GraphQLString },
  }
});

const pnlColorderDataModelListType = new GraphQLInputObjectType({
  name: 'PnLColorderDataModelList',
  description: 'PnL col order Model List Data',
  fields: {
    Id: { type: GraphQLInt },
    Type: { type: GraphQLString },
    Title: { type: GraphQLString },
    Color: { type: GraphQLString },
    DataKey: { type: GraphQLString },
    Cols: { type: new GraphQLList(pnlcolItemDataModelListType) },
  }
});

module.exports = pnlColorderDataModelListType;