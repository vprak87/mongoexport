const graphql = require('graphql');
const { GraphQLObjectType, GraphQLList,GraphQLString } = graphql


const hotelmissingdatepropertydata = new GraphQLObjectType({
    name: 'propertymissingdates',
    description: 'Missing Dates on property page',
    fields: {
        RoomRevenue:{ type: GraphQLString },
        OtherFNBRevenue:{ type: GraphQLString }
        
    }
});
module.exports = hotelmissingdatepropertydata;


