const graphql = require('graphql');
const { GraphQLObjectType, GraphQLInt } = graphql

const removeresponseitemdata = new GraphQLObjectType({
    name: 'removeresponseitemdata',
    description: 'Remove Response Item',
    fields: {
        ok: { type: GraphQLInt }
    }
});

module.exports = removeresponseitemdata;
