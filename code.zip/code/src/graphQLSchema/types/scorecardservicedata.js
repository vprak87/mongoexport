const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList } = graphql

const servicegssitemdataType = new GraphQLObjectType({
    name: 'servicegssitemdata',
    description: 'Scorecard Service GSS Item Data',
    fields: {
        title: { type: GraphQLString },
        monthname: { type: GraphQLString },
        value: { type: GraphQLString },
    }
});

const servicegssdataType = new GraphQLObjectType({
    name: 'servicegssdata',
    description: 'Scorecard Service GSS Data',
    fields: {
        title: { type: GraphQLString },
        items: { type: new GraphQLList(servicegssitemdataType) },
    }
});


const scorecardservicedataType = new GraphQLObjectType({
    name: 'ScorecardServiceData',
    description: 'Scorecard Service Data',
    fields: {
        servicegssdata: { type: new GraphQLList(servicegssdataType) },
    }
});

module.exports = scorecardservicedataType;

