const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean } = graphql

const laborconfigdata = new GraphQLObjectType({
    name: 'laborconfigdata',
    description: 'Labor Config Data',
    fields: {
        userid: { type: GraphQLInt },
        laborsection1: { type: GraphQLString },
        laborsection2: { type: GraphQLString },
        payrolldepartmentwise: { type: GraphQLBoolean },
        payrollvsrevenuevsocc: { type: GraphQLBoolean },
        actualvspayrollchart: { type: GraphQLBoolean },
        housekeepingwidget: { type: GraphQLBoolean },
        payrollactualvsplanhourswidget: { type: GraphQLBoolean },
        payrollactualvsplanwageswidget: { type: GraphQLBoolean },
        defaultweekday: { type: GraphQLString }

    }
});

module.exports = laborconfigdata;
