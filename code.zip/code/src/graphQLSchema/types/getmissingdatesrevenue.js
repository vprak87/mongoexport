const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString,GraphQLScalarType} = graphql
const RevenueMissingDate = new GraphQLScalarType({
    name: 'revdates',
    serialize(date) {
      return date.toISOString()
    },
    parseValue(date) {
      try           { return new Date(value); }
      catch (error) { return null; }
    },
    parseLiteral(ast) {
      if (ast.kind === Kind.INT) {
        return new Date(parseInt(ast.value, 10));
      }
      else if (ast.kind === Kind.STRING) {
        return this.parseValue(ast.value);
      }
      else {
        return null;
      }
    },
});
const getmissingdatesrevenue = new GraphQLObjectType({
    name: 'getmissingrevenuedates',
    description: 'Get Revenue Missing Dates',
    fields: {
        date:{ type: RevenueMissingDate }
    }
});
module.exports = getmissingdatesrevenue;
