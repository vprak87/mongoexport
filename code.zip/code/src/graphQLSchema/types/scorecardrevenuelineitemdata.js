const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const scorecardrevenuelineitemdataType = new GraphQLObjectType({
    name: 'ScorecardRevenueLineItemData',
    description: 'Scorecard RevenueData - Line Items',
    fields: {
        title: { type: GraphQLString },
        actual: { type: GraphQLString },
        plan: { type: GraphQLString },
        variance: { type: GraphQLString },
        variancetooltip: { type: GraphQLString },
        variancetooltipcolor: { type: GraphQLString },
        lastyear: { type: GraphQLString },
        lastyearvariance: { type: GraphQLString },
        lastyearvariancetooltip: { type: GraphQLString },
        lastyearvariancetooltipcolor: { type: GraphQLString }
    }
});

module.exports = scorecardrevenuelineitemdataType;

