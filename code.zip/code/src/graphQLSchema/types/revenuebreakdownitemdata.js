const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList} = graphql

const RevenueBreakdownitem = new GraphQLObjectType({
    name: 'RevenueBreakdownitem',
    description: 'Revenue Breakdown item',
    fields: {
        label: { type: GraphQLString },
        data: { type: GraphQLString },
        sub: { type: GraphQLString },
        color: { type: GraphQLString }
    }
});
const RevenueBreakdownitemdata = new GraphQLObjectType({
    name: 'RevenueBreakdownitemdata',
    description: 'RevenueBreakdownitemdata',
    fields: {
        label: { type: GraphQLString },
        data: { type: GraphQLString },
        sub: { type: new GraphQLList(RevenueBreakdownitem)},
        color: { type: GraphQLString }
    }
});

module.exports = RevenueBreakdownitemdata