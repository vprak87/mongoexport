const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt } = graphql


const kpikeyitemlist = new GraphQLObjectType({
    name: 'kpikeyitemlist',
    description: 'kpi key Item list',
    fields: {
        id: { type: GraphQLString },
        KPIKey: { type: GraphQLString },
        DisplayOrder: { type: GraphQLString },
        UpdateDateTime: { type: GraphQLString }
    }
});

const createkpigroupdataitem = new GraphQLObjectType({
    name: 'createkpigroupdataitem',
    description: 'create kpi group data Item',
    fields: {
        _id: { type: GraphQLString },
        ID: { type: GraphQLInt },
        GroupName: { type: GraphQLString },
        GroupColor: { type: GraphQLString },
        DisplayOrder: { type: GraphQLInt },
        UserID: { type: GraphQLInt },
        UpdateDateTime: { type: GraphQLString },
        kpilist: { type: new graphql.GraphQLList(kpikeyitemlist) },
    }
});

module.exports = createkpigroupdataitem;
