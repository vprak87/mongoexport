const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const revenuetabledata = 
new GraphQLObjectType({ 
    name: 'revenuetabledata', 
    description: 'Revenue Breckdown table Item ', 
    fields: { 
        amount: { type: GraphQLString }, 
        description: { type: GraphQLString }
        }
});

module.exports = revenuetabledata;
