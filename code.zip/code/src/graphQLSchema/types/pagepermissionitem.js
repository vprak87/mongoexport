const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const pagepermissionitem = new GraphQLObjectType({
    name: 'pagepermissionitem',
    description: 'page permission item data',
    fields: {
        controllername: { type: GraphQLString },
        action:{ type: GraphQLString }        
    }
});

module.exports = pagepermissionitem;
