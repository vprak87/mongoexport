const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat, GraphQLInputObjectType } = graphql;

const pnlRawItemDataModelList3Type = new GraphQLObjectType({
  name: 'PnLrawItemDataModelList3',
  description: 'PnL Raw Item Model List2 Data',
  fields: {
    Raw_Name: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Enable: { type: GraphQLBoolean },
    Highlighted: { type: GraphQLBoolean },
    Merged: { type: GraphQLBoolean },
  }
});

const pnlGroupDataModelList3Type = new GraphQLObjectType({
  name: 'PnLGroupDataModelList3',
  description: 'PnL Group Model List2 Data',
  fields: {
    Group_Name: { type: GraphQLString },
    Group_Title: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Items: { type: new GraphQLList(pnlRawItemDataModelList3Type) },
  }
});

const pnlcolItemDataModelList1Type = new GraphQLObjectType({
  name: 'PnLcolItemDataModelList1',
  description: 'PnL col Item Model Data',
  fields: {
    ID: { type: GraphQLInt },
    Type: { type: GraphQLString },
    Datakey: { type: GraphQLString },
    Title: { type: GraphQLString },
  }
});

const pnlcolSetDataModelListType = new GraphQLObjectType({
  name: 'PnLcolsetDataModelList2',
  description: 'PnL column set Model List Data',
  fields: {
    ID: { type: GraphQLInt },
    Type: { type: GraphQLString },
    Title: { type: GraphQLString },
    Color: { type: GraphQLString },
    Datakey: { type: GraphQLString },
    Cols: { type: new GraphQLList(pnlcolItemDataModelList1Type) },
  }
});

const pnlrawandcolorderdataoutType = new GraphQLObjectType({
    name: 'mutation',
    description: 'PnL raw and col order data',
    fields: {
      User_ID: { type: graphql.GraphQLInt },
      Hotel_ID: { type: graphql.GraphQLInt },
      Pnl_view: { type: graphql.GraphQLString },
      Created_at: { type: graphql.GraphQLString },
      Groups: { type: new GraphQLList(pnlGroupDataModelList3Type) },
      Colorder: { type: new GraphQLList(pnlcolSetDataModelListType) },
    }
});

module.exports = pnlrawandcolorderdataoutType;