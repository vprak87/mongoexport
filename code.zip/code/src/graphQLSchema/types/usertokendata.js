const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLBoolean } = graphql

const usertokendata = new GraphQLObjectType({
    name: 'usertokendata',
    description: 'User Token Data',
    fields: {
        success: { type: GraphQLBoolean },
        token: { type: GraphQLString }
    }
});

module.exports = usertokendata;
