const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const kpidataitem = new GraphQLObjectType({
    name: 'kpidataitem',
    description: 'KPI Column Item',
    fields: {
        columnname: { type: GraphQLString },
        kpikey: { type: GraphQLString }
    }
});

module.exports = kpidataitem;
