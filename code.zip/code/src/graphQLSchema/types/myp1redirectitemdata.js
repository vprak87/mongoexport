const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const myp1redirectitemdata =
    new GraphQLObjectType({
        name: 'myp1redirectitemdata',
        description: 'MYP 1 Redirect URL Item Type',
        fields: {
            title: { type: GraphQLString },
            url: { type: GraphQLString }
        }
    });

module.exports = myp1redirectitemdata;
