const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLList } = graphql


const STRactualdataType = new GraphQLObjectType({
    name: 'actualdata',
    description: 'STR - Line Item Data',
    fields: {
        title: { type: GraphQLString },
        occact: { type: GraphQLString },
        occactcolor: { type: GraphQLString },
        occchg: { type: GraphQLString },
        occchgcolor: { type: GraphQLString },
        mpiact: { type: GraphQLString },
        mpiactcolor: { type: GraphQLString },
        mpichg: { type: GraphQLString },
        mpichgcolor: { type: GraphQLString },
        occrankact: { type: GraphQLString },
        occrankchg: { type: GraphQLString },
        adract: { type: GraphQLString },
        adractcolor: { type: GraphQLString },
        adrchg: { type: GraphQLString },
        adrchgcolor: { type: GraphQLString },
        ariact: { type: GraphQLString },
        ariactcolor: { type: GraphQLString },
        arichg: { type: GraphQLString },
        arichgcolor: { type: GraphQLString },
        adrrankact: { type: GraphQLString },
        adrrankchg: { type: GraphQLString },
        revparact: { type: GraphQLString },
        revparactcolor: { type: GraphQLString },
        revparchg: { type: GraphQLString },
        revparchgcolor: { type: GraphQLString },
        rgiact: { type: GraphQLString },
        rgiactcolor: { type: GraphQLString },
        rgichg: { type: GraphQLString },
        rgichgcolor: { type: GraphQLString },
        revparrankact: { type: GraphQLString },
        revparrankchg: { type: GraphQLString },
        missingdates: { type: GraphQLString }
    }
});


const stritemdataType = new GraphQLObjectType({
    name: 'stritemdata',
    description: 'STR Report Data',
    fields: {
        id: { type: GraphQLInt },
        actualdata: { type: STRactualdataType },
        comparisiondata: { type: STRactualdataType }
    }
});


module.exports = stritemdataType;

