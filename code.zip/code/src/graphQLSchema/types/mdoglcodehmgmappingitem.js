const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt,GraphQLBoolean} = graphql

const mdoglcodehmgmappingitem = new GraphQLObjectType({
    name: 'mdoglcodehmgmappingitem',
    description: 'mdo glcode master data',
    fields: {       
        _id: { type: GraphQLString },
        HMGGLCode:{ type: GraphQLString },
        MDOGLCode:{ type: GraphQLString },
        Description:{ type: GraphQLString },
        Status: { type: GraphQLBoolean },
        OrganizationID: { type: GraphQLInt }
    }
});

module.exports = mdoglcodehmgmappingitem;