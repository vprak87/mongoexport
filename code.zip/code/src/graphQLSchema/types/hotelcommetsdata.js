const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString,GraphQLInt,GraphQLScalarType } = graphql;

const DateFormatType = new GraphQLScalarType({
    name: 'DateFormat',
    serialize(date) {
      return date.toISOString()
    },
    parseValue(date) {
      try           { return new Date(value); }
      catch (error) { return null; }
    },
    parseLiteral(ast) {
      if (ast.kind === Kind.INT) {
        return new Date(parseInt(ast.value, 10));
      }
      else if (ast.kind === Kind.STRING) {
        return this.parseValue(ast.value);
      }
      else {
        return null;
      }
    },
});

const repply = new GraphQLObjectType({
    name: 'existingrepply',
    description: 'Repply Data',
    fields: {
        text: { type: GraphQLString }
    }
});

const childcomment = new GraphQLObjectType({
    name: 'childcomment',
    description: 'Comemnt List ',
    fields: {
        ID:{ type: GraphQLInt },
        HotelID: { type: GraphQLInt },
        Date: { type: DateFormatType },
        UserID:{ type: GraphQLInt },
        Tags: { type: GraphQLString },
        Description: { type: GraphQLString },
        Reply: { type: GraphQLString },
        UpdateDateTime: { type: DateFormatType },
        UserName: { type: GraphQLString },
        DisplayDate: { type: GraphQLString },
        HotelName: { type: GraphQLString },
        FirstName: { type: GraphQLString },
        LastName: { type: GraphQLString },
        ExistingReply: { type: new graphql.GraphQLList(repply)  },
        ParentID:{ type: GraphQLInt },
        ChildComments:{ type: GraphQLString }
    }
});

const hotelcommentdata = new GraphQLObjectType({
    name: 'commentview',
    description: 'Hotel Comment View',
    fields: {
            ID:{ type: GraphQLInt },
            HotelID: { type: GraphQLInt },
            Date: { type: DateFormatType },
            UserID:{ type: GraphQLInt },
            Tags: { type: GraphQLString },
            Description: { type: GraphQLString },
            Reply: { type: GraphQLString },
            UpdateDateTime: { type: DateFormatType },
            UserName: { type: GraphQLString },
            DisplayDate: { type: GraphQLString },
            HotelName: { type: GraphQLString },
            FirstName: { type: GraphQLString },
            LastName: { type: GraphQLString },
            ExistingReply: { type: new graphql.GraphQLList(repply)  },
            ParentID:{ type: GraphQLInt },
            ChildComments:{ type: new graphql.GraphQLList(childcomment) }
            }
});

module.exports = hotelcommentdata;


