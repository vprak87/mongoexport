const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt,GraphQLBoolean} = graphql

const hmgglcodemasteritem = new GraphQLObjectType({
    name: 'hmgglcodemasterdata',
    description: 'HMG GLCode master data',
    fields: {       
        _id: { type: GraphQLString },
        GLCode:{ type: GraphQLString },
        Description:{ type: GraphQLString },
        OrganizationID: { type: GraphQLInt },
        IsActive: { type: GraphQLBoolean }
    }
});

module.exports = hmgglcodemasteritem;