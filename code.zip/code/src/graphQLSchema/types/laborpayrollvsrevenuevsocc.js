const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString} = graphql

const payrollvsrevenuevsoccType = new GraphQLObjectType({
    name: 'LaborPayrollVsRevenueVsOccData',
    description: 'Labor Data - Payroll vs Revenue vs Occ',
    fields: {
        Date: { type: GraphQLString },
        Payroll: { type: GraphQLString },
        PayrollPercentage: { type: GraphQLString },
        Revenue:  { type: GraphQLString },
        Occ:{ type: GraphQLString },      
    }
});

module.exports = payrollvsrevenuevsoccType;