const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt } = graphql

const kpicolumndataitem = new GraphQLObjectType({
    name: 'addkpicolumndataitem',
    description: 'Add KPI Column data Item',
    fields: {
        ID: { type: GraphQLInt },
        DisplayOrder: { type: GraphQLInt },
        CreateOwnTableMasterID: { type: GraphQLInt },
        UserID: { type: GraphQLInt }
    }
});

module.exports = kpicolumndataitem;
