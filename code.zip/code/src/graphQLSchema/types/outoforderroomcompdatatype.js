const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLFloat} = graphql

const outoforderroomcompdatatype = new GraphQLObjectType({
    name: 'outoforderroomcompdatatype',
    description: 'ooo comptable data Type',
    fields: {
        hotelid: { type: GraphQLString },
        outoforderrooms: { type: GraphQLString },
        comprooms: { type: GraphQLString },
    }
});

module.exports = outoforderroomcompdatatype;

