const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt,GraphQLBoolean} = graphql

const mdoglcodemappingtabledata = new GraphQLObjectType({
    name: 'mdoglcodemappingtabledata',
    description: 'mdo glcode mapping  data',
    fields: {       
        _id: { type: GraphQLString },
        ID: { type: GraphQLInt },
        GLCode:{ type: GraphQLString },
        Description:{ type: GraphQLString },
        DisplayDescription: { type: GraphQLString },
        ParentId: { type: GraphQLInt },
        IsActive: { type: GraphQLBoolean },
        MappingID:{ type: GraphQLString },
            MappingStatus:{ type: GraphQLString },
            CustomDescription:{ type: GraphQLString },
            HMGGLCode:{ type: GraphQLString },
    }
});

module.exports = mdoglcodemappingtabledata;