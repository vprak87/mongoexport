const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString,GraphQLInt,GraphQLBoolean,GraphQLFloat } = graphql

const useritemdata =
    new GraphQLObjectType({
        name: 'useritemdata',
        description: 'users Item Type',
        fields: {
            ID: { type: GraphQLInt },
            UserName: { type: GraphQLString },
            Password: { type: GraphQLString },
            FirstName:{ type: GraphQLString },
            LastName: { type: GraphQLString },
            Gender: { type: GraphQLString },
            CompanyName: { type: GraphQLString },
            Country: { type: GraphQLString },
            Address1: { type: GraphQLString },
            Address2: { type: GraphQLString },
            City: { type: GraphQLString },
            State: { type: GraphQLString },
            BusineePhoneNumber: { type: GraphQLString },
            AltPhoneNumber: { type: GraphQLString },
            FaxNumber: { type: GraphQLString },
            SecretQuestion: { type: GraphQLString },
            SecreAnswer: { type: GraphQLString },
            UpdateDateTime: { type: GraphQLString },
            UpdatedBy: { type: GraphQLString },
            RoleID: { type: GraphQLInt },
            IsActive: { type: GraphQLBoolean },
            IsRegisterForPoForm: { type: GraphQLBoolean },
            PasswordRecoveryToken: { type: GraphQLString },
            OrganizationId: { type: GraphQLInt },
            IsRegisterForExpenseForm: { type: GraphQLBoolean },
            IsFirstTimeLogin: { type: GraphQLBoolean},
            SecondaryOrganizationId: { type: GraphQLInt },
            AccessFailedCount: { type: GraphQLInt },
            IsLockout: { type: GraphQLBoolean },
            Cmp_Id: { type: GraphQLInt },
            Cmp_OrgUser_Id: { type: GraphQLInt }
        }
    });

module.exports = useritemdata;
