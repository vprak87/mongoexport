const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLList } = graphql


const STRmonthdataitemType = new GraphQLObjectType({
    name: 'monthitemdata',
    description: 'STR Portfolio - Month Item Data',
    fields: {
        hotelvalue: { type: GraphQLString },
        hotelvaluechange: { type: GraphQLString },
        compsetvalue: { type: GraphQLString },
        compsetvaluechange: { type: GraphQLString }
    }
});

const STRmonthdataType = new GraphQLObjectType({
    name: 'monthdata',
    description: 'STR Portfolio - Month Data',
    fields: {
        revpar: { type: STRmonthdataitemType },
        adr: { type: STRmonthdataitemType },
        occ: { type: STRmonthdataitemType }
    }
});


const strportfolioitemdataType = new GraphQLObjectType({
    name: 'strportfolioitemdata',
    description: 'STR Portfolio Data',
    fields: {
        hotelid: { type: GraphQLInt },
        month: { type: GraphQLString },
        name: { type: GraphQLString },
        ytdroomrevenue: { type: GraphQLString },
        currentmonth: { type: STRmonthdataType },
        running12month: { type: STRmonthdataType }
    }
});


module.exports = strportfolioitemdataType;

