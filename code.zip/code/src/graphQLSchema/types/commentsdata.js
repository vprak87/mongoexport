const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql;

const commentsdata = new GraphQLObjectType({
    name: 'comment',
    description: 'Comment List',
    fields: {
        Description:{ type: GraphQLString },
        FirstName: { type: GraphQLString },
        LastName: { type: GraphQLString }
    }
});

module.exports = commentsdata;


