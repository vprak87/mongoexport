const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const cashtableitem = new GraphQLObjectType({
    name: 'cashtableitem',
    description: 'cash table List',
    fields: {
        hotelid: { type: GraphQLString },
        description:{ type: GraphQLString },   
        totalcurrent: { type: GraphQLString },
        totalmtd: { type: GraphQLString }
    }
});

module.exports = cashtableitem;


