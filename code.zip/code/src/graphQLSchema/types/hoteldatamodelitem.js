const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat } = graphql

const hotelDataModelListType = new GraphQLObjectType({
  name: 'HotelDataModelList',
  description: 'Hotel Model List Data',
  fields: {
    AddressLine1: { type: GraphQLString },
    ID: { type: GraphQLInt },
    City: { type: GraphQLString },
    Country: { type: GraphQLString },
    AccountingTool: { type: GraphQLString },
    AddressLine2: { type: GraphQLString },
    Attention: { type: GraphQLString },
    HotelCode: { type: GraphQLString },
    HotelName: { type: GraphQLString },
    NumberofAvailableRooms: { type: GraphQLInt },
    State: { type: GraphQLString },
    OrganizationId: { type: GraphQLInt },
    PMS: { type: GraphQLString },
    PMSPropertyID: { type: GraphQLString },
    PMSPropertyName: { type: GraphQLString },
    TimeZone: { type: GraphQLString },
    Zip: { type: GraphQLString },    
    IsActive: { type: GraphQLBoolean },
    IsValidMYP: { type: GraphQLBoolean },
    
    // MissingDateOtherRevenueEnabled: { type: GraphQLBoolean },
    // Property: { type: GraphQLString },
    // PropertyCode: { type: GraphQLString },
    // STRID: { type: GraphQLString },
    // Cmp_Id: { type: GraphQLInt },
    // JoinedDate: { type: GraphQLString },
    // DefaultCurrency: { type: GraphQLString },
    // UpdateDateTime: { type: GraphQLString },
    // UpdatedBy: { type: GraphQLString },

  }
});


module.exports = hotelDataModelListType;