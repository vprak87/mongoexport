const graphql = require('graphql');
const { GraphQLObjectType, GraphQLInt,GraphQLString,GraphQLList } = graphql


const datewithlink = new GraphQLObjectType({
    name: 'datewithlink',
    description: 'Date with Link',
    fields: {
      Section: { type: GraphQLString },
      Month: { type: GraphQLString },
      Link: { type: GraphQLString }
    }
});
const hotelmissingdatedata = new GraphQLObjectType({
    name: 'hotelmissingdatedata',
    description: 'Missing Data List',
    fields: {
        StrMissingDates:{ type: new GraphQLList(datewithlink) },
        Type:{ type: GraphQLString },
        HotelID:{ type: GraphQLInt }
        
    }
});

module.exports = hotelmissingdatedata;


