const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const scorecardlaborlineitemdataType = new GraphQLObjectType({
    name: 'ScorecardLaborLineItemData',
    description: 'Scorecard Labor Data - Line Items',
    fields: {
        title: { type: GraphQLString },
        actual: { type: GraphQLString },
        actualpor: { type: GraphQLString },
        plan: { type: GraphQLString },
        planpor: { type: GraphQLString },
        variance: { type: GraphQLString },
        variancepor: { type: GraphQLString },
        variancetooltip: { type: GraphQLString },
        variancetooltipcolor: { type: GraphQLString },
        lastyear: { type: GraphQLString },
        lastyearpor: { type: GraphQLString },
        lastyearvariance: { type: GraphQLString },
        lastyearvariancepor: { type: GraphQLString },
        lastyearvariancetooltip: { type: GraphQLString },
        lastyearvariancetooltipcolor: { type: GraphQLString },
    }
});

module.exports = scorecardlaborlineitemdataType;

