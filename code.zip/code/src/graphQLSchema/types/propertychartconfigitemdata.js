const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt} = graphql

const propertychartconfigitemdata = new GraphQLObjectType({
    name: 'PropertyChartConfig',
    description: 'PropertyChartConfig',
    fields: {        
        id:{ type: GraphQLInt },
        widgetname:  { type: GraphQLString },
        charttype:  { type: GraphQLString },
        chartperiod: { type: GraphQLString },
        comparechartdata: { type: GraphQLString },                       
        userid:{ type: GraphQLInt },
    }
});

module.exports = propertychartconfigitemdata;