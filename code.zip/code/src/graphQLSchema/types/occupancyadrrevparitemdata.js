const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const occupancyadrrevparitemdata = new GraphQLObjectType({
    name: 'occupancyadrrevparitemdata',
    description: 'occupancy adr revpar item data',
    fields: {
        occupancychart: { type: GraphQLString },
        occupancymax:{ type: GraphQLString },     
        occupancyactual: { type: GraphQLString },     
        occupancylastyear: { type: GraphQLString },  
        occupancybudget:{ type: GraphQLString },
        occupancyforecast: { type: GraphQLString },
        adrchart: { type: GraphQLString },
        adrmax:{ type: GraphQLString },
        adractual: { type: GraphQLString },
        adrlastyear: { type: GraphQLString },
        adrbudget: { type: GraphQLString },
        adrforecast: { type: GraphQLString },
        revparchart:{ type: GraphQLString },
        revparmax:{ type: GraphQLString },            
        revparactual:{ type: GraphQLString },
        revparlastyear:{ type: GraphQLString },
        revparbudget:{ type: GraphQLString },
        revparforecast:{ type: GraphQLString }
    }
});

module.exports = occupancyadrrevparitemdata;
