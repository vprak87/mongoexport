const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat } = graphql

const hotelDataModelListType = new GraphQLObjectType({
  name: 'HotelDataModelList',
  description: 'Hotel Model List Data',
  fields: {
    AddressLine1: { type: GraphQLString },
    ID: { type: GraphQLInt },
    City: { type: GraphQLString },
    Country: { type: GraphQLString },
    AccountingTool: { type: GraphQLString },
    AddressLine2: { type: GraphQLString },
    Attention: { type: GraphQLString },
    HotelCode: { type: GraphQLString },
    HotelName: { type: GraphQLString },
    NumberofAvailableRooms: { type: GraphQLInt },
    State: { type: GraphQLString },
    OrganizationID: { type: GraphQLInt },
    PMS: { type: GraphQLString },
    PMSPropertyID: { type: GraphQLString },
    PMSPropertyName: { type: GraphQLString },
    TimeZone: { type: GraphQLString },
    Zip: { type: GraphQLString },    
    IsActive: { type: GraphQLBoolean },
    
    
    // MissingDateOtherRevenueEnabled: { type: GraphQLBoolean },
    // Property: { type: GraphQLString },
    // PropertyCode: { type: GraphQLString },
    // STRID: { type: GraphQLString },
    // Cmp_Id: { type: GraphQLInt },
    // JoinedDate: { type: GraphQLString },
    // DefaultCurrency: { type: GraphQLString },
    // UpdateDateTime: { type: GraphQLString },
    // UpdatedBy: { type: GraphQLString },

  }
});

// const hotelGroupsDataModelListType = new GraphQLObjectType({
//   name: 'HotelGroupDataModelList',
//   description: 'Hotel Group Model List Data',
//   fields: {
//     // GroupName: { type: GraphQLString },
//     // GroupID: { type: GraphQLInt },
//     // Hotels: { type: new GraphQLList(hotelDataModelListType) }
//     groupname: { type: GraphQLString },
//     hotels: { type: new GraphQLList(hotelDataModelListType) }

//   }
// });

// const mgmtGroupsModelListType = new GraphQLObjectType({
//   name: 'HotelManagementGroupDataModelList',
//   description: 'Hotel management Group Model List Data',
//   fields: {
//     // GroupName: { type: GraphQLString },
//     // GroupID: { type: GraphQLInt },
//     // Hotels: { type: new GraphQLList(hotelDataModelListType) }
//     // groupname: { type: GraphQLString },
//     // hotels: { type: new GraphQLList(hotelDataModelListType) }

//     hmg_id: { type: GraphQLString },
//     hmg_name: { type: GraphQLString },
//     country: { type: GraphQLString },
//     address1: { type: GraphQLString },
//     address2: { type: GraphQLString },
//     city: { type: GraphQLString },
//     state: { type: GraphQLString },
//     hotel_list: { type: new GraphQLList(hotelDataModelListType) },
//     hotelgroups : { type: new GraphQLList(hotelGroupsDataModelListType) },
//   }
// });

// const hotellisttdataType = new GraphQLObjectType({
//     name: 'HotelListData',
//     description: 'hotel list data',
//     fields: {
//       // OrganizationName: { type: GraphQLString },
//       // OrganizationID: { type: GraphQLInt },
//       // hotelList: { type: new GraphQLList(hotelDataModelListType) },
//       // hotelGroups: { type: new GraphQLList(hotelGroupsDataModelListType) },

//       error: { type: GraphQLBoolean },
//       message: { type: GraphQLString },
//       user_id: { type: GraphQLString },
//       user_name: { type: GraphQLString },
//       hotel_management_group : { type: new GraphQLList(mgmtGroupsModelListType) }
//     }
// });
const hotelpmsType = new GraphQLObjectType({
  name: 'HotelpmssData',
  description: 'hotel pms list data',
  fields: {
    _id: { type: GraphQLString },
    pms_name: { type: GraphQLString },
  }
})


const hoteldataType = new GraphQLObjectType({
    name: 'HotelData',
    description: 'hotel data',
    fields: {
        id: { type: GraphQLString },
        hotel_id: { type: GraphQLInt },
        hotel_code: { type: GraphQLString },
        hotel_name: { type: GraphQLString },
        pms: { type: new GraphQLList(hotelpmsType) },
        numberofavailablerooms: { type: GraphQLInt },
        updatedatetime: { type: GraphQLString },
        updatedby: { type: GraphQLString },
        addressline2: { type: GraphQLString },
        city: { type: GraphQLString },
        stateiso2: { type: GraphQLString }
    }
})


const hotelgroupsType = new GraphQLObjectType({
    name: 'HotelgroupsData',
    description: 'hotel groups list data',
    fields: {
      groupname: { type: GraphQLString },
      hg_myp_id: { type: GraphQLInt },
      hotels: { type: new GraphQLList(hoteldataType) }
    }
})

const hotelManagementGroupsType = new GraphQLObjectType({
  name: 'HotelMgmtgroupsData',
  description: 'hotel Management groups list data',
  fields: {
    hmg_id: { type: GraphQLString },
    hmg_myp_id: { type: GraphQLInt },
    hmg_name: { type: GraphQLString },
    country: { type: GraphQLString },
    address1: { type: GraphQLString },
    address2: { type: GraphQLString },
    city: { type: GraphQLString },
    state: { type: GraphQLString },
    hotel_list: { type: new GraphQLList(hoteldataType) },
    hotelgroups : { type: new GraphQLList(hotelgroupsType) },
  }
})

const hotellisttdataType = new GraphQLObjectType({
    name: 'HotelListData',
    description: 'hotel list data',
    fields: {
      error: { type: GraphQLBoolean },
      message: { type: GraphQLString },
      user_id: { type: GraphQLString },
      user_name: { type: GraphQLString },
      user_myp_id: { type: GraphQLInt },
      hotel_management_group : { type: new GraphQLList(hotelManagementGroupsType) }
    }
});


module.exports = hotellisttdataType;