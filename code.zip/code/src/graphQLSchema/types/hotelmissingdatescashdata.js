const graphql = require('graphql');
const { GraphQLObjectType, GraphQLList,GraphQLString } = graphql


const hotelmissingdatepropertydata = new GraphQLObjectType({
    name: 'propertymissingdatescashdata',
    description: 'Missing Dates for cash data on property page',
    fields: {
        missingdates:{ type: GraphQLString }
        
    }
});
module.exports = hotelmissingdatepropertydata;