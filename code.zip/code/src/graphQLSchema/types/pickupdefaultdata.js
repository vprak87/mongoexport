const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat } = graphql

const pickupDataModelListType = new GraphQLObjectType({
  name: 'PickupDataModelList',
  description: 'Pickup Model List Data',
  fields: {
      Date: { type: GraphQLString },
      DailyActivityDate: { type: GraphQLString },
      Occupancy: { type: GraphQLFloat },
      TotalRevenue: { type: GraphQLFloat },
      NoOfRoomSold: { type: GraphQLInt },
      NoOfRoomAvailable: { type: GraphQLInt },
      Pickup1Amount: { type: GraphQLFloat },
      Pickup3Amount: { type: GraphQLFloat },
      Pickup7Amount: { type: GraphQLFloat },
      PickupSDLYAmount: { type: GraphQLFloat },
      Pickup1RoomSold: { type: GraphQLInt },
      Pickup3RoomSold: { type: GraphQLInt },
      Pickup7RoomSold: { type: GraphQLInt },
      PickupSDLYRoomSold: { type: GraphQLInt },
      DeltaForcast: { type: GraphQLFloat },
      TodayDate: { type: GraphQLString },
      IsFriORSat: { type: GraphQLBoolean },
      GroupBlock: { type: GraphQLInt },
      GroupNotPickedUp: { type: GraphQLInt },
      TransientDelta7: { type: GraphQLFloat },
      TransientDeltaSDLY: { type: GraphQLFloat },
      TransientDelta3: { type: GraphQLFloat },
      TransientDelta1: { type: GraphQLFloat },
      TransientRoomSold: { type: GraphQLInt }
  }
});

const pickupdefaultdataType = new GraphQLObjectType({
    name: 'PickupDefaultData',
    description: 'pickup default page data',
    fields: {
        PickupDataModelList: { type: new GraphQLList(pickupDataModelListType) },
        CurrentDate: { type: GraphQLString },
        DailyActivityDateDelta1: { type: GraphQLString },
        DailyActivityDateDelta3: { type: GraphQLString },
        DailyActivityDateDelta7: { type: GraphQLString },
        DailyActivityDateDeltaSDLY: { type: GraphQLString }
    }
});

module.exports = pickupdefaultdataType;