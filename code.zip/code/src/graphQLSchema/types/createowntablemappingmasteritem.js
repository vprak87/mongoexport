const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat } = graphql

const createOwntablemappingMasteritemType = new GraphQLObjectType({
  name: 'CreateOwntablemappingMasteritem',
  description: 'CreateOwntablemappingMasteritem',
  fields: {
    id:{ type: GraphQLInt },
    tablename:{ type: GraphQLString },
    columname:{ type: GraphQLString },
    displayorder:{ type: GraphQLInt },
    kpikey:{ type: GraphQLString },
    parentkey: { type: GraphQLBoolean },
    hassubkey:  { type: GraphQLBoolean },
    kpiformula:{ type: GraphQLString },
    unit:{ type: GraphQLString },
    organizationid:{ type: GraphQLInt },
    iscustom: { type: GraphQLBoolean },
  
  }
});

module.exports = createOwntablemappingMasteritemType;