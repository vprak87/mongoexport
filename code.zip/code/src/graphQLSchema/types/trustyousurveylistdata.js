const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt} = graphql

const trustyousurveylistdata = new GraphQLObjectType({
    name: 'trustyousurveylistdata',
    description: 'trust you survey data',
    fields: {       
        id: { type: GraphQLInt },
        organisationid:{ type: GraphQLInt },
        date:{ type: GraphQLString },
        category: { type: GraphQLString },
        subcategory: { type: GraphQLString },
        description: { type: GraphQLString },
        categoryvalue: { type: GraphQLString },
        updatedatetime:{ type: GraphQLString },
        updatedby:{ type: GraphQLString },
        hotelid:{ type: GraphQLInt }
    }
});

module.exports = trustyousurveylistdata;