const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const marketsegmentitemdata = 
new GraphQLObjectType({ 
    name: 'marketsegmentitemdata', 
    description: 'Market Segment Item Type', 
    fields: { 
        type: { type: GraphQLString }, 
        actual: { type: GraphQLString }, 
        lastyr: { type: GraphQLString } 
    } 
});

module.exports = marketsegmentitemdata;
