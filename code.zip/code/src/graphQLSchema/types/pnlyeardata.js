const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat } = graphql;

const pnlDataModelListType = new GraphQLObjectType({
  name: 'PnLDataModelList',
  description: 'PnL Model List Data',
  fields: {
    Name: { type: GraphQLString },
    Amount: { type: GraphQLFloat },
    Category: { type: GraphQLString },
    IsActive: { type: GraphQLBoolean },
    MonthName: { type: GraphQLString },
    GLCode: { type: GraphQLString },
  }
});

const pnlItemDataModelListType = new GraphQLObjectType({
  name: 'PnLitemDataModelList',
  description: 'PnL item Model List Data',
  fields: {
    MonthName: { type: GraphQLString },
    TotalSales: { type: GraphQLFloat },
    TotalExpenses: { type: GraphQLFloat },
    NetProfitBeforeTax: { type: GraphQLFloat },
    TotalTaxes: { type: GraphQLFloat },
    NetProfit: { type: GraphQLFloat },
    RevenueList: { type: new GraphQLList(pnlDataModelListType) },
    TaxList: { type: new GraphQLList(pnlDataModelListType) },
    ExpenseList: { type: new GraphQLList(pnlDataModelListType) },
    OperatingExpenseList: { type: new GraphQLList(pnlDataModelListType) },
    FixedExpensesList: { type: new GraphQLList(pnlDataModelListType) },
    UndistcostExpensesList: { type: new GraphQLList(pnlDataModelListType) },
    ITDAExpensesList: { type: new GraphQLList(pnlDataModelListType) },
    LabourExpenseList: { type: new GraphQLList(pnlDataModelListType) },
  }
});

const pnlrawsItemDataModelListType = new GraphQLObjectType({
  name: 'PnLrawsItemDataModelList',
  description: 'PnL raw Item Model List Data',
  fields: {
    Raw_Name: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Enable: { type: GraphQLBoolean },
    Highlighted: { type: GraphQLBoolean },
    Merged: { type: GraphQLBoolean },
  }
});

const pnlrawGroupDataModelListType = new GraphQLObjectType({
  name: 'PnLrawGroupDataModelList',
  description: 'PnL raw Group Model List Data',
  fields: {
    Group_Name: { type: GraphQLString },
    Group_Title: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Items: { type: new GraphQLList(pnlrawsItemDataModelListType) },
  }
});

const pnlrawOrderDataModelListType = new GraphQLObjectType({
  name: 'PnLrawOrderDataModelList',
  description: 'PnL raw order Model List Data',
  fields: {
    User_ID: { type: GraphQLInt },
    Hotel_ID: { type: GraphQLInt },
    Pnl_view: { type: GraphQLString },
    Created_at: { type: GraphQLString },
    Groups: { type: new GraphQLList(pnlrawGroupDataModelListType) },
  }
});

const pnlyearlydataType = new GraphQLObjectType({
    name: 'PnLyearlyData',
    description: 'PnL yearly section page data',
    fields: {
      Items: { type: new GraphQLList(pnlItemDataModelListType) },
      RevenueList: { type: new GraphQLList(pnlDataModelListType) },
      TaxList: { type: new GraphQLList(pnlDataModelListType) },
      ExpenseList: { type: new GraphQLList(pnlDataModelListType) },
      OperatingExpenseList: { type: new GraphQLList(pnlDataModelListType) },
      UndistcostExpensesList: { type: new GraphQLList(pnlDataModelListType) },
      ITDAExpensesList: { type: new GraphQLList(pnlDataModelListType) },
      FixedExpensesList: { type: new GraphQLList(pnlDataModelListType) },
      NetBeforeTaxList: { type: new GraphQLList(pnlDataModelListType) },
      NetProfitList: { type: new GraphQLList(pnlDataModelListType) },
      ExpenseList1: { type: new GraphQLList(pnlDataModelListType) },
      GOPList: { type: new GraphQLList(pnlDataModelListType) },
      NOPList: { type: new GraphQLList(pnlDataModelListType) },
      NetProfitMarginList: { type: new GraphQLList(pnlDataModelListType) },
      EBIDTAExpensesList: { type: new GraphQLList(pnlDataModelListType) },
      GrossProfitMarginList: { type: new GraphQLList(pnlDataModelListType) },
      LabourExpenseList: { type: new GraphQLList(pnlDataModelListType) },
      LaborDataType: { type: GraphQLString },
      Year: { type: GraphQLInt },
      HotelId: { type: GraphQLInt },
      OrgId: { type: GraphQLInt },
      rawOrder: { type: pnlrawOrderDataModelListType }
    }
});

module.exports = pnlyearlydataType;
