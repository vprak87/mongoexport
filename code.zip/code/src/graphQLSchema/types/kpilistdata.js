const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const kpilistdata = new GraphQLObjectType({
    name: 'kpi',
    description: 'Key List',
    fields: {
        Name: { type: GraphQLString },
        Text: { type: GraphQLString }
    }
});

module.exports = kpilistdata;


