const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const currancylabledata = new GraphQLObjectType({
    name: 'currancylabledata',
    description: 'currancylabledata',
    fields: {
        currancylable: { type: GraphQLString }
    }
});

module.exports = currancylabledata;
