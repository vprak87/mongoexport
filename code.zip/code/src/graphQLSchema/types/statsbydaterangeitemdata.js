const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const statsbydaterangeitemdata = new GraphQLObjectType({
    name: 'statsbydaterangedata',
    description: 'Stats By Date Range Data',
    fields: {
        hotelid:{ type: GraphQLString },
        hotelname: { type: GraphQLString },
        date: { type: GraphQLString },
        adr: { type: GraphQLString },
        revpar: { type: GraphQLString },
        fandbrevenue: { type: GraphQLString },
        otherrevenue: { type: GraphQLString },
        occupancy: { type: GraphQLString },
        noofroomsold: { type: GraphQLString },
        ooorooms: { type: GraphQLString },
        totalrevenue: { type: GraphQLString },
    }
});

module.exports = statsbydaterangeitemdata;
