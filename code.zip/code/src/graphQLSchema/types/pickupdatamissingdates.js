const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const pickupdatamissingdates = new GraphQLObjectType({
    name: 'pickupdatamissingdates',
    description: 'Pickup Data Missing Dates',
    fields: {
        missingdates: { type: GraphQLString }
    }
});

module.exports = pickupdatamissingdates;
