const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const cashdetailitemdata = new GraphQLObjectType({
    name: 'CashDetailItemdata',
    description: 'Cash Detail Data',
    fields: {
        hotelid: { type: GraphQLString },
        orgId: { type: GraphQLString },
        hotelname: { type: GraphQLString },
        ishotelgroup: { type: GraphQLString },
        organisationname: { type: GraphQLString },
        dmrasubtype: { type: GraphQLString },           
        cash: { type: GraphQLString },
        poscash: { type: GraphQLString },
        othercash: { type: GraphQLString },
        refundcash: { type: GraphQLString },
        creditcard: { type: GraphQLString },
        amex: { type: GraphQLString },
        posamex: { type: GraphQLString },
        visa: { type: GraphQLString },
        posvisa: { type: GraphQLString },
        mc: { type: GraphQLString },
        posmc: { type: GraphQLString },
        dinerscard: { type: GraphQLString },
        posdinerscard: { type: GraphQLString },
        discovercard: { type: GraphQLString },
        posdiscovercard: { type: GraphQLString },
        debit: { type: GraphQLString },
        posdebit: { type: GraphQLString },
        eft: { type: GraphQLString },
        poseft: { type: GraphQLString },
        posmanual: { type: GraphQLString },
        posbankcards: { type: GraphQLString },
        paidouts: { type: GraphQLString },
        directbill: { type: GraphQLString },
        hiltonadvancepurchase: { type: GraphQLString },
        wiretransfer: { type: GraphQLString },
        date: { type: GraphQLString },
        comments: { type: GraphQLString },
    }
});

module.exports = cashdetailitemdata;
