const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const dashboardmonthwiseitem = new GraphQLObjectType({
    name: 'dashboardmonthwiseitem',
    description: 'Dashboard Month Wise Item',
    fields: {
        month: { type: GraphQLString },
        occupancy: { type: GraphQLString },
        occupancyly:{ type: GraphQLString },
        occupancydelta:{ type: GraphQLString },
        adr:{ type: GraphQLString },           
        adrly: { type: GraphQLString },   
        adrdelta:{ type: GraphQLString },      
        revpar: { type: GraphQLString },
        revparly: { type: GraphQLString },
        revpardelta: { type: GraphQLString },
        weeknumber: { type: GraphQLString },
        isoccupancyup: { type: GraphQLString },
        isadrup: { type: GraphQLString },
        isrevpaup: { type: GraphQLString }
    }
});

module.exports = dashboardmonthwiseitem;
