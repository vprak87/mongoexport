const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat } = graphql


const pickupsummerydataType = new GraphQLObjectType({
    name: 'PickupSummeryData',
    description: 'pickup summery page data',
    fields: {
      PickUpRoomNight: { type: GraphQLFloat },
      PickUpRevenue: { type: GraphQLFloat },
      PickUpADR: { type: GraphQLFloat },
      MTDBudgetRoomNight: { type: GraphQLFloat },
      MTDBudgetRevenue: { type: GraphQLFloat },
      MTDForcastRoomNight: { type: GraphQLFloat },
      MTDForcastRevenue: { type: GraphQLFloat },
      OTBBudgetRoomNight: { type: GraphQLFloat },
      OTBBudgetRevenue: { type: GraphQLFloat },
      OTBForcastRoomNight: { type: GraphQLFloat },
      OTBForcastRevenue: { type: GraphQLFloat },
      MonthYear: { type: GraphQLString }
    }
});

module.exports = pickupsummerydataType;