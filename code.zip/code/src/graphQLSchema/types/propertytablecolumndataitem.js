const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt } = graphql

const propertytablecolumndataitem = new GraphQLObjectType({
    name: 'propertytablecolumndataitem',
    description: 'Add KPI Column data Item',
    fields: { 
        id: { type: GraphQLInt },
        displayorder: { type: GraphQLInt },
        columname: { type: GraphQLString },
        columperiod: { type: GraphQLString },
        userid: { type: GraphQLInt }
    }
});

module.exports = propertytablecolumndataitem;
