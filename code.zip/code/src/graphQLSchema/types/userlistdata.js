const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat } = graphql

const singleuserType = new GraphQLObjectType({
  name: 'SingleUserData',
  description: 'Single User data',
  fields: {
    myp_id: { type: GraphQLInt },
    first_name: { type: GraphQLString },
    last_name: { type: GraphQLString },
    email: { type: GraphQLString },
  }
})

const userlisttdataType = new GraphQLObjectType({
    name: 'UserListData',
    description: 'user list data',
    fields: {
      error: { type: GraphQLBoolean },
      message: { type: GraphQLString },
      data : { type: new GraphQLList(singleuserType) }
    }
});


module.exports = userlisttdataType;