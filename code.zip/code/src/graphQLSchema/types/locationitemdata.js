const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const locationitemdata = new GraphQLObjectType({
    name: 'locationitemdata',
    description: 'location item data',
    fields: {
        locationid: { type: GraphQLString }
    }
});

module.exports = locationitemdata;
