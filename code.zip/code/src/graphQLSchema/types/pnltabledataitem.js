const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt } = graphql

const pnltablecolumdata = new GraphQLObjectType({
    name: 'pnltablecolumdata',
    description: 'PNL Table Colum Item Data',
    fields: {
        columnname: { type: GraphQLString },
        columnperiod:{ type: GraphQLString },
        columnvalue: { type: GraphQLString }
    }
});

const pnltabledataitem = new GraphQLObjectType({
    name: 'pnltabledataitem',
    description: 'Pnl Table  Item Data',
    fields: {
        rowname: { type: GraphQLString },
        roworder:{type:GraphQLInt},
        id: {type:GraphQLInt},
        parentid:{type:GraphQLInt},
        glcode: { type: GraphQLString },
        rowdata: { type: new graphql.GraphQLList(pnltablecolumdata) }
    }
});

module.exports = pnltabledataitem;
