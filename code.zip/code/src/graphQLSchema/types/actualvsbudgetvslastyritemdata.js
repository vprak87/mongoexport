const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const actualvsbudgetvslastyritemdata = new GraphQLObjectType({
    name: 'actualvsbudgetvslastyritemdata',
    description: 'actualvsbudgetvslastyr item data',
    fields: {
        rractual:{ type: GraphQLString },
        fbactual:{ type: GraphQLString },
        oiactual:{ type: GraphQLString },     
        toactual:{ type: GraphQLString },  
        rrlastyear:{ type: GraphQLString },
        fblastyear:{ type: GraphQLString } ,   
        oilastyear:{ type: GraphQLString },
        tolastyear:{ type: GraphQLString } , 
        rrbudget:{ type: GraphQLString },
        fbbudget:{ type: GraphQLString },   
        oibudget:{ type: GraphQLString },     
        tobudget:{ type: GraphQLString }
    }
});

module.exports = actualvsbudgetvslastyritemdata;
