const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt,GraphQLBoolean} = graphql

const mdoglcodemasterdata = new GraphQLObjectType({
    name: 'mdoglcodemasterdata',
    description: 'mdo glcode master data',
    fields: {       
        _id: { type: GraphQLString },
        ID: { type: GraphQLInt },
        GLCode:{ type: GraphQLString },
        Description:{ type: GraphQLString },
        DisplayDescription: { type: GraphQLString },
        ParentId: { type: GraphQLInt },
        IsActive: { type: GraphQLBoolean }
    }
});

module.exports = mdoglcodemasterdata;