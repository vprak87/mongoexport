const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const kpikeyitem = new GraphQLObjectType({
    name: 'kpikeyitem',
    description: 'kpi key Item',
    fields: {
        KPIKey: { type: GraphQLString }
    }
});

module.exports = kpikeyitem;
