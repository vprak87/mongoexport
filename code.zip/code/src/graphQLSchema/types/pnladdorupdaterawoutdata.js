const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat, GraphQLInputObjectType } = graphql;

const pnlRawItemDataModelList2Type = new GraphQLObjectType({
  name: 'PnLrawItemDataModelList2',
  description: 'PnL Raw Item Model List2 Data',
  fields: {
    Raw_Name: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Enable: { type: GraphQLBoolean },
    Highlighted: { type: GraphQLBoolean },
    Merged: { type: GraphQLBoolean }
  }
});

const pnlGroupDataModelList2Type = new GraphQLObjectType({
  name: 'PnLGroupDataModelList2',
  description: 'PnL Group Model List2 Data',
  fields: {
    Group_Name: { type: GraphQLString },
    Group_Title: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Items: { type: new GraphQLList(pnlRawItemDataModelList2Type) },
  }
});

const pnlraworderdataoutType = new GraphQLObjectType({
    name: 'Mutation2',
    description: 'PnL raw order data',
    fields: {
      User_ID: { type: graphql.GraphQLInt },
      Hotel_ID: { type: graphql.GraphQLInt },
      Pnl_view: { type: graphql.GraphQLString },
      Created_at: { type: graphql.GraphQLString },
      Groups: { type: new GraphQLList(pnlGroupDataModelList2Type) },
    }
});

module.exports = pnlraworderdataoutType;