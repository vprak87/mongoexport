const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const membershipstaysitemdata = 
new GraphQLObjectType({ 
    name: 'membershipstaysitemdata', 
    description: 'Membership Stays Item Type', 
    fields: { 
        label: { type: GraphQLString }, 
        value: { type: GraphQLString }, 
        color: { type: GraphQLString } 
    } 
});

module.exports = membershipstaysitemdata;
