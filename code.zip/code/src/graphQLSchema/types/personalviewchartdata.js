const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLFloat, GraphQLInt, GraphQLList, GraphQLScalarType} = graphql

const TimestampType = new GraphQLScalarType({
    name: 'Timestamp',
    serialize(date) {
      return date.toISOString()
    },
    parseValue(date) {
      try           { return new Date(value); }
      catch (error) { return null; }
    },
    parseLiteral(ast) {
      if (ast.kind === Kind.INT) {
        return new Date(parseInt(ast.value, 10));
      }
      else if (ast.kind === Kind.STRING) {
        return this.parseValue(ast.value);
      }
      else {
        return null;
      }
    },
});
const defaults = {

};
const chartdata = new GraphQLObjectType({
  name: 'ChartData',
  description: 'Personel View - chart details',
  fields: {
    date: { type: TimestampType },
    kpikey: { type: GraphQLString},
    displayname: { type: GraphQLString},
    actualvalue: { type: GraphQLString},
    lyvalue: { type: GraphQLString},
    budgetvalue: { type: GraphQLString},
    forcastvalue: { type: GraphQLString},
    actualunit: { type: GraphQLString},    
  }
})
const personalviewchartdataType = new GraphQLObjectType({
    name: 'PersonalViewChartData',
    description: 'Personal View - Chart Data',
    fields: {
        AllStatsData: { type: new GraphQLList(chartdata)}
    }
});

module.exports = personalviewchartdataType;