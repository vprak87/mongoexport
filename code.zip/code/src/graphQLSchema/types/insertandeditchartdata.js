const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString} = graphql;

const insertandeditchartdataType = new GraphQLObjectType({
    name: 'insert_and_edit',
    description: 'chart_data',
    fields: {
        _id:{ type: GraphQLString },
        userid:{ type: GraphQLString },
        templateid:{ type: GraphQLString },
        graphid:{ type: GraphQLString },
        tempname:{ type: GraphQLString }
    }
});

module.exports = insertandeditchartdataType;