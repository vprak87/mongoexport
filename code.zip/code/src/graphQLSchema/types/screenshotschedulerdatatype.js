const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt} = graphql

const screenshotschedulerdataType = new GraphQLObjectType({
    name: 'screenshotscheduler',
    description: 'screenshot scheduler data Type',
    fields: {
        _id:{ type: GraphQLString },
        ID:{ type: GraphQLInt },
        BaseURL:{ type: GraphQLString },
        Page: { type: GraphQLString },
        SchedulePageURL:{ type: GraphQLString },
        CreatedDate:{ type: GraphQLString },
        UserID:{ type: GraphQLInt },
    }
});

module.exports = screenshotschedulerdataType;