const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const weatherdata = new GraphQLObjectType({
    name: 'weatherdata',
    description: 'weather Data',
    fields: {
        id:{ type: GraphQLString },
        city: { type: GraphQLString },
        stateiso: { type: GraphQLString },
        countrycode: { type: GraphQLString },
        period:{ type: GraphQLString }, 
        date: { type: GraphQLString },
        temperaturecmin: { type: GraphQLString },
        temperaturecmax: { type: GraphQLString },
        temperaturecavg: { type: GraphQLString },
        temperaturefmin: { type: GraphQLString },
        temperaturefmax: { type: GraphQLString },
        winddirection: { type: GraphQLString },
        windspeedkmh: { type: GraphQLString },
        windspeedmph: { type: GraphQLString },
        poppercentday: { type: GraphQLString },            
        fxiconday: { type: GraphQLString },
        fxconditionday: { type: GraphQLString }    
    }
});

module.exports = weatherdata;
