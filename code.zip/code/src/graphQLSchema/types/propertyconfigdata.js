const graphql = require('graphql');
const { GraphQLObjectType, GraphQLInt, GraphQLBoolean, GraphQLFloat } = graphql

const propertyconfigdata = new GraphQLObjectType({
    name: 'propertyconfigdata',
    description: 'Property Config Data',
    fields: {
        userid: { type: GraphQLInt },
        rollingrevenuecomparision: { type: GraphQLBoolean },
        revenuebreakdowan: { type: GraphQLBoolean },
        actvsbudvslastyr: { type: GraphQLBoolean },
        adrvsrevpar: { type: GraphQLBoolean },
        dashboardocc: { type: GraphQLBoolean },
        dashboardadr: { type: GraphQLBoolean },
        dashboardrevpar: { type: GraphQLBoolean },
        membershipstays: { type: GraphQLBoolean },
        dashboardmarketcurrentvslastyear: { type: GraphQLBoolean },
        cashwidget: { type: GraphQLBoolean },
        guestledgerwidget: { type: GraphQLBoolean },
        payrollactualvsplanwidget: { type: GraphQLBoolean },
        strwidget: { type: GraphQLBoolean },
        tripadvisorratingwidget: { type: GraphQLBoolean },
        googleplaceratingwidget: { type: GraphQLBoolean },
        facebookpagewidget: { type: GraphQLBoolean },
        yelpreviewwidget: { type: GraphQLBoolean },
        weatherwidget: { type: GraphQLBoolean },
        aragingwidget: { type: GraphQLBoolean },
        gsspriority: { type: GraphQLBoolean },
        ooocompwidget: { type: GraphQLBoolean },
        totalprofit: { type: GraphQLBoolean },
        totalexpensebreakdown: { type: GraphQLBoolean },
        expensebudgetdepartment: { type: GraphQLBoolean },
        expensebudgetcategory: { type: GraphQLBoolean },
        invoicevscreditcard: { type: GraphQLBoolean },
        expenseformbyglcode: { type: GraphQLBoolean },
    }
});

module.exports = propertyconfigdata;
