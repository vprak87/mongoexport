const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat, GraphQLInputObjectType } = graphql;

const pnlRawItemDataModelListType = new GraphQLInputObjectType({
  name: 'PnLrawItemDataModelList',
  description: 'PnL Raw Item Model List Data',
  fields: {
    Raw_Name: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Enable: { type: GraphQLBoolean },
    Highlighted: { type: GraphQLBoolean },
    Merged: { type: GraphQLBoolean }
  }
});

const pnlGroupDataModelListType = new GraphQLInputObjectType({
  name: 'PnLGroupDataModelList',
  description: 'PnL Group Model List Data',
  fields: {
    Group_Name: { type: GraphQLString },
    Group_Title: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Items: { type: new GraphQLList(pnlRawItemDataModelListType) },
  }
});

// const pnlraworderdataType = new GraphQLObjectType({
//     name: 'PnLraworderData',
//     description: 'PnL raw order data',
//     fields: {
//       Items: { type: new GraphQLList(pnlMonthItemDataModelListType) },
//       RevenueList: { type: new GraphQLList(pnlMonthDataModelListType) },
//       ExpenseList: { type: new GraphQLList(pnlMonthDataModelListType) },
//       LabourExpenseList: { type: new GraphQLList(pnlMonthDataModelListType) },
//       TaxList: { type: new GraphQLList(pnlMonthDataModelListType) },
//       NetBeforeTaxList: { type: new GraphQLList(pnlMonthDataModelListType) },
//       NetProfitList: { type: new GraphQLList(pnlMonthDataModelListType) },
//       NetProfitMarginList: { type: new GraphQLList(pnlMonthDataModelListType) },
//       CategoryList: { type: new GraphQLList(GraphQLString) },
//       Year: { type: GraphQLInt },
//       OrgId: { type: GraphQLInt },
//       LaborDataType: { type: GraphQLString }
//     }
// });

module.exports = pnlGroupDataModelListType;