const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt } = graphql

const createkpidataitem = new GraphQLObjectType({
    name: 'createkpidataitem',
    description: 'Create KPI data Item',
    fields: {
        _id: { type: GraphQLString },
        ID: { type: GraphQLInt },
        CreateOwnTableMasterID: { type: GraphQLInt },
        DisplayOrder: { type: GraphQLInt },
        UserID: { type: GraphQLInt },
        UpdateDateTime: { type: GraphQLString }
    }
});

module.exports = createkpidataitem;
