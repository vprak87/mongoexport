const graphql = require('graphql');
const { GraphQLObjectType, GraphQLInt, GraphQLBoolean, GraphQLFloat } = graphql

const scorecardconfigdata = new GraphQLObjectType({
    name: 'scorecardconfigdata',
    description: 'Scorecard Config Data',
    fields: {
        userid: { type: GraphQLInt },
        scorecardrevenuewidget: { type: GraphQLBoolean },
        scorecardstrwidget: { type: GraphQLBoolean },
        scorecardlabourwidget: { type: GraphQLBoolean },
        scorecardprofitwidget: { type: GraphQLBoolean },
        scorecardservicewidget: { type: GraphQLBoolean },
        scorecardtotalrevenueper: { type: GraphQLFloat },
        scorecardstrcurrentmonthper: { type: GraphQLFloat },
        scorecardlabourporvariance: { type: GraphQLFloat },
        scorecardservicescore: { type: GraphQLFloat },
        scorecardserviceweightedper: { type: GraphQLFloat },

    }
});

module.exports = scorecardconfigdata;
