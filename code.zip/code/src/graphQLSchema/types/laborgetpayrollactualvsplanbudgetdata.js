const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList} = graphql
const DepartmentList = new GraphQLObjectType({
    name: 'DepartmentList',
    description: 'Labor Data - Department List',
    fields: {
        Name: { type: GraphQLString }
    }
});
const PayrollActualvsPlanBudget_Wages = new GraphQLObjectType({
    name: 'PayrollActualvsPlanBudgetWages',
    description: 'Labor Data - PayrollActualvsPlanBudget_Wages',
    fields: {
        Actual: { type: GraphQLString },
        Plan: { type: GraphQLString },
        OT_Wages: { type: GraphQLString },
        Variance: { type: GraphQLString },
        POR_Actual:{ type: GraphQLString },
        POR_Plan:{ type: GraphQLString },
        POR_Variance:{ type: GraphQLString },      
        Actual1:{ type: GraphQLString },
        Plan1:{ type: GraphQLString },
        OT_Wages1:{ type: GraphQLString },
        Variance1:{ type: GraphQLString },
        POR_Actual1:{ type:  GraphQLString },
        POR_Plan1:{ type:  GraphQLString },
        POR_Variance1:{ type:  GraphQLString }

    }
});
const laborgetpayrollactualvsbudgetdataType = new GraphQLObjectType({
    name: 'PayrollActualvsPlanBudget',
    description: 'Labor Data - Payroll Actual vs PlanBudget',
    fields: {
        IsHotelEffectiveness: { type: GraphQLString },
        headertopic1: { type: GraphQLString },
        headertopic2: { type: GraphQLString },
        headersubtopic1: { type: GraphQLString },
        headersubtopicfrom2:{ type: GraphQLString },
        headersubtopicto2:{ type: GraphQLString },
        departmentlist:{ type: new GraphQLList(DepartmentList)},
        payrollactualvsplanbudget:{ type: new GraphQLList(PayrollActualvsPlanBudget_Wages)}
    }
});

module.exports = laborgetpayrollactualvsbudgetdataType