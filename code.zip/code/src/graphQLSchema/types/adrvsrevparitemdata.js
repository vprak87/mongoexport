const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const adrvsrevparitemdata = 
new GraphQLObjectType({ 
    name: 'adrvsrevparitemdata', 
    description: 'ADR VS RevPAR Item Type', 
    fields: { 
        adr: { type: GraphQLString }, 
        revpar: { type: GraphQLString }, 
        date: { type: GraphQLString } 
        } 
});

module.exports = adrvsrevparitemdata;
