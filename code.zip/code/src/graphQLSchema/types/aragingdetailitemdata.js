const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const aragingdetailitemdata = new GraphQLObjectType({
    name: 'aragingdetailitemdata',
    description: 'AR Aging Detail Data',
    fields: {
        hotelid: { type: GraphQLString },
        orgId: { type: GraphQLString },
        hotelname:{ type: GraphQLString },
        ishotelgroup:{ type: GraphQLString },
        organisationname:{ type: GraphQLString },           
        dmrasubtype: { type: GraphQLString },   
        description:{ type: GraphQLString },      
        unapplied_credits: { type: GraphQLString },
        due_0_30: { type: GraphQLString },
        due_31_60: { type: GraphQLString },
        due_61_90: { type: GraphQLString },
        due_91_120: { type: GraphQLString },
        over_120: { type: GraphQLString },
        total: { type: GraphQLString },
        houseledger: { type: GraphQLString },
        advdeposit: { type: GraphQLString },
        totalar: { type: GraphQLString },
        daysInar: { type: GraphQLString },
        daysInarhouse: { type: GraphQLString },
        totalrevenue: { type: GraphQLString },            
        date: { type: GraphQLString },
        totalrevenue: { type: GraphQLString },
    }
});

module.exports = aragingdetailitemdata;
