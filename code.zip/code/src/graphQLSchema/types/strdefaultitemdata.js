const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLFloat, GraphQLInt, GraphQLList } = graphql


const STRdefaultdataType = new GraphQLObjectType({
    name: 'strdefaultdata',
    description: 'STR (Default) - Line Item Data',
    fields: {
        myproperty: { type: GraphQLFloat },
        mypropertychange: { type: GraphQLFloat },
        index: { type: GraphQLFloat },
        indexchange: { type: GraphQLFloat }
    }
});


const strdefaultitemdataType = new GraphQLObjectType({
    name: 'strdefaultitemdata',
    description: 'STR Report Data (Default)',
    fields: {
        month: { type: GraphQLString },
        week: { type: GraphQLString },
        day: { type: GraphQLString },
        date: { type: GraphQLString },
        displaydate: { type: GraphQLString },
        occupancy: { type: STRdefaultdataType },
        adr: { type: STRdefaultdataType },
        revpar: { type: STRdefaultdataType }
    }
});


module.exports = strdefaultitemdataType;

