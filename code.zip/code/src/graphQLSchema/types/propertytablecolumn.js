
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt } = graphql

const propertytablecolumn = new GraphQLObjectType({
    name: 'propertytablecolumn',
    description: 'Column GraphQL Object Schemal Model',
    fields: {
        columname: { type: graphql.GraphQLString },
        columperiod: { type: graphql.GraphQLString }
    }
});

module.exports = propertytablecolumn;
