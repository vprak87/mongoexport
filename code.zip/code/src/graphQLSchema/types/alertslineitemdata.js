const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLBoolean } = graphql

const alertslineitemdataType = new GraphQLObjectType({
    name: 'alertslineitemdata',
    description: 'Alerts Line Item',
    fields: {
        title: { type: GraphQLString },
        message: { type: GraphQLString },
        type: { type: GraphQLString },
        hotelname: { type: GraphQLString },
        issuccess: { type: GraphQLBoolean },
    }
});

module.exports = alertslineitemdataType;

