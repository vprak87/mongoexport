const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLFloat} = graphql;


const laborgethousekeepingperroomdataType = new GraphQLObjectType({
    name: 'LaborHousekeepingPerRoom',
    description: 'Labor Data - Housekeeping Per Room',
    fields: {
        header:{ type: GraphQLString },
        value:{ type: GraphQLFloat },
        title:{ type: GraphQLString },  
        IsHotelEffectiveness:{ type: GraphQLString }     
    }
});

module.exports = laborgethousekeepingperroomdataType;
