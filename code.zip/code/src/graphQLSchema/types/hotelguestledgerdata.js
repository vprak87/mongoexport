const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const hotelguestledgerdata = new GraphQLObjectType({
    name: 'hotelguestledgerdata',
    description: 'Hotel Guest Ledger ',
    fields: {
        hotelid: { type: GraphQLString },
        beginingbalance:{ type: GraphQLString },     
        endingbalance:{ type: GraphQLString },
        debit: { type: GraphQLString },
        credit:{ type: GraphQLString },     
        description:{ type: GraphQLString }
    }
});

module.exports = hotelguestledgerdata;


