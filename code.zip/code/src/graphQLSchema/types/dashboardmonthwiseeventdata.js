const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const dashboardmonthwiseeventdata = new GraphQLObjectType({
    name: 'dashboardmonthwiseeventdata',
    description: 'Dashboard Month Wise Event Item',
    fields: {
        eventname: { type: GraphQLString },
        description: { type: GraphQLString },
        hotelname:{ type: GraphQLString },
        startdate:{ type: GraphQLString }
    }
});

module.exports = dashboardmonthwiseeventdata;
