const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList} = graphql
const DepartmentList = new GraphQLObjectType({
    name: 'DepartmentListHours',
    description: 'Labor Data - Department List',
    fields: {
        Name: { type: GraphQLString }
    }
});
const PayrollActualvsPlanBudget_Hours = new GraphQLObjectType({
    name: 'PayrollActualvsPlanBudget_Hours',
    description: 'Labor Data - PayrollActualvsPlanBudget_Hours',
    fields: {
        ActualHoursMTD: { type: GraphQLString },
        PlanHoursMTD: { type: GraphQLString },
        OTHoursMTD:{ type: GraphQLString },      
        VarianceHoursMTD: { type: GraphQLString },
        ActualPORHoursMTD: { type: GraphQLString },
        PlanPORHoursMTD: { type: GraphQLString },
        VariancePORHoursMTD: { type: GraphQLString }, 
        ActualHours: { type: GraphQLString },
        PlanHours: { type: GraphQLString },
        OTHours:{ type: GraphQLString },       
        VarianceHours: { type: GraphQLString },
        ActualPORHours: { type: GraphQLString },
        PlanPORHours: { type: GraphQLString },
        VariancePORHours: { type: GraphQLString },     
        ActualHoursWTD: { type: GraphQLString },
        PlanHoursWTD: { type: GraphQLString },
        OTHoursWTD:{ type: GraphQLString },        
        VarianceHoursWTD: { type: GraphQLString },
        ActualPORHoursWTD: { type: GraphQLString },
        PlanPORHoursWTD: { type: GraphQLString },
        VariancePORHoursWTD: { type: GraphQLString }
    }
});
const laborgetpayrollactualvsbudgethoursdataType = new GraphQLObjectType({
    name: 'PayrollActualvsPlanBudgetHours',
    description: 'Labor Data - Payroll Actual vs PlanBudget Hours',
    fields: {
        IsHotelEffectiveness: { type: GraphQLString },
        headertopic1: { type: GraphQLString },
        headertopic2: { type: GraphQLString },
        headersubtopic1: { type: GraphQLString },
        headersubtopicfrom2:{ type: GraphQLString },
        headersubtopicto2:{ type: GraphQLString },
        departmentlist:{ type: new GraphQLList(DepartmentList)},
        payrollactualvsplanbudgethours:{ type: new GraphQLList(PayrollActualvsPlanBudget_Hours)}
    }
});

module.exports = laborgetpayrollactualvsbudgethoursdataType