const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const scorecardprofitlineitemdataType = new GraphQLObjectType({
    name: 'ScorecardProfitLineItemData',
    description: 'Scorecard ProfitData - Line Items',
    fields: {
        title: { type: GraphQLString },
        actual: { type: GraphQLString },
        actualpercentage: { type: GraphQLString },
        plan: { type: GraphQLString },
        planpercentage: { type: GraphQLString },
        variance: { type: GraphQLString },
        variancepercentage: { type: GraphQLString },
        variancetooltip: { type: GraphQLString },
        variancetooltipcolor: { type: GraphQLString },
        lastyear: { type: GraphQLString },
        lastyearpercentage: { type: GraphQLString },
        lastyearvariance: { type: GraphQLString },
        lastyearvariancepercentage: { type: GraphQLString },
        lastyearvariancetooltip: { type: GraphQLString },
        lastyearvariancetooltipcolor: { type: GraphQLString }
    }
});

module.exports = scorecardprofitlineitemdataType;

