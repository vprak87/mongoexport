const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt} = graphql

const createtnewpersonalviewdataType = new GraphQLObjectType({
    name: 'CreateTemplate',
    description: 'Create new template',
    fields: {
        _id:{ type: GraphQLString },
        userid:{ type: GraphQLInt },
        name:{ type: GraphQLString },
        description:{ type: GraphQLString },
        templateid:{ type: GraphQLString }
    }
});

module.exports = createtnewpersonalviewdataType;