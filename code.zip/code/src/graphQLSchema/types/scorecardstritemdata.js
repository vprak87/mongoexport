const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList, GraphQLFloat } = graphql

const STRChangeoverPYType = new GraphQLObjectType({
    name: 'strchangeoverpy',
    description: 'Scorecard STR - % Change over PY Data',
    fields: {
        monthname: { type: GraphQLString },
        occ: { type: GraphQLString },
        occtooltip: { type: GraphQLString },
        occtooltipcolor: { type: GraphQLString },
        adr: { type: GraphQLString },
        adrtooltip: { type: GraphQLString },
        adrtooltipcolor: { type: GraphQLString },
        revpar: { type: GraphQLString },
        revpartooltip: { type: GraphQLString },
        revpartooltipcolor: { type: GraphQLString }
    }
});


const STRChangeoverPYChartType = new GraphQLObjectType({
    name: 'strchangeoverpychartdata',
    description: 'Scorecard STR - % Change over PY Chart Data',
    fields: {
        monthname: { type: GraphQLString },
        occ: { type: GraphQLFloat },
        adr: { type: GraphQLFloat },
        revpar: { type: GraphQLFloat }
    }
});



const STRIndexChangeType = new GraphQLObjectType({
    name: 'strindexchangedata',
    description: 'Scorecard STR - Index % Change Data',
    fields: {
        monthname: { type: GraphQLString },
        occ: { type: GraphQLString },
        occtooltip: { type: GraphQLString },
        occtooltipcolor: { type: GraphQLString },
        adr: { type: GraphQLString },
        adrtooltip: { type: GraphQLString },
        adrtooltipcolor: { type: GraphQLString },
        revpar: { type: GraphQLString },
        revpartooltip: { type: GraphQLString },
        revpartooltipcolor: { type: GraphQLString }
    }
});

const STRIndexChangeChartType = new GraphQLObjectType({
    name: 'strindexchangechartdata',
    description: 'Scorecard STR - Index % Change Chart Data',
    fields: {
        monthname: { type: GraphQLString },
        occ: { type: GraphQLFloat },
        adr: { type: GraphQLFloat },
        revpar: { type: GraphQLFloat }
    }
});


const STRRankType = new GraphQLObjectType({
    name: 'strrankdata',
    description: 'Scorecard STR - Rank Data',
    fields: {
        monthname: { type: GraphQLString },
        occ: { type: GraphQLString },
        occtooltip: { type: GraphQLString },
        occtooltipcolor: { type: GraphQLString },
        adr: { type: GraphQLString },
        adrtooltip: { type: GraphQLString },
        adrtooltipcolor: { type: GraphQLString },
        revpar: { type: GraphQLString },
        revpartooltip: { type: GraphQLString },
        revpartooltipcolor: { type: GraphQLString }
    }
});

const STRRankChartType = new GraphQLObjectType({
    name: 'strrankchartdata',
    description: 'Scorecard STR - Rank Chart Data',
    fields: {
        monthname: { type: GraphQLString },
        occ: { type: GraphQLFloat },
        adr: { type: GraphQLFloat },
        revpar: { type: GraphQLFloat }
    }
});

const scorecardstritemdataType = new GraphQLObjectType({
    name: 'scorecardstritemdata',
    description: 'Scorecard STR Data',
    fields: {
        strchangeoverpydata: { type: new GraphQLList(STRChangeoverPYType) },
        strchangeoverpychartdata: { type: new GraphQLList(STRChangeoverPYChartType) },
        strindexchangedata: { type: new GraphQLList(STRIndexChangeType) },
        strindexchangechartdata: { type: new GraphQLList(STRIndexChangeChartType) },
        strrankdata: { type: new GraphQLList(STRRankType) },
        strrankchartdata: { type: new GraphQLList(STRRankChartType) },

    }
});



module.exports = scorecardstritemdataType;

