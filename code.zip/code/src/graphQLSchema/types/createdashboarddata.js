const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt} = graphql

const createdashboarddataType = new GraphQLObjectType({
    name: 'CreateDashboard',
    description: 'Load Custome Templates',
    fields: {
        id: { type: GraphQLString },
        ID: { type: GraphQLInt },
        name: { type: GraphQLString }
    }
});

module.exports = createdashboarddataType;