const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt,GraphQLBoolean,GraphQLScalarType } = graphql

 const DateFormatType = new GraphQLScalarType({
     name: 'DateFormat',
     serialize(date) {
       return date.toISOString()
    },
    parseValue(date) {
       try           { return new Date(value); }
       catch (error) { return null; }
    },
     parseLiteral(ast) {
       if (ast.kind === Kind.INT) {
         return new Date(parseInt(ast.value, 10));
       }      else if (ast.kind === Kind.STRING) {
        return this.parseValue(ast.value);
       }
       else {         return null;      }
     },
 });
const outoforderbyreasontype = new GraphQLObjectType({
    name: 'outoforderbyreasontype',
    description: 'outoforderbyreasondata List',
    fields: {
 
        ID: { type: GraphQLInt },
        HotelID: { type: GraphQLInt },
         DateFrom: { type: GraphQLString },
         DateTo: { type: GraphQLString },
         NoOfRooms: { type: GraphQLInt },
    //     ReportedDate: { type: DateFormatType },
     ReasonCode: { type: GraphQLString },
     Description: { type: GraphQLString },
         RoomType: { type: GraphQLString },
         Status: { type: GraphQLString },
    //     ReturnStatus: { type: GraphQLString },
         Remarks: { type: GraphQLString },
    // UpdatedBy: { type: GraphQLString },
    //     UpdatedDateTime: { type: DateFormatType},
    //     IsDelete: { type: GraphQLBoolean }
    
    
    
    }
});

module.exports = outoforderbyreasontype;


