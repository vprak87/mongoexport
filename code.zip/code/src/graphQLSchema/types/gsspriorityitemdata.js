const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const gsspriorityitemdata = new GraphQLObjectType({
    name: 'gsspriorityitemdata',
    description: 'gsspriorityitemdata',
    fields: {
        description: { type: GraphQLString },  
        actualgss: { type: GraphQLString },  
        actualgssly: { type: GraphQLString },
        benchmarkgss: { type: GraphQLString },
        totalgss: { type: GraphQLString },
        chart: { type: GraphQLString }
    }
});

module.exports = gsspriorityitemdata;
