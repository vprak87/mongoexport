const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const rollingrevenueitemdata = 
new GraphQLObjectType({ 
    name: 'rollingrevenueitemdata', 
    description: 'Rolling Revenue Item Type', 
    fields: { 
            actual: { type: GraphQLString }, 
            budget: { type: GraphQLString }, 
            forecast: { type: GraphQLString }, 
            date: { type: GraphQLString } 
        }
});

module.exports = rollingrevenueitemdata;
