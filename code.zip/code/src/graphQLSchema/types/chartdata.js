const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString } = graphql

const chartdata = new GraphQLObjectType({
    name: 'chart',
    description: 'Chart List',
    fields: {
        _id:{ type: GraphQLString },
        Name: { type: GraphQLString }
        
    }
});

module.exports = chartdata;


