const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt } = graphql

const portfoliostatsdata = new GraphQLObjectType({
    name: 'portfoliostatsdata',
    description: 'Portfolio Stats Item Data',
    fields: {
        kpikey: { type: GraphQLString },
        displayname: { type: GraphQLString },
        actualvalue: { type: GraphQLString },
        actualunit: { type: GraphQLString },
        variancelevel: { type: GraphQLString },
        tooltip: { type: GraphQLString }
    }
});

const portfoliokpigroupdata = new GraphQLObjectType({
    name: 'portfoliokpigroupdata',
    description: 'Portfolio KPI Group Item Data',
    fields: {
        kpigroupid: { type: GraphQLInt },
        kpigroupname: { type: GraphQLString },
        kpigroupcolor: { type: GraphQLString },
        stats: { type: new graphql.GraphQLList(portfoliostatsdata) }
    }
});

const portfoliohoteldata = new GraphQLObjectType({
    name: 'portfoliohoteldata',
    description: 'Portfolio Hotel Item Data',
    fields: {
        hotelid: { type: GraphQLInt },
        hotelname: { type: GraphQLString },
        kpigroups: { type: new graphql.GraphQLList(portfoliokpigroupdata) }
    }
});




const portfoliogroupdata = new GraphQLObjectType({
    name: 'portfoliogroupdata',
    description: 'Portfolio Group Item Data',
    fields: {
        groupid: { type: GraphQLInt },
        groupname: { type: GraphQLString },
        hotels: { type: new graphql.GraphQLList(portfoliohoteldata) }

    }
});

const portfoliodataitem = new GraphQLObjectType({
    name: 'portfoliodataitem',
    description: 'Portfolio Item Data',
    fields: {
        groups: { type: new graphql.GraphQLList(portfoliogroupdata) },
        portfoliostats: { type: portfoliohoteldata }

    }
});

module.exports = portfoliodataitem;
