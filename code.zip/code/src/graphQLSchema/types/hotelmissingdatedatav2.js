const graphql = require('graphql');
const { GraphQLObjectType, GraphQLInt, GraphQLString, GraphQLList } = graphql

const hotelmissingdatedatav2 = new GraphQLObjectType({
    name: 'hotelmissingdatedatav2',
    description: 'Missing Data List',
    fields: {
        HTMLOutput: { type: GraphQLString },
        Type: { type: GraphQLString },
        HotelID: { type: GraphQLInt }

    }
});

module.exports = hotelmissingdatedatav2;


