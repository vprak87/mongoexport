const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLFloat} = graphql

const laborgetactualvspayrolldataType = new GraphQLObjectType({
    name: 'LaborActualvsPayrollData',
    description: 'Labor Data - Actual vs Payroll',
    fields: {
        Type: { type: GraphQLString },
        Category: { type: GraphQLString },
        PayrollActual: { type: GraphQLFloat },
        PayrollBudget: { type: GraphQLFloat },
    }
});

module.exports = laborgetactualvspayrolldataType;

