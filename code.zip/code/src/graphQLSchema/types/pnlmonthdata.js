const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat } = graphql;

const pnlMonthDataModelListType = new GraphQLObjectType({
  name: 'PnLmonthlyDataModelList',
  description: 'PnL Monthly Model List Data',
  fields: {
    Name: { type: GraphQLString },
    Amount: { type: GraphQLFloat },
    Category: { type: GraphQLString },
    IsActive: { type: GraphQLBoolean },
    MonthName: { type: GraphQLString },
    GLCode: { type: GraphQLString },
  }
});

const pnlMonthItemDataModelListType = new GraphQLObjectType({
  name: 'PnLMonthlyitemDataModelList',
  description: 'PnL Monthly item Model List Data',
  fields: {
    Period: { type: GraphQLString },
    TotalSales: { type: GraphQLFloat },
    TotalExpenses: { type: GraphQLFloat },
    NetProfitBeforeTax: { type: GraphQLFloat },
    TotalTaxes: { type: GraphQLFloat },
    NetProfit: { type: GraphQLFloat },
    RevenueList: { type: new GraphQLList(pnlMonthDataModelListType) },
    TaxList: { type: new GraphQLList(pnlMonthDataModelListType) },
    ExpenseList: { type: new GraphQLList(pnlMonthDataModelListType) },
    LabourExpenseList: { type: new GraphQLList(pnlMonthDataModelListType) },
  }
});


const pnlrawsItemData2ModelListType = new GraphQLObjectType({
  name: 'PnLrawsItemData2ModelList',
  description: 'PnL raw Item Model List Data',
  fields: {
    Raw_Name: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Enable: { type: GraphQLBoolean },
    Highlighted: { type: GraphQLBoolean },
    Merged: { type: GraphQLBoolean },
  }
});

const pnlrawGroupDataModel2ListType = new GraphQLObjectType({
  name: 'PnLrawGroupData2ModelList',
  description: 'PnL raw Group Model List Data',
  fields: {
    Group_Name: { type: GraphQLString },
    Group_Title: { type: GraphQLString },
    Order_ID: { type: GraphQLInt },
    Items: { type: new GraphQLList(pnlrawsItemData2ModelListType) },
  }
});

const pnlrawOrderDataModel2ListType = new GraphQLObjectType({
  name: 'PnLrawOrderData2ModelList',
  description: 'PnL raw order Model List Data',
  fields: {
    User_ID: { type: GraphQLInt },
    Hotel_ID: { type: GraphQLInt },
    Pnl_view: { type: GraphQLString },
    Created_at: { type: GraphQLString },
    Groups: { type: new GraphQLList(pnlrawGroupDataModel2ListType) },
  }
});

const pnlcolItemModelListType = new GraphQLObjectType({
  name: 'PnLColItemModelList',
  description: 'PnL col item Model List Data',
  fields: {
    Id: { type: GraphQLInt },
    Type: { type: GraphQLString },
    Title: { type: GraphQLString },
    DataKey: { type: GraphQLString },
  }
});

const pnlcolOrderDatasetModelListType = new GraphQLObjectType({
  name: 'PnLcolOrderDatasetModelList',
  description: 'PnL col order data set Model List Data',
  fields: {
    Id: { type: GraphQLInt },
    Type: { type: GraphQLString },
    Title: { type: GraphQLString },
    Color: { type: GraphQLString },
    DataKey: { type: GraphQLString },
    Cols: { type: new GraphQLList(pnlcolItemModelListType) },
  }
});

const pnlcolOrderDataModelListType = new GraphQLObjectType({
  name: 'PnLcolOrderData2ModelList',
  description: 'PnL col order Model List Data',
  fields: {
    User_ID: { type: GraphQLInt },
    Hotel_ID: { type: GraphQLInt },
    Created_at: { type: GraphQLString },
    Data: { type: new GraphQLList(pnlcolOrderDatasetModelListType) },
  }
});


const pnlmonthlydataType = new GraphQLObjectType({
    name: 'PnLmonthlyData',
    description: 'PnL monthly section page data',
    fields: {
      Items: { type: new GraphQLList(pnlMonthItemDataModelListType) },
      RevenueList: { type: new GraphQLList(pnlMonthDataModelListType) },
      ExpenseList: { type: new GraphQLList(pnlMonthDataModelListType) },
      LabourExpenseList: { type: new GraphQLList(pnlMonthDataModelListType) },
      TaxList: { type: new GraphQLList(pnlMonthDataModelListType) },
      NetBeforeTaxList: { type: new GraphQLList(pnlMonthDataModelListType) },
      NetProfitList: { type: new GraphQLList(pnlMonthDataModelListType) },
      NetProfitMarginList: { type: new GraphQLList(pnlMonthDataModelListType) },
      CategoryList: { type: new GraphQLList(GraphQLString) },
      Year: { type: GraphQLInt },
      OrgId: { type: GraphQLInt },
      LaborDataType: { type: GraphQLString },
      rawOrder: { type: pnlrawOrderDataModel2ListType },
      colOrder: { type:  pnlcolOrderDataModelListType}
    }
});

module.exports = pnlmonthlydataType;