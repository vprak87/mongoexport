const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt } = graphql

const propertytablecolumdata = new GraphQLObjectType({
    name: 'propertytablecolumdata',
    description: 'Property Table Colum Item Data',
    fields: {
        columnname: { type: GraphQLString },
        columnperiod:{ type: GraphQLString },
        columnvalue: { type: GraphQLString }
    }
});

const propertydashboardtabledataitem = new GraphQLObjectType({
    name: 'propertydashboardtabledataitem',
    description: 'Property Dashboard Table  Item Data',
    fields: {
        rowname: { type: GraphQLString },
        rowdata: { type: new graphql.GraphQLList(propertytablecolumdata) }
    }
});

module.exports = propertydashboardtabledataitem;
