let PnL = require('./pnl');
let PnL2 = require('./pnlmonthly');

module.exports = {
  ...PnL,
  ...PnL2
};