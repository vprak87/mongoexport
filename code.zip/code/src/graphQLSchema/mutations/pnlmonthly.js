const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat } = graphql;

const PnlHelper = require('../../helpers/pnlyear_helper');
const PnlMonthHelper = require('../../helpers/pnlmonthly_helper');

const pnladdorupdatedatarawType = require('../types/pnladdorupdaterawdata');
const pnladdorupdatedatarawoutType = require('../types/pnladdorupdaterawoutdata');

const pnlcolorderdataType = require('../types/pnladdorupdatecolorderdata');
const pnlcolandraworderdataType = require('../types/pnladdorupdatecolorderoutdata');

module.exports = {
  // pnladdorupdaterawdata: {
  //   type: pnladdorupdatedatarawoutType,
  //   description: 'add or update P&L Yearly raw order Section',
  //   args: {
  //       User_ID: { type: graphql.GraphQLInt },
  //       Hotel_ID: { type: graphql.GraphQLInt },
  //       Pnl_view: { type: graphql.GraphQLString },
  //       Groups: { type: new GraphQLList(pnladdorupdatedatarawType) },
  //   },
  //   resolve: (source, { User_ID, Hotel_ID, Pnl_view, Groups }) => {
  //     return new Promise((resolve, reject) => {
  //       PnlHelper.updateOrSaveRawData_GraphQL(User_ID, Hotel_ID, Pnl_view, Groups, (err, result) => {
  //         resolve(result);
  //       });
  //     })
  //   }
  // },
  pnladdorupdatecolorderdata: {
    type: pnlcolandraworderdataType,
    description: 'add or update P&L Monthly col order and raw Section',
    args: {
        User_ID: { type: graphql.GraphQLInt },
        Hotel_ID: { type: graphql.GraphQLInt },
        Pnl_view: { type: graphql.GraphQLString },
        Groups: { type: new GraphQLList(pnladdorupdatedatarawType) },
        Col_order: {type: new GraphQLList(pnlcolorderdataType)}
    },
    resolve: (source, { User_ID, Hotel_ID, Pnl_view, Groups, Col_order }) => {
      return new Promise((resolve, reject) => {
        // PnlHelper.updateOrSaveRawData_GraphQL(User_ID, Hotel_ID, Pnl_view, Groups, (err, result) => {
        //   // resolve(result);
        PnlMonthHelper.editOrSavepnlMonthlyColOrder_GraphQL(User_ID, Hotel_ID, Pnl_view, Groups, Col_order, (err, result) => {
          resolve(result);
        })
      })
    }
  },
}