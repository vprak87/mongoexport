const graphql = require('graphql');
const queries = require('./queries');
const Mutations = require('./mutations');

var rootQuery = new graphql.GraphQLObjectType({
    name: 'Query',
    fields: { ...queries },
});

const mutations = new graphql.GraphQLObjectType({
    name: 'Mutation',
    fields: { ...Mutations }
})

module.exports = new graphql.GraphQLSchema({
    query: rootQuery,
    mutation: mutations
});