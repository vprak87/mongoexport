
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList } = graphql
const PortfolioHelper = require('../../helpers/portfolio_helper');
const dashboardmonthwiseitem = require('../types/dashboardmonthwiseitem');
const portfoliodataitem = require('../types/portfoliodataitem');
const kpidataitem = require('../types/kpidataitem');
const kpicolumndataitem = require('../types/kpicolumndataitem');
const removeresponseitemdata = require('../types/removeresponseitemdata');
const kpikeyitem = require('../types/kpikeyitem');
const createkpigroupdataitem = require('../types/createkpigroupdataitem');
const createkpidataitem = require('../types/createkpidataitem');
const dashboardmonthwiseeventdata =require('../types/dashboardmonthwiseeventdata')
const currancylabledata = require('../types/currancylabledata')
module.exports = {
    dashboardmonthwise: {
        type: new graphql.GraphQLList(dashboardmonthwiseitem),
        description: 'Get Dashboard Month Wise Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            year: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid, year }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.getDashboardMonthWiseData_GraphQL(userid, hotelid, year, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    dashboarddaywise: {
        type: new graphql.GraphQLList(dashboardmonthwiseitem),
        description: 'Get Dashboard Month Wise Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            month: { type: graphql.GraphQLInt },
            year: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid, month, year }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.getDashboardDayWiseData_GraphQL(userid, hotelid, month, year, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    dashboardmonthwiseevent: {
        type: new graphql.GraphQLList(dashboardmonthwiseeventdata),
        description: 'Get Dashboard Month Wise Data Event',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            month: { type: graphql.GraphQLInt },
            year: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid, month, year }) => {
            return new Promise((resolve, reject) => {
                PortfolioHelper.getDashboardMonthWiseEvent_GraphQL(userid, hotelid, month, year, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    portfoliodata: {
        type: portfoliodataitem,
        description: 'Get Portfolio Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
            reportenddate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
            id: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, reportdate, reportenddate, period, id }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.getPortfolioData_GraphQL(userid, reportdate, period, id, reportenddate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    createkpigroup: {
        type: createkpigroupdataitem,
        description: 'Create KPI Group',
        args: {
            userid: { type: graphql.GraphQLInt },
            name: { type: graphql.GraphQLString },
            color: { type: graphql.GraphQLString },
            kpilist: { type: new graphql.GraphQLList(GraphQLString) },
        },
        resolve: (source, { userid, name, color, kpilist }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.createGroup_GraphQL(userid, name, color, kpilist, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    editkpigroup: {
        type: createkpigroupdataitem,
        description: 'Edit KPI Group',
        args: {
            userid: { type: graphql.GraphQLInt },
            groupid: { type: graphql.GraphQLInt },
            name: { type: graphql.GraphQLString },
            color: { type: graphql.GraphQLString },
            kpilist: { type: new graphql.GraphQLList(GraphQLString) },
        },
        resolve: (source, { userid, groupid, name, color, kpilist }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.editGroup_GraphQL(userid, groupid, name, color, kpilist, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    kpimasterlistdata: {
        type: new graphql.GraphQLList(kpidataitem),
        description: 'Get KPI Master List Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            type: { type: graphql.GraphQLString },
        },
        resolve: (source, { userid, type, }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.getKPIMasterListData_GraphQL(userid, type, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    addkpicolumns: {
        type: new graphql.GraphQLList(kpicolumndataitem),
        description: 'Add KPI Columns',
        args: {
            userid: { type: graphql.GraphQLInt },
            kpilist: { type: new graphql.GraphQLList(GraphQLString) },
        },
        resolve: (source, { userid, kpilist }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.addKPIColumns_GraphQL(userid, kpilist, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    reorderkpicolumns: {
        type: new graphql.GraphQLList(kpicolumndataitem),
        description: 'Re-order KPI Columns',
        args: {
            userid: { type: graphql.GraphQLInt },
            type: { type: graphql.GraphQLString },
            kpilist: { type: new graphql.GraphQLList(GraphQLString) },
        },
        resolve: (source, { userid, type, kpilist }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.reorderKPIColumns_GraphQL(userid, type, kpilist, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    removekpicolumn: {
        type: new graphql.GraphQLList(removeresponseitemdata),
        description: 'Remove KPI Column',
        args: {
            userid: { type: graphql.GraphQLInt },
            kpikey: { type: GraphQLString },
        },
        resolve: (source, { userid, kpikey }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.removeKPIColumns_GraphQL(userid, kpikey, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    removekpigroup: {
        type: new graphql.GraphQLList(removeresponseitemdata),
        description: 'Remove KPI Group',
        args: {
            userid: { type: graphql.GraphQLInt },
            groupid: { type: graphql.GraphQLInt },
        },
        resolve: (source, { userid, groupid }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.removeGroup_GraphQL(userid, groupid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    updatekpicolumn: {
        type: createkpidataitem,
        description: 'Update KPI Column',
        args: {
            userid: { type: graphql.GraphQLInt },
            oldkpikey: { type: graphql.GraphQLString },
            newkpikey: { type: graphql.GraphQLString },
        },
        resolve: (source, { userid, oldkpikey, newkpikey }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.updatekpicolumn_GraphQL(userid, oldkpikey, newkpikey, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    currancyexchangelable: {
        type: new graphql.GraphQLList(currancylabledata),
        description: 'Get Google PlaceId ',
        args: {
            userid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid }) => {

            return new Promise((resolve, reject) => {
                PortfolioHelper.getCurrancyExchangeLable_GraphQL(userid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
}

