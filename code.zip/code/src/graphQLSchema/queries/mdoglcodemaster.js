const graphql = require('graphql');

const MDOGLCodeMasterHelper = require('../../helpers/mdoglcodemaster_helper');
const mdoglcodemasterListdataType = require('../types/mdoglcodemasterdata');
const hmgglcodemasterListdataType = require('../types/hmgglcodemasteritem');
const mdoglcodehmgmappingListdataType = require('../types/mdoglcodehmgmappingitem');
const removeresponseitemdata = require('../types/removeresponseitemdata');
const mdoglcodehmgmappingitem = require('../types/mdoglcodehmgmappingitem');
const mdoglcodehmgmappingListInputdataType = require('../types/mdoglcodehmgmappingiteminput');
const mdoglcodemappingtabledata = require('../types/mdoglcodemappingtabledata');

module.exports = {
  getmdoglcodemasterbyparentid: {
    type: new graphql.GraphQLList(mdoglcodemasterListdataType),
      description: 'Get MDO GLCode Master List ',
      args: {
        parentid: { type: graphql.GraphQLInt }
    },
    resolve: (source, { parentid }) => {
          return new Promise((resolve, reject) => {
            MDOGLCodeMasterHelper.getMDOGLCodeMasterByParentId_GraphQL(parentid, (err, result) => {
                  resolve(result);
              });
          })
      }
  },

  getmdoglcodemaster: {
    type: new graphql.GraphQLList(mdoglcodemasterListdataType),
    description: 'Get mdo glcode master List ',
    resolve: (source) => {
          return new Promise((resolve, reject) => {
            MDOGLCodeMasterHelper.getMDOGLCodeMaster_GraphQL((err, result) => {
                  resolve(result);
              });
          })
      }
  },
  createorupdatemdoglcodemaster: {
      type: new graphql.GraphQLList(mdoglcodemasterListdataType),
      description: 'Create screenshotscheduler',
      args: {
        id: { type: graphql.GraphQLInt },              
        glcode: { type: graphql.GraphQLString },
        description: { type: graphql.GraphQLString },
        displaydescription: { type: graphql.GraphQLString },
        parentid: { type: graphql.GraphQLInt },
        isactive: { type: graphql.GraphQLBoolean }
      },
      resolve: (source, {id,glcode, description, displaydescription, parentid,isactive }) => {

          return new Promise((resolve, reject) => {
            MDOGLCodeMasterHelper.createOrUpdateMDOGLCodeMaster_GraphQL(id,glcode, description, displaydescription, parentid,isactive,(err, result) => {
                  resolve(result);
              });
          })
      }
  },   
  removemdoglcodemaster: {
    type: new graphql.GraphQLList(removeresponseitemdata),
    description: 'Remove mdo glcode master',
    args: {
        id: { type: graphql.GraphQLInt }
    },
    resolve: (source, { id }) => {

        return new Promise((resolve, reject) => {
          MDOGLCodeMasterHelper.deleteMDOGLCodeMaster_GraphQL(id, (err, result) => {
                resolve([result]);
            });
        })
    }
},

gethmgglcodemasterbyorganizationid: {
  type: new graphql.GraphQLList(hmgglcodemasterListdataType),
    description: 'Get HMG GLCode Master List ',
    args: {
      organizationid: { type: graphql.GraphQLInt }
  },
  resolve: (source, { organizationid }) => {
        return new Promise((resolve, reject) => {
          MDOGLCodeMasterHelper.getHMGGLCodeMasterByOrganizationID_GraphQL(organizationid, (err, result) => {
                resolve(result);
            });
        })
    }
},

createorupdatehmgglcodemaster: {
    type: new graphql.GraphQLList(hmgglcodemasterListdataType),
    description: 'Create hmg glcode master',
    args: {
      id: { type: graphql.GraphQLString },              
      glcode: { type: graphql.GraphQLString },
      description: { type: graphql.GraphQLString },
      organizationid: { type: graphql.GraphQLInt },
      isactive: { type: graphql.GraphQLBoolean }
    },
    resolve: (source, {id,glcode, description, organizationid,isactive }) => {

        return new Promise((resolve, reject) => {
          MDOGLCodeMasterHelper.createOrUpdateHMGGLCodeMaster_GraphQL(id,glcode, description, organizationid,isactive,(err, result) => {
                resolve(result);
            });
        })
    }
},   
removehmgglcodemaster: {
  type: new graphql.GraphQLList(removeresponseitemdata),
  description: 'Remove hmg glcode master',
  args: {
      id: { type: graphql.GraphQLString }
  },
  resolve: (source, { id }) => {

      return new Promise((resolve, reject) => {
        MDOGLCodeMasterHelper.deleteHMGGLCodeMaster_GraphQL(id, (err, result) => {
              resolve([result]);
          });
      })
  }
},
getmdoglcodehmgmappingbyorganizationid: {
  type: new graphql.GraphQLList(mdoglcodehmgmappingListdataType),
    description: 'Get MDO GLCode HMG Mapping List ',
    args: {
      organizationid: { type: graphql.GraphQLInt }
  },
  resolve: (source, { organizationid }) => {
        return new Promise((resolve, reject) => {
          MDOGLCodeMasterHelper.getMDOGLCodeHMGMappingByOrganizationID_GraphQL(organizationid, (err, result) => {
                resolve(result);
            });
        })
    }
},

createorupdatemdoglcodehmgmapping: {
    type: new graphql.GraphQLList(mdoglcodehmgmappingListdataType),
    description: 'Create mdo glcode hmg mapping',
    //args: {
     // id: { type: graphql.GraphQLString }, 
     // hmgglcode: { type: graphql.GraphQLString },             
     // mdoglcode: { type: graphql.GraphQLString },
      //description: { type: graphql.GraphQLString },
      //status: { type: graphql.GraphQLBoolean },
     // organizationid: { type: graphql.GraphQLInt }
   // },
    args: {
      mapping: { type: new graphql.GraphQLList(mdoglcodehmgmappingListInputdataType)}
      //hmgglcode: { type: graphql.GraphQLString },             
      //mdoglcode: { type: graphql.GraphQLString },
      //description: { type: graphql.GraphQLString },
      //status: { type: graphql.GraphQLBoolean },
      //organizationid: { type: graphql.GraphQLInt }
    },

   // resolve: (source, {id,hmgglcode,mdoglcode, description,status, organizationid }) => {
      resolve: (source, {mapping }) => {
        return new Promise((resolve, reject) => {
         // console.log("in graphql query");
          //MDOGLCodeMasterHelper.createOrUpdateM(DOGLCodeHMGMapping_GraphQL(id,hmgglcode,mdoglcode, description,status, organizationid,(err, result) => {
            MDOGLCodeMasterHelper.createOrUpdateMDOGLCodeHMGMapping_GraphQL(mapping,(err, result) => {
   
          resolve(result);
            });
        })
    }
},   
removemdoglcodehmgmapping: {
  type: new graphql.GraphQLList(removeresponseitemdata),
  description: 'Remove mdo glcode hmg mapping',
  args: {
      id: { type: graphql.GraphQLString }
  },
  resolve: (source, { id }) => {

      return new Promise((resolve, reject) => {
        MDOGLCodeMasterHelper.deleteMDOGLCodeHMGMapping_GraphQL(id, (err, result) => {
              resolve([result]);
          });
      })
  }
},
getmdoglcodemappingtable: {
  type: new graphql.GraphQLList(mdoglcodemappingtabledata),
    description: 'Get GLCode Mapping Master List ',
    args: {
      organizationid: { type: graphql.GraphQLInt }
  },
  resolve: (source, { organizationid }) => {
        return new Promise((resolve, reject) => {
          MDOGLCodeMasterHelper.getMDOGLCodeMasterMapping_GraphQL(organizationid, (err, result) => {
                resolve(result);
            });
        })
    }
},
}