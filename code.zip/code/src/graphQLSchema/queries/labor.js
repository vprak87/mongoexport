
const graphql = require('graphql');

const LaborHelper = require('../../helpers/labor_helper');
const payrolldepartmentdata = require('../types/laborpayrolldepartmentdata');
const payrollvsrevenuevsocc = require('../types/laborpayrollvsrevenuevsocc');
const getactualvspayroll = require('../types/laborgetactualvspayroll');
const gethousekeepingperroom = require('../types/laborgethousekeepingperroom');
const laborgetpayrollactualvsbudgetdata = require('../types/laborgetpayrollactualvsplanbudgetdata');
const laborgetpayrollactualvsbudgethoursdata = require('../types/laborgetpayrollactualvsplanbudgethoursdata');
const laborconfigdata = require('../types/laborconfigdata');

module.exports = {
    payrolldepartmentdata: {
        type: new graphql.GraphQLList(payrolldepartmentdata),
        description: 'Get Labor Data Section',
        args: {
            hotelId: { type: graphql.GraphQLInt },
            period: { type: graphql.GraphQLString },
            currentDate: { type: graphql.GraphQLString }
        },
        resolve: (source, { hotelId, period, currentDate }) => {

            return new Promise((resolve, reject) => {
                LaborHelper.getLaborData_GraphQL(hotelId, period, currentDate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    payrollvsrevenuevsocc: {
        type: new graphql.GraphQLList(payrollvsrevenuevsocc),
        description: 'Get Labor Data Section',
        args: {
            hotelId: { type: graphql.GraphQLInt },
            period: { type: graphql.GraphQLInt },
            currentDate: { type: graphql.GraphQLString }
        },
        resolve: (source, { hotelId, period, currentDate }) => {

            return new Promise((resolve, reject) => {
                LaborHelper.getLaborDataPayrollvsRevenuevsOcc_GraphQL(hotelId, period, currentDate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getactualvspayroll: {
        type: new graphql.GraphQLList(getactualvspayroll),
        description: 'Get Labor Data Section',
        args: {
            hotelId: { type: graphql.GraphQLInt },
            period: { type: graphql.GraphQLString },
            currentDate: { type: graphql.GraphQLString }
        },
        resolve: (source, { hotelId, period, currentDate }) => {

            return new Promise((resolve, reject) => {
                LaborHelper.getActualvsPayroll_GraphQL(hotelId, period, currentDate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    gethousekeepingperroom: {
        type: new graphql.GraphQLList(gethousekeepingperroom),
        description: 'Get Labor Data Section',
        args: {
            userid:{ type: graphql.GraphQLString },
            hotelId: { type: graphql.GraphQLInt },
            period: { type: graphql.GraphQLString },
            currentDate: { type: graphql.GraphQLString },
            laborsection1: { type: graphql.GraphQLString },
            laborsection2: { type: graphql.GraphQLString },
            laborwidgetday: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid,hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday }) => {

            return new Promise((resolve, reject) => {
                LaborHelper.getHouseKeepingPerRoom_GraphQL(userid,hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getpayrollactualvsplanbudget: {
        type: new graphql.GraphQLList(laborgetpayrollactualvsbudgetdata),
        description: 'Get Labor Data Section',
        args: {
            userid:{ type: graphql.GraphQLString },
            hotelId: { type: graphql.GraphQLInt },
            currentDate: { type: graphql.GraphQLString },
            laborsection1: { type: graphql.GraphQLString },
            laborsection2: { type: graphql.GraphQLString },
            laborwidgetday: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid,hotelId, currentDate, laborsection1, laborsection2, laborwidgetday }) => {

            return new Promise((resolve, reject) => {
                LaborHelper.GetPayrollActualvsPlanBudget_GraphQL(userid,hotelId, currentDate, laborsection1, laborsection2, laborwidgetday, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getpayrollactualvsplanbudgethours: {
        type: new graphql.GraphQLList(laborgetpayrollactualvsbudgethoursdata),
        description: 'Get Labor Data Section',
        args: {
            userid: { type: graphql.GraphQLString },
            hotelId: { type: graphql.GraphQLInt },
            period: { type: graphql.GraphQLString },
            currentDate: { type: graphql.GraphQLString },
            laborsection1: { type: graphql.GraphQLString },
            laborsection2: { type: graphql.GraphQLString },
            laborwidgetday: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid,hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday }) => {

            return new Promise((resolve, reject) => {
                LaborHelper.GetPayrollActualvsPlanBudgetHours_GraphQL(userid,hotelId, period, currentDate, laborsection1, laborsection2, laborwidgetday, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getconfigslabor: {
        type: laborconfigdata,
        description: 'Get Labor Data Section',
        args: {
            userid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid }) => {

            return new Promise((resolve, reject) => {
                LaborHelper.GetConfigs_GraphQL(userid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    saveconfigslabor: {
        type: laborconfigdata,
        description: 'Save Labor Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            laborsection1: { type: graphql.GraphQLString },
            laborsection2: { type: graphql.GraphQLString },
            payrolldepartmentwise: { type: graphql.GraphQLBoolean },
            payrollvsrevenuevsocc: { type: graphql.GraphQLBoolean },
            actualvspayrollchart: { type: graphql.GraphQLBoolean },
            housekeepingwidget: { type: graphql.GraphQLBoolean },
            payrollactualvsplanhourswidget: { type: graphql.GraphQLBoolean },
            payrollactualvsplanwageswidget: { type: graphql.GraphQLBoolean },
            defaultweekday: { type: graphql.GraphQLString },
        },
        resolve: (source, { userid, laborsection1, laborsection2, payrolldepartmentwise, payrollvsrevenuevsocc,
            actualvspayrollchart, housekeepingwidget, payrollactualvsplanhourswidget,
            payrollactualvsplanwageswidget, defaultweekday }) => {

            return new Promise((resolve, reject) => {
                LaborHelper.SaveConfigs_GraphQL(userid, laborsection1, laborsection2, payrolldepartmentwise, payrollvsrevenuevsocc,
                    actualvspayrollchart, housekeepingwidget, payrollactualvsplanhourswidget,
                    payrollactualvsplanwageswidget, defaultweekday, (err, result) => {
                        resolve(result);
                    });
            })
        }
    }
}
