
const graphql = require('graphql');

const TrendsHelper = require('../../helpers/trends_helper');
const trendschartdata = require('../types/trendschartitemdata');

module.exports = {
    trendschartdata: {
        type: new graphql.GraphQLList(trendschartdata),
        description: 'Get Trends Chart Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, reportdate, period }) => {

            return new Promise((resolve, reject) => {
                TrendsHelper.getChartData_GraphQL(userid, hotelid, reportdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    }
}
