
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList } = graphql

const ScorecardHelper = require('../../helpers/scorecard_helper');
const scorecardrevenuelineitemdataType = require('../types/scorecardrevenuelineitemdata');
const scorecardprofitlineitemdataType = require('../types/scorecardprofitlineitemdata');
const scorecardstritemdataType = require('../types/scorecardstritemdata');
const scorecardlaborlineitemdataType = require('../types/scorecardlaborlineitemdata');
const scorecardconfigdata = require('../types/scorecardconfigdata');
const getmissingdatesrevenue = require('../types/getmissingdatesrevenue');
const hotelmissingdatescashdata =  require('../types/hotelmissingdatescashdata');
const scorecardservicedataType = require('../types/scorecardservicedata');

module.exports = {
    scorecardrevenuedata: {
        type: new graphql.GraphQLList(scorecardrevenuelineitemdataType),
        description: 'Get Scorecard Revenue Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, reportdate, period }) => {
            return new Promise((resolve, reject) => {
                ScorecardHelper.getRevenueData_GraphQL(userid, hotelid, reportdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    scorecardprofitdata: {
        type: new graphql.GraphQLList(scorecardprofitlineitemdataType),
        description: 'Get Scorecard Profit Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, reportdate, period }) => {

            return new Promise((resolve, reject) => {
                ScorecardHelper.getProfitData_GraphQL(userid, hotelid, reportdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    scorecardstrdata: {
        type: scorecardstritemdataType,
        description: 'Get Scorecard STR Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
            reporttype: { type: graphql.GraphQLString },

        },
        resolve: (source, { userid, hotelid, reportdate, period, reporttype }) => {

            return new Promise((resolve, reject) => {
                ScorecardHelper.getSTRData_GraphQL(userid, hotelid, reportdate, period, reporttype, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    scorecardlabordata: {
        type: new graphql.GraphQLList(scorecardlaborlineitemdataType),
        description: 'Get Scorecard Labor Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, reportdate, period }) => {

            return new Promise((resolve, reject) => {
                ScorecardHelper.getLaborData_GraphQL(userid, hotelid, reportdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getconfigsscorecard: {
        type: scorecardconfigdata,
        description: 'Get Scorecard Data Section',
        args: {
            userid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid }) => {

            return new Promise((resolve, reject) => {
                ScorecardHelper.GetConfigs_GraphQL(userid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    saveconfigsscorecard: {
        type: scorecardconfigdata,
        description: 'Save Scorecard Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            scorecardrevenuewidget: { type: graphql.GraphQLBoolean },
            scorecardstrwidget: { type: graphql.GraphQLBoolean },
            scorecardlabourwidget: { type: graphql.GraphQLBoolean },
            scorecardprofitwidget: { type: graphql.GraphQLBoolean },
            scorecardservicewidget: { type: graphql.GraphQLBoolean },
            scorecardtotalrevenueper: { type: graphql.GraphQLFloat },
            scorecardstrcurrentmonthper: { type: graphql.GraphQLFloat },
            scorecardlabourporvariance: { type: graphql.GraphQLFloat },
            scorecardservicescore: { type: graphql.GraphQLFloat },
            scorecardserviceweightedper: { type: graphql.GraphQLFloat },
        },
        resolve: (source, { userid, scorecardrevenuewidget, scorecardstrwidget, scorecardlabourwidget, scorecardprofitwidget, scorecardservicewidget,
            scorecardtotalrevenueper, scorecardstrcurrentmonthper, scorecardlabourporvariance,
            scorecardservicescore, scorecardserviceweightedper }) => {

            return new Promise((resolve, reject) => {
                ScorecardHelper.SaveConfigs_GraphQL(userid, scorecardrevenuewidget, scorecardstrwidget, scorecardlabourwidget, scorecardprofitwidget, scorecardservicewidget,
                    scorecardtotalrevenueper, scorecardstrcurrentmonthper, scorecardlabourporvariance,
                    scorecardservicescore, scorecardserviceweightedper, (err, result) => {
                        resolve(result);
                    });
            })
        }
    },
    scorecardservicedata: {
        type: scorecardservicedataType,
        description: 'Get Scorecard Service Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, reportdate, period }) => {

            return new Promise((resolve, reject) => {
                ScorecardHelper.getServiceData_GraphQL(userid, hotelid, reportdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getrevenuemissingdata: {
        type: new graphql.GraphQLList(hotelmissingdatescashdata),
        description: 'Get Scorecard Service Data Section',
        args: {
            hotelid: { type: graphql.GraphQLInt },
            currentDate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { hotelid, period,currentDate }) => {

            return new Promise((resolve, reject) => {
                ScorecardHelper.GetMissingDatesRevenue(hotelid,period,currentDate, (err, result) => {
                    resolve(result);
                });
            })
        }
    }, 
}

