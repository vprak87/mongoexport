const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList } = graphql
const MYP1RedirectHelper = require('../../helpers/myp1redirect_helper');
const usertokendataType = require('../types/usertokendata');
const myp1redirectdataType = require('../types/myp1redirectitemdata');
module.exports = {
    getusertokendata: {
        type: usertokendataType,
        description: 'Get User Token Data For MYP 1.0 Redirect',
        args: {
            userid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid }) => {
            return new Promise((resolve, reject) => {
                MYP1RedirectHelper.getUserToken_GraphQL(userid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    myp1redirecturl: {
        type: new graphql.GraphQLList(myp1redirectdataType),
        description: 'Get MYP 1.0 Redirect URL',
        args: {
            token: { type: graphql.GraphQLString }
        },
        resolve: (source, { token }) => {
            return new Promise((resolve, reject) => {
                MYP1RedirectHelper.getURLData(token, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getmyp1redirecturl: {
        type: myp1redirectdataType,
        description: 'Get MYP 1.0 Redirect URL With Params',
        args: {
            token: { type: graphql.GraphQLString },
            pagename: { type: graphql.GraphQLString },
            type: { type: graphql.GraphQLString },
            id: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
        },
        resolve: (source, { token, pagename, type, id, reportdate, period }) => {
            return new Promise((resolve, reject) => {
                MYP1RedirectHelper.getURLDatawithParams(token, pagename, type, id, reportdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    }
    // },
    //   testarrayobjasparam: {
    //     type: graphql.GraphQLString,
    //     description: 'Testing',
    //     args: {
    //         samplearrayobj: { type: usertokendataType },
    //     },
    //     resolve: (source, { token, pagename }) => {
    //         return new Promise((resolve, reject) => {
    //             MYP1RedirectHelper.getURLData(token, pagename, (err, result) => {
    //                 resolve(result);
    //             });
    //         })
    //     }
    // }
}