const graphql = require('graphql');

const HotelroomstatusHelper =require('../../helpers/hotelroomstatuses_helper');

const outoforderbyreasondataType = require('../types/outoforderbyreasondata');

module.exports = {
  getoutoforderbyreasonreport: {
    type: new graphql.GraphQLList(outoforderbyreasondataType),
      description: 'Get Outoforder by reason List ',
      args: {
        hotelid: { type: graphql.GraphQLInt },
        datefrom: { type: graphql.GraphQLString },
        dateto: { type: graphql.GraphQLString }
    },
    resolve: (source, { hotelid, datefrom, dateto }) => {
          return new Promise((resolve, reject) => {
            HotelroomstatusHelper.getOutoforderbyreasonReportData_GraphQL(hotelid, datefrom, dateto, (err, result) => {
                  resolve(result);
              });
          })
      }
  }
}