
const graphql = require('graphql');
const StrreportHelper = require('../../helpers/strreport_helper');
const stritemdataType = require('../types/stritemdata');
const strdefaultitemdataType = require('../types/strdefaultitemdata');
const strportfolioitemdataType = require('../types/strportfolioitemdata');

module.exports = {
    strreportdata: {
        type: new graphql.GraphQLList(stritemdataType),
        description: 'Get STR Report Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            year: { type: graphql.GraphQLInt },
            month: { type: graphql.GraphQLString },
            comparison: { type: graphql.GraphQLString },
            type: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, year, month, comparison, type }) => {
            return new Promise((resolve, reject) => {
                StrreportHelper.getStrReportData_GraphQL(userid, hotelid, year, month, comparison, type, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    strreportdetaildata: {
        type: new graphql.GraphQLList(stritemdataType),
        description: 'Get STR Report Detail Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            year: { type: graphql.GraphQLInt },
            number: { type: graphql.GraphQLInt },
            comparison: { type: graphql.GraphQLString },
            type: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, year, number, comparison, type }) => {
            return new Promise((resolve, reject) => {
                StrreportHelper.getStrReportDetailData_GraphQL(userid, hotelid, year, number, comparison, type, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    strreportdefaultdata: {
        type: new graphql.GraphQLList(strdefaultitemdataType),
        description: 'Get STR Report Default Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            year: { type: graphql.GraphQLInt },
            month: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, year, month }) => {
            return new Promise((resolve, reject) => {
                StrreportHelper.getStrReportDefaultData_GraphQL(userid, hotelid, year, month, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    strportfoliodata: {
        type: new graphql.GraphQLList(strportfolioitemdataType),
        description: 'Get STR Portfolio Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            orgid: { type: graphql.GraphQLInt },
            year: { type: graphql.GraphQLInt },
            month: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, orgid, year, month }) => {
            return new Promise((resolve, reject) => {
                StrreportHelper.getSTRPortfolioData_GraphQL(userid, orgid, year, month, (err, result) => {
                    resolve(result);
                });
            })
        }
    },





}

