
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLInputObjectType, GraphQLString, GraphQLList } = graphql
const PropertyHelper = require('../../helpers/property/property_helper');
const occupancyadrrevparitemdata = require('../types/occupancyadrrevparitemdata');
const actualvsbudgetvslastyritemdata = require('../types/actualvsbudgetvslastyritemdata');
const revenuebreakdownitemdata = require('../types/revenuebreakdownitemdata');
const StrreportHelper = require('../../helpers/strreport_helper');
const stritemdataType = require('../types/stritemdata');
const adrvsrevparitemdata = require('../types/adrvsrevparitemdata');
const rollingrevenueitemdata = require('../types/rollingrevenueitemdata');
const membershipstaysitemdata = require('../types/membershipstaysitemdata');
const marketsegmentitemdata = require('../types/marketsegmentitemdata');
const outoforderroomcompdatatype = require('../types/outoforderroomcompdatatype');
const propertyconfigdata = require('../types/propertyconfigdata');
const hotelguestledgerdata = require('../types/hotelguestledgerdata');
const weatherdata = require('../types/weatherdata');
const propertydashboardtabledataitem = require('../types/propertydashboardtabledata');
const propertytablecolumndataitem = require('../types/propertytablecolumndataitem')
const createOwntablemappingMasteritemType = require('../types/createowntablemappingmasteritem');
const removeresponseitemdata = require('../types/removeresponseitemdata')
const cashtableitem = require('../types/cashtableitem');
const gsspriorityitemdata = require('../types/gsspriorityitemdata');
const ColumnType = new GraphQLInputObjectType({ name: 'Column', description: 'Column GraphQL Object Schemal Model', fields: { columname: { type: graphql.GraphQLString }, columperiod: { type: graphql.GraphQLString } } });
const locationitemdata = require('../types/locationitemdata');
const revenuetabledata = require('../types/revenuetabledata');
const otahoteldata = require('../types/otahoteldata');
const hotelmissingdatepropertydata = require('../types/hotelmissingdatepropertydata');
const hotelmissingdatescashdata =  require('../types/hotelmissingdatescashdata');
const propertychartconfigdata = require('../types/propertychartconfigitemdata');
module.exports = {
    cashtablechart: {
        type: new graphql.GraphQLList(cashtableitem),
        description: 'Get cash table Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate, days }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getHotelCashTableData_GraphQL(userid, hotelid, currentdate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    occupancyadrrevparchart: {
        type: new graphql.GraphQLList(occupancyadrrevparitemdata),
        description: 'Get Occupancy ADR vs RevPAR Chart Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate, period }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getDashboardOccupancyADRvsRevPARChart_GraphQL(userid, hotelid, currentdate, period, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
    actualvsbudgetvslastyrchart: {
        type: new graphql.GraphQLList(actualvsbudgetvslastyritemdata),
        description: 'Get actualvsbudgetvslastyr  Chart Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate, period }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getActualVsBudgetVsLastYrChart_GraphQL(userid, hotelid, currentdate, period, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
    adrvsrevparchart: {
        type: new graphql.GraphQLList(adrvsrevparitemdata),
        description: 'Get ADR VS RevPAR Chart Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            days: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid, currentdate, days }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getADRVSRevPARChart_GraphQL(userid, hotelid, currentdate, days, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    revenuebreakdownchart: {
        type: new graphql.GraphQLList(revenuebreakdownitemdata),
        description: 'Get revenue breakdown data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate, period }) => {
            return new Promise((resolve, reject) => {
                PropertyHelper.getRevenueBreakdown_GraphQL(userid, hotelid, currentdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    revenuebreakdowntable: {
        type: new graphql.GraphQLList(revenuetabledata),
        description: 'Get revenue breakdown table data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate, period }) => {
            return new Promise((resolve, reject) => {
                PropertyHelper.getRevenueBreakdownTable_GraphQL(userid, hotelid, currentdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    rollingrevenuecomparisonchart: {
        type: new graphql.GraphQLList(rollingrevenueitemdata),
        description: 'Get Rolling Revenue Chart Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            days: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid, currentdate, days }) => {
            return new Promise((resolve, reject) => {
                PropertyHelper.getRollingRevenueComparison_GraphQL(userid, hotelid, currentdate, days, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    membershipstayschart: {
        type: new graphql.GraphQLList(membershipstaysitemdata),
        description: 'Get Membership Stays data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate, period }) => {
            return new Promise((resolve, reject) => {
                PropertyHelper.getMembershipStays_GraphQL(userid, hotelid, currentdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    marketsegmentvslastyrchart: {
        type: new graphql.GraphQLList(marketsegmentitemdata),
        description: 'Get Market Segment Current vs. Last Yr data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate, period }) => {
            return new Promise((resolve, reject) => {
                PropertyHelper.getRoomSalesVsLastYr_GraphQL(userid, hotelid, currentdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    outoforderroomcomptable: {
        type: new graphql.GraphQLList(outoforderroomcompdatatype),
        description: 'Get Out Of Order Comp Table data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate, period }) => {
            return new Promise((resolve, reject) => {
                PropertyHelper.getOOOCompTable_GraphQL(userid, hotelid, currentdate, period, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
    strreportwidgetdata: {
        type: new graphql.GraphQLList(stritemdataType),
        description: 'Get STR Report Widget Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            comparison: { type: graphql.GraphQLString },
            type: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate, comparison, type }) => {
            return new Promise((resolve, reject) => {
                StrreportHelper.getStrReportWidgetData_GraphQL(userid, hotelid, currentdate, comparison, type, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    guestledgerwidget: {
        type: new graphql.GraphQLList(hotelguestledgerdata),
        description: 'Get Guest Ledger Widget Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate }) => {
            return new Promise((resolve, reject) => {
                PropertyHelper.getGuestLedgerWidget_GraphQL(userid, hotelid, currentdate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    weatherwidget: {
        type: new graphql.GraphQLList(weatherdata),
        description: 'Get weather Widget Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate }) => {
            return new Promise((resolve, reject) => {
                PropertyHelper.getWeatherWidget_GraphQL(userid, hotelid, currentdate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    gssprioritychart: {
        type: new graphql.GraphQLList(gsspriorityitemdata),
        description: 'Get GSS Priority Chart Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
            priority: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid, currentdate, period, priority }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getGSSPriorityChart_GraphQL(userid, hotelid, currentdate, period, priority, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
    gettripadvisorlocationid: {
        type: new graphql.GraphQLList(locationitemdata),
        description: 'Get Trip Advisor LocationId',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getTripAdvisorLocationId_GraphQL(userid, hotelid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getgoogleplaceid: {
        type: new graphql.GraphQLList(locationitemdata),
        description: 'Get Google PlaceId ',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getGooglePlaceId_GraphQL(userid, hotelid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getfacebookpageurl: {
        type: new graphql.GraphQLList(locationitemdata),
        description: 'Get Facebook Page URL',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getFacebookPageURL_GraphQL(userid, hotelid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getyelpurl: {
        type: new graphql.GraphQLList(locationitemdata),
        description: 'Get Yelp URL',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getYelpURL_GraphQL(userid, hotelid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getotahoteldata: {
        type: new graphql.GraphQLList(otahoteldata),
        description: 'Get OTA Hotel Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            days: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid, hotelid,currentdate,days}) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getOtaHotelData_GraphQL(userid, hotelid,currentdate,days, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getconfigsproperty: {
        type: propertyconfigdata,
        description: 'Get Property Data Section',
        args: {
            userid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.GetConfigs_GraphQL(userid, (err, result) => {

                    resolve(result);
                });
            })
        }
    },
    updateconfigproperty: {
        type: propertyconfigdata,
        description: 'Update Property Chart',
        args: {
            userid: { type: graphql.GraphQLInt },
            configkey: { type: graphql.GraphQLString },
            configvalue: { type: graphql.GraphQLBoolean },
        },
        resolve: (source, { userid, configkey, configvalue, }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.UpdateConfigs_GraphQL(userid, configkey, configvalue, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    saveconfigsproperty: {
        type: propertyconfigdata,
        description: 'Save Property Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            rollingrevenuecomparision: { type: graphql.GraphQLBoolean },
            revenuebreakdowan: { type: graphql.GraphQLBoolean },
            actvsbudvslastyr: { type: graphql.GraphQLBoolean },
            adrvsrevpar: { type: graphql.GraphQLBoolean },
            dashboardocc: { type: graphql.GraphQLBoolean },
            dashboardadr: { type: graphql.GraphQLBoolean },
            dashboardrevpar: { type: graphql.GraphQLBoolean },
            membershipstays: { type: graphql.GraphQLBoolean },
            dashboardmarketcurrentvslastyear: { type: graphql.GraphQLBoolean },
            cashwidget: { type: graphql.GraphQLBoolean },
            guestledgerwidget: { type: graphql.GraphQLBoolean },
            payrollactualvsplanwidget: { type: graphql.GraphQLBoolean },
            strwidget: { type: graphql.GraphQLBoolean },
            tripadvisorratingwidget: { type: graphql.GraphQLBoolean },
            googleplaceratingwidget: { type: graphql.GraphQLBoolean },
            facebookpagewidget: { type: graphql.GraphQLBoolean },
            yelpreviewwidget: { type: graphql.GraphQLBoolean },
            weatherwidget: { type: graphql.GraphQLBoolean },
            aragingwidget: { type: graphql.GraphQLBoolean },
            gsspriority: { type: graphql.GraphQLBoolean },
            ooocompwidget: { type: graphql.GraphQLBoolean },
            totalprofit: { type: graphql.GraphQLBoolean },
            totalexpensebreakdown: { type: graphql.GraphQLBoolean },
            expensebudgetdepartment: { type: graphql.GraphQLBoolean },
            expensebudgetcategory: { type: graphql.GraphQLBoolean },
            invoicevscreditcard: { type: graphql.GraphQLBoolean },
            expenseformbyglcode: { type: graphql.GraphQLBoolean },
        },
        resolve: (source, { userid, rollingrevenuecomparision,
            revenuebreakdowan,
            actvsbudvslastyr,
            adrvsrevpar,
            dashboardocc,
            dashboardadr,
            dashboardrevpar,
            membershipstays,
            dashboardmarketcurrentvslastyear,
            cashwidget,
            guestledgerwidget,
            payrollactualvsplanwidget,
            strwidget,
            tripadvisorratingwidget,
            googleplaceratingwidget,
            facebookpagewidget,
            yelpreviewwidget,
            weatherwidget,
            aragingwidget,
            gsspriority,
            ooocompwidget,
            totalprofit,
            totalexpensebreakdown,
            expensebudgetdepartment,
            expensebudgetcategory,
            invoicevscreditcard,
            expenseformbyglcode }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.SaveConfigs_GraphQL(userid, rollingrevenuecomparision,
                    revenuebreakdowan,
                    actvsbudvslastyr,
                    adrvsrevpar,
                    dashboardocc,
                    dashboardadr,
                    dashboardrevpar,
                    membershipstays,
                    dashboardmarketcurrentvslastyear,
                    cashwidget,
                    guestledgerwidget,
                    payrollactualvsplanwidget,
                    strwidget,
                    tripadvisorratingwidget,
                    googleplaceratingwidget,
                    facebookpagewidget,
                    yelpreviewwidget,
                    weatherwidget,
                    aragingwidget,
                    gsspriority,
                    ooocompwidget,
                    totalprofit,
                    totalexpensebreakdown,
                    expensebudgetdepartment,
                    expensebudgetcategory,
                    invoicevscreditcard,
                    expenseformbyglcode, (err, result) => {
                        resolve(result);
                    });
            })
        }
    },
    propertydashboardtable: {
        type: new graphql.GraphQLList(propertydashboardtabledataitem),
        description: 'property dashboard table Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, currentdate }) => {
            return new Promise((resolve, reject) => {
                PropertyHelper.getPropertyDashboardTable_GraphQL(userid, hotelid, currentdate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    addtablecolumns: {
        type: new graphql.GraphQLList(propertytablecolumndataitem),
        description: 'Add Table Columns',
        args: {
            userid: { type: graphql.GraphQLInt },
            columlist: { type: new GraphQLList(ColumnType) },
        },
        resolve: (source, { userid, columlist }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.addKPIColumns_GraphQL(userid, columlist, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    removetablecolumn: {
        type: new graphql.GraphQLList(removeresponseitemdata),
        description: 'Remove KPI Column',
        args: {
            userid: { type: graphql.GraphQLInt },
            columname: { type: GraphQLString },
            columperiod: { type: GraphQLString },
        },
        resolve: (source, { userid, columname, columperiod }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.removeTableColumns_GraphQL(userid, columname, columperiod, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
    columnmasterlist: {
        type: new graphql.GraphQLList(propertytablecolumndataitem),
        description: 'Get column master list Data',
        args: {
            userid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getColumnMasterListData_GraphQL(userid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    updatetablecolumn: {
        type: new graphql.GraphQLList(propertytablecolumndataitem),
        description: 'Update Table Column',
        args: {
            userid: { type: graphql.GraphQLInt },
            oldcolumname: { type: graphql.GraphQLString },
            oldcolumperiod: { type: graphql.GraphQLString },
            newcolumname: { type: graphql.GraphQLString },
            newcolumperiod: { type: graphql.GraphQLString },
        },
        resolve: (source, { userid, oldcolumname, oldcolumperiod, newcolumname, newcolumperiod }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.updatetablecolumn_GraphQL(userid, oldcolumname, oldcolumperiod, newcolumname, newcolumperiod, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
    tablecolumnlookupdata: {
        type: new graphql.GraphQLList(createOwntablemappingMasteritemType),
        description: 'Get table column lookup Data',
        args: {
            tablename: { type: graphql.GraphQLString }
        },
        resolve: (source, { tablename }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getTableColumnLookupData_GraphQL(tablename, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getallmissingdateslastdays:{
        type: hotelmissingdatepropertydata,
        description: 'Property page missing dates last year',
        args: {
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLInt},
            roomrevenue: { type: graphql.GraphQLString },
            otherrevenue: { type: graphql.GraphQLString }
        },
        resolve: (source, { hotelid,currentdate,period,roomrevenue,otherrevenue }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getAllMissingDatesLastDays(hotelid,currentdate,period,roomrevenue,otherrevenue, (err, result) => {
                    resolve(result);
                });
            })
        }       
    },
    getmissingdatescash:{
        type: new graphql.GraphQLList(hotelmissingdatescashdata),
        description: 'Property page missing dates cash data',
        args: {
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
        },
        resolve: (source, { hotelid,currentdate,period }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getMissingDatesCash(hotelid,currentdate,period, (err, result) => {
                    resolve(result);
                });
            })
        }       
    },
    getmissingdatesaraging:{
        type: new graphql.GraphQLList(hotelmissingdatescashdata),
        description: 'Property page missing dates araging data',
        args: {
            hotelid: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
        },
        resolve: (source, { hotelid,currentdate,period }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getMissingDatesARAging(hotelid,currentdate,period, (err, result) => {
                    resolve(result);
                });
            })
        }       
    },   
    createorupdatechartconfig: {
        type: new graphql.GraphQLList(propertychartconfigdata),
        description: 'Create or update chart config ',
        args: {
            id: { type: graphql.GraphQLInt },
            widgetname: { type: graphql.GraphQLString },
            charttype: { type: graphql.GraphQLString },
            chartperiod: { type: graphql.GraphQLString },
            comparechartdata: { type: graphql.GraphQLString },
            userid: { type: graphql.GraphQLInt },
        },
        resolve: (source, { id,userid, widgetname, charttype, chartperiod,comparechartdata }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.createOrUpdatePropertyChartConfig_GraphQL(id,userid, widgetname, charttype, chartperiod,comparechartdata, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
    removechartconfig: {
        type: new graphql.GraphQLList(removeresponseitemdata),
        description: 'Remove Chart Config',
        args: {
            id: { type: graphql.GraphQLInt }
        },
        resolve: (source, { id }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.deletePropertyChartConfig_GraphQL(id, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
    chartconfigbyuserid: {
        type: new graphql.GraphQLList(propertychartconfigdata),
        description: 'Get Property Chart Config',
        args: {
            userid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getPropertyChartConfigByUserId_GraphQL(userid, (err, result) => {
                    resolve(result);
                });
            })
        }
    }, 
    chartconfigbyid: {
        type: new graphql.GraphQLList(propertychartconfigdata),
        description: 'Get Property Chart Config',
        args: {
            id: { type: graphql.GraphQLInt }
        },
        resolve: (source, { id }) => {

            return new Promise((resolve, reject) => {
                PropertyHelper.getPropertyChartConfigById_GraphQL(id, (err, result) => {
                    resolve([result]);
                });
            })
        }
    }, 
}
