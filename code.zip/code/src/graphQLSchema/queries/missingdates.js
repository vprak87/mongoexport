const graphql = require('graphql');

const ExclamationHelper = require('../../helpers/exclamation_helper');
const hotelmissingdatedata = require('../types/hotelmissingdatedata');
const hotelmissingdatedatav2 = require('../types/hotelmissingdatedatav2');
const hotelmissingdatepropertydata = require('../types/hotelmissingdatepropertydata');
module.exports = {
    hotelmissingdatedata: {
        type: new graphql.GraphQLList(hotelmissingdatedata),
        description: 'Get Hotel Missing Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelIds: { type: graphql.GraphQLString },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
            startDate: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelIds, currentdate, period, startDate }) => {

            return new Promise((resolve, reject) => {
                ExclamationHelper.getHotelMissingDates_GraphQL(userid, hotelIds, currentdate, period, startDate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    hotelmissingdatedatav2: {
        type: new graphql.GraphQLList(hotelmissingdatedatav2),
        description: 'Get Hotel Missing Data Section v2',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelIds: { type: graphql.GraphQLString },
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
            startDate: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelIds, currentdate, period, startDate }) => {

            return new Promise((resolve, reject) => {
                ExclamationHelper.getHotelMissingDates_v2_GraphQL(userid, hotelIds, currentdate, period, startDate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },


    propertymissingdates: {
        type: new graphql.GraphQLList(hotelmissingdatepropertydata),
        description: 'Property page missing dates',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelId: { type: graphql.GraphQLInt },
            currentDate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelId, currentDate, period }) => {

            return new Promise((resolve, reject) => {
                ExclamationHelper.GetMissingDatesProperty(userid, hotelId, currentDate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    }
}
