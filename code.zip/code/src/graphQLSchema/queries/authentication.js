const graphql = require('graphql');

const AuthenticationHelper = require('../../helpers/authentication_helper');
const useritemdata = require('../types/useritemdata');
//TODO
module.exports = {
  userLogin: {
    type: new graphql.GraphQLList(useritemdata),
      description: 'Login User ',
      args: {
        username: { type: graphql.GraphQLString },
        password: { type: graphql.GraphQLString }
    },
    resolve: (source, { username,password }) => {
          return new Promise((resolve, reject) => {
            AuthenticationHelper.UserLogin_GraphQL(username,password, (err, result) => {
                  resolve(result);
              });
          })
      }
  },
}