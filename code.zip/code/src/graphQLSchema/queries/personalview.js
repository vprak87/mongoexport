
const graphql = require('graphql');

const PersonalViewHelper = require('../../helpers/personalview_helper');
const personalviewchartdata = require('../types/personalviewchartdata');
const createdashboarddata = require('../types/createdashboarddata');
const createtnewpersonalviewdata = require('../types/createtnewpersonalviewdata');
const insertandeditchartdata = require('../types/insertandeditchartdata');
const kpilistdata = require('../types/kpilistdata');
const chartdata = require('../types/chartdata');

module.exports = {
    getkpilist: {
        type: new graphql.GraphQLList(kpilistdata),
        description: 'Get KPI Data ',
        resolve: (source) => {

            return new Promise((resolve, reject) => {
                PersonalViewHelper.getKPIList((err, result) => {
                    resolve(result);
                });
            })
        }
    },
    getchartist: {
        type: new graphql.GraphQLList(chartdata),
        description: 'Get Graph Data ',
        resolve: (source) => {

            return new Promise((resolve, reject) => {
                PersonalViewHelper.getGraphData((err, result) => {
                    resolve(result);
                });
            })
        }
    },
    createdashboard: {
        type: new graphql.GraphQLList(createdashboarddata),
        description: 'Get Chart Data Section',
        resolve: (source) => {

            return new Promise((resolve, reject) => {
                PersonalViewHelper.getTemplatesList((err, result) => {
                    resolve(result);
                });
            })
        }
    },
    createtnewpersonalview: {
        type: new graphql.GraphQLList(createtnewpersonalviewdata),
        description: 'Get Chart Data Section',
        args: {
                userid: { type: graphql.GraphQLString },              
                name: { type: graphql.GraphQLString },
                description: { type: graphql.GraphQLString },
                templateId: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid,name, description, templateId }) => {

            return new Promise((resolve, reject) => {
                PersonalViewHelper.createTemplate( userid,name, description, templateId,(err, result) => {
                    resolve(result);
                });
            })
        }
    },   
    personalviewchartdata: {
        type: new graphql.GraphQLList(personalviewchartdata),
        description: 'Get Chart Data Section',
        args: {
                userid: { type: graphql.GraphQLString },            
                fromdate: { type: graphql.GraphQLString },
                todate: { type: graphql.GraphQLString },
                type: { type: graphql.GraphQLString },
                id: { type: graphql.GraphQLInt },
                period: { type: graphql.GraphQLString },
                kpi: { type: graphql.GraphQLString }
        },
        resolve: (source, {userid,fromdate, todate, type, id, period,kpi }) => {

            return new Promise((resolve, reject) => {
                PersonalViewHelper.getChartData(userid,fromdate, todate, type, id, period,kpi,(err, result) => {
                    resolve(result);
                });
            })
        }
    },
    insertandeditchartdata:{
        type: new graphql.GraphQLList(insertandeditchartdata),
        description: 'Get Chart Data Section',
        args: {            
                _id: { type: graphql.GraphQLString},
                userid: { type: graphql.GraphQLString },
                templateid: { type: graphql.GraphQLString },
                graphid: { type: graphql.GraphQLString }
        },
        resolve: (source, { _id, userid, templateid,graphid }) => {

            return new Promise((resolve, reject) => {
                PersonalViewHelper.editTemplate(_id, userid, templateid,graphid,(err, result) => {
                    resolve(result);
                });
            })
        }        
    },
    getsavedtemplatedata:{
        type: new graphql.GraphQLList(createtnewpersonalviewdata),
        description: 'Get Template Data Section',
        args: {
                userid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid }) => {

            return new Promise((resolve, reject) => {
                PersonalViewHelper.getSavedTemplatetData(userid, (err, result) => {
                    resolve(result);
                });
            })
        }        
    },
    getsavedchartdata:{
        type: new graphql.GraphQLList(insertandeditchartdata),
        description: 'Get Chart Data Section',
        args: {
                userid: { type: graphql.GraphQLInt },
                templateid: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid,templateid }) => {

            return new Promise((resolve, reject) => {
                PersonalViewHelper.getSavedChartData(userid,templateid, (err, result) => {
                    resolve(result);
                });
            })
        }        
    },
    deletesavedchart:{
        type: new graphql.GraphQLList(insertandeditchartdata),
        description: 'Get Chart Data Section',
        args: {
                id: { type: graphql.GraphQLString }
        },
        resolve: (source, {id}) => {

            return new Promise((resolve, reject) => {
                PersonalViewHelper.deleteSavedChart(id,(err, result) => {
                    resolve(result);
                });
            })
        }        
    }
}
