const graphql = require('graphql');
 
const PermissionHelper = require('../../helpers/permission_helper');
const pagepermissionitem = require('../types/pagepermissionitem');
module.exports = {
    pagepermission: {
        type: new graphql.GraphQLList(pagepermissionitem),
        description: 'pagepermission',
        args: {
            userid: { type: graphql.GraphQLInt }
        },
        resolve: (source, { userid }) => {
            return new Promise((resolve, reject) => {
                PermissionHelper.getPageAccessByUserId_GraphQL(userid, (err, result) => {
                    resolve(result);
                });
            })
        }
    }
}
