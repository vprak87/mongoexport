const graphql = require('graphql');

const PickupHelper = require('../../helpers/pickup_helper');
const MonthlyPickupHelper = require('../../helpers/monthlypickup_helper');
const SummeryPickupHelper = require('../../helpers/pickupsummery_helper');
const pickupdefaultdataType = require('../types/pickupdefaultdata');
const pickupmonthlydataType = require('../types/pickupmonthlydata');
const pickupsummerydataType = require('../types/pickupsummerydata');
const pickupdatamissingdates = require('../types/pickupdatamissingdates');
module.exports = {
    pickupdefaultdata: {
        type: pickupdefaultdataType,
        description: 'Get Pickup Default Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            today: { type: graphql.GraphQLString },
            days: { type: graphql.GraphQLInt },
            startDate: { type: graphql.GraphQLString },
        },
        resolve: (source, { userid, hotelid, today, days, startDate }) => {
            return new Promise((resolve, reject) => {
                PickupHelper.getPickupData_GraphQL(hotelid, today, days, startDate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    pickupmonthlydata: {
        type: new graphql.GraphQLList(pickupmonthlydataType),
        description: 'Get Pickup Monthly Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelId: { type: graphql.GraphQLInt },
            month: { type: graphql.GraphQLInt },
            currentdate: { type: graphql.GraphQLString },
        },
        resolve: (source, { userid, hotelId, month, currentdate }) => {
            return new Promise((resolve, reject) => {
                MonthlyPickupHelper.getMonthlyPickupData_GraphQL( hotelId, month, currentdate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    pickupsummerydata: {
        type: new graphql.GraphQLList(pickupsummerydataType),
        description: 'Get Pickup Summery Data Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            date: { type: graphql.GraphQLString },
        },
        resolve: (source, { userid, hotelid, date }) => {
            return new Promise((resolve, reject) => {
                SummeryPickupHelper.getSummeryPickupData_GraphQL( hotelid, date, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    pickupdatamissingdates: {
        type: new graphql.GraphQLList(pickupdatamissingdates),
        description: 'Get Pickup Data Missing Dates',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            days: { type: graphql.GraphQLInt },
            today: { type: graphql.GraphQLString }
        },
        resolve: (source, { userid, hotelid, days,today }) => {
            return new Promise((resolve, reject) => {
                SummeryPickupHelper.getMissingPickupDates_GraphQL( userid, hotelid, days,today, (err, result) => {
                    resolve(result);
                });
            })
        }
    },    
    

}
