
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList } = graphql
const CashdetailHelper = require('../../helpers/property/cashdetail_helper');
const cashdetailitemdata = require('../types/cashdetailitemdata');

module.exports = {
    cashdetaildata: {
        type: new graphql.GraphQLList(cashdetailitemdata),
        description: 'Get Cash Detail Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },          
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
            customenddate: { type: graphql.GraphQLString },
        },
        resolve: (source, {userid,hotelid,currentdate, period,customenddate}) => {

            return new Promise((resolve, reject) => {
                CashdetailHelper.getCashDetailData_GraphQL(userid,hotelid,currentdate, period,customenddate, (err, result) => {
                    resolve(result);
                });
            })
        }
    }
}

