
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList } = graphql
const CustomKPIHelper = require('../../helpers/customkpi_helper');
const createOwntablemappingMasteritemType = require('../types/createowntablemappingmasteritem');
var KpiItemType= new GraphQLObjectType({name: 'KpiItemType',description: 'Kpi Item Type',fields: {kpikey:{ type: GraphQLString },columname:{ type: GraphQLString } }})

module.exports = {
    kpidata: {
        type: new graphql.GraphQLList(createOwntablemappingMasteritemType),
        description: 'Get Create Own Table Mapping Master Data',
        args: {
            organizationid: { type: graphql.GraphQLInt }
        },
        resolve: (source, {organizationid}) => {

            return new Promise((resolve, reject) => {
                CustomKPIHelper.getCustomKPIByOrgId_GraphQL(organizationid, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    kpilookupsdata: {       
        type: new graphql.GraphQLList(KpiItemType),
        description: 'Get Distinct KPI Data',
        resolve: (source, {}) => {

            return new Promise((resolve, reject) => {
                CustomKPIHelper.getKPILookups_GraphQL((err, result) => {
                    resolve(result);
                });
            })
        }
    },
    insertkpidata: {
        type: new graphql.GraphQLList(createOwntablemappingMasteritemType),
        description: 'Get Created KPI Data',
        args: {
            kpiname:  { type: graphql.GraphQLString },
            kpiformula: { type: graphql.GraphQLString },
            unit: { type: graphql.GraphQLString },
            organizationid: { type: graphql.GraphQLInt }
        },
        resolve: (source, {kpiname,kpiformula,unit,organizationid}) => {
            return new Promise((resolve, reject) => {
                CustomKPIHelper.IsExistKPI(null,kpiname,organizationid,(err, kpi_result) => {
                    if (err) {
                        reject(err);
                    }
                    else {
                        CustomKPIHelper.insertCustomKPI_GraphQL(kpiname,kpiformula,unit,organizationid,(err, result) => {
                            resolve([result]);
                        });               
                    }
            
                })
               
            })
        }
    },
    getkpiforedit: {
        type: new graphql.GraphQLList(createOwntablemappingMasteritemType),
        description: 'Get KPI For Edit',
        args: {
            kpiid: { type: graphql.GraphQLInt }
        },
        resolve: (source, {kpiid}) => {

            return new Promise((resolve, reject) => {
                CustomKPIHelper.getCustomKPIForEdit_GraphQL(kpiid, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
    updatekpidata: {
        type: new graphql.GraphQLList(createOwntablemappingMasteritemType),
        description: 'Update KPI Data',
        args: {
            kpiid: { type: graphql.GraphQLInt },
            kpiname:  { type: graphql.GraphQLString },
            kpiformula: { type: graphql.GraphQLString },
            unit: { type: graphql.GraphQLString },
            organizationid: { type: graphql.GraphQLInt }
        },
        resolve: (source, {kpiid,kpiname,kpiformula,unit,organizationid}) => {
            return new Promise((resolve, reject) => {
                CustomKPIHelper.IsExistKPI(kpiid,kpiname,organizationid,(err, kpi_result) => {
                    if (err) {
                        reject(err);
                    }
                    else {
                        CustomKPIHelper.updateCustomKPI_GraphQL(kpiid,kpiname,kpiformula,unit,organizationid,(err, result) => {
                            resolve([result]);
                        });               
                    }
            
                })
               
            })
        }
    },
    deletekpi: {
        type: new graphql.GraphQLList(createOwntablemappingMasteritemType),
        description: 'Delete KPI',
        args: {
            kpiid: { type: graphql.GraphQLInt }
        },
        resolve: (source, {kpiid}) => {

            return new Promise((resolve, reject) => {
                CustomKPIHelper.deleteCustomKPI_GraphQL(kpiid, (err, result) => {
                    resolve([result]);
                });
            })
        }
    },
}

