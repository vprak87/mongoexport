const graphql = require('graphql');
const HotelHelper = require('../../helpers/hotels_helper');
const HotelListHelper = require('../../helpers/hotellist_helper');
const hotelListdataType = require('../types/hotellistdata');
const hotelDataModelListType = require('../types/hoteldatamodelitem');
module.exports = {
  gethotellistdata: {
      type: hotelListdataType,
      description: 'Get Hotel List Data Section',
      args: {
          userEmail: { type: graphql.GraphQLString }
      },
      resolve: (source, { userEmail }) => {
          return new Promise((resolve, reject) => {
            HotelListHelper.getHotelList_GraphQL(userEmail, (err, result) => {
                  resolve(result);
              });
          })
      }
  },
  gethotellistbyOrganizationID: {
    type:  new graphql.GraphQLList(hotelDataModelListType),
    description: 'Get Hotel Data Section',
    args: {
        organizationid: { type: graphql.GraphQLInt },
        userid: { type: graphql.GraphQLInt }
    },
    resolve: (source, { organizationid,userid }) => {
        return new Promise((resolve, reject) => {
            HotelHelper.getHotelsByOrganizationIdNew_GraphQL(organizationid,userid, (err, result) => {
                resolve(result);
            });
        })
    }
}
}