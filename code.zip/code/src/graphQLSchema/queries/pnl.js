const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLInt, GraphQLBoolean,  GraphQLList, GraphQLFloat, GraphQLInputObjectType } = graphql;

const PnlHelper = require('../../helpers/pnlyear_helper');
const PnlMonthHelper = require('../../helpers/pnlmonthly_helper');
// const MonthlyPickupHelper = require('../../helpers/monthlypickup_helper');
const PNLHelper = require('../../helpers/pnl_helper');
const pnlyeardataType = require('../types/pnlyeardata');
const pnlmonthdataType = require('../types/pnlmonthdata');

// const pnladdorupdatedatarawType = require('../types/pnladdorupdaterawdata');
// const pnladdorupdatedataraw2Type = require('../types/pnladdorupdaterawdata2');
const propertytablecolumndataitem = require('../types/propertytablecolumndataitem');
const pnltablecolumndataitem = require('../types/pnltablecolumndataitem');
const pnltabledataitem = require('../types/pnltabledataitem');

module.exports = {
  pnlyeardata: {
    type: pnlyeardataType,
    description: 'Get P&L Year Data Section',
    args: {
        userid: { type: graphql.GraphQLInt },
        hotelid: { type: graphql.GraphQLInt },
        year: { type: graphql.GraphQLInt }
    },
    resolve: (source, { userid, hotelid, year }) => {
      return new Promise((resolve, reject) => {
        PnlHelper.getYearPnlData_GraphQL(hotelid, year, (err, result) => {
          resolve(result);
        });
      })
    }
  },
  pnlmonthdata: {
    type: pnlmonthdataType,
    description: 'Get P&L Month Data Section',
    args: {
        userid: { type: graphql.GraphQLInt },
        hotelid: { type: graphql.GraphQLInt },
        currentdate: { type: graphql.GraphQLString }
    },
    resolve: (source, { userid, hotelid, currentdate }) => {
      return new Promise((resolve, reject) => {
        PnlMonthHelper.getMonthPnlData_GraphQL(hotelid, currentdate, userid, (err, result) => {
          resolve(result);
        });
      })
    }
  }, 
  pnlcolumntablemapping: {
    type: new graphql.GraphQLList(pnltablecolumndataitem),
    description: 'Get Pnl Table Mapping Data',
    args: {
        userid: { type: graphql.GraphQLInt },
        pnltype: { type: graphql.GraphQLString },

    },
    resolve: (source, { userid , pnltype}) => {

        return new Promise((resolve, reject) => {
          console.log("in graphql");
          PNLHelper.getPnlTableMapping_GraphQL(userid,pnltype ,(err, result) => {
                resolve(result);
            });
        })
    },
},

pnlupdatetablecolumn: {
  type: new graphql.GraphQLList(pnltablecolumndataitem),
  description: 'Update Table Column',
  args: {
      userid: { type: graphql.GraphQLInt },
      oldcolumname: { type: graphql.GraphQLString },
      oldcolumperiod: { type: graphql.GraphQLString },
      newcolumname: { type: graphql.GraphQLString },
      newcolumperiod: { type: graphql.GraphQLString },
      pnltype: { type: graphql.GraphQLString },

  },
  resolve: (source, { userid, oldcolumname, oldcolumperiod, newcolumname, newcolumperiod ,pnltype}) => {

      return new Promise((resolve, reject) => {
        PNLHelper.updatetablecolumn_GraphQL(userid, oldcolumname, oldcolumperiod, newcolumname, newcolumperiod,pnltype, (err, result) => {
              resolve([result]);
          });
      })
  }
},
pnlmonthlytable: {
  type: new graphql.GraphQLList(pnltabledataitem),
  description: 'get PNL Monthly table Data',
  args: {
      userid: { type: graphql.GraphQLInt },
      hotelid: { type: graphql.GraphQLInt },
      currentdate: { type: graphql.GraphQLString }
  },
  resolve: (source, { userid, hotelid, currentdate }) => {
      return new Promise((resolve, reject) => {
        PNLHelper.getPNLTable_GraphQL(userid, hotelid, currentdate, (err, result) => {
              resolve(result);
          });
      })
  }
},
pnlannualtable: {
  type: new graphql.GraphQLList(pnltabledataitem),
  description: 'get PNL Yearly table Data',
  args: {
      userid: { type: graphql.GraphQLInt },
      hotelid: { type: graphql.GraphQLInt },
      datamode: { type: graphql.GraphQLString },
      year: { type: graphql.GraphQLInt }
  },
  resolve: (source, {userid, hotelid, datamode,year }) => {
      return new Promise((resolve, reject) => {
        PNLHelper.getPNLAnnualTable_GraphQL(userid, hotelid, datamode,year, (err, result) => {
              resolve(result);
          });
      })
  }
},
}