
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList } = graphql

const AlertsHelper = require('../../helpers/alerts_helper');
const alertslineitemdataType = require('../types/alertslineitemdata');


module.exports = {
    alertspropertydata: {
        type: new graphql.GraphQLList(alertslineitemdataType),
        description: 'Get Alerts For Property Page Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
        },
        resolve: (source, { userid, hotelid, reportdate }) => {
            return new Promise((resolve, reject) => {
                AlertsHelper.getPropertyData_GraphQL(userid, hotelid, reportdate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    alertsportfoliodata: {
        type: new graphql.GraphQLList(alertslineitemdataType),
        description: 'Get Alerts For Portfolio Page Section',
        args: {
            userid: { type: graphql.GraphQLInt },
            reportdate: { type: graphql.GraphQLString },
        },
        resolve: (source, { userid, reportdate }) => {
            return new Promise((resolve, reject) => {
                AlertsHelper.getPortfolioData_GraphQL(userid, reportdate, (err, result) => {
                    resolve(result);
                });
            })
        }
    }


}

