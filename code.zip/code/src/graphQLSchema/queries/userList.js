const graphql = require('graphql');

const UserListHelper = require('../../helpers/userlist_helper');
const userListdataType = require('../types/userlistdata');

module.exports = {
  getuserlistdata: {
      type: userListdataType,
      description: 'Get Hotel List Data Section',
      resolve: (source) => {
          return new Promise((resolve, reject) => {
            UserListHelper.getUserList_GraphQL((err, result) => {
                  resolve(result);
              });
          })
      }
  }
}