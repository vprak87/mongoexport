
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList } = graphql
const ARAgingDetailHelper = require('../../helpers/property/aragingdetail_helper');
const aragingdetailitemdata = require('../types/aragingdetailitemdata');

module.exports = {
    aragingdetaildata: {
        type: new graphql.GraphQLList(aragingdetailitemdata),
        description: 'Get AR Aging Detail',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            hotelgroupid: { type: graphql.GraphQLInt },            
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
        },
        resolve: (source, {userid,hotelid,hotelgroupid,currentdate, period}) => {

            return new Promise((resolve, reject) => {
                ARAgingDetailHelper.getARAgingDetailData_GraphQL(userid,hotelid,hotelgroupid,currentdate, period, (err, result) => {
                    resolve(result);
                });
            })
        }
    }
}

