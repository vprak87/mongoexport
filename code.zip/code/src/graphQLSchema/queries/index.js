let Scorecard = require('./scorecard.js');
let Trends = require('./trends.js');
let Pickup = require('./pickup.js');
let Statsbydaterange = require('./statsbydaterange');
let Labor = require('./labor.js');
let Personalview = require('./personalview.js');
let Strreport = require('./strreport.js');
let Cashdetail = require('./cashdetail.js');
let ARAgaindetail = require('./aragingdetail.js');
let Hotellist = require('./hotelList.js');
let PnLYear = require('./pnl');
let Portfolio = require('./portfolio.js');
let CustomKPI = require('./customkpi');
let Property = require('./property');
let Hotelmissingdates = require('./missingdates');
let Comments = require('./comments');
let MYP1Redirect = require('./myp1redirect');
let Alerts = require('./alerts');
let Permission = require('./permission');
let Userlist = require('./userList.js');
let Trustyousurveyreport = require('./trustyousurveyreport.js');
let ScreenshotScheduler = require('./screenshotscheduler.js');
let Outoforderbyreasonreport = require('./outoforderbyreasonreport.js');
let MDOGLCodeMaster = require('./mdoglcodemaster.js');
let Authentication = require('./authentication.js');
module.exports = {
    ...Scorecard,
    ...Trends,
    ...Statsbydaterange,
    ...Labor,
    ...Personalview,
    ...Strreport,
    ...Cashdetail,
    ...Pickup,
    ...ARAgaindetail,
    ...Hotellist,
    ...PnLYear,
    ...Portfolio,
    ...CustomKPI,
    ...Property,
    ...Hotelmissingdates,
    ...Comments,
    ...MYP1Redirect,
    ...Alerts,
    ...Permission,
    ...Userlist,
    ...Trustyousurveyreport,
    ...ScreenshotScheduler,
    ...Outoforderbyreasonreport,
    ...MDOGLCodeMaster,
    ...Authentication,
};