
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLString, GraphQLList } = graphql
const StatsbydaterangeHelper = require('../../helpers/property/statsbydaterange_helper');
const statsbydaterangeitemdata = require('../types/statsbydaterangeitemdata');

module.exports = {
    statsbydaterangedata: {
        type: new graphql.GraphQLList(statsbydaterangeitemdata),
        description: 'Get Stats By Date Range Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLInt },
            startdate: { type: graphql.GraphQLString },
            enddate: { type: graphql.GraphQLString },
            roomrevenuenodata: { type: graphql.GraphQLString },
            fnbrevenuenodata: { type: graphql.GraphQLString },
            otherrevenenodata: { type: graphql.GraphQLString } 
        },
        resolve: (source, { userid, hotelid, startdate, enddate,roomrevenuenodata,fnbrevenuenodata,otherrevenenodata }) => {

            return new Promise((resolve, reject) => {
                StatsbydaterangeHelper.getStatsbyDateRangeData_GraphQL(userid, hotelid, startdate, enddate,roomrevenuenodata,fnbrevenuenodata,otherrevenenodata, (err, result) => {
                    resolve(result);
                });
            })
        }
    }
}
