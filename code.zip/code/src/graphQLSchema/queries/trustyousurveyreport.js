const graphql = require('graphql');

const TrustYouSurveyHelper = require('../../helpers/trustyousurveyreport_helper');
const trustyousurveyListdataType = require('../types/trustyousurveylistdata');

module.exports = {
  gettrustyousurveyreport: {
    type: new graphql.GraphQLList(trustyousurveyListdataType),
      description: 'Get Trust You Survey List ',
      args: {
        hotelid: { type: graphql.GraphQLInt },
        date: { type: graphql.GraphQLString },
        category: { type: graphql.GraphQLString }
    },
    resolve: (source, { hotelid, date, category }) => {
          return new Promise((resolve, reject) => {
            TrustYouSurveyHelper.getTrustYouSurveyReportData_GraphQL(hotelid, date, category, (err, result) => {
                  resolve(result);
              });
          })
      }
  }
}