

const graphql = require('graphql');
const { GraphQLString, GraphQLList,GraphQLInt } = graphql;
const CommentsHelper = require('../../helpers/comments_helper');
const commentsdata = require('../types/commentsdata');
const hotelcommentdata = require('../types/hotelcommetsdata');

module.exports = {
    commentdata: {
        type: new graphql.GraphQLList(commentsdata),
        description: 'Comment Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            tags: { type: graphql.GraphQLString },          
            hotelId: { type: graphql.GraphQLInt },
            currentDate: { type: graphql.GraphQLString },
        },
        resolve: (source, {userid,tags,hotelId, currentDate}) => {

            return new Promise((resolve, reject) => {
                CommentsHelper.getCommentDetailData_GraphQL(userid,tags,hotelId, currentDate, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
    gethotelcomment: {
        type: new graphql.GraphQLList(hotelcommentdata),
        description: 'Comment Data',
        args: {
            userid: { type: graphql.GraphQLInt },
            hotelid: { type: graphql.GraphQLString },          
            currentdate: { type: graphql.GraphQLString },
            period: { type: graphql.GraphQLString },
            startDate: { type: graphql.GraphQLString },
            strtags: { type: graphql.GraphQLString }
        },
        resolve: (source, {userid,hotelid,currentdate, period,startDate,strtags}) => {

            return new Promise((resolve, reject) => {
                CommentsHelper.getHotelCommentData_GraphQL(userid,hotelid,currentdate, period,startDate,strtags, (err, result) => {
                    resolve(result);
                });
            })
        }
    },
}



