const graphql = require('graphql');

const ScreenshotSchedulerHelper = require('../../helpers/screenshotscheduler_helper');
const screenshotschedulerdataType = require('../types/screenshotschedulerdatatype');
const removeresponseitemdata = require('../types/removeresponseitemdata');

module.exports = {
  getscreenshotSchedulerByUserId: {
    type: new graphql.GraphQLList(screenshotschedulerdataType),
      description: 'Get screenshot scheduler List ',
      args: {
        userid: { type: graphql.GraphQLInt }
    },
    resolve: (source, { userid }) => {
          return new Promise((resolve, reject) => {
            ScreenshotSchedulerHelper.getScreenshotSchedulerByUserId_GraphQL(userid, (err, result) => {
                  resolve(result);
              });
          })
      }
  },
  createorupdatescreenshotscheduler: {
      type: new graphql.GraphQLList(screenshotschedulerdataType),
      description: 'Create screenshotscheduler',
      args: {
        id: { type: graphql.GraphQLInt },              
        userid: { type: graphql.GraphQLInt },
        baseurl: { type: graphql.GraphQLString },
        page: { type: graphql.GraphQLString },
        schedulepageurl: { type: graphql.GraphQLString },
        createddate: { type: graphql.GraphQLString }
      },
      resolve: (source, {id,userid, baseurl, page, schedulepageurl,createddate }) => {

          return new Promise((resolve, reject) => {
            ScreenshotSchedulerHelper.createOrUpdateScreenshotScheduler_GraphQL(id,userid, baseurl, page, schedulepageurl,createddate,(err, result) => {
                  resolve(result);
              });
          })
      }
  },   
  removescreenshotscheduler: {
    type: new graphql.GraphQLList(removeresponseitemdata),
    description: 'Remove Screenshot',
    args: {
        id: { type: graphql.GraphQLInt }
    },
    resolve: (source, { id }) => {

        return new Promise((resolve, reject) => {
          ScreenshotSchedulerHelper.deletelstScreenshot_GraphQL(id, (err, result) => {
                resolve([result]);
            });
        })
    }
}
}