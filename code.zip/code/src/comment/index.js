const express = require('express');
const router = express.Router(),
    Controller = require('./controller/comments');

router.get("/commentsdata", Controller.CommentsData)
router.get("/showchart", Controller.ShowChart)



module.exports = router