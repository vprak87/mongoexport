const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const Checkit = require('checkit');
const UserHelper = require('../../helpers/user_helper');
const HotelsHelper = require('../../helpers/hotels_helper');
const CommentsHelper = require('../../helpers/comments_helper');

var log = require('log4js').getLogger("comments");



let CommentsController = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);

    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        //get myp hotelid from cmp_id
        HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
            if (err) {
                return next(err);
            }
            if (!hoteldata) {
                return next(HttpMsg.HotelNotFound);
            }
            else {
                
                CommentsHelper.getHotelComment([hoteldata][0].ID, data.currentdate, userconfigdata, data.period, req.body.startDate,req.body.strtags,(err, result) => {
                    if (err) {
                        return next(err);
                    }

                    let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                    res.status(200).send(response);
                });
            }
        });

    });

}

let ShowChartController = (req, res, next) => {
    var checkit = new Checkit({
        userid:'required',
        tags: 'required',
        hotelId: 'required',
        currentDate: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);

    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        //get myp hotelid from cmp_id
        HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
            if (err) {
                return next(err);
            }
            if (!hoteldata) {
                return next(HttpMsg.HotelNotFound);
            }
            else {
                
                CommentsHelper.getshowchartdata(data.tags, [hoteldata][0].ID, data.currentDate, userconfigdata,(err, result) => {
                    if (err) {
                        return next(err);
                    }

                    let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                    res.status(200).send(response);
                });
            }
        });

    });

}

module.exports = {
    CommentsData: CommentsController,
    ShowChart:ShowChartController
}
