const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class Hotelcommentview {

    constructor(options) {
        const child = {
            ID: '',
            HotelID: '',
            Date: '',
            UserID: 0,
            Tags: '',
            Description: '',
            UpdateDateTime: '',
            UpdatedBy:'',
            ParentID:0,
            UserTags:'',
            DisplayDate:'',
            UserName:'',
            FirstName:'',
            LastName:'',
            HotelName:'',
            ExistingReply:[],
            ChildComments:[]
        };
        // Default values
        const defaults = {
            ID: '',
            HotelID: '',
            Date: '',
            UserID: 0,
            Tags: '',
            Description: '',
            UpdateDateTime: '',
            UpdatedBy:'',
            ParentID:0,
            UserTags:'',
            DisplayDate:'',
            UserName:'',
            FirstName:'',
            LastName:'',
            HotelName:'',
            ExistingReply:[],
            ChildComments:[child]
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }



}


module.exports = Hotelcommentview;