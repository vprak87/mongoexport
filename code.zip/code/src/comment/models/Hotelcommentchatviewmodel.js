const Utils = require('../../common/utils');
const Constants = require('../../common/constants');
const Hotelcommentview = require('./Hotelcommentview');
class Hotelcommentchatviewmodel {

    constructor(options) {

        // Default values
        const defaults = {
            HotelComments:[Hotelcommentview],
            IDTags:''
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }

}

module.exports = Hotelcommentchatviewmodel;