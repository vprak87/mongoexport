class plstatementrevenueitemdata {

  constructor(options) {
    const defaults = {
      Name: '',
      Amount: 0.00,
      Category: '',
      IsActive: false,
      MonthName: '',
      GLCode: ''
    }
    
    let opts = Object.assign({}, defaults, options);

    // assign options to instance data (using only property names contained
    //  in defaults object to avoid copying properties we don't want)
    Object.keys(defaults).forEach(prop => {
        this[prop] = opts[prop];
    });
  }

  setFormat(data) {
    this.Name = data.name == null ? '' : data.name;
    this.Category = data.category == null ? '' : data.category;

    return this;
  }

}

module.exports = plstatementrevenueitemdata;