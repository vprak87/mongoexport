const PlstatementRevenueItemData = require('./plstatementrevenueitemdata');

class plstatementmonthwiseitemdata {

  constructor(options) {
    const defaults = {
      MonthName: 0.00,
      TotalSales: '',
      TotalExpenses: '',
      NetProfitBeforeTax: '',
      TotalTaxes: '',
      NetProfit: '',
      RevenueList: [],
      TaxList: [],
      ExpenseList: [],
      OperatingExpenseList: [],
      FixedExpensesList: [],
      UndistcostExpensesList: [],
      ITDAExpensesList: [],
      LabourExpenseList: []
    }
    
    let opts = Object.assign({}, defaults, options);

    // assign options to instance data (using only property names contained
    //  in defaults object to avoid copying properties we don't want)
    Object.keys(defaults).forEach(prop => {
        this[prop] = opts[prop];
    });
  }
}

module.exports = plstatementmonthwiseitemdata;