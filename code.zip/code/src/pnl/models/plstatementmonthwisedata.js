const PlstatementRevenueItemData = require('./plstatementrevenueitemdata');
const PlstatementMonthwiseItemData = require('./plstatementmonthwiseitemdata');

class plstatementmonthwisedata {

  constructor(options) {
    const defaults = {
      Items: [],
      RevenueList: [],
      TaxList: [],
      ExpenseList: [],
      OperatingExpenseList: [],
      UndistcostExpensesList: [],
      ITDAExpensesList: [],
      FixedExpensesList: [],
      NetBeforeTaxList: [],
      NetProfitList: [],
      ExpenseList1: [],
      GOPList: [],
      NOPList: [],
      NetProfitMarginList: [],
      EBIDTAExpensesList: [],
      GrossProfitMarginList: [],

      LabourExpenseList: [],
      LaborDataType: '',
      Year: 0,
      HotelId: 0,
      OrgId: 0
    }

    let opts = Object.assign({}, defaults, options);

    // assign options to instance data (using only property names contained
    //  in defaults object to avoid copying properties we don't want)
    Object.keys(defaults).forEach(prop => {
        this[prop] = opts[prop];
    });
  }

  setFormat() {
    let data = {
      Name: "Room Revenue",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "F&B Revenue",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);


    data = {
      Name: "Other Revenue",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Outlet 1 - Other",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Outlet 2 - Other",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Outlet 3 - Other",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Outlet 4 - Other",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Outlet 1 - F&B",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Outlet 2 - F&B",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Outlet 3 - F&B",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Outlet 4 - F&B",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Restaurant",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Bar",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Banquet",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Parking",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Gift Shop",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Beverage",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Food",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "TOTAL SALES",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);
    return this;
  }

}

module.exports = plstatementmonthwisedata;