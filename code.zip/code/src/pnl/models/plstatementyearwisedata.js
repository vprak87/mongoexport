class plstatementyearwisemdata {

  constructor(options) {
    const defaults = {
      Items: [],
      RevenueList: [],
      ExpenseList: [],
      LabourExpenseList: [],
      TaxList: [],
      NetBeforeTaxList: [],
      NetProfitList: [],
      NetProfitMarginList: [],
      CategoryList: []
    }
    
    let opts = Object.assign({}, defaults, options);

    // assign options to instance data (using only property names contained
    //  in defaults object to avoid copying properties we don't want)
    Object.keys(defaults).forEach(prop => {
        this[prop] = opts[prop];
    });
  }

  setFormat() {
    let data = {
      Name: "Room Revenue",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "F&B Revenue",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "Other Revenue",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    data = {
      Name: "TOTAL SALES",
      Category: "Revenue",
      Amount: 0,
      GLCode: null,
      ISActive: false,
      MonthName: null
    }
    this.RevenueList.push(data);

    this.CategoryList.push("GL Code");
    this.CategoryList.push("MTD");
    this.CategoryList.push("YTD");
    this.CategoryList.push("Variance to Last Year");
    this.CategoryList.push("Variance to Budget");
    this.CategoryList.push("Last Year Actual");
    this.CategoryList.push("Last Year Budget");
    this.CategoryList.push("CPOR");

    return this;
  }

}

module.exports = plstatementyearwisemdata;