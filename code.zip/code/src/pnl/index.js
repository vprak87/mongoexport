const express = require('express');
const router = express.Router(),
    Controller = require('./controllers/pnl');


router.get("/pnlyeardata", Controller.PnlYearData);
router.get("/pnlmonthdata", Controller.PnlMonthData);
router.get("/pnlsave", Controller.PnlSaveData);
router.get("/pnlmonthlysave", Controller.PnlSaveMonthData);


module.exports = router;