const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const Checkit = require('checkit');
const UserHelper = require('../../helpers/user_helper');

const pnlYearHelper = require('../../helpers/pnlyear_helper');
const pnlMonthHelper = require('../../helpers/pnlmonthly_helper');

var log = require('log4js').getLogger("pnl");

let pnlYearDataFn = (req, res, next) => {

  var checkit = new Checkit({
      userid: 'required',
      hotelid: 'required',
      year: 'required',
  });

  var [err, data] = checkit.validateSync(req.body);
  if (err) {
      log.error(err.toJSON());
      return res.status(400).send(err.toJSON());
  }

  UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
    if (err) {
        return next(err);
    }
    pnlYearHelper.getYearPnlData(data.hotelid, data.year, userconfigdata, (err, result) => {
      if (err) {
          return next(err);
      }
      let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
      res.status(200).send(response);
    });
  });
}

let pnlMonthDataFn = (req, res, next) => {

  var checkit = new Checkit({
      userid: 'required',
      hotelid: 'required',
      currentdate: 'required',
  });

  var [err, data] = checkit.validateSync(req.body);
  if (err) {
      log.error(err.toJSON());
      return res.status(400).send(err.toJSON());
  }

  UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
    if (err) {
        return next(err);
    }
    pnlMonthHelper.getMonthPnlData(data.hotelid, data.currentdate, userconfigdata, (err, result) => {
      if (err) {
          return next(err);
      }
      let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
      res.status(200).send(response);
    });
  });
}



let savepnlDataFn = (req, res, next) => {
  var checkit = new Checkit({
    userid: 'required',
    hotelid: 'required',
    view: 'required',
    groups: 'required'
  });
  var [err, data] = checkit.validateSync(req.body);
  if (err) {
      log.error(err.toJSON());
      return res.status(400).send(err.toJSON());
  }
  UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
    if (err) {
        return next(err);
    }
    pnlYearHelper.editOrSavepnlRawOrder(data.userid, data.hotelid, data.view, data.groups, (err, result)=> {
      if(err) {
        console.log(err)
        return next(err);
      } 
      let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build(); 
      res.status(200).send(response);
    })
  })
}

let savepnlMonthlyDataFn = (req, res, next) => {
  var checkit = new Checkit({
    userid: 'required',
    hotelid: 'required',
    view: 'required',
    groups: 'required',
    colorder: 'required'
  });
  var [err, data] = checkit.validateSync(req.body);
  if (err) {
      log.error(err.toJSON());
      return res.status(400).send(err.toJSON());
  }
  UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
    if (err) {
        return next(err);
    }
    pnlYearHelper.editOrSavepnlRawOrder(data.userid, data.hotelid, data.view, data.groups, (err, result)=> {
      if(err) {
        console.log(err);
        return next(err);
      } 
      // let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build(); 
      // res.status(200).send(response);
      pnlMonthHelper.editOrSavepnlcolOrder(data.userid, data.hotelid, data.colorder, (err2, result2)=> { 
        if(err2) {
          console.log(err2);
          return next(err2);
        } 
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result2).build(); 
        res.status(200).send(response);
      })
    })
  })
}

module.exports = {
  PnlYearData: pnlYearDataFn,
  PnlMonthData: pnlMonthDataFn,
  PnlSaveData: savepnlDataFn,
  PnlSaveMonthData: savepnlMonthlyDataFn
}