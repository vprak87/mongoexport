const Checkit = require('checkit');
const jwt = require('jsonwebtoken');
const log = require('log4js').getLogger("authentication");
const config = require('../../../appsettings.js');

const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');

const UserHelper = require('../../helpers/user_helper');
const SequenceHelper = require('../../helpers/sequence_helper');
const DBTable = require('../../schema/db_table');

const { User: UserSchema, SchemaField: UserSchemaFields } = require('../../models/user');

const { WebAPITokens: WebAPITokensSchema, SchemaField: WebAPITokensSchemaFields } = require('../../models/webapitokens');
const { Autosequence: AutosequenceSchema, SchemaField: AutosequenceSchemaFields } = require('../../models/autosequence');

let loginFn = (req, res, next) => {

    log.debug("START: loginFn");

    let { username } = req.body;

    var checkit = new Checkit({
        username: 'required',
        password: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }


    UserHelper.login(data.username, data.password, (err, result) => {

        if (err) {
            return next(err);
        }
        //after user login is ok, generate the token
        req.token = jwt.sign({
            id: result.ID,
        }, config.jwt.secret, {
            expiresIn: config.jwt.expiresIn
        });

        //insert token in 'WebAPITokens' table
        log.debug("START: insert token in 'WebAPITokens' table for userid:" + result.ID);

        var today = new Date();
        var todayplus12months = new Date();
        todayplus12months.setMonth(today.getMonth() + 12);


        //add seq code here...
        SequenceHelper.getValueForNextSequence(DBTable.WEBAPITOKENS, (err, seq) => {

            if (err) {
                return next(err)
            }

            var webapitokens = {
                [WebAPITokensSchemaFields.TokenId]: seq,
                [WebAPITokensSchemaFields.UserId]: result.ID,
                [WebAPITokensSchemaFields.AuthToken]: req.token,
                [WebAPITokensSchemaFields.IssuedOn]: today,
                [WebAPITokensSchemaFields.ExpiresOn]: todayplus12months
            };

            let webAPITokensSchema = new WebAPITokensSchema(webapitokens);
            webAPITokensSchema.save((err, webapitokenresult) => {
                if (err) {
                    return next(err)
                }

                let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                res.status(200).send(response);
            })

        });

        log.debug("END: insert token in 'WebAPITokens' table for userid:" + result.ID);


    }).catch(function (err) {
        if (err) {
            return next(err);
        }
    });
    log.debug("END: loginFn");
}

let testFn = (req, res, next) => {
    var result = Utils.encode("superadmin");

    let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
    res.status(200),
    res.send(response)
}

module.exports = {
    login: loginFn,
    test: testFn
}