const express = require('express');
const router = express.Router();

Controller = require('./controller/authentication');
validation = require('./controller/validation');


router.post("/login", Controller.login)
router.get("/test", validation.checkJWT,  Controller.test)



module.exports = router