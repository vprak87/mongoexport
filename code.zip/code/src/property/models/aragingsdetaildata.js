const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class ARAgainDetailData {
   
    constructor(options) {

        // Default values
        const defaults = {
            hotelid: 0,
            orgId: 0,
            hotelname:'',
            ishotelgroup:false,
            organisationname:'',            
            dmrasubtype: '',    
            description:'',       
            unapplied_credits: 0,
            due_0_30: 0,
            due_31_60: 0,
            due_61_90: 0,
            due_91_120: 0,
            over_120: 0,
            total: 0,
            houseledger: 0,
            advdeposit: 0,
            totalar: 0,
            daysInar: 0,
            daysInarhouse: 0,
            totalrevenue: 0,            
            date: '',
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }

    setFormat(data) {
        const defaultzero = 0;

        this.unapplied_credits = data.unapplied_credits == null || data.unapplied_credits == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.unapplied_credits, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.due_0_30 = data.due_0_30 == null || data.due_0_30 == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.due_0_30, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.due_31_60 = data.due_31_60 == null || data.due_31_60 == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.due_31_60, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.due_61_90 = data.due_61_90 == null || data.due_61_90 == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.due_61_90, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.due_91_120 = data.due_91_120 == null || data.due_91_120 == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.due_91_120, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.over_120 = data.over_120 == null || data.over_120 == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.over_120, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.total = data.total == null || data.total == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.total, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.houseledger = data.houseledger == null || data.houseledger == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.houseledger, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.advdeposit = data.advdeposit == null || data.advdeposit == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.advdeposit, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.totalar = data.totalar == null || data.totalar == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.totalar, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.daysInar = data.daysInar == null || data.daysInar == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.daysInar, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.daysInarhouse = data.daysInarhouse == null || data.daysInarhouse == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.daysInarhouse, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.totalrevenue = data.totalrevenue == null || data.totalrevenue == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.totalrevenue, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        
        return this
    }
}
module.exports = ARAgainDetailData
