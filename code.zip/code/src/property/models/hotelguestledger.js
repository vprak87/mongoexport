const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class HotelGuestLedgerData {
   
    constructor(options) {

        // Default values
        const defaults = {
            hotelid: 0,
            beginingbalance:0,     
            endingbalance:0,
            debit: 0,
            credit:0,     
            description:''
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }
    
    setFormat(data) {
        const defaultzero = 0;

        this.beginingbalance = data.beginingbalance == null || data.beginingbalance ==0 ? defaultzero.toFixed(2) : Utils.formatValue(data.beginingbalance, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.endingbalance = data.endingbalance == null || data.endingbalance == 0 ? defaultzero.toFixed(2) : Utils.formatValue(data.endingbalance, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.debit = data.debit == null || data.debit ==0 ? defaultzero.toFixed(2) : Utils.formatValue(data.debit, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.credit = data.credit == null || data.credit ==0 ? defaultzero.toFixed(2) : Utils.formatValue(data.credit, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        return this
    }
}
module.exports = HotelGuestLedgerData
