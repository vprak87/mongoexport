const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class GSSPriorityData {
   
    constructor(options) {

        // Default values
        const defaults = {
            
            description:'',  
            actualgss: 0,   
            actualgssly:0,
            benchmarkgss: 0,
            totalgss: 0,
            chart:0
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }
    
    setFormat(data) {
        const defaultzero = 0;
        this.actualgss = data.actualgss == null || data.actualgss ==0 ? defaultzero.toFixed(2) : Utils.formatValue(data.actualgss, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.totalgss = data.totalgss == null || data.totalgss ==0 ? defaultzero.toFixed(2) : Utils.formatValue(data.totalgss, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.actualgssly = data.actualgssly == null || data.actualgssly ==0 ? defaultzero.toFixed(2) : Utils.formatValue(data.actualgssly, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.benchmarkgss = data.benchmarkgss == null || data.benchmarkgss == 0 ? defaultzero.toFixed(2) : Utils.formatValue(data.benchmarkgss, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        
        return this
    }
}
module.exports = GSSPriorityData
