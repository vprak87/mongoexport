const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class OccupancyADRvsRevPARData {
   
    constructor(options) {

        // Default values
        const defaults = {
            occupancychart: 0,
            occupancymax:0,     
            occupancyactual: 0,     
            occupancylastyear: 0,  
            occupancybudget:0,
            occupancyforecast: 0,
            adrchart: 0,
            adrmax:0,
            adractual: 0,
            adrlastyear: 0,
            adrbudget: 0,
            adrforecast: 0,
            revparchart:0,
            revparmax:0,            
            revparactual:0,
            revparlastyear:0,
            revparbudget:0,
            revparforecast:0,
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }
}
module.exports = OccupancyADRvsRevPARData
