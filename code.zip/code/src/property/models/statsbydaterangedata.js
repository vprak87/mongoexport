const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class Statsbydaterangedata {
   
    constructor(options) {

        // Default values
        const defaults = {
            hotelid: 0,
            hotelname:'',
            date: '',
            adr: Constants.NoDataValue.NODATA,
            revpar:Constants.NoDataValue.NODATA,
            fandbrevenue: Constants.NoDataValue.NODATA,
            otherrevenue: Constants.NoDataValue.NODATA,            
            occupancy: Constants.NoDataValue.NODATA,
            noofroomsold: Constants.NoDataValue.NODATA,
            ooorooms:0,
            totalrevenue: Constants.NoDataValue.NODATA,
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }

    setFormat(data) {
        const defaultzero = 0;

        this.adr = data.adr == null || data.adr == '0' ? Constants.NoDataValue.NODATA : Utils.formatValue(data.adr, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.revpar = data.revpar == null ||  data.revpar == '0'  ? Constants.NoDataValue.NODATA : Utils.formatValue(data.revpar, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.fandbrevenue = data.fandbrevenue == null ||  data.fandbrevenue == '0' ? Constants.NoDataValue.NODATA : Utils.formatValue(data.fandbrevenue, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.otherrevenue = data.otherrevenue == null || data.otherrevenue == '0' ? Constants.NoDataValue.NODATA : Utils.formatValue(data.otherrevenue, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.totalrevenue = data.totalrevenue == null || data.totalrevenue == '0' ? Constants.NoDataValue.NODATA : Utils.formatValue(data.totalrevenue, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.ooorooms = data.ooorooms == null ? defaultzero.toFixed(2) : Utils.formatValue(data.ooorooms, Constants.NumeralFormats.Comma0DecimalNegativeBrackets);
        this.occupancy = data.occupancy == null || data.occupancy == '0' ? Constants.NoDataValue.NODATA : Utils.formatValue(data.occupancy, Constants.NumeralFormats.NoComma2DecimalNegativeBrackets);
        this.noofroomsold = data.noofroomsold == null || data.noofroomsold == '0' ? Constants.NoDataValue.NODATA : Utils.formatValue(data.noofroomsold, Constants.NumeralFormats.Comma0DecimalNegativeBrackets);
        
        return this
    }
}
module.exports = Statsbydaterangedata
