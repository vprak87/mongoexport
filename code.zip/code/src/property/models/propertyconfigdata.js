const Utils = require('../../common/utils');
const Constants = require('../../common/constants');
class Propertyconfigdata {

    constructor(options) {

        // Default values
        const defaults = {
            userid: 0,
            rollingrevenuecomparision: false,
            revenuebreakdowan: false,
            actvsbudvslastyr: false,
            adrvsrevpar: false,
            dashboardocc: false,
            dashboardadr: false,
            dashboardrevpar: false,
            membershipstays: false,
            dashboardmarketcurrentvslastyear: false,
            cashwidget: false,
            guestledgerwidget: false,
            payrollactualvsplanwidget: false,
            strwidget: false,
            tripadvisorratingwidget: false,
            googleplaceratingwidget: false,
            facebookpagewidget: false,
            yelpreviewwidget: false,
            weatherwidget: false,
            aragingwidget: false,
            gsspriority: false,
            ooocompwidget: false,
            totalprofit: false,
            totalexpensebreakdown: false,
            expensebudgetdepartment: false,
            expensebudgetcategory: false,
            invoicevscreditcard: false,
            expenseformbyglcode: false,

        };

        let opts = Object.assign({}, defaults, options);
        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }
}
module.exports = Propertyconfigdata