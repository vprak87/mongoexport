const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class RevenueBreakdownData {
   
    constructor(options) {

        // Default values
        const defaults = {
            label: '',
            data:0,     
            subs: [],     
            color:  getRandomColor()
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }

}

function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
} 
module.exports = RevenueBreakdownData
