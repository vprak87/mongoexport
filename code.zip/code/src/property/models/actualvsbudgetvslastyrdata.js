const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class ActualVsBudgetVsLastYrData {
   
    constructor(options) {

        // Default values
        const defaults = {
            rractual: 0,
            fbactual:0,     
            oiactual: 0,     
            toactual: 0,  
            rrlastyear: 0,
            fblastyear:0,     
            oilastyear: 0,     
            tolastyear: 0,  
            rrbudget: 0,
            fbbudget:0,     
            oibudget: 0,     
            tobudget: 0
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }

    setFormat(data) {
        const defaultzero = 0;

        this.rractual = data.rractual == null || data.rractual == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.rractual, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.fbactual = data.fbactual == null || data.fbactual == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.fbactual, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.oiactual = data.oiactual == null || data.oiactual == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.oiactual, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.toactual = data.toactual == null || data.toactual == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.toactual, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.rrlastyear = data.rrlastyear == null || data.rrlastyear == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.rrlastyear, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.fblastyear = data.fblastyear == null || data.fblastyear == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.fblastyear, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.oilastyear = data.oilastyear == null || data.oilastyear == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.oilastyear, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.tolastyear = data.tolastyear == null || data.tolastyear == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.tolastyear, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.rrbudget = data.rrbudget == null || data.rrbudget == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.rrbudget, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.oilastyearar = data.oilastyearar == null || data.oilastyearar == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.oilastyearar, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.fbbudget = data.fbbudget == null || data.fbbudget == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.fbbudget, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.oibudget = data.oibudget == null || data.oibudget == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.oibudget, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.tobudget = data.tobudget == null || data.tobudget == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.tobudget, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        
        return this
    }
}
module.exports = ActualVsBudgetVsLastYrData
