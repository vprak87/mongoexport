const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class CashTableData {
   
    constructor(options) {

        // Default values
        const defaults = {
            hotelid: 0,
            description:'',     
            totalcurrent:0,
            totalmtd: 0
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }
    
    setFormat(data) {
        const defaultzero = 0;

        this.totalcurrent = data.totalcurrent == null || data.totalcurrent ==0 ? defaultzero.toFixed(2) : Utils.formatValue(data.totalcurrent, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.totalmtd = data.totalmtd == null || data.totalmtd == 0 ? defaultzero.toFixed(2) : Utils.formatValue(data.totalmtd, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        return this
    }
}
module.exports = CashTableData
