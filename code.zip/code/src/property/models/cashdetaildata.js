const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class CashDetailData {
   
    constructor(options) {

        // Default values
        const defaults = {
            hotelid: 0,
            orgId: 0,
            hotelname:'',
            ishotelgroup:false,
            organisationname:'',
            dmrasubtype: '',           
            cash: 0,
            poscash: 0,
            othercash: 0,
            refundcash: 0,
            creditcard: 0,
            amex: 0,
            posamex: 0,
            visa: 0,
            posvisa: 0,
            mc: 0,
            posmc: 0,
            dinerscard: 0,
            posdinerscard: 0,
            discovercard: 0,
            posdiscovercard: 0,
            debit: 0,
            posdebit: 0,
            eft: 0,
            poseft: 0,
            posmanual: 0,
            posbankcards: 0,
            paidouts: 0,
            directbill: 0,
            hiltonadvancepurchase: 0,
            wiretransfer: 0,
            date: '',
            comments:''
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }

    setFormat(data) {
        const defaultzero = 0;

        this.cash = data.cash == null || data.cash == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.cash, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.poscash = data.poscash == null || data.poscash == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.poscash, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.othercash = data.othercash == null || data.othercash == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.othercash, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.refundcash = data.refundcash == null || data.refundcash == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.refundcash, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.creditcard = data.creditcard == null || data.creditcard == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.creditcard, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.amex = data.amex == null || data.amex == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.amex, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.posamex = data.posamex == null || data.posamex == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.posamex, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.visa = data.visa == null || data.visa == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.visa, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.posvisa = data.posvisa == null || data.posvisa == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.posvisa, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.mc = data.mc == null || data.mc == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.mc, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.posmc = data.posmc == null || data.posmc == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.posmc, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.dinerscard = data.dinerscard == null || data.dinerscard == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.dinerscard, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.posdinerscard = data.posdinerscard == null || data.posdinerscard == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.posdinerscard, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.debit = data.debit == null || data.debit == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.debit, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.posdebit = data.posdebit == null || data.posdebit == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.posdebit, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.eft = data.eft == null || data.eft == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.eft, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.poseft = data.poseft == null || data.poseft == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.poseft, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.posmanual = data.posmanual == null || data.posmanual == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.posmanual, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.posbankcards = data.posbankcards == null || data.posbankcards == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.posbankcards, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.paidouts = data.paidouts == null || data.paidouts == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.paidouts, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.directbill = data.directbill == null || data.directbill == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.directbill, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.hiltonadvancepurchase = data.hiltonadvancepurchase == null || data.hiltonadvancepurchase == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.hiltonadvancepurchase, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.wiretransfer = data.wiretransfer == null || data.wiretransfer == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.wiretransfer, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        return this
    }
}
module.exports = CashDetailData
