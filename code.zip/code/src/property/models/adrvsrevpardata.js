const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class ADRVSRevPARData {
   
    constructor(options) {

        // Default values
        const defaults = {
            adr: 0,
            revpar:0,     
            date:''
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }

    setFormat(data) {
        const defaultzero = 0;

        this.adr = data.adr == null || data.adr == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.adr, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        this.revpar = data.revpar == null || data.revpar == '0' ? defaultzero.toFixed(2) : Utils.formatValue(data.revpar, Constants.NumeralFormats.Comma2DecimalNegativeBrackets);
        
        return this
    }
}
module.exports = ADRVSRevPARData
