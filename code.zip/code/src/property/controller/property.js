const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const Checkit = require('checkit');
const UserHelper = require('../../helpers/user_helper');
const StatsbyDateRangeHelper = require('../../helpers/property/statsbydaterange_helper');
const CashDetailHelper = require('../../helpers/property/cashdetail_helper');
const ARAgingDetailHelper = require('../../helpers/property/aragingdetail_helper');
var log = require('log4js').getLogger("StatsbyDateRange");
const HotelsHelper = require('../../helpers/hotels_helper');
const PropertyHelper = require('../../helpers/property/property_helper');
let StatsbyDateRangeFn = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        startdate: 'required',
        enddate: 'required',
        roomrevenuenodata: 'required',
        fnbrevenuenodata: 'required',
        otherrevenenodata: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        //get myp hotelid from cmp_id
        HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
            if (err) {
                return next(err);
            }
            if (!hoteldata) {
                return next(HttpMsg.HotelNotFound);
            }
            else {
                StatsbyDateRangeHelper.getStatsbyDateRangeData(hoteldata.ID, data.startdate, data.enddate, data.roomrevenuenodata, data.fnbrevenuenodata, data.otherrevenenodata, userconfigdata, (err, result) => {
                    if (err) {
                        return next(err);
                    }

                    let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                    res.status(200).send(response);
                });
            }
        });

    });

}

let CashDetailFn = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        //get myp hotelid from cmp_id
        HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
            if (err) {
                return next(err);
            }
            if (!hoteldata) {
                return next(HttpMsg.HotelNotFound);
            }
            else {
                CashDetailHelper.getCashDetailData(data.userid, hoteldata.ID,data.currentdate, data.period, userconfigdata, (err, result) => {
                    if (err) {
                        return next(err);
                    }

                    let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                    res.status(200).send(response);
                });
            }
        });

    });

}

let ARAgingDetailFn = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        hotelgroupid: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        //get myp hotelid from cmp_id
        HotelsHelper.getHotelDataByCMPID(data.hotelid, (err, hoteldata) => {
            if (err) {
                return next(err);
            }
            if (!hoteldata) {
                return next(HttpMsg.HotelNotFound);
            }
            else {
                ARAgingDetailHelper.getARAgingDetailData(data.userid, hoteldata.ID, data.hotelgroupid, data.currentdate, data.period, userconfigdata, (err, result) => {
                    if (err) {
                        return next(err);
                    }

                    let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
                    res.status(200).send(response);
                });
            }
        });

    });

}

let OccupancyADRvsRevPARFn = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PropertyHelper.getDashboardOccupancyADRvsRevPARChart(data.userid, data.hotelid,data.currentdate, data.period, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}
let ActualVsBudgetVsLastYrFn = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PropertyHelper.getDashboardOccupancyADRvsRevPARChart_GraphQL(data.userid,data.hotelid,data.currentdate, data.period, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}
let ADRVSRevPARFn = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        currentdate: 'required',
        days: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PropertyHelper.getADRVSRevPARChart(data.userid,data.hotelid,data.currentdate, data.days, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}
let RollingRevenueComparisonFn = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        currentdate: 'required',
        days: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PropertyHelper.getRollingRevenueComparison(data.hotelid,data.currentdate, data.days, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}
let MembershipStaysFn = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PropertyHelper.getMembershipStaysChart(data.userid,data.hotelid,data.currentdate, data.period, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}
let MarketSegmentVsLastYrFn = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PropertyHelper.getRoomSalesVsLastYrChart(data.userid,data.hotelid,data.currentdate, data.period, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}
let GetAllMissingDatesLastDays = (req, res, next) => {
    var checkit = new Checkit({
        hotelid: 'required',
        currentdate: 'required',
        period: 'required',
        roomrevenue:'required',
        otherrevenue:'required'

    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PropertyHelper.getAllMissingDatesLastDays(data.hotelid,data.currentdate, data.period,data.roomrevenue,data.otherrevenue, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}
let GetMissingDatesCash = (req, res, next) => {
    var checkit = new Checkit({
        hotelid: 'required',
        currentdate: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PropertyHelper.getMissingDatesCash(data.hotelid,data.currentdate, req.body.period, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });
}
let GetMissingDatesARAging = (req, res, next) => {
    var checkit = new Checkit({
        hotelid: 'required',
        currentdate: 'required',
        period: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PropertyHelper.getMissingDatesARAging(data.hotelid,data.currentdate,data.period, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });
}
module.exports = {
    StatsbyDateRangeData: StatsbyDateRangeFn,
    CashDetailData: CashDetailFn,
    ARAgingDetail: ARAgingDetailFn,
    OccupancyADRvsRevPAR:OccupancyADRvsRevPARFn,
    ActualVsBudgetVsLastYr:ActualVsBudgetVsLastYrFn,
    ADRVSRevPAR:ADRVSRevPARFn,
    RollingRevenueComparison:RollingRevenueComparisonFn,
    MembershipStays:MembershipStaysFn,
    MarketSegmentVsLastYr:MarketSegmentVsLastYrFn,
    GetAllMissingDatesLastDays:GetAllMissingDatesLastDays,
    GetMissingDatesCash:GetMissingDatesCash,
    GetMissingDatesARAging:GetMissingDatesARAging
}