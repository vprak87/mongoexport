const express = require('express');
const router = express.Router(),
    Controller = require('./controller/property');


router.get("/statsbydaterangedata", Controller.StatsbyDateRangeData)
router.get("/cashdetaildata", Controller.CashDetailData)
router.get("/aragingdetaildata", Controller.ARAgingDetail)
router.get("/occupancyvsrevpar", Controller.OccupancyADRvsRevPAR)
router.get("/actualvsbudgetvslastyr", Controller.ActualVsBudgetVsLastYr)
router.get("/adrvsrevpar", Controller.ADRVSRevPAR)
router.get("/rollingrevenue", Controller.RollingRevenueComparison)
router.get("/membershipstays", Controller.MembershipStays)
router.get("/marketsegmentvslastyr", Controller.MarketSegmentVsLastYr)
router.get("/getallmissingdateslastdays", Controller.GetAllMissingDatesLastDays)
router.get("/getmissingdatescash", Controller.GetMissingDatesCash)
router.get("/getmissingdatesaraging", Controller.GetMissingDatesARAging)
module.exports = router