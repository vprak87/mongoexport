

const Checkit = require('checkit');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const MYP1RedirectHelper = require('../../helpers/myp1redirect_helper');

var log = require('log4js').getLogger("myp1redirect");

let UserTokenDataFn = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    MYP1RedirectHelper.getUserToken(data.userid, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}

let URLDataFn = (req, res, next) => {

    var checkit = new Checkit({
        token: 'required',
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    MYP1RedirectHelper.getURLData(data.token, (err, result) => {
        if (err) {
            return next(err);
        }

        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });

}


module.exports = {
    UserTokenData: UserTokenDataFn,
    URLData: URLDataFn,
}
