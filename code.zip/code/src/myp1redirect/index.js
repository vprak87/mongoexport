const express = require('express');
const router = express.Router(),
    Controller = require('./controller/myp1redirect');

router.get("/usertokendata", Controller.UserTokenData);
router.get("/urldata", Controller.URLData);

module.exports = router
