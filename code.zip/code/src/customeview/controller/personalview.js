const Utils = require('../../common/utils');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const Checkit = require('checkit');
let PersonalViewHelper = require('../../helpers/personalview_helper');
var log = require('log4js').getLogger("personalview");

let newPersonalView = (req, res, next) => {
    PersonalViewHelper.getTemplatesList((err, result) => {
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });
}
let addPersonalData = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        name: 'required',
        templateId:'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    } 
    PersonalViewHelper.createTemplate(data.userid,data.name,req.body.description,data.templateId,(err, result) => {
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });
}
let getKPIList = (req, res, next) => {
    PersonalViewHelper.getKPIList((err, result) => {
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });
}
let getChartData = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        id:'required',
        period:'required',
        kpi:'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    PersonalViewHelper.getChartData(data.userid,req.body.fromdate ,req.body.todate ,req.body.type ,data.id ,data.period ,data.kpi,(err, result) => {
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });        
}
let editChartData = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        templateid:'required',
        graphid:'required',
        subtemplateid:'required',
        chartposition:'required',
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }    
    PersonalViewHelper.editTemplate(req.body._id,data.userid,
        data.templateid,
        data.graphid,
        data.subtemplateid,
        data.chartposition,
        (err, result) => {
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });
}

let getSavedTemplatetData  = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
    });
    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    } 
    PersonalViewHelper.getSavedTemplatetData(data.userid,(err, result) => {
        
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });           
}
let getSavedChartData  = (req, res, next) => {
    var checkit = new Checkit({
        userid: 'required',
        templateid : 'required'
    });
    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    } 
    PersonalViewHelper.getSavedChartData(data.userid,data.templateid,(err, result) => {
        
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });           
}
let deleteSavedChart = (req, res, next) => {
    var checkit = new Checkit({
        id: 'required',
    });
    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    } 
    PersonalViewHelper.deleteSavedChart(data.id,(err, result) => {
        
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });    
}
let getgraphtypeData = (req, res, next) => {
    PersonalViewHelper.getGraphData((err, result) => {
        
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
        res.status(200).send(response);
    });    
}

module.exports = {
    GetNewPersonalViewData: newPersonalView,
    AddPersonalViewData:addPersonalData,
    GetKPIList:getKPIList,
    GetChartData:getChartData,
    EditChartData:editChartData,
    getSavedTemplatetData:getSavedTemplatetData,
    getSavedChartData:getSavedChartData,
    DeleteSavedChart:deleteSavedChart,
    GetGraphTypes:getgraphtypeData
}