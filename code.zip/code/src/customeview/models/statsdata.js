const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class StatsData {

    constructor(options) {

        // Default values
        const defaults = {
            date:'',
            kpikey: '',
            displayname: '',
            actualvalue: '',
            lyvalue: '',
            budgetvalue: '',
            forcastvalue: '',
            actualunit: ''
        };
        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }
    setFormatGroup(data) {
        const defaultzero = 0;

        if (this.actualunit == Constants.Units.Percentage) {
            this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.NoComma2Decimal);
            this.lyvalue  = data.lyvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.lyvalue, Constants.NumeralFormats.NoComma2Decimal);
            this.budgetvalue  = data.budgetvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.budgetvalue, Constants.NumeralFormats.NoComma2Decimal);
            this.forcastvalue  = data.forcastvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.forcastvalue, Constants.NumeralFormats.NoComma2Decimal);
        }
        if (this.actualunit == Constants.Units.DecimalNumber) {
            this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.NoComma2Decimal);
            this.lyvalue  = data.lyvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.lyvalue, Constants.NumeralFormats.NoComma2Decimal);
            this.budgetvalue  = data.budgetvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.budgetvalue, Constants.NumeralFormats.NoComma2Decimal);
            this.forcastvalue  = data.forcastvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.forcastvalue, Constants.NumeralFormats.NoComma2Decimal); 
        }
        else if (this.actualunit == Constants.Units.Number) {
            this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.NoComma0Decimal);
            this.lyvalue  = data.lyvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.lyvalue, Constants.NumeralFormats.NoComma0Decimal);
            this.budgetvalue  = data.budgetvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.budgetvalue, Constants.NumeralFormats.NoComma0Decimal);
            this.forcastvalue  = data.forcastvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.forcastvalue, Constants.NumeralFormats.NoComma0Decimal);
        }
        else if (this.actualunit == Constants.Units.Text) {
            this.actualvalue = data.actualvalue == null ? '' : data.actualvalue;
            this.lyvalue  = data.lyvalue == null ? '' : data.lyvalue;
            this.budgetvalue  = data.budgetvalue == null ? '' : data.budgetvalue;
            this.forcastvalue  = data.forcastvalue == null ? '' : data.forcastvalue; 
        }
        else {
            this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.Comma2Decimal);
            this.lyvalue  = data.lyvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.lyvalue, Constants.NumeralFormats.Comma2Decimal);
            this.budgetvalue  = data.budgetvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.budgetvalue, Constants.NumeralFormats.Comma2Decimal);
            this.forcastvalue  =  data.forcastvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.forcastvalue, Constants.NumeralFormats.Comma2Decimal);
        }
        return this;
    }
    setFormat(data) {
        const defaultzero = 0;

        if (this.actualunit == Constants.Units.Percentage) {
            this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.NoComma2Decimal);
        }
        if (this.actualunit == Constants.Units.DecimalNumber) {
            this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.NoComma2Decimal);
        }
        else if (this.actualunit == Constants.Units.Number) {
            this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.NoComma0Decimal);
        }
        else if (this.actualunit == Constants.Units.Text) {
            this.actualvalue = data.actualvalue == null ? '' : data.actualvalue;
        }
        else {
            this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.Comma2Decimal);
        }
        return this;
    }    
}
 
        
module.exports = StatsData;