const express = require('express');
const router = express.Router(),
    Controller = require('./controller/personalview');


router.get("/newpersonalview", Controller.GetNewPersonalViewData);
router.get("/addpersonalview", Controller.AddPersonalViewData);
router.get("/getchartdata", Controller.GetChartData);
router.get("/editchartdata", Controller.EditChartData);
router.get("/getsavedtemplatedata", Controller.getSavedTemplatetData);
router.get("/getsavedchartdata", Controller.getSavedChartData);
router.get("/deletesavedchart", Controller.DeleteSavedChart);
router.get("/getkpilist", Controller.GetKPIList);
router.get("/getgraphdata", Controller.GetGraphTypes);







module.exports = router