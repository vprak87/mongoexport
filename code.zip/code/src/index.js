'use strict';
const HttpMsg = require('./common/constants');
const Response = require('./common/response');
const dbtable = require('./schema/db_table');

var config = require('../appsettings.js');

const express = require('express'),
    jwt = require('jsonwebtoken'),
    Authentication = require('./authentication'),
    User = require('./user'),
    Scorecard = require('./scorecard'),
    Trends = require('./trends'),
    Pickup = require('./pickup'),
    Strreport = require('./strreport'),
    app = express(),
    MObjectId = require('mongoose').Types.ObjectId,
    Labor = require('./labor'),
    Property = require('./property'),
    Pnl = require('./pnl'),
    Customkpi = require('./customkpi'),
    portfolio = require('./portfolio'),
    Customeview = require('./customeview'),
    HotelList = require('./hotelList'),
    alerts = require('./alerts'),
    Comments = require('./comment'),
    MYP1Redirect = require('./myp1redirect'),
    Exclamation = require('./exclamation'),
    UserList = require('./userList');

const { User: UserSchema, SchemaField: UserSchemaFields } = require('./models/user');
const { WebAPITokens: WebAPITokensSchema, SchemaField: WebAPITokensSchemaFields } = require('./models/webapitokens');


var apiRoutesValidated = express.Router();

// route middleware to verify a token
apiRoutesValidated.use(function (req, res, next) {
    // check header or url parameters or post parameters for token
    var token = req.body.token || req.query.token || req.headers['token'];
    // decode token
    if (token) {
        // verifies secret and checks exp
        jwt.verify(token, config.jwt.secret, function (err, decoded) {
            if (err) {
                let response = new Response(false, 401).setMessage(HttpMsg.TokenFailed).build();
                return res.status(401).send(response);
            } else {

                // if everything is good, save to request for use in other routes
                req.id = decoded.id;


                //get user from id  
                // users- webapitokens

                let userAggregate = UserSchema.aggregate();

                userAggregate.match({
                    // [UserSchemaFields._id]: MObjectId(req.id)
                    [UserSchemaFields.ID]: req.id
                })

                var today = Date.now;

                //webapitoken detail
                userAggregate.lookup({
                    from: dbtable.WEBAPITOKENS,
                    // let: { uId: `$${UserSchemaFields._id}` },
                    let: { uId: `$${UserSchemaFields.ID}` },
                    pipeline: [
                        {
                            $match:
                            {
                                $expr: {
                                    $and: [
                                        { $eq: ["$$uId", `$${WebAPITokensSchemaFields.UserId}`] },
                                        // { $gt: [`$${WebAPITokensSchemaFields.ExpiresOn}`, today] }
                                    ]
                                }
                            }
                        },
                        {
                            $project: {
                                "_id": 1,
                                [WebAPITokensSchemaFields.AuthToken]: 1
                            }
                        }
                    ],
                    as: "AuthTokens"
                })

                userAggregate.exec((err, result) => {
                    if (err)
                        return next(err)

                    if (!result || result.length == 0) {
                        let response = new Response(false, 401).setMessage(HttpMsg.UserTokenFailed).build();
                        return res.status(401).send(response);
                    }
                    else {

                        let userJson = result[0].AuthTokens;

                        let t = userJson.filter(function (ut) { return ut.AuthToken == token })[0];
                        if (!t) {
                            let response = new Response(false, 401).setMessage(HttpMsg.UserNOTLoggedIn).build();
                            return res.status(401).send(response);
                        } else {
                            req.user = result[0];
                            next();
                        }
                    }
                });
            }
        });
    } else {
        let response = new Response(false, 401).setMessage(HttpMsg.InvalidToken).build();
        return res.status(401).send(response);
    }
});

app.use("/authentication", Authentication);
app.use('/user', apiRoutesValidated, User);
app.use('/test', User);
app.use('/labor', Labor);
app.use('/customeview', Customeview);
app.use('/scorecard', Scorecard);
app.use('/trends', Trends);
app.use('/strreport', Strreport);
app.use('/pickup', Pickup);
app.use('/property', Property);
app.use('/pnl', Pnl);

app.use('/portfolio', portfolio);
app.use('/customkpi', Customkpi);

app.use('/hotellist', HotelList);
app.use('/alerts', alerts);
app.use('/comments', Comments);
app.use('/exclamation', Exclamation);
app.use('/myp1redirect', MYP1Redirect);
app.use('/userlist', UserList);


module.exports = app;

