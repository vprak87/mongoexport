'use strict';
let CreateowntablemappingsgroupSchema = {
    _id: '_id',
    ID: 'ID',
    UserID: 'UserID',
    GroupName: 'GroupName',
    GroupColor: 'GroupColor',
    DisplayOrder: 'DisplayOrder',
    UpdatedBy: 'UpdatedBy',
    UpdateDateTime: 'UpdateDateTime',
    kpilist: 'kpilist'


}


module.exports = CreateowntablemappingsgroupSchema