'use strict';
let HotelavendraalertinsightSchema = {
    _id: '_id',
    AvendraAlertInsightid: 'AvendraAlertInsightid',
    AlertID: 'AlertID',
    AvendraAlertGroupId: 'AvendraAlertGroupId',
    AvendraAlertSubGroupId: 'AvendraAlertSubGroupId',
    UnitNumber: 'UnitNumber',
    AvendraAlertInsightTypeId: 'AvendraAlertInsightTypeId',
    InsightDescription: 'InsightDescription',
    InsightNumber: 'InsightNumber',
    AvendraAlertInsightLevelId: 'AvendraAlertInsightLevelId'



}


module.exports = HotelavendraalertinsightSchema