'use strict';
let EmailpdfreportcolumnmasterSchema = {
    _id: '_id',
    ID: 'ID',
    Name: 'Name',
    DisplayName: 'DisplayName',
    Type: 'Type',
    DisplayOrder: 'DisplayOrder'
}


module.exports = EmailpdfreportcolumnmasterSchema