'use strict';
let CitySchema = {
    _id: '_id',
    CityId: 'CityId',
    Name: 'Name',
    StateISO: 'StateISO',
    ZipCode: 'ZipCode'
}


module.exports = CitySchema