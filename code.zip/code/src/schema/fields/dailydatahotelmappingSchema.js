'use strict';
let DailydatahotelmappingSchema = {
    _id: '_id',
    ID: 'ID',
    HotelID: 'HotelID',
    ClientHotelId: 'ClientHotelId'
}


module.exports = DailydatahotelmappingSchema