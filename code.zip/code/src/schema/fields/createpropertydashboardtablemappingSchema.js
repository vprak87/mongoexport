'use strict';
let CreatePropertyDashboardTableMappingSchema = {
    _id: '_id',
    ID: 'ID',
    ColumName: 'ColumName',
    ColumPeriod: 'ColumPeriod',
    DisplayOrder: 'DisplayOrder',
    UserID: 'UserID'
}


module.exports = CreatePropertyDashboardTableMappingSchema