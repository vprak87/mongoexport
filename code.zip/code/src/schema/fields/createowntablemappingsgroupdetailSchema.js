'use strict';
let CreateowntablemappingsgroupdetailSchema = {
    _id: '_id',
    ID: 'ID',
    GroupID: 'GroupID',
    KPIKey: 'KPIKey',
    DisplayOrder: 'DisplayOrder',
    UpdatedBy: 'UpdatedBy',
    UpdateDateTime: 'UpdateDateTime'


}


module.exports = CreateowntablemappingsgroupdetailSchema