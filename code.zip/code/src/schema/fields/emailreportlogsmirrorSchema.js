'use strict';
let EmailreportlogsmirrorSchema = {
    _id: '_id',
    ID: 'ID',
    ReportDate: 'ReportDate',
    UserID: 'UserID',
    EmailAddress: 'EmailAddress',
    HotelID: 'HotelID',
    EmailSent: 'EmailSent',
    NoDataFound: 'NoDataFound',
    ActionType: 'ActionType',
    IsManager: 'IsManager',
    IsAdmin: 'IsAdmin',
    InsertedDateTime: 'InsertedDateTime',
    UpdatedDateTime: 'UpdatedDateTime',
    UpdatedBy: 'UpdatedBy',
    ScheduledDateTime: 'ScheduledDateTime',
    Category: 'Category',
    EmailConfigurationScheduleID: 'emailConfigurationScheduleID',
}


module.exports = EmailreportlogsmirrorSchema