'use strict';
let EmailconfigurationotherrecipientsSchema = {
    _id: '_id',
    ID: 'ID',
    EmailConfigurationID: 'EmailConfigurationID',
    UserID: 'UserID',
    UpdatedBy: 'UpdatedBy',
    UpdatedDateTime: 'UpdatedDateTime',
    EmailConfigurationScheduleID: 'emailConfigurationScheduleID'
}


module.exports = EmailconfigurationotherrecipientsSchema