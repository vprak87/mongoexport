'use strict';
let EmailconfigurationreportSchema = {
    _id: '_id',
    ID: 'EmailConfigurationReportId',
    EmailConfigurationReportName: 'EmailConfigurationReportName'
}


module.exports = EmailconfigurationreportSchema