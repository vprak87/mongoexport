'use strict';
let ContactsupportlogsSchema = {
    _id: '_id',
    LogId: 'LogId',
    QuestionId: 'QuestionId',
    Subject: 'Subject',
    Message: 'Message',
    Rating: 'Rating',
    UpdatedBy: 'UpdatedBy',
    UpdatedDateTime: 'UpdatedDateTime'

}


module.exports = ContactsupportlogsSchema