'use strict';
let HotelavendraalertdetailSchema = {
    _id: '_id',
    AvendraAlertDetailid: 'AvendraAlertDetailid',
    AvendraAlertInsightid: 'AvendraAlertInsightid',
    UnitNumber: 'UnitNumber',
    RankValue: 'RankValue',
    Attributes: 'Attributes',
    AvendraAlertGroupId: 'AvendraAlertGroupId',
    AvendraAlertSubGroupId: 'AvendraAlertSubGroupId'



}


module.exports = HotelavendraalertdetailSchema