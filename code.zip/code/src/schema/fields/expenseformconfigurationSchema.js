'use strict';
let ExpenseformconfigurationSchema = {
    _id: '_id',
    ID: 'ID',
    OrganisationId: 'OrganisationId',
    ExpenseTypeCreditCard: 'ExpenseTypeCreditCard',
    ExpenseTypeInvoice: 'ExpenseTypeInvoice',
    ExpenseTypeUrgent: 'ExpenseTypeUrgent',
    UpdatedDateTime: 'UpdatedDateTime',
    UpdatedBy: 'UpdatedBy',
    ExpenseTypeStatement: 'ExpenseTypeStatement',
    ExpenseTypeDepositSlip: 'ExpenseTypeDepositSlip',
    ExpenseTypePettyCash: 'ExpenseTypePettyCash',
    ExpenseTypeWages: 'ExpenseTypeWages'

}


module.exports = ExpenseformconfigurationSchema