'use strict';
let CreateowntablemappingSchema = {
    _id: '_id',
    ID: 'ID',
    UserID: 'UserID',
    CreateOwnTableMasterID: 'CreateOwnTableMasterID',
    DisplayOrder: 'DisplayOrder',
    UpdatedBy: 'UpdatedBy',
    UpdateDateTime: 'UpdateDateTime'


}


module.exports = CreateowntablemappingSchema