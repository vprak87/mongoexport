'use strict';
let GlcodemasterSchema = {
    _id: '_id',
    ID: 'ID',
    HotelID: 'HotelID',
    GLCode: 'GLCode',
    GLDescripton: 'GLDescripton',
    DepartmentID: 'DepartmentID',
    UpdateDateTime: 'UpdateDateTime',
    UpdatedBy: 'UpdatedBy'

}


module.exports = GlcodemasterSchema