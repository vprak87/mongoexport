'use strict';
let FbpagehotelmappingSchema = {
    _id: '_id',
    ID: 'ID',
    FBPageURL: 'FBPageURL',
    HotelID: 'HotelID'

}


module.exports = FbpagehotelmappingSchema