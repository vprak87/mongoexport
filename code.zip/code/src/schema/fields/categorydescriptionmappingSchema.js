'use strict';
let CategorydescriptionmappingSchema = {
    _id: '_id',
    ID: 'ID',
    HotelID: 'HotelID',
    Date: 'Date',
    Category: 'Category',
    OldCategory: 'OldCategory',
    Description: 'Description',
    OrganisationID: 'OrganisationID',
    PMS: 'PMS',
    UpdatedBy: 'UpdatedBy',
    UpdatedDateTime: 'UpdatedDateTime',
}


module.exports = CategorydescriptionmappingSchema