'use strict';
let AccountingtoolmasterpropertiesSchema = {
    _id: '_id',
    ID: 'Id',
    Property: 'Property'
}


module.exports = AccountingtoolmasterpropertiesSchema