'use strict';
let EmailuserhoteltokenSchema = {
    _id: '_id',
    ID: 'Id',
    UserID: 'UserID',
    HotelID: 'HotelID',
    HotelGroupID: 'HotelGroupID',
    Token: 'Token'

}


module.exports = EmailuserhoteltokenSchema