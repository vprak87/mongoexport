'use strict';
let EmailconfigurationreportSchema = {
    _id: '_id',
    ID: 'emailConfigurationScheduleID',
    EmailConfigurationID: 'emailConfigurationID',
    EmailConfigurationReportID: 'emailConfigurationReport_Id',
    ScheduleTime: 'scheduleTime',
    TimeZone: 'timeZone',
    EmailNotificationRequest: 'emailNotificationRequest',
    ScheduleType: 'scheduleType',
    OtherRecipients: 'otherRecipients',
    BlackAndWhiteColor: 'BlackAndWhiteColor',
    IsScheduleActive: 'IsScheduleActive',
    UpdatedBy: 'updatedBy',
    UpdatedOn: 'updatedOn'
}


module.exports = EmailconfigurationreportSchema