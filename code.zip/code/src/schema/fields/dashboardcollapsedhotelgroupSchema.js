'use strict';
let DashboardcollapsedhotelgroupSchema = {
    _id: '_id',
    ID: 'ID',
    UserID: 'UserID',
    HotelGroups: 'HotelGroups',
    UpdatedBy: 'UpdatedBy',
    UpdateDateTime: 'UpdateDateTime'
}


module.exports = DashboardcollapsedhotelgroupSchema