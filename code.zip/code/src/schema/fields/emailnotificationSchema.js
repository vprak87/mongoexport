'use strict';
let EmailnotificationSchema = {
    _id: '_id',
    ID: 'ID',
    ReportDate: 'ReportDate',
    HotelID: 'HotelID',
    UserID: 'UserID',
    SendEmailToUserID: 'SendEmailToUserID',
    NoDataFound: 'NoDataFound',
    EmailSent: 'EmailSent',
    InsertedDateTime: 'InsertedDateTime',
    InsertedBy: 'InsertedBy',
    UpdatedDateTime: 'UpdatedDateTime',
    UpdatedBy: 'UpdatedBy'
}


module.exports = EmailnotificationSchema