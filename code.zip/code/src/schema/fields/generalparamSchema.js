'use strict';
let GeneralparamSchema = {
    _id: '_id',
    ID: 'ID',
    KeyParam: 'KeyParam',
    ValueParam: 'ValueParam'

}


module.exports = GeneralparamSchema