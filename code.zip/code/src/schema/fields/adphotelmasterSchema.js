'use strict';
let AdphotelmasterSchema = {
    _id: '_id',
    ID: 'Id',
    Description: 'Description',
    Code: 'Code',
    HotelID: 'HotelID'
}


module.exports = AdphotelmasterSchema