'use strict';
let HotelavendraalertsubgroupSchema = {
    _id: '_id',
    AvendraAlertSubGroupId: 'AvendraAlertSubGroupId',
    AvendraAlertSubGroupName: 'AvendraAlertSubGroupName'



}


module.exports = HotelavendraalertsubgroupSchema