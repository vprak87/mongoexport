'use strict';
let CashdescriptionmappingSchema = {
    _id: '_id',
    ID: 'ID',
    HotelID: 'HotelID',
    OrganizationID: 'OrganizationID',
    Description: 'Description',
    Category: 'Category',
    UpdateDateTime: 'UpdateDateTime',
    UpdatedBy: 'UpdatedBy',
    IsActive: 'IsActive'
}


module.exports = CashdescriptionmappingSchema