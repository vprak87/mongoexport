'use strict';
let CreatePnlTableMappingSchema = {
    _id: '_id',
    ID: 'ID',
    ColumName: 'ColumName',
    ColumPeriod: 'ColumPeriod',
    DisplayOrder: 'DisplayOrder',
    UserID: 'UserID',
    PNLType: 'PNLType'
}


module.exports = CreatePnlTableMappingSchema