'use strict';
let EmailconfigurationdaysSchema = {
    _id: '_id',
    ID: 'ID',
    EmailConfigurationID: 'EmailConfigurationID',
    Day: 'Day',
    UpdatedBy: 'UpdatedBy',
    UpdatedDateTime: 'UpdatedDateTime',
    EmailConfigurationScheduleID: 'emailConfigurationScheduleID'
}


module.exports = EmailconfigurationdaysSchema