'use strict';
let EmailconfigurationSchema = {
    _id: '_id',
    ID: 'ID',
    UserID: 'UserID',
    EmailRequest: 'EmailRequest',
    ErrorRequest: 'ErrorRequest',
    RoomRevenueRequest: 'RoomRevenueRequest',
    RoomRevenueTableRequest: 'RoomRevenueTableRequest',
    IsDelete: 'IsDelete',
    UpdatedBy: 'UpdatedBy',
    UpdatedDateTime: 'UpdatedDateTime',
    ScheduleTime: 'ScheduleTime',
    TimeZone: 'TimeZone',
    EmailNotificationRequest: 'EmailNotificationRequest',
    PDFReportRequest: 'PDFReportRequest',
    MissingDatesPDFReportRequest: 'MissingDatesPDFReportRequest',
    BlackAndWhiteColor: 'BlackAndWhiteColor',
    ScheduleType: 'ScheduleType',
    OtherRecipients: 'OtherRecipients',
    ARAgingPDFReportRequest: 'ARAgingPDFReportRequest',
    IsEmailActive: 'IsEmailActive'
}


module.exports = EmailconfigurationSchema