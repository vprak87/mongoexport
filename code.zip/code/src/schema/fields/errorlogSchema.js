'use strict';
let ErrorlogSchema = {
    _id: '_id',
    ErrorId: 'ErrorId',
    UserID: 'UserId',
    TimeUtc: 'TimeUtc',
    ErrorMessage: 'ErrorMessage',
    Exception: 'Exception'

}


module.exports = ErrorlogSchema