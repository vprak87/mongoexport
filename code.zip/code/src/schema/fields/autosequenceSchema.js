'use strict';
let AutosequenceSchema = {
    _id: '_id',
    TableName: 'tablename',
    SequenceValue: 'sequence_value'
}


module.exports = AutosequenceSchema