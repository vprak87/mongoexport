'use strict';
let EventsSchema = {
    _id: '_id',
    ID: 'ID',
    HotelID: 'HotelID',
    EventName: 'EventName',
    Description: 'Description',
    StartDate: 'StartDate',
    TimeZone: 'TimeZone',
    UpdateDateTime: 'UpdateDateTime',
    UpdatedBy: 'UpdatedBy',
    IsActive: 'IsActive',
    IsRepeat: 'IsRepeat',
    Repeats: 'Repeats',
    RepeatEvery: 'RepeatEvery',
    RepeatOn: 'RepeatOn',
    EndDate: 'EndDate'

}


module.exports = EventsSchema