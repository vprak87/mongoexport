'use strict';
let CreateowntablemappingmasterSchema = {
    _id: '_id',
    ID: 'ID',
    TableName: 'TableName',
    ColumName: 'ColumName',
    DisplayOrder: 'DisplayOrder',
    KPIKey: 'KPIKey',
    ParentKey: 'ParentKey',
    HasSubKey: 'HasSubKey',
    KPIFormula: 'KPIFormula',
    Unit: 'Unit',
    OrganizationId: 'OrganizationId',
    IsCustom:'IsCustom'


}


module.exports = CreateowntablemappingmasterSchema