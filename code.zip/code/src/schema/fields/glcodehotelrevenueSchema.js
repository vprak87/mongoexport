'use strict';
let GlcodehotelrevenueSchema = {
    _id: '_id',
    ID: 'ID',
    HotelName: 'HotelName',
    Description: 'Description',
    DisplayDescription: 'DisplayDescription',
    GLCode: 'GLCode',
    HotelID: 'HotelID',
    OrganizationID: 'OrganizationID',
    UpdateDateTime: 'UpdateDateTime',
    UpdatedBy: 'UpdatedBy',
    IsActive: 'IsActive',
    Category: 'Category',
    DepartmentID: 'DepartmentID',
    DisplayPMSCode: 'DisplayPMSCode',
    GLDescription: 'GLDescription'

}


module.exports = GlcodehotelrevenueSchema