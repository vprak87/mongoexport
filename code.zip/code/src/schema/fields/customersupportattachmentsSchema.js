'use strict';
let CustomersupportattachmentsSchema = {
    _id: '_id',
    ID: 'Id',
    LogId: 'LogId',
    FilePath: 'FilePath'
}


module.exports = CustomersupportattachmentsSchema