'use strict';
let DynamicshotelmappingSchema = {
    _id: '_id',
    ID: 'ID',
    HotelID: 'HotelID',
    ServerName: 'ServerName',
    DatabaseName: 'DatabaseName',
    UserName: 'UserName',
    Password: 'Password',
    IsActive: 'IsActive',
    UpdatedDateTime: 'UpdatedDateTime',
    UpdatedBy: 'UpdatedBy'
}


module.exports = DynamicshotelmappingSchema