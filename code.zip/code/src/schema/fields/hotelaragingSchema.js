'use strict';
let HotelaragingSchema = {
    _id: '_id',
    ID: 'ID',
    HotelID: 'HotelID',
    Description: 'Description',
    Date: 'Date',
    InvoiceNumber: 'InvoiceNumber',
    InvoiceDate: 'InvoiceDate',
    Amount: 'Amount',
    Due_0_30: 'Due_0_30',
    Due_31_60: 'Due_31_60',
    Due_61_90: 'Due_61_90',
    Due_91_120: 'Due_91_120',
    Over_120: 'Over_120',
    UpdatedDateTime: 'UpdatedDateTime',
    UpdatedBy: 'UpdatedBy',
    Unapplied_Credits: 'Unapplied_Credits'

}


module.exports = HotelaragingSchema