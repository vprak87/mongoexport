'use strict';
let CatagoriesSchema = {
    _id: '_id',
    ID: 'ID',
    Catagory: 'Catagory'
}


module.exports = CatagoriesSchema