'use strict';
let CountrySchema = {
    _id: '_id',
    CountryId: 'CountryId',
    Name: 'Name',
    CountryISO: 'CountryISO'

}


module.exports = CountrySchema