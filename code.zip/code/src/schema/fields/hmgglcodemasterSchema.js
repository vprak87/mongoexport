'use strict';
let HMGGLCodeMasterSchema = {
    _id: '_id',
    GLCode: 'GLCode',
    Description: 'Description',
    OrganizationID: 'OrganizationID',
    IsActive: 'IsActive'
}


module.exports = HMGGLCodeMasterSchema