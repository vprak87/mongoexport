'use strict';
let BoardcastmessageSchema = {
    _id: '_id',
    BoardcastMessageID: 'BoardcastMessageID',
    UserID: 'UserID',
    OrgID: 'OrgID',
    Message: 'Message',
    StartDate: 'StartDate',
    EndDate: 'EndDate',
    IsActive: 'IsActive',
    UpdatedDateTime: 'UpdatedDateTime',
    UpdatedBy: 'UpdatedBy',
}


module.exports = BoardcastmessageSchema