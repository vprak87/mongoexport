'use strict';
let FailedemaillistSchema = {
    _id: '_id',
    ID: 'ID',
    EmailAddress: 'EmailAddress',
    UserId: 'UserId',
    ReportedDate: 'ReportedDate',
    Status: 'Status',
    Remarks: 'Remarks',
    UpdatedDateTime: 'UpdatedDateTime'

}


module.exports = FailedemaillistSchema