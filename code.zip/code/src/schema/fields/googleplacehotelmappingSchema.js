'use strict';
let GoogleplacehotelmappingSchema = {
    _id: '_id',
    ID: 'ID',
    PlaceID: 'PlaceID',
    HotelID: 'HotelID'

}


module.exports = GoogleplacehotelmappingSchema