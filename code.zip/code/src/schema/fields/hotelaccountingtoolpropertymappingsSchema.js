'use strict';
let HotelaccountingtoolpropertymappingsSchema = {
    _id: '_id',
    ID: 'Id',
    HotelId: 'HotelId',
    MasterProperty: 'MasterProperty',
    AccountingProperty: 'AccountingProperty',
    UpdatedBy: 'UpdatedBy',
    UpdatedDateTime: 'UpdatedDateTime'

}


module.exports = HotelaccountingtoolpropertymappingsSchema