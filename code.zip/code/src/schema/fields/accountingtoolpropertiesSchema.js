'use strict';
let AccountingtoolpropertiesSchema = {
    _id: '_id',
    ID: 'Id',
    AccountingTool: 'AccountingTool',
    Property: 'Property'
}


module.exports = AccountingtoolpropertiesSchema