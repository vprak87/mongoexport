'use strict';
let AccountingtoolemailogsSchema = {
    _id: '_id',
    ID: 'Id',
    TransID: 'TransID',
    UpdatedDateTime: 'UpdatedDateTime',
    Category: 'Category'
}


module.exports = AccountingtoolemailogsSchema