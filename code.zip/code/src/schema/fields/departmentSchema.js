'use strict';
let DepartmentSchema = {
    _id: '_id',
    ID: 'Id',
    Name: 'Name',
    OrganizationID: 'OrganizationID',
    UpdateDateTime: 'UpdateDateTime',
    UpdatedBy: 'UpdatedBy',
    IsActive: 'IsActive',
    DepartmentCode: 'DepartmentCode'
}


module.exports = DepartmentSchema