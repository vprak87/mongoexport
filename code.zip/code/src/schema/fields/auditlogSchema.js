'use strict';
let AuditlogSchema = {
    _id: '_id',
    AuditId: 'AuditId',
    IPAddress: 'IPAddress',
    UserName: 'UserName',
    URLAccessed: 'URLAccessed',
    TimeAccessed: 'TimeAccessed',
    PostedData: 'PostedData'
}


module.exports = AuditlogSchema