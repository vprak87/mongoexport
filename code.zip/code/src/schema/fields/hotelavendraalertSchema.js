'use strict';
let HotelavendraalertSchema = {
    _id: '_id',
    AlertID: 'AlertID',
    ClientId: 'ClientId',
    CustomerId: 'CustomerId',
    ContactId: 'ContactId',
    TopicCode: 'TopicCode',
    SubtopicCode: 'SubtopicCode',
    RankValue: 'RankValue',
    Attribute1: 'Attribute1',
    Attribute2: 'Attribute2',
    Attribute3: 'Attribute3',
    Attribute4: 'Attribute4',
    Attribute5: 'Attribute5',
    CreatedOn: 'CreatedOn',
    CreatedBy: 'CreatedBy',
    UpdatedOn: 'UpdatedOn',
    UpdatedBy: 'UpdatedBy',
    HotelID: 'hotelID',
    Alert_Number: 'Alert_Number'



}


module.exports = HotelavendraalertSchema