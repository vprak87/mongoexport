'use strict';
let HotelavendraalertgroupSchema = {
    _id: '_id',
    AvendraAlertGroupId: 'AvendraAlertGroupId',
    AvendraAlertGroupName: 'AvendraAlertGroupName'



}


module.exports = HotelavendraalertgroupSchema