'use strict';
let AccountingtoolmasterSchema = {
    _id: '_id',
    ID: 'Id',
    AccountingTool: 'AccountingTool'
}


module.exports = AccountingtoolmasterSchema