'use strict';
let BoardcastmessagelogSchema = {
    _id: '_id',
    BoardcastMessageLogID: 'BoardcastMessageLogID',
    BoardcastMessageID: 'BoardcastMessageID',
    UserID: 'UserID',
    UpdatedDateTime: 'UpdatedDateTime',
    UpdatedBy: 'UpdatedBy'
}


module.exports = BoardcastmessagelogSchema