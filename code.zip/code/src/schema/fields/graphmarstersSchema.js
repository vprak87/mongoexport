'use strict';
let GraphmastersSchema = {
    _id: '_id',
    Name: 'Name'

}


module.exports = GraphmastersSchema