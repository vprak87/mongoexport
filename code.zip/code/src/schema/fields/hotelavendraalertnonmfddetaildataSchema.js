'use strict';
let HotelavendraalertnonmfddetaildataSchema = {
    _id: '_id',
    AvendraAlertNonMFDDetailDataId: 'AvendraAlertNonMFDDetailDataId',
    AvendraAlertInsightid: 'AvendraAlertInsightid',
    ERM_Parent: 'ERM_Parent',
    CUST_ID: 'CUST_ID',
    BP_CATEGORY_NM: 'BP_CATEGORY_NM',
    BP_DIST_CATEGORY: 'BP_DIST_CATEGORY',
    DIST_NM: 'DIST_NM',
    SPEND: 'SPEND'



}


module.exports = HotelavendraalertnonmfddetaildataSchema