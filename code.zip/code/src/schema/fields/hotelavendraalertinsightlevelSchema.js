'use strict';
let HotelavendraalertinsightlevelSchema = {
    _id: '_id',
    AvendraAlertInsightLevelId: 'AvendraAlertInsightLevelId',
    AvendraAlertInsightLevelName: 'AvendraAlertInsightLevelName'



}


module.exports = HotelavendraalertinsightlevelSchema