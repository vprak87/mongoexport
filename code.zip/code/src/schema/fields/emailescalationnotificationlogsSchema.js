'use strict';
let EmailescalationnotificationlogsSchema = {
    _id: '_id',
    ID: 'ID',
    ReportDate: 'ReportDate',
    UserID: 'UserID',
    EmailSent: 'EmailSent',
    InsertedDateTime: 'InsertedDateTime',
    InsertedBy: 'InsertedBy',
    UpdatedDateTime: 'UpdatedDateTime',
    UpdatedBy: 'UpdatedBy'
}


module.exports = EmailescalationnotificationlogsSchema