'use strict';
let EmailescalationconfigurationSchema = {
    _id: '_id',
    ID: 'ID',
    HotelID: 'HotelID',
    UserID: 'UserID',
    Type: 'Type',
    UpdatedBy: 'UpdatedBy',
    UpdatedDateTime: 'UpdatedDateTime',
    ScheduleTime: 'ScheduleTime',
    TimeZone: 'TimeZone'
}


module.exports = EmailescalationconfigurationSchema