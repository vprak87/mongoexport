'use strict';
let HotelavendraalertinsighttypeSchema = {
    _id: '_id',
    AvendraAlertInsightTypeId: 'AvendraAlertInsightTypeId',
    AvendraAlertInsightType: 'AvendraAlertInsightType'



}


module.exports = HotelavendraalertinsighttypeSchema