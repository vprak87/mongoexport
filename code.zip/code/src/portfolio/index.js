const express = require('express');
const router = express.Router(),
    Controller = require('./controller/portfolio');


router.get("/portfoliodata", Controller.PortfolioData)
router.get("/dashboardmonthwise", Controller.DashboardMonthwise)
router.get("/dashboarddaywise", Controller.DashboardDaywise)

router.post("/createkpigroup", Controller.CreateKPIGroup);
router.post("/editkpigroup", Controller.EditKPIGroup);


router.get("/kpimasterlist", Controller.KPIMasterList)
router.post("/addkpicolumns", Controller.AddKPIColumns);
router.post("/removekpicolumn", Controller.RemoveKPIColumn);

module.exports = router