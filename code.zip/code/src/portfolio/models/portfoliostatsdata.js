const Utils = require('../../common/utils');
const Constants = require('../../common/constants');

class Portfoliostatsdata {

    constructor(options) {

        // Default values
        const defaults = {
            kpikey: '',
            displayname: '',
            actualvalue: 0,
            actualunit: '',
            variancelevel: '',
            tooltip: ''
        };

        let opts = Object.assign({}, defaults, options);

        // assign options to instance data (using only property names contained
        //  in defaults object to avoid copying properties we don't want)
        Object.keys(defaults).forEach(prop => {
            this[prop] = opts[prop];
        });
    }

    setFormat(data) {
        const defaultzero = 0;
        const defaultna = 'NA';
        const defaultna2 = 'N/A';

        if (this.actualunit == Constants.Units.Percentage) {
            if (this.actualvalue == defaultna || this.actualvalue == defaultna2) {
            }
            else {
                this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.NoComma2Decimal);
            }
        }
        if (this.actualunit == Constants.Units.DecimalNumber) {
            if (this.actualvalue == defaultna || this.actualvalue == defaultna2) {
            }
            else {
                this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.NoComma2Decimal);
            }
        }
        else if (this.actualunit == Constants.Units.Number) {
            if (this.actualvalue == defaultna || this.actualvalue == defaultna2) {
            }
            else {
                this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(0) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.NoComma0Decimal);
            }
        }
        else if (this.actualunit == Constants.Units.Text) {
            this.actualvalue = data.actualvalue == null ? '' : data.actualvalue;
        }
        else {
            if (this.actualvalue == defaultna || this.actualvalue == defaultna2) {
            }
            else {
                this.actualvalue = data.actualvalue == null ? defaultzero.toFixed(2) : Utils.formatValue(data.actualvalue, Constants.NumeralFormats.Comma2Decimal);
            }
        }
        return this;
    }

}
module.exports = Portfoliostatsdata

