
const Checkit = require('checkit');
const HttpMsg = require('../../common/constants');
const Response = require('../../common/response');
const UserHelper = require('../../helpers/user_helper');
const PortfolioHelper = require('../../helpers/portfolio_helper');
const CreateowntablemappingsgroupHelper = require('../../helpers/createowntablemappingsgroup_helper');


var log = require('log4js').getLogger("portfolio");

let PortfolioDataFn = (req, res, next) => {


    var checkit = new Checkit({
        userid: 'required',
        reportdate: 'required',
        period: 'required',
        id: 'required',
        enddate: 'string',
    });


    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }


    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        PortfolioHelper.getPortfolioData(data.userid, data.reportdate, data.period, data.id, data.enddate, userconfigdata, (err, result) => {
            if (err) {
                return next(err);
            }

            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        });
    });

}

let DashboardMonthwiseFn = (req, res, next) => {


    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'int',
        year: 'required'
    });


    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }


    UserHelper.getUserData(data.userid, (err, userinfo) => {
        if (err) {
            return next(err);
        }
        PortfolioHelper.getDashboardMonthwise(userinfo, data.hotelid, data.year, (err, result) => {
            if (err) {
                return next(err);
            }

            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        });
    });

}

let DashboardDaywiseFn = (req, res, next) => {


    var checkit = new Checkit({
        userid: 'required',
        hotelid: 'int',
        month: 'required',
        year: 'required'
    });


    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }


    UserHelper.getUserData(data.userid, (err, userinfo) => {
        if (err) {
            return next(err);
        }
        PortfolioHelper.getDashboardDaywise(userinfo, data.hotelid, data.month, data.year, (err, result) => {
            if (err) {
                return next(err);
            }

            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        });
    });

}




let EditKPIGroupFn = (req, res, next) => {

    var checkit = new Checkit({
        groupid: 'required',
        name: 'required',
        color: 'required',
        userid: 'required',
        kpilist: [],
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    CreateowntablemappingsgroupHelper.editGroup(data, (err, result) => {
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recordedAdded).setResultData(result).build();
        res.status(200)
        res.send(response);
    });
}


let CreateKPIGroupFn = (req, res, next) => {

    var checkit = new Checkit({
        name: 'required',
        color: 'required',
        userid: 'required',
        kpilist: [],
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    CreateowntablemappingsgroupHelper.createGroup(data, (err, result) => {
        if (err) {
            return next(err);
        }
        let response = new Response(true, 200).setMessage(HttpMsg.recordedAdded).setResultData(result).build();
        res.status(200)
        res.send(response);
    });
}

let AddKPIColumnsFn = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
        kpilist: [],
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        PortfolioHelper.addKPIColumns(data.userid, data.kpilist, userconfigdata, (err, result) => {
            if (err) {
                return next(err);
            }
            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        });
    });


}

let RemoveKPIColumnFn = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
        kpikey: 'required',
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        PortfolioHelper.removeKPIColumns(data.userid, data.kpikey, userconfigdata, (err, result) => {
            if (err) {
                return next(err);
            }
            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        });
    });


}



let KPIMasterListFn = (req, res, next) => {

    var checkit = new Checkit({
        userid: 'required',
        type: 'required'
    });

    var [err, data] = checkit.validateSync(req.body);
    if (err) {
        log.error(err.toJSON());
        return res.status(400).send(err.toJSON());
    }

    UserHelper.getUserConfigData(data.userid, (err, userconfigdata) => {
        if (err) {
            return next(err);
        }
        PortfolioHelper.getKPIMasterListData(data.userid, data.type, userconfigdata, (err, result) => {
            if (err) {
                return next(err);
            }

            let response = new Response(true, 200).setMessage(HttpMsg.recoredFound).setResultData(result).build();
            res.status(200).send(response);
        });
    });

}




module.exports = {
    PortfolioData: PortfolioDataFn,
    DashboardMonthwise: DashboardMonthwiseFn,
    DashboardDaywise: DashboardDaywiseFn,
    CreateKPIGroup: CreateKPIGroupFn,
    EditKPIGroup: EditKPIGroupFn,
    KPIMasterList: KPIMasterListFn,
    AddKPIColumns: AddKPIColumnsFn,
    RemoveKPIColumn: RemoveKPIColumnFn
}
