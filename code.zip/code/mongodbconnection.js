const mongoose = require('mongoose');

var mongoDBConnectionString = function mongoDbConnection(host, port, dbname, successCallBack, failCallBack) {

    // MongoDB Connection 
	mongoose.connect(`mongodb+srv://${host}/${dbname}`,{ useNewUrlParser: true,useUnifiedTopology: true,useCreateIndex:true})
    mongoose.set('useFindAndModify', false);

    const db = mongoose.connection;

    db.on('error', err => {
        console.error(`Error while connecting to DB: ${err.message}`);
        setTimeout(() => {
            if (failCallBack)
            failCallBack(err.message)
          }, 1000);
    });
    db.on('connected', () => {
        console.log('DB connected successfully!');
        if (successCallBack)
            successCallBack('DB connected successfully!')
    });

}

module.exports = mongoDBConnectionString

