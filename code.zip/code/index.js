var express = require('express');
const graphqlHTTP = require('express-graphql');
var errorHandler = require('express-errorhandler');
var app = express();
var mongoDBConnection = require('./mongodbconnection');
const src = require('./src');
const cors = require('cors');
var config = require('./appsettings.js');
var log4js = require('log4js');
var axios = require('axios');
// const schema = require('./schema.js');
const schema = require('./src/graphQLSchema');

//include Auth0 middleware
const authMiddleware = require('./src/middleware/userAuth');

log4js.configure('./log4js.json');
//We won't need this.
//var logger = require('morgan');
var log = log4js.getLogger("app");

const Response = require('./src/common/response.js'),
    bodyParser = require('body-parser')
urlencodedParser = bodyParser.urlencoded({ extended: true }),
    jsonParser = bodyParser.json(),
    server = require('http').createServer(app),
    compression = require('compression');

validation = require('./src/authentication/controller/validation');

mongoDBConnection(config.db.host, config.db.port, config.db.database);

axios.defaults.baseURL = config.appsettings.myp1_apibaseurl;
axios.defaults.headers.common['Token'] = config.appsettings.myp1_apitoken;

app.use(compression())
app.use(cors());

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,PATCH,OPTIONS');
    next();
  });
// replace this with the log4js connect-logger
//app.use(morgan('[:date[clf]] :method :url :status :res[content-length] - :response-time ms :user-agent'));

app.use(log4js.connectLogger(log4js.getLogger("http"), { level: 'auto' }));


app.use(urlencodedParser)
app.use(jsonParser)

//use auth0 middleware
app.use(authMiddleware)


var requestTime = function (req, res, next) {
    req.requestTime = Date.now()
    next()
}

app.use(requestTime);

app.use('/api', src);


app.use('/graphql', graphqlHTTP((request, response, graphQLParams) => ({
    schema: schema,
    graphiql: true,
    context: {
        user: request.user
    }
})))

app.use(errorHandler({
    includeStackTrace: true,

}))

const port = process.env.port || 3033;

server.listen(port, () => {
    console.log(`Web server listening on: ${port}`);
});