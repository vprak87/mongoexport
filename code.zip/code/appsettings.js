module.exports = {
    db: {
        host: 'remote_dev:8Z0gPBVWz2iz8yjh@myp-zjri4.mongodb.net',
        database: 'perspective_10_08_2020',
        // database: 'Perspective',
        port: 27017
    },
    jwt: {
        secret: 'xA9bSZE6M9',
        expiresIn: 31550000 // 1 year
    },
    appsettings:
    {
         myp1_apibaseurl: 'https://myperspective.io/API',
        //myp1_apibaseurl: 'http://localhost:61485',
        myp1_apitoken: 'aa5a9b68-1c79-4e3e-9310-21dcb7b49e8b',
        sync_to_SQLServer: true,
        myp1_redirecturl: 'https://www.myperspective.io/MYP2/Index',//'http://localhost:23922/MYP2/Index',
    }
};